package kr.mzs.gunbedvisual.mixin;

import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 2026-11-27 (rev12): a zombie this player hit within 3 s is drawn with the vanilla red hurt overlay (no outline pass). */
@Mixin(LivingEntityRenderer.class)
public abstract class GunbedHitTintMixin {
    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V", at = @At("TAIL"), require = 0)
    private void gunbed$hitTint(LivingEntity entity, LivingEntityRenderState state, float partialTick, CallbackInfo ci) {
        if (kr.mzs.gunbedvisual.HudState.INSTANCE.hitTinted(entity.getUUID())) state.hasRedOverlay = true;
    }
}
