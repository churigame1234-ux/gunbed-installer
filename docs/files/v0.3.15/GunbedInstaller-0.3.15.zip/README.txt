Gunbed Installer 0.3.15 / adapters 0.3.15 / shared assets 0.3.15
Fix: transparent viewing apertures for five optics including QR-24 APM4s.
Run installer, select version and your existing game folder. Other mods, settings and worlds are preserved.
No new gun pack added.
