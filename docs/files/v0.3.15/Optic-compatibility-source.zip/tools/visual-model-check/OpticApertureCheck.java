import com.google.gson.*;
import kr.mzs.gunbedvisual.model.*;
import org.joml.*;
import java.lang.Math;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import javax.imageio.ImageIO;

public final class OpticApertureCheck {
 static Object field(Object o,String n)throws Exception{var f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
 static float[] hit(GunMesh.Vertex a,GunMesh.Vertex b,GunMesh.Vertex c,Vector3f from){Vector3f av=new Vector3f(a.x(),a.y(),a.z()),e1=new Vector3f(b.x(),b.y(),b.z()).sub(av),e2=new Vector3f(c.x(),c.y(),c.z()).sub(av),p=new Vector3f(0,0,-1).cross(e2),t=new Vector3f(from).sub(av);float det=e1.dot(p);if(Math.abs(det)<1e-7)return null;float u=t.dot(p)/det;if(u<0||u>1)return null;Vector3f q=t.cross(e1,new Vector3f());float v=new Vector3f(0,0,-1).dot(q)/det;if(v<0||u+v>1||e2.dot(q)/det<0)return null;return new float[]{a.u()*(1-u-v)+b.u()*u+c.u()*v,a.v()*(1-u-v)+b.v()*u+c.v()*v};}
 public static void main(String[] args)throws Exception{Path root=Path.of(args[0]);JsonObject presets=JsonParser.parseString(Files.readString(root.resolve("assets/gunbed/default_optics.json"))).getAsJsonObject();Set<String> seen=new HashSet<>();List<Object> rows=new ArrayList<>();
  for(var preset:presets.entrySet()){JsonObject d=preset.getValue().getAsJsonObject();String id=d.get("id").getAsString();if(!seen.add(id))continue;var geo=JsonParser.parseString(Files.readString(root.resolve(d.get("model").getAsString()))).getAsJsonObject();JsonObject anim=new JsonObject();anim.add("animations",new JsonObject());var mesh=new GunMesh(geo,anim,true);var pm=GunMesh.class.getDeclaredMethod("pose",String.class,double.class);pm.setAccessible(true);var hm=GunMesh.class.getDeclaredMethod("hidden",String.class,String.class);hm.setAccessible(true);var poses=(Map<String,Matrix4f>)pm.invoke(mesh,null,0d);Matrix4f view=new Matrix4f().rotationZ((float)Math.PI);Vector3f center=new Matrix4f(view).mul(poses.get("scope_view")).transformPosition(new Vector3f());Vector3f origin=new Vector3f(center.x,center.y,100);String[] texture=d.get("texture").getAsString().split(":",2);var image=ImageIO.read(root.resolve("assets/"+texture[0]+"/"+texture[1]).toFile());List<String> blockers=new ArrayList<>();
   for(var entry:((Map<String,?>)field(mesh,"bones")).entrySet()){String name=entry.getKey();if((boolean)hm.invoke(mesh,name,null))continue;int index=0;for(Object cube:(List<?>)field(entry.getValue(),"cubes")){var vertices=new ArrayList<GunMesh.Vertex>();Matrix4f world=new Matrix4f(view).mul(poses.get(name)).mul((Matrix4f)field(cube,"transform"));((BedrockCube)field(cube,"geometry")).compile(new MeshPose(world),(x,y,z,color,u,v,overlay,light,nx,ny,nz)->vertices.add(new GunMesh.Vertex(x,y,z,u,v,nx,ny,nz)),0,0,1,1,1,1);boolean blocked=false;for(int n=0;n<vertices.size();n+=4)for(int[] tri:new int[][]{{0,1,2},{0,2,3}}){float[] uv=hit(vertices.get(n+tri[0]),vertices.get(n+tri[1]),vertices.get(n+tri[2]),origin);if(uv==null)continue;int x=Math.min(image.getWidth()-1,Math.max(0,(int)(uv[0]*image.getWidth()))),y=Math.min(image.getHeight()-1,Math.max(0,(int)(uv[1]*image.getHeight())));if((image.getRGB(x,y)>>>24)>25)blocked=true;}if(blocked)blockers.add(name+":"+index);index++;}}
   rows.add(Map.of("id",id,"center",List.of(center.x,center.y,center.z),"blockers",blockers));}
  System.out.println(new Gson().toJson(rows));
 }
}
