import com.google.gson.*;
import kr.mzs.gunbedvisual.model.GunMesh;
import org.joml.*;
import java.lang.Math;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

/** Bake a clear optical bore into the existing asset format; no runtime shader required. */
public final class OpticClearanceBake {
    static GunMesh.Vertex mix(GunMesh.Vertex a,GunMesh.Vertex b,float t){return new GunMesh.Vertex(a.x()+(b.x()-a.x())*t,a.y()+(b.y()-a.y())*t,a.z()+(b.z()-a.z())*t,a.u()+(b.u()-a.u())*t,a.v()+(b.v()-a.v())*t,a.nx()+(b.nx()-a.nx())*t,a.ny()+(b.ny()-a.ny())*t,a.nz()+(b.nz()-a.nz())*t);}
    static List<GunMesh.Vertex> half(List<GunMesh.Vertex> p,float nx,float ny,float c,boolean inside){
        List<GunMesh.Vertex> out=new ArrayList<>();if(p.isEmpty())return out;
        GunMesh.Vertex a=p.get(p.size()-1);float da=nx*a.x()+ny*a.y()-c;
        for(var b:p){float db=nx*b.x()+ny*b.y()-c;boolean ia=inside?da<=0:da>=0,ib=inside?db<=0:db>=0;if(ia!=ib)out.add(mix(a,b,da/(da-db)));if(ib)out.add(b);a=b;da=db;}return out;
    }
    static void triangles(List<GunMesh.Vertex> out,List<GunMesh.Vertex> p){for(int i=1;i+1<p.size();i++){var a=p.get(0);var b=p.get(i);var c=p.get(i+1);if(new Vector3f(b.x()-a.x(),b.y()-a.y(),b.z()-a.z()).cross(new Vector3f(c.x()-a.x(),c.y()-a.y(),c.z()-a.z())).lengthSquared()<1e-17)continue;out.add(a);out.add(b);out.add(c);out.add(c);}}
    static List<GunMesh.Vertex> bore(List<GunMesh.Vertex> vertices,Vector3f center,float radius){
        List<GunMesh.Vertex> out=new ArrayList<>();
        for(int q=0;q<vertices.size();q+=4)for(int[] tri:new int[][]{{0,1,2},{0,2,3}}){List<GunMesh.Vertex> rest=new ArrayList<>(List.of(vertices.get(q+tri[0]),vertices.get(q+tri[1]),vertices.get(q+tri[2])));for(int side=0;side<12&&!rest.isEmpty();side++){double angle=side*Math.PI/6;float x=(float)Math.cos(angle),y=(float)Math.sin(angle),c=x*center.x+y*center.y+radius;triangles(out,half(rest,x,y,c,false));rest=half(rest,x,y,c,true);}}return out;
    }
    static JsonObject baked(List<GunMesh.Vertex> vertices){
        JsonObject s=new JsonObject();s.add("viewOffset",new Gson().toJsonTree(new float[]{0,0,0}));s.addProperty("leftArm",0);s.addProperty("rightArm",0);s.addProperty("muzzle",0);s.addProperty("proceduralArms",false);s.addProperty("nativeArms",false);
        JsonArray v=new JsonArray(),indices=new JsonArray();for(int q=0;q<vertices.size();q+=4)for(int k=0;k<3;k++){var p=vertices.get(q+k);indices.add(v.size());v.add(new Gson().toJsonTree(new float[]{-24*p.z(),-24*p.x(),24*p.y(),-p.nz(),-p.nx(),p.ny(),p.u(),p.v(),0}));}s.add("vertices",v);
        JsonObject part=new JsonObject();part.addProperty("texture","$optic");part.add("indices",indices);JsonArray parts=new JsonArray();parts.add(part);s.add("parts",parts);
        JsonArray identity=new Gson().toJsonTree(new int[]{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1}).getAsJsonArray(),bones=new JsonArray(),frames=new JsonArray();bones.add(identity);frames.add(bones);frames.add(bones.deepCopy());JsonObject clip=new JsonObject();clip.addProperty("fps",1);clip.add("frames",frames);JsonObject clips=new JsonObject();clips.add("idle1",clip);s.add("clips",clips);s.add("aliases",new JsonObject());return s;
    }
    public static void main(String[] args)throws Exception{
        Path resources=Path.of(args[0]),backup=Path.of(args[1]);Files.createDirectories(backup);JsonObject presets=JsonParser.parseString(Files.readString(resources.resolve("assets/gunbed/default_optics.json"))).getAsJsonObject();Set<String> seen=new HashSet<>();List<Object> report=new ArrayList<>();Map<String,Float> radii=Map.of("scope_pso_1",.039f,"scope_mk4ert",.046f,"scope_c79",.054f,"scope_1866_4x",.032f,"sight_apm4s",.043f);
        for(var entry:presets.entrySet()){JsonObject preset=entry.getValue().getAsJsonObject();String id=preset.get("id").getAsString();if(!seen.add(id))continue;Path file=resources.resolve(preset.get("model").getAsString());String original=Files.readString(file);JsonObject data=JsonParser.parseString(original).getAsJsonObject();data.remove("gunbed:source_mesh");JsonObject anim=JsonParser.parseString("{\"animations\":{}}").getAsJsonObject();GunMesh mesh=new GunMesh(data,anim,true);var pose=GunMesh.class.getDeclaredMethod("pose",String.class,double.class);pose.setAccessible(true);var poses=(Map<String,Matrix4f>)pose.invoke(mesh,null,0d);Vector3f center=new Matrix4f().rotationZ((float)Math.PI).mul(poses.get("scope_view")).transformPosition(new Vector3f());List<GunMesh.Vertex> before=mesh.frame(null,0,0).vertices();float radius=radii.getOrDefault(id,.04f);List<GunMesh.Vertex> after=before;
            if(radii.containsKey(id)){Path saved=backup.resolve(file.getFileName());if(!Files.exists(saved))Files.writeString(saved,original);after=bore(before,center,radius);data.add("gunbed:source_mesh",baked(after));data.add("gunbed:clear_aperture",new Gson().toJsonTree(Map.of("center",List.of(center.x,center.y,center.z),"radius",radius,"sides",12)));Files.writeString(file,new GsonBuilder().setPrettyPrinting().create().toJson(data)+"\n");GunMesh reloaded=new GunMesh(data,anim,true);var actual=reloaded.frame(null,0,0).vertices();if(actual.size()!=after.size())throw new IllegalStateException("Vertex count drift "+id);for(int i=0;i<actual.size();i++){var a=actual.get(i);var b=after.get(i);if(Math.abs(a.x()-b.x())+Math.abs(a.y()-b.y())+Math.abs(a.z()-b.z())>1e-5)throw new IllegalStateException("Coordinate drift "+id);}}
            Map<String,Object> row=new LinkedHashMap<>();row.put("id",id);row.put("texture",preset.get("texture").getAsString());row.put("center",List.of(center.x,center.y,center.z));row.put("radius",radius);row.put("changed",radii.containsKey(id));row.put("before",before);row.put("after",after);report.add(row);
        }
        Files.writeString(backup.resolve("mesh-preview.json"),new Gson().toJson(report));System.out.println(new Gson().toJson(report.stream().map(r->((Map<?,?>)r).entrySet().stream().filter(e->!List.of("before","after").contains(e.getKey())).collect(java.util.stream.Collectors.toMap(e->e.getKey().toString(),Map.Entry::getValue))).toList()));
    }
}
