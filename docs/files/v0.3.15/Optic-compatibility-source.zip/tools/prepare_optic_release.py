"""Asset-only optical fix, preserving the verified nine 0.3.13 adapters."""
import json,shutil,zipfile
from server_audit import ROOT,dump,sha256

VERSION='0.3.15';meta=ROOT/f'.local/installer-online-v{VERSION}';assets=ROOT/f'.local/publication-assets-v{VERSION}';public=ROOT/f'distribution/docs/files/v{VERSION}'
for p in (assets,public):p.mkdir(parents=True,exist_ok=True)
shutil.copytree(ROOT/'.local/installer-online-v0.3.14',meta,dirs_exist_ok=True)
jar=ROOT/f'client/build/shared/libs/GunbedAssets-{VERSION}.jar';assert jar.exists()
with zipfile.ZipFile(jar) as z:
    assert json.loads(z.read('fabric.mod.json'))['version']==VERSION
    for id in ('sight_apm4s','scope_pso_1','scope_mk4ert','scope_c79','scope_1866_4x'):
        assert 'gunbed:source_mesh' in json.loads(z.read(f'assets/tacz/geo_models/attachment/{id}_geo.json'))
for p in (assets,public):shutil.copy2(jar,p/jar.name)
release=json.loads((meta/'online.json').read_text());manifest=json.loads((meta/'manifest.json').read_text())
old_base=release['asset_base'];new_base=old_base.rsplit('/',1)[0]+'/v'+VERSION
release.update(tag='v'+VERSION,asset_base=new_base,asset_bases=[new_base,old_base],client_version=VERSION,shared_assets_version=VERSION)
for v,data in manifest['versions'].items():
    adapter=next(e for e in data['mods'] if e['file'].startswith('GunbedVisuals-'))
    original=ROOT/'.local/publication-assets-v0.3.13'/adapter['file'];updated=assets/f'GunbedVisuals-{v}-{VERSION}.jar'
    with zipfile.ZipFile(original) as src,zipfile.ZipFile(updated,'w',zipfile.ZIP_DEFLATED) as out:
        metadata=json.loads(src.read('fabric.mod.json'));metadata['version']=VERSION;metadata['depends']['gunbed_assets']='>=0.3.15 <0.4.0'
        for entry in src.infolist():out.writestr(entry,json.dumps(metadata,ensure_ascii=False,indent=2).encode() if entry.filename=='fabric.mod.json' else src.read(entry.filename))
    with zipfile.ZipFile(original) as src,zipfile.ZipFile(updated) as out:
        assert all(src.read(n)==out.read(n) for n in src.namelist() if n!='fabric.mod.json'),'Only dependency metadata may change'
    target=ROOT/f'client/build/{v}/libs'/updated.name;shutil.copy2(updated,target);shutil.copy2(updated,public/updated.name)
    dump(ROOT/f'client/.generated/{v}/resources/fabric.mod.json',metadata)
    release['mirrors'].pop(adapter['sha256'],None);adapter.update(file=updated.name,path=v+'/mods/'+updated.name,url=new_base+'/'+updated.name,sha256=sha256(updated),size=updated.stat().st_size)
    release['mirrors'][sha256(updated)]=['https://churigame1234-ux.github.io/gunbed-installer/files/v'+VERSION+'/'+updated.name,'https://raw.githubusercontent.com/churigame1234-ux/gunbed-installer/main/docs/files/v'+VERSION+'/'+updated.name]
    matches=[e for e in data['mods'] if e['file'].startswith('GunbedAssets-')];assert len(matches)==1;e=matches[0];old_hash=e['sha256']
    e.update(file=jar.name,path='mods/'+jar.name,url=new_base+'/'+jar.name,sha256=sha256(jar),size=jar.stat().st_size)
    release['mirrors'].pop(old_hash,None)
release['mirrors'][sha256(jar)]=['https://churigame1234-ux.github.io/gunbed-installer/files/v'+VERSION+'/'+jar.name,'https://raw.githubusercontent.com/churigame1234-ux/gunbed-installer/main/docs/files/v'+VERSION+'/'+jar.name]
source=assets/'Optic-compatibility-source.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
    for name in ('tools/visual-model-check/OpticClearanceBake.java','tools/visual-model-check/OpticApertureCheck.java','tools/check_optic_clearance.py','tools/prepare_optic_release.py','tools/generate_visual_adapter.py','client/build.gradle','client/THIRD-PARTY.md'):
        z.write(ROOT/name,name)
    for f in (ROOT/'client/src/main/resources/assets/tacz/geo_models/attachment').glob('*_geo.json'):z.write(f,'assets/tacz/geo_models/attachment/'+f.name)
    z.writestr('README.txt','Gunbed shared assets 0.3.15: derived optical clearance meshes; existing client code remains 0.3.13. Original Bedrock geometry retained in each JSON. Use OpticClearanceBake with the source from GunbedVisuals-source.zip.\n')
shutil.copy2(source,public/source.name)
release['sources'][source.name]={'url':new_base+'/'+source.name,'sha256':sha256(source),'size':source.stat().st_size,'mirrors':['https://churigame1234-ux.github.io/gunbed-installer/files/v'+VERSION+'/'+source.name,'https://raw.githubusercontent.com/churigame1234-ux/gunbed-installer/main/docs/files/v'+VERSION+'/'+source.name]}
shutil.copy2(ROOT/'client/THIRD-PARTY.md',meta/'THIRD-PARTY.md');dump(meta/'manifest.json',manifest);dump(meta/'online.json',release)
print(json.dumps({'success':True,'asset_sha256':sha256(jar),'asset_bytes':jar.stat().st_size,'versions':len(manifest['versions'])}))
