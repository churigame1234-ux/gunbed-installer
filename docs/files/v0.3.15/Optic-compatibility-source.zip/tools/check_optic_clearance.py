"""Render the actual pre/post optic meshes and check that their optical axes are open."""
import json,math
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from server_audit import ROOT,dump

rows=json.loads((ROOT/'.local/optic-clearance-v15/mesh-preview.json').read_text())
size=256
sheet=Image.new('RGB',(size*2,size*len(rows)),(25,29,35));draw=ImageDraw.Draw(sheet)
report=[]
for row_index,row in enumerate(rows):
    ns,path=row['texture'].split(':',1);texture=np.array(Image.open(ROOT/'client/src/main/resources/assets'/ns/path).convert('RGBA'))
    cx,cy,_=row['center'];radius=row['radius'];extent=radius*2.5;scale=size/(2*extent)
    masks=[]
    for column,phase in enumerate(('before','after')):
        pixels=np.zeros((size,size,4),dtype=np.uint8);depth=np.full((size,size),-np.inf)
        vertices=row[phase]
        for q in range(0,len(vertices),4):
            for tri in ((0,1,2),(0,2,3)):
                v=[vertices[q+i] for i in tri];p=np.array([[(a['x']-cx)*scale+size/2,-(a['y']-cy)*scale+size/2,a['z']] for a in v]);a,b,c=p
                den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
                if abs(den)<1e-10:continue
                x0=max(0,int(p[:,0].min()));x1=min(size,int(p[:,0].max())+1);y0=max(0,int(p[:,1].min()));y1=min(size,int(p[:,1].max())+1)
                if x0>=x1 or y0>=y1:continue
                y,x=np.mgrid[y0:y1,x0:x1];x=x+.5;y=y+.5
                w0=((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(y-c[1]))/den;w1=((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(y-c[1]))/den;w2=1-w0-w1
                z=w0*a[2]+w1*b[2]+w2*c[2];uv=[w0*v[0][k]+w1*v[1][k]+w2*v[2][k] for k in ('u','v')]
                tx=np.clip((uv[0]*texture.shape[1]).astype(int),0,texture.shape[1]-1);ty=np.clip((uv[1]*texture.shape[0]).astype(int),0,texture.shape[0]-1);col=texture[ty,tx]
                mask=(w0>=-1e-7)&(w1>=-1e-7)&(w2>=-1e-7)&(col[:,:,3]>25)&(z>depth[y0:y1,x0:x1])
                pixels[y0:y1,x0:x1][mask]=col[mask];depth[y0:y1,x0:x1][mask]=z[mask]
        masks.append(pixels[:,:,3]>25)
        bg=Image.new('RGBA',(size,size),(130,177,190,255));d=ImageDraw.Draw(bg);d.rectangle((0,143,size,size),fill=(100,132,70));d.rectangle((108,95,148,155),fill=(215,95,65));d.line((128,70,128,180),fill='white');d.line((83,125,173,125),fill='white');bg.alpha_composite(Image.fromarray(pixels));sheet.paste(bg.convert('RGB'),(column*size,row_index*size));draw.text((column*size+7,row_index*size+6),row['id']+' '+phase,fill='white',stroke_width=1,stroke_fill='black')
    y,x=np.mgrid[:size,:size];inner=(x+.5-size/2)**2+(y+.5-size/2)**2<(radius*scale*.8)**2
    blocked=[int((m&inner).sum()) for m in masks]
    if row['changed']:assert blocked[1]==0,(row['id'],blocked)
    report.append({'id':row['id'],'changed':row['changed'],'central_opaque_pixels_before':blocked[0],'central_opaque_pixels_after':blocked[1],'samples':int(inner.sum())})
target=ROOT/'reports/optic-clearance-preview.png';sheet.save(target)
dump(ROOT/'reports/optic-clearance-check.json',{'success':True,'optics':report,'preview':str(target),'note':'Actual textured mesh, orthographic optical-axis check; not an in-game screenshot.'})
print(json.dumps({'success':True,'optics':report}))
