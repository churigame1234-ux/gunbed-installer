Gunbed installer 0.3.20 / adapters 0.3.19 / shared assets 0.3.20
Textures are delivered by the Gunbed server resource pack. Accept the required pack after joining.
