Uses a separately installed, licensed ItemsAdder 4.0.16 JAR for its own pack protection. ItemsAdder code is not included. Adapter runtime code is unchanged from 0.3.19.
