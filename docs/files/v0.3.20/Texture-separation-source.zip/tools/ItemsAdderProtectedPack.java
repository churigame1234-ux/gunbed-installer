import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import java.io.*;
import java.lang.invoke.*;

/** Use the installed ItemsAdder's own protection; never distribute its classes. */
public final class ItemsAdderProtectedPack {
 public static void main(String[] args)throws Throwable {
  if(args.length!=3)throw new IllegalArgumentException("input.zip output.zip protection2");
  Path input=Path.of(args[0]).toRealPath(),output=Path.of(args[1]).toAbsolutePath();
  if(input.equals(output))throw new IllegalArgumentException("Keep the unprotected backup");
  Class<?> protection=Class.forName("itemsadder.m.ase");
  MethodHandle entryProtection=MethodHandles.publicLookup().findStatic(protection,"a",MethodType.methodType(void.class,ZipEntry.class));
  MethodHandle archiveProtection=MethodHandles.publicLookup().findStatic(protection,"u",MethodType.methodType(void.class,File.class));
  int count=0;
  try(ZipFile source=new ZipFile(input.toFile());ZipOutputStream dest=new ZipOutputStream(Files.newOutputStream(output))){
   dest.setLevel(9);
   for(ZipEntry item:Collections.list(source.entries())){
    if(item.isDirectory())continue;
    String name=item.getName();
    if(name.startsWith("/")||name.contains("\\")||Arrays.asList(name.split("/")).contains(".."))throw new IOException("Unsafe input path");
    ZipEntry target=new ZipEntry(name);dest.putNextEntry(target);
    try(InputStream stream=source.getInputStream(item)){stream.transferTo(dest);}
    dest.closeEntry();entryProtection.invokeExact(target);count++;
   }
  }
  if(Boolean.parseBoolean(args[2]))archiveProtection.invokeExact(output.toFile());
  // Minecraft uses ZipFile; validate bytes against the trusted source without extraction.
  try(ZipFile source=new ZipFile(input.toFile());ZipFile result=new ZipFile(output.toFile())){
   for(ZipEntry entry:Collections.list(source.entries())){
    if(entry.isDirectory())continue;
    try(InputStream a=source.getInputStream(entry);InputStream b=result.getInputStream(result.getEntry(entry.getName()))){
     if(!Arrays.equals(a.readAllBytes(),b.readAllBytes()))throw new IOException("Content changed: "+entry.getName());
    }
   }
  }
  System.out.println("Protected by installed ItemsAdder: entries="+count+" protection_1=true protection_2="+args[2]+"; Java content verification passed");
 }
}
