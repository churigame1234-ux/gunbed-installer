"""Move PNG resources out of the shared JAR and merge them into the existing pack."""
import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
from server_audit import ROOT,GUNBED,dump,sha256

V='0.3.20'
WORK=ROOT/'.local/texture-pack';WORK.mkdir(exist_ok=True)
ORIGINAL=ROOT/'.local/publication-assets-v0.3.17/GunbedAssets-0.3.17.jar'
LIVE=GUNBED/'plugins/ItemsAdder/output/generated.zip'
IA=ROOT/'.local/stage-retired/ItemsAdder-4.0.16-fps-runtime-error.jar'
JAVA=Path('C:/Program Files/Java/jdk-25.0.2/bin')

def prepare():
 with zipfile.ZipFile(ORIGINAL) as jar:
  textures={n:jar.read(n) for n in jar.namelist() if '/textures/' in n and not n.endswith('/')}
  # Vanilla eagerly bakes icon models before joining. Keep their definitions
  # beside the images, while custom geo_models/animations stay classpath-readable.
  icon_definitions={n:jar.read(n) for n in jar.namelist() if n.startswith('assets/') and not n.endswith('/') and ('/models/item/' in n or any('/'+kind+'/' in n for kind in ['items','equipment','particles']))}
  moved={**textures,**icon_definitions}
  assert len(textures)>=1900 and all(n.endswith(('.png','.png.mcmeta')) for n in textures)
  newjar=WORK/f'GunbedAssets-{V}.jar'
  with zipfile.ZipFile(newjar,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as dest:
   for n in jar.namelist():
    if n in moved or n.endswith('/'):continue
    data=jar.read(n)
    if n=='fabric.mod.json':
     metadata=json.loads(data);metadata['version']=V
     metadata['description']='Gunbed models, animations and sounds. Textures are delivered by the Gunbed server resource pack.'
     data=json.dumps(metadata,ensure_ascii=False,indent=2).encode()
    dest.writestr(n,data)
 with zipfile.ZipFile(newjar) as jar:
  assert not any('/textures/' in n for n in jar.namelist())
  def references(value):
   if isinstance(value,dict):return [p for v in value.values() for p in references(v)]
   if isinstance(value,list):return [p for v in value for p in references(v)]
   return [value] if isinstance(value,str) and value.startswith('assets/') and value.endswith('.json') else []
  for source in ['assets/tacz/gunbed_catalog.json','assets/gunbed/default_optics.json']:
   for dependency in references(json.loads(jar.read(source))):assert dependency in jar.namelist(),dependency
  with zipfile.ZipFile(ORIGINAL) as old:
   assert all(jar.read(n)==old.read(n) for n in jar.namelist() if n!='fabric.mod.json')
 baseline=WORK/('original-pack-'+sha256(LIVE)[:16]+'.zip')
 if not baseline.exists():shutil.copy2(LIVE,baseline)
 unprotected=WORK/'pack-unprotected.zip';overrides=[]
 # On later runs the live ZIP is intentionally not readable by ordinary ZIP
 # libraries. Reuse only the private source whose SHA belongs to that live pack.
 input_source=baseline
 try:
  with zipfile.ZipFile(input_source) as probe:probe.read('pack.mcmeta')
 except zipfile.BadZipFile:
  previous=json.loads((ROOT/'reports/texture-pack-preparation.json').read_text())
  assert previous['packSha256']==sha256(LIVE),'Unknown protected pack; use its authoritative private source'
  private=Path(previous['unprotected']);assert private.exists() and sha256(private)==previous['unprotectedSha256']
  cached=WORK/'previous-private-source.zip';shutil.copy2(private,cached);input_source=cached
 with zipfile.ZipFile(input_source) as old,zipfile.ZipFile(unprotected,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as dest:
  oldnames=set(old.namelist())
  for n in old.namelist():
   if n.endswith('/'):continue
   data=old.read(n)
   if n in textures:
    if data!=textures[n]:overrides.append(n)
    data=textures[n]
   dest.writestr(n,data)
  for n,data in moved.items():
   if n not in oldnames:dest.writestr(n,data)
  dest.writestr('GUNBED-TEXTURES-NOTICE.txt','Gunbed server-delivered textures. Original authors and licenses remain applicable. This pack uses ItemsAdder extraction deterrence, not encryption or guaranteed copy prevention.\n')
 with zipfile.ZipFile(input_source) as old,zipfile.ZipFile(unprotected) as new:
  assert new.testzip() is None
  assert all(new.read(n)==old.read(n) for n in old.namelist() if n not in textures and not n.endswith('/'))
  assert all(hashlib.sha256(new.read(n)).digest()==hashlib.sha256(data).digest() for n,data in textures.items())
 subprocess.run([str(JAVA/'javac.exe'),'-encoding','UTF-8','-d',str(WORK),str(ROOT/'tools/ItemsAdderProtectedPack.java')],check=True)
 protected=WORK/'pack-protected.zip'
 subprocess.run([str(JAVA/'java.exe'),'-cp',str(WORK)+';'+str(IA),'ItemsAdderProtectedPack',str(unprotected),str(protected),'true'],check=True)
 report={'success':True,'release':V,'originalPackSha256':sha256(LIVE),'originalAssetsSha256':sha256(ORIGINAL),
  'texturesMoved':len(textures),'textureBytes':sum(map(len,textures.values())),'textureOverrides':overrides,'iconDefinitionsMoved':len(icon_definitions),
  'oldJarBytes':ORIGINAL.stat().st_size,'newJar':str(newjar),'newJarBytes':newjar.stat().st_size,'newJarSha256':sha256(newjar),
  'pack':str(protected),'packBytes':protected.stat().st_size,'packSha256':sha256(protected),'packSha1':hashlib.sha1(protected.read_bytes()).hexdigest(),
  'unprotected':str(unprotected),'unprotectedSha256':sha256(unprotected),'baseline':str(baseline),'itemsadderVersion':'4.0.16','protection_1':True,'protection_2':True,'protection_3':False,
  'runtimeGeometryAnimationsSoundsUnchanged':True,'clientAdapterCodeChanged':False,'published':False}
 dump(ROOT/'reports/texture-pack-preparation.json',report);print(json.dumps(report))
if __name__=='__main__':prepare()
