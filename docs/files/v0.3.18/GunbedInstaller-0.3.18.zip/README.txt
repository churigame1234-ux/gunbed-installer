Gunbed Installer 0.3.18 / adapters 0.3.18 / shared assets 0.3.17
Adds match-only pixel/control recording for human imitation learning. No trained human policy is bundled.
Other mods, settings and worlds are preserved.
