package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(net.minecraft.client.Camera.class)
public abstract class GunbedFovMixin {
    @Inject(method="calculateFov",at=@At("RETURN"),cancellable=true)
    private void gunbedZoom(float partial, CallbackInfoReturnable<Float> ci){var player=net.minecraft.client.Minecraft.getInstance().player;if( player!=null&&kr.mzs.gunbedvisual.GunbedRender.active(player))ci.setReturnValue(kr.mzs.gunbedvisual.VisualState.INSTANCE.zoomFov(ci.getReturnValue()));}
}
