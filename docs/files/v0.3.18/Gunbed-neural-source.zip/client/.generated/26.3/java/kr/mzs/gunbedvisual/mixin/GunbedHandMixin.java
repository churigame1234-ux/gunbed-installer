package kr.mzs.gunbedvisual.mixin;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FirstPersonHandsAndItemsRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import net.minecraft.client.renderer.state.level.FirstPersonHandsAndItemsRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import kr.mzs.gunbedvisual.GunbedRender;
@Mixin(FirstPersonHandsAndItemsRenderer.class)
public abstract class GunbedHandMixin {
    @Inject(method="submitHandsWithItems",at=@At("HEAD"),cancellable=true)
    private void gunbed$hand(float delta,PoseStack pose,SubmitNodeCollector buffers,PlayerRenderState playerState,FirstPersonHandsAndItemsRenderState hands,CallbackInfo ci) {
        var player=Minecraft.getInstance().player;
        if(player!=null && playerState.avatarRenderState!=null && GunbedRender.render(player,pose,buffers,playerState.avatarRenderState.lightCoords))ci.cancel();
    }
}
