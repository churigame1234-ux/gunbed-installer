package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.Minecraft;
import kr.mzs.gunbedvisual.GunbedRender;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Minecraft.class)
public abstract class GunbedInputMixin {
    private boolean gunbed$controls(){var client=Minecraft.getInstance();return client.player!=null&&(kr.mzs.gunbedvisual.HudState.INSTANCE.loadoutPending||GunbedRender.controlled(client.player));}
    @Inject(method="handleKeybinds",at=@At("HEAD"),cancellable=true)
    private void gunbed$choice(CallbackInfo ci){var client=Minecraft.getInstance();if(client.gui.screen()!=null||!kr.mzs.gunbedvisual.HudState.INSTANCE.active()||!kr.mzs.gunbedvisual.HudState.INSTANCE.loadoutPending)return;for(int i=0;i<(kr.mzs.gunbedvisual.HudState.INSTANCE.loadoutPrevious?4:3);i++)if(client.options.keyHotbarSlots[i].consumeClick()){kr.mzs.gunbedvisual.GunbedVisualClient.chooseLoadout(i+1);break;}ci.cancel();}
    @Inject(method="startAttack",at=@At("HEAD"),cancellable=true)
    private void gunbed$attack(CallbackInfoReturnable<Boolean> ci){if(gunbed$controls())ci.setReturnValue(false);}
    @Inject(method="continueAttack",at=@At("HEAD"),cancellable=true)
    private void gunbed$continue(boolean held,CallbackInfo ci){if(gunbed$controls())ci.cancel();}
    @Inject(method="startUseItem",at=@At("HEAD"),cancellable=true)
    private void gunbed$use(CallbackInfo ci){if(gunbed$controls())ci.cancel();}
}
