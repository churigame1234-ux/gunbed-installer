package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.world.entity.Display;
import net.minecraft.client.renderer.entity.state.ItemDisplayEntityRenderState;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
@Mixin(net.minecraft.client.renderer.entity.DisplayRenderer.ItemDisplayRenderer.class)
public abstract class GunbedTurretMixin {
 @Inject(method="extractRenderState(Lnet/minecraft/world/entity/Display$ItemDisplay;Lnet/minecraft/client/renderer/entity/state/ItemDisplayEntityRenderState;F)V",at=@At("TAIL"))
 private void gunbed$extract(Display.ItemDisplay entity,ItemDisplayEntityRenderState state,float partial,CallbackInfo ci){var data=(kr.mzs.gunbedvisual.TurretDisplayData)(Object)state;var itemState=entity.itemRenderState();if(itemState==null){data.gunbed$kind("");return;}var model=itemState.itemStack().get(net.minecraft.core.component.DataComponents.ITEM_MODEL);String kind="";if(model!=null&&model.getNamespace().equals("gunbed")&&model.getPath().startsWith("turret/"))kind=model.getPath().substring(7);data.gunbed$kind(kind);data.gunbed$pitch(kr.mzs.gunbedvisual.HudState.INSTANCE.turretPitch(entity.getUUID()));}
 @Inject(method="renderInner(Lnet/minecraft/client/renderer/entity/state/ItemDisplayEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IF)V",at=@At("HEAD"),cancellable=true)
 private void gunbed$draw(ItemDisplayEntityRenderState state,PoseStack poses,MultiBufferSource buffers,int light,float partial,CallbackInfo ci){if(kr.mzs.gunbedvisual.GunbedWorldMeshes.draw(((kr.mzs.gunbedvisual.TurretDisplayData)(Object)state).gunbed$kind(),poses,buffers,light,((kr.mzs.gunbedvisual.TurretDisplayData)(Object)state).gunbed$pitch()))ci.cancel();}
}
