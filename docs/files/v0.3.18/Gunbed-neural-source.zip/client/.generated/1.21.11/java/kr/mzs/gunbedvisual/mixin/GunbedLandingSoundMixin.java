package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(net.minecraft.client.sounds.SoundManager.class)
public abstract class GunbedLandingSoundMixin {
 @Inject(method="play",at=@At("HEAD"),cancellable=true)
 private void gunbedLanding(net.minecraft.client.resources.sounds.SoundInstance sound,CallbackInfoReturnable<net.minecraft.client.sounds.SoundEngine.PlayResult> ci){var p=net.minecraft.client.Minecraft.getInstance().player;if(p==null||!kr.mzs.gunbedvisual.HudState.INSTANCE.active())return;double dx=sound.getX()-p.getX(),dy=sound.getY()-p.getY(),dz=sound.getZ()-p.getZ();if(dx*dx+dy*dy+dz*dz<4&&kr.mzs.gunbedvisual.GroundAudio.mute(sound.getIdentifier().getPath(),p.getY()))ci.setReturnValue(net.minecraft.client.sounds.SoundEngine.PlayResult.NOT_STARTED);}
}
