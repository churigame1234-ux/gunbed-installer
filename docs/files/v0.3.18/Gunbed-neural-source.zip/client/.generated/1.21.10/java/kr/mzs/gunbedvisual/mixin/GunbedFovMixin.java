package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(net.minecraft.client.renderer.GameRenderer.class)
public abstract class GunbedFovMixin {
    @Inject(method="getFov",at=@At("RETURN"),cancellable=true)
    private void gunbedZoom(net.minecraft.client.Camera camera,float partial,boolean useFov, CallbackInfoReturnable<Float> ci){var player=net.minecraft.client.Minecraft.getInstance().player;if(useFov&& player!=null&&kr.mzs.gunbedvisual.GunbedRender.active(player))ci.setReturnValue(kr.mzs.gunbedvisual.VisualState.INSTANCE.zoomFov(ci.getReturnValue()));}
}
