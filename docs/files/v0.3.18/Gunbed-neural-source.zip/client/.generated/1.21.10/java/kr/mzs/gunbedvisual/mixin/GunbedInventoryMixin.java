package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(net.minecraft.client.gui.screens.inventory.InventoryScreen.class)
public abstract class GunbedInventoryMixin {
 @Inject(method="init",at=@At("HEAD"))
 private void gunbedHideBook(CallbackInfo ci){var player=net.minecraft.client.Minecraft.getInstance().player;if(player!=null&&kr.mzs.gunbedvisual.HudState.INSTANCE.active())player.getRecipeBook().setOpen(net.minecraft.world.inventory.RecipeBookType.CRAFTING,false);}
 @Inject(method="renderBg",at=@At("TAIL"))
 private void gunbedPanel(net.minecraft.client.gui.GuiGraphics g,float partial,int mx,int my,CallbackInfo ci){if(!kr.mzs.gunbedvisual.HudState.INSTANCE.active())return;var screen=(net.minecraft.client.gui.screens.inventory.InventoryScreen)(Object)this;var mc=net.minecraft.client.Minecraft.getInstance();int left=(screen.width-176)/2,top=(screen.height-166)/2;kr.mzs.gunbedvisual.GunbedHud.inventory(g,left,top);}
 @Inject(method="renderLabels",at=@At("HEAD"),cancellable=true)
 private void gunbedLabels(net.minecraft.client.gui.GuiGraphics g,int mouseX,int mouseY,CallbackInfo ci){if(kr.mzs.gunbedvisual.HudState.INSTANCE.active())ci.cancel();}
 @Inject(method="init",at=@At("TAIL"))
 private void gunbedRecipe(CallbackInfo ci){if(!kr.mzs.gunbedvisual.HudState.INSTANCE.active())return;var screen=(net.minecraft.client.gui.screens.inventory.InventoryScreen)(Object)this;for(var child:screen.children())if(child instanceof net.minecraft.client.gui.components.ImageButton b)b.visible=false;}
}
