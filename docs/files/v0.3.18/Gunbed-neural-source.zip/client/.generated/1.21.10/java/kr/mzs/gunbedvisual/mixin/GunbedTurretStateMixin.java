package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.*;
@Mixin(net.minecraft.client.renderer.entity.state.ItemDisplayEntityRenderState.class)
public abstract class GunbedTurretStateMixin implements kr.mzs.gunbedvisual.TurretDisplayData {@Unique private float gunbed$pitch;public float gunbed$pitch(){return gunbed$pitch;}public void gunbed$pitch(float pitch){gunbed$pitch=pitch;}@Unique private String gunbed$kind="";public String gunbed$kind(){return gunbed$kind;}public void gunbed$kind(String kind){gunbed$kind=kind;}}
