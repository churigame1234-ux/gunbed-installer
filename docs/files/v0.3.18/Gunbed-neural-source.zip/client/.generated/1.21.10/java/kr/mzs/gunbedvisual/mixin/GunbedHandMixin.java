package kr.mzs.gunbedvisual.mixin;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import kr.mzs.gunbedvisual.GunbedRender;
@Mixin(ItemInHandRenderer.class)
public abstract class GunbedHandMixin {
    @Inject(method="renderArmWithItem",at=@At("HEAD"),cancellable=true)
    private void gunbed$hand(AbstractClientPlayer player,float delta,float pitch,InteractionHand hand,float swing,ItemStack stack,float equip,PoseStack pose,SubmitNodeCollector buffers,int light,CallbackInfo ci) {
        if(hand==InteractionHand.MAIN_HAND) {
            if(GunbedRender.render(player,pose,buffers,light))ci.cancel();
        } else if(GunbedRender.active(player))ci.cancel();
    }
}
