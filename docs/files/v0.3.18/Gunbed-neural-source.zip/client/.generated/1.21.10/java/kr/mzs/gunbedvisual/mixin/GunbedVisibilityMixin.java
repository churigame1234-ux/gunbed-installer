package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(net.minecraft.world.entity.Entity.class)
public abstract class GunbedVisibilityMixin {
 @Inject(method="shouldRenderAtSqrDistance",at=@At("RETURN"),cancellable=true)
 private void gunbed$distance(double square,CallbackInfoReturnable<Boolean> ci){if(!((Object)this instanceof net.minecraft.world.entity.Display)&&kr.mzs.gunbedvisual.HudState.INSTANCE.active()&&square<16384&&!ci.getReturnValue())ci.setReturnValue(true);}
 @Inject(method="getTeamColor",at=@At("RETURN"),cancellable=true)
 private void gunbed$glow(CallbackInfoReturnable<Integer> ci){var state=kr.mzs.gunbedvisual.HudState.INSTANCE;if(!state.active())return;var entity=(net.minecraft.world.entity.Entity)(Object)this;Integer colour=state.glow(entity.getUUID());if(colour!=null)ci.setReturnValue(colour);}
}
