package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
@Mixin(net.minecraft.client.gui.GuiGraphics.class)
public abstract class GunbedCountMixin {
 @ModifyVariable(method="renderItemDecorations(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;IILjava/lang/String;)V",at=@At("HEAD"),argsOnly=true,ordinal=0)
 private String gunbedCount(String value,net.minecraft.client.gui.Font font,net.minecraft.world.item.ItemStack item,int x,int y,String original){return kr.mzs.gunbedvisual.ItemCounts.label(item,value);}
}
