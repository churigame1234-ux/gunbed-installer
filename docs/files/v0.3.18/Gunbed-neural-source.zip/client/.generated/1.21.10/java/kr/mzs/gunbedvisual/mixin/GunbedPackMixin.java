package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(net.minecraft.client.multiplayer.ClientCommonPacketListenerImpl.class)
public abstract class GunbedPackMixin {
 @Inject(method="handleResourcePackPush",at=@At("RETURN"))
 private void gunbedPack(net.minecraft.network.protocol.common.ClientboundResourcePackPushPacket packet,CallbackInfo ci){kr.mzs.gunbedvisual.PackOwnership.pushed(packet.id(),packet.url());}
}
