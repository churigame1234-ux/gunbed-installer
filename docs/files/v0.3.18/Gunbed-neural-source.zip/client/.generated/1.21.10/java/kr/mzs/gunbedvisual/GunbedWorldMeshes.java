package kr.mzs.gunbedvisual;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import org.joml.Vector3f;
import kr.mzs.gunbedvisual.model.GunMesh;
public final class GunbedWorldMeshes {
 public static boolean draw(String kind,PoseStack matrices,SubmitNodeCollector buffers,int light){return draw(kind,matrices,buffers,light,0);}
 public static boolean draw(String kind,PoseStack matrices,SubmitNodeCollector buffers,int light,float pitch){if(!HudState.INSTANCE.active()||kind==null||kind.isEmpty())return false;var mesh=TurretMesh.get(kind);if(mesh.isEmpty())return false;for(var surface:mesh){matrices.pushPose();if(surface.frame().vertices().stream().mapToDouble(v->v.y()).average().orElse(0)>.48){matrices.translate(0,.55,0);matrices.mulPose(new org.joml.Matrix4f().rotationX((float)Math.toRadians(pitch)));matrices.translate(0,-.55,0);}var type=RenderType.entityCutout(ResourceLocation.parse(surface.texture()));buffers.submitCustomGeometry(matrices,type,(pose,consumer)->vertices(surface.frame(),pose,consumer,light,surface.color()));matrices.popPose();}return true;}
 private static void vertices(GunMesh.Frame frame,PoseStack.Pose pose,VertexConsumer consumer,int light,int color){Vector3f p=new Vector3f(),n=new Vector3f();for(var v:frame.vertices()){pose.pose().transformPosition(v.x(),v.y(),v.z(),p);pose.normal().transform(v.nx(),v.ny(),v.nz(),n).normalize();consumer.addVertex(p.x,p.y,p.z).setColor(color).setUv(v.u(),v.v()).setOverlay(net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY).setLight(light).setNormal(n.x,n.y,n.z);}}
}
