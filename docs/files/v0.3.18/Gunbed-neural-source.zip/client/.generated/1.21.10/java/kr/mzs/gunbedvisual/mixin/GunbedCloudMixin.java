package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(net.minecraft.client.renderer.CloudRenderer.class)
public abstract class GunbedCloudMixin {
    @Inject(method="render",at=@At("HEAD"),cancellable=true)
    private void gunbedClouds(CallbackInfo ci){if(kr.mzs.gunbedvisual.HudState.INSTANCE.active())ci.cancel();}
}
