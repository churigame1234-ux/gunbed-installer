package kr.mzs.gunbedvisual.model;
public final class MeshColor {
    private MeshColor() {}
    public static int argb(float a,float r,float g,float b) {
        return ((int)(a*255)<<24)|((int)(r*255)<<16)|((int)(g*255)<<8)|(int)(b*255);
    }
}
