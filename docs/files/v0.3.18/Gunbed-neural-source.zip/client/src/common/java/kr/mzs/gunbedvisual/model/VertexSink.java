package kr.mzs.gunbedvisual.model;
@FunctionalInterface
public interface VertexSink {
    void addVertex(float x, float y, float z, int color, float u, float v, int overlay, int light, float nx, float ny, float nz);
}
