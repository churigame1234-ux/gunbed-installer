package kr.mzs.gunbedvisual;
import com.google.gson.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import kr.mzs.gunbedvisual.model.GunMesh;

/** Exact supplied triangles; the world renderer never voxelizes these meshes. */
public final class TurretMesh {
    public record Surface(String texture,int color,GunMesh.Frame frame){}
    private static final Map<String,List<Surface>> CACHE=new HashMap<>();
    public static List<Surface> get(String kind){return CACHE.computeIfAbsent(kind,TurretMesh::load);}
    private static List<Surface> load(String kind){
        if(!Set.of("burst","slowness","healing","siege").contains(kind))return List.of();
        try(var in=TurretMesh.class.getResourceAsStream("/assets/gunbed/models/turret/native/"+kind+".json")){
            var data=JsonParser.parseReader(new InputStreamReader(Objects.requireNonNull(in),StandardCharsets.UTF_8)).getAsJsonObject();
            List<Surface> result=new ArrayList<>();
            for(var value:data.getAsJsonArray("parts")){var part=value.getAsJsonObject();List<GunMesh.Vertex> vertices=new ArrayList<>();
                for(var row:part.getAsJsonArray("vertices")){var a=row.getAsJsonArray();vertices.add(new GunMesh.Vertex(a.get(0).getAsFloat(),a.get(1).getAsFloat(),a.get(2).getAsFloat(),a.get(3).getAsFloat(),a.get(4).getAsFloat(),a.get(5).getAsFloat(),a.get(6).getAsFloat(),a.get(7).getAsFloat()));}
                var color=part.getAsJsonArray("color");int argb=0xff000000|((int)(color.get(0).getAsFloat()*255)<<16)|((int)(color.get(1).getAsFloat()*255)<<8)|(int)(color.get(2).getAsFloat()*255);
                result.add(new Surface(part.get("texture").getAsString(),argb,new GunMesh.Frame(List.copyOf(vertices),null,null,null)));}
            return List.copyOf(result);
        }catch(IOException e){throw new UncheckedIOException(e);}
    }
}
