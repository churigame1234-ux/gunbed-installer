package kr.mzs.gunbedvisual.model;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
public record MeshPose(Matrix4f pose, Matrix3f normal) {
    public MeshPose(Matrix4f matrix) { this(matrix, new Matrix3f(matrix).invert().transpose()); }
}
