package kr.mzs.gunbedvisual.model;

import com.google.gson.*;
import org.joml.*;
import java.util.*;
import java.lang.Math;

/** Original indexed triangles and sampled skeletal poses, without Source game code. */
final class SourceTriangleMesh {
    private record Influence(int bone,float weight,Vector3f position,Vector3f normal){}
    private record Point(Vector3f position,Vector3f normal,float u,float v,int bone,Influence[] influences){}
    private record Part(String texture,int[] indices){}
    private record Clip(float fps,Matrix4f[][] frames){}
    private final Point[] points;
    private final List<Part> parts=new ArrayList<>();
    private final Map<String,Clip> clips=new HashMap<>();
    private final Map<String,String> aliases=new HashMap<>();
    private final Matrix4f view;
    private final int left,right,muzzle;
    private final boolean proceduralArms;
    private final boolean nativeArms;
    SourceTriangleMesh(JsonObject data){
        var source=data.getAsJsonObject("gunbed:source_mesh");
        var offset=source.getAsJsonArray("viewOffset");
        view=new Matrix4f().translation(offset==null?0:offset.get(0).getAsFloat(),offset==null?-.03f:offset.get(1).getAsFloat(),offset==null?-.6f:offset.get(2).getAsFloat()).mul(new Matrix4f(0,0,-1,0,-1,0,0,0,0,1,0,0,0,0,0,1)).scale(1f/24f);
        var vertices=source.getAsJsonArray("vertices");points=new Point[vertices.size()];
        for(int i=0;i<points.length;i++){var a=vertices.get(i).getAsJsonArray();Influence[] influences=null;if(a.size()>9){var weights=a.get(9).getAsJsonArray();influences=new Influence[weights.size()];for(int j=0;j<weights.size();j++){var w=weights.get(j).getAsJsonArray();influences[j]=new Influence(w.get(0).getAsInt(),w.get(1).getAsFloat(),new Vector3f(w.get(2).getAsFloat(),w.get(3).getAsFloat(),w.get(4).getAsFloat()),new Vector3f(w.get(5).getAsFloat(),w.get(6).getAsFloat(),w.get(7).getAsFloat()));}}points[i]=new Point(new Vector3f(a.get(0).getAsFloat(),a.get(1).getAsFloat(),a.get(2).getAsFloat()),new Vector3f(a.get(3).getAsFloat(),a.get(4).getAsFloat(),a.get(5).getAsFloat()),a.get(6).getAsFloat(),a.get(7).getAsFloat(),a.get(8).getAsInt(),influences);}
        for(var value:source.getAsJsonArray("parts")){var part=value.getAsJsonObject();var array=part.getAsJsonArray("indices");int[] indices=new int[array.size()];for(int i=0;i<indices.length;i++)indices[i]=array.get(i).getAsInt();parts.add(new Part(part.get("texture").getAsString(),indices));}
        for(var entry:source.getAsJsonObject("clips").entrySet()){var clip=entry.getValue().getAsJsonObject();var frames=clip.getAsJsonArray("frames");Matrix4f[][] poses=new Matrix4f[frames.size()][];for(int f=0;f<poses.length;f++){var bones=frames.get(f).getAsJsonArray();poses[f]=new Matrix4f[bones.size()];for(int b=0;b<poses[f].length;b++){var values=bones.get(b).getAsJsonArray();float[] numbers=new float[16];for(int k=0;k<16;k++)numbers[k]=values.get(k).getAsFloat();poses[f][b]=new Matrix4f().set(numbers).transpose();}}clips.put(entry.getKey(),new Clip(clip.get("fps").getAsFloat(),poses));}
        for(var e:source.getAsJsonObject("aliases").entrySet())aliases.put(e.getKey(),e.getValue().getAsString());
        left=source.get("leftArm").getAsInt();right=source.get("rightArm").getAsInt();muzzle=source.get("muzzle").getAsInt();
        proceduralArms=!source.has("proceduralArms")||source.get("proceduralArms").getAsBoolean();
        nativeArms=source.has("nativeArms")&&source.get("nativeArms").getAsBoolean();
    }
    private Clip clip(String name){return clips.get(aliases.getOrDefault(name==null?"":name,"idle1"));}
    boolean has(String name){return aliases.containsKey(name)||clips.containsKey(name);}
    double duration(String name){var c=clip(name);return (c.frames.length-1)/c.fps;}
    GunMesh.Frame frame(String name,double time){
        Clip clip=clip(name);float value=(float)Math.max(0,time*clip.fps);boolean idle=name==null||name.isEmpty()||name.equals("static_idle");if(name==null||name.isEmpty())value=(float)((System.nanoTime()/1e9*clip.fps)%(clip.frames.length-1));if(idle)value%=clip.frames.length-1;else value=Math.min(value,clip.frames.length-1);
        int f=(int)value,next=Math.min(f+1,clip.frames.length-1);float blend=value-f;
        Matrix4f[] matrices=new Matrix4f[clip.frames[f].length];for(int b=0;b<matrices.length;b++)matrices[b]=new Matrix4f(clip.frames[f][b]).lerp(clip.frames[next][b],blend);
        Vector3f p=new Vector3f(),n=new Vector3f();GunMesh.Vertex[] transformed=new GunMesh.Vertex[points.length];
        Vector3f weightedPosition=new Vector3f(),weightedNormal=new Vector3f();
        for(int i=0;i<points.length;i++){Point point=points[i];if(point.influences==null){matrices[point.bone].transformPosition(point.position,p);matrices[point.bone].transformDirection(point.normal,n);}else{p.zero();n.zero();for(Influence influence:point.influences){matrices[influence.bone].transformPosition(influence.position,weightedPosition);matrices[influence.bone].transformDirection(influence.normal,weightedNormal);p.fma(influence.weight,weightedPosition);n.fma(influence.weight,weightedNormal);}}view.transformPosition(p);view.transformDirection(n);if(n.lengthSquared()<1e-12f)n.set(0,1,0);else n.normalize();transformed[i]=new GunMesh.Vertex(p.x,p.y,p.z,point.u,point.v,n.x,n.y,n.z);}
        Map<String,List<GunMesh.Vertex>> surfaces=new LinkedHashMap<>();List<GunMesh.Vertex> all=new ArrayList<>();
        for(Part part:parts){var vertices=surfaces.computeIfAbsent(part.texture,k->new ArrayList<>());for(int i=0;i<part.indices.length;i+=3){GunMesh.Vertex a=transformed[part.indices[i]],b=transformed[part.indices[i+1]],c=transformed[part.indices[i+2]];vertices.add(a);vertices.add(b);vertices.add(c);vertices.add(c);}}
        if(proceduralArms){var skin=surfaces.computeIfAbsent("$skin",key->new ArrayList<>());
        limb(skin,matrices[6],11.1f,32,48,0,6);limb(skin,matrices[7],8.15f,32,48,6,6);limb(skin,matrices[left],4.2f,32,48,9,3);
        limb(skin,matrices[25],11.1f,40,16,0,6);limb(skin,matrices[26],8.15f,40,16,6,6);limb(skin,matrices[right],4.2f,40,16,9,3);}
        for(var batch:surfaces.values())all.addAll(batch);
        return new GunMesh.Frame(all,nativeArms?minecraftArm(matrices[left],true):null,nativeArms?minecraftArm(matrices[right],false):null,new Matrix4f(view).mul(matrices[muzzle]).scale(24f),surfaces);
    }
    private Matrix4f minecraftArm(Matrix4f wrist,boolean left){
        // Vanilla's arm is a 4x12-pixel cuboid. Anchor its hand end at the
        // animated wrist; the player renderer supplies skin, slimness and sleeve.
        return new Matrix4f().translation(left?0:.08f,left?0:.01f,0).mul(view).mul(wrist).translate(2.0f,left?-1.4f:1.4f,-1.3f).rotateZ(-(float)Math.PI/2).scale(14f,32f,14f).translate(left?-.375f:.375f,-.75f,0);
    }
    private void limb(List<GunMesh.Vertex> out,Matrix4f bone,float length,int u,int v,int offset,int pixels){
        Matrix4f matrix=new Matrix4f(view).mul(bone);float r=2.25f;
        float[][] p={{0,-r,-r},{length,-r,-r},{length,r,-r},{0,r,-r},{0,-r,r},{length,-r,r},{length,r,r},{0,r,r}};
        int[][] faces={{0,3,2,1},{4,5,6,7},{0,1,5,4},{3,7,6,2},{0,4,7,3},{1,2,6,5}};
        float[][] normals={{0,0,-1},{0,0,1},{0,-1,0},{0,1,0},{-1,0,0},{1,0,0}};
        for(int f=0;f<6;f++){
            float tu=u+(f<4?f*4:4),tv=v+4+offset,tw=4,th=pixels;
            if(f>=4){tv=v;th=4;}
            Vector3f normal=matrix.transformDirection(new Vector3f(normals[f])).normalize();
            float[][] uv={{tu,tv},{tu,tv+th},{tu+tw,tv+th},{tu+tw,tv}};
            for(int k=0;k<4;k++){float[] c=p[faces[f][k]];Vector3f point=matrix.transformPosition(new Vector3f(c));out.add(new GunMesh.Vertex(point.x,point.y,point.z,uv[k][0]/64,uv[k][1]/64,normal.x,normal.y,normal.z));}
        }
    }
}
