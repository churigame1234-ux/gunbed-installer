package kr.mzs.gunbedvisual;
import kr.mzs.gunbedvisual.model.GunMesh;
import org.joml.*;
import java.util.*;

/** One view-space action moves the mesh and both native skin hands together. */
final class ModePose {
    private ModePose(){}
    static GunMesh.Frame transform(GunMesh.Frame frame,Matrix4f matrix){
        var vertices=vertices(frame.vertices(),matrix);Map<String,List<GunMesh.Vertex>> surfaces=new LinkedHashMap<>();
        frame.surfaces().forEach((name,list)->surfaces.put(name,vertices(list,matrix)));
        return new GunMesh.Frame(vertices,arm(frame.leftArm(),matrix),arm(frame.rightArm(),matrix),arm(frame.muzzle(),matrix),surfaces);
    }
    private static Matrix4f arm(Matrix4f arm,Matrix4f transform){return arm==null?null:new Matrix4f(transform).mul(arm);}
    private static List<GunMesh.Vertex> vertices(List<GunMesh.Vertex> input,Matrix4f transform){
        List<GunMesh.Vertex> result=new ArrayList<>(input.size());Vector3f position=new Vector3f(),normal=new Vector3f();
        for(var vertex:input){transform.transformPosition(vertex.x(),vertex.y(),vertex.z(),position);transform.transformDirection(vertex.nx(),vertex.ny(),vertex.nz(),normal).normalize();result.add(new GunMesh.Vertex(position.x,position.y,position.z,vertex.u(),vertex.v(),normal.x,normal.y,normal.z));}return result;
    }
}
