package kr.mzs.gunbedvisual;
import kr.mzs.gunbedvisual.model.GunMesh;
import org.joml.*;
public final class M79Pose {
 public static GunMesh.Frame apply(GunMesh.Frame frame){Matrix4f fit=new Matrix4f().translation(.20f,-.31f,-.69f).scale(.65f);var body=ModePose.transform(new GunMesh.Frame(frame.vertices(),null,null,null,frame.surfaces()),fit);Matrix4f right=new Matrix4f().translation(.24f,-.31f,-.54f).rotateX(-.35f).rotateZ(.2f).scale(.65f,1.2f,.65f).translate(.375f,-.75f,0);Matrix4f left=new Matrix4f().translation(.12f,-.28f,-.95f).rotateX(-.35f).rotateZ(-.45f).scale(.65f,1.2f,.65f).translate(-.375f,-.75f,0);return new GunMesh.Frame(body.vertices(),left,right,null,body.surfaces());}
}
