package kr.mzs.gunbedvisual;

import com.google.gson.*;
import java.util.*;
import java.util.function.Function;

/** Keep source art intact; combine Gunbed-authored parts and motion only in memory. */
public final class ModeAssets {
    private ModeAssets(){}
    public record Loaded(JsonObject geometry,JsonObject animation){}
    public static JsonObject definition(JsonObject catalog,String id){
        JsonObject entry=catalog.getAsJsonObject(id);if(entry==null)return null;
        if(!entry.has("base"))return entry;
        JsonObject original=catalog.getAsJsonObject(entry.get("base").getAsString());if(original==null||original.has("base"))throw new IllegalArgumentException("Unknown mode base");
        JsonObject result=original.deepCopy();result.addProperty("id",id);result.add("mode_overlay",entry.get("mode_overlay"));return result;
    }
    public static Loaded load(JsonObject definition,Function<String,JsonObject> reader){
        JsonObject geometry=reader.apply(definition.get("model").getAsString()),animation=reader.apply(definition.get("animation").getAsString());
        if(definition.has("defaultAnimation")){var own=animation.getAsJsonObject("animations");for(var entry:reader.apply(definition.get("defaultAnimation").getAsString()).getAsJsonObject("animations").entrySet())if(!own.has(entry.getKey()))own.add(entry.getKey(),entry.getValue());}
        if(definition.has("mode_overlay"))apply(geometry,animation,reader.apply(definition.get("mode_overlay").getAsString()));
        return new Loaded(geometry,animation);
    }
    private static JsonArray vec(float...numbers){JsonArray result=new JsonArray();for(float n:numbers)result.add(n);return result;}
    private static JsonObject keys(Object...pairs){JsonObject object=new JsonObject();for(int i=0;i<pairs.length;i+=2)object.add(pairs[i].toString(),(JsonElement)pairs[i+1]);return object;}
    private static JsonArray position(JsonObject channel){if(channel==null||!channel.has("position")||!channel.get("position").isJsonArray())return vec(0,0,0);return channel.getAsJsonArray("position").deepCopy();}
    private static void apply(JsonObject geometry,JsonObject animation,JsonObject overlay){
        JsonArray bones=geometry.getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject().getAsJsonArray("bones");bones.add(overlay.getAsJsonObject("part").deepCopy());
        var clips=animation.getAsJsonObject("animations");var idle=clips.has("static_idle")&&clips.getAsJsonObject("static_idle").has("bones")?clips.getAsJsonObject("static_idle").getAsJsonObject("bones"):new JsonObject();
        String left="";for(JsonElement bone:bones){String name=bone.getAsJsonObject().get("name").getAsString();if(name.equalsIgnoreCase("lefthand")){left=name;break;}}
        for(var spec:Map.of("mode_switch",.9,"deploy",5.0,"undeploy",1.5).entrySet()){
            double duration=spec.getValue();JsonObject channels=new JsonObject();channels.add("mode_lever",keys("rotation",keys("0",vec(0,0,0),Double.toString(duration*.4),vec(0,0,16),Double.toString(duration*.65),vec(0,0,0),Double.toString(duration),vec(0,0,0))));
            if(!left.isEmpty()){JsonArray rest=position(idle.getAsJsonObject(left));JsonArray hand=vec(rest.get(0).getAsFloat()+2,rest.get(1).getAsFloat()+2.5f,rest.get(2).getAsFloat()+3);channels.add(left,keys("position",keys("0",rest,Double.toString(duration*.2),hand,Double.toString(duration*.6),hand,Double.toString(duration),rest)));}
            JsonObject clip=keys("bones",channels);clip.addProperty("animation_length",duration);clip.addProperty("loop",false);clips.add(spec.getKey(),clip);
        }
    }
}
