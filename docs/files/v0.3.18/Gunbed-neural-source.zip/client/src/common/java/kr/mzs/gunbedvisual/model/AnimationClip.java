package kr.mzs.gunbedvisual.model;

import com.google.gson.*;
import java.util.*;

/** Bedrock channels, including discontinuous pre/post keys and Catmull-Rom curves. */
public final class AnimationClip {
    private final JsonObject data;
    public final double duration;
    public AnimationClip(JsonObject data) {
        this.data = data;
        duration = data.has("animation_length") ? data.get("animation_length").getAsDouble() : 1;
    }
    public boolean has(String bone,String channel) {
        return data.has("bones") && data.getAsJsonObject("bones").has(bone)
                && data.getAsJsonObject("bones").getAsJsonObject(bone).has(channel);
    }
    public List<String> sounds(double from,double to){List<String> result=new ArrayList<>();if(!data.has("sound_effects"))return result;for(var entry:data.getAsJsonObject("sound_effects").entrySet()){double time;try{time=Double.parseDouble(entry.getKey());}catch(NumberFormatException ignored){continue;}if(time<=from||time>to)continue;JsonElement raw=entry.getValue();if(raw.isJsonArray()){for(JsonElement value:raw.getAsJsonArray())if(value.isJsonObject()&&value.getAsJsonObject().has("effect"))result.add(value.getAsJsonObject().get("effect").getAsString());}else if(raw.isJsonObject()&&raw.getAsJsonObject().has("effect"))result.add(raw.getAsJsonObject().get("effect").getAsString());}return result;}
    public float[] sample(String bone,String channel,double time,float[] fallback) {
        if (!has(bone,channel)) return fallback;
        JsonElement raw = data.getAsJsonObject("bones").getAsJsonObject(bone).get(channel);
        if (!raw.isJsonObject()) return vector(raw, fallback);
        JsonObject object=raw.getAsJsonObject();
        if (object.has("vector") || object.has("post")) return vector(raw, fallback);
        var frames = new ArrayList<Map.Entry<Double,JsonElement>>();
        for (var entry:object.entrySet()) {
            try { frames.add(Map.entry(Double.parseDouble(entry.getKey()),entry.getValue())); }
            catch (NumberFormatException ignored) { }
        }
        frames.sort(Map.Entry.comparingByKey());
        if (frames.isEmpty()) return fallback;
        int right=0; while(right<frames.size() && frames.get(right).getKey()<=time) right++;
        if(right==0) return vector(side(frames.getFirst().getValue(),"pre"),fallback);
        if(right==frames.size()) return vector(side(frames.getLast().getValue(),"post"),fallback);
        int left=right-1;
        float[] a=vector(side(frames.get(left).getValue(),"post"),fallback), b=vector(side(frames.get(right).getValue(),"pre"),fallback);
        float t=(float)((time-frames.get(left).getKey())/(frames.get(right).getKey()-frames.get(left).getKey()));
        JsonElement key=frames.get(left).getValue();
        boolean cubic=key.isJsonObject() && key.getAsJsonObject().has("lerp_mode") && key.getAsJsonObject().get("lerp_mode").getAsString().equals("catmullrom");
        float[] result=new float[3];
        float[] before=vector(side(frames.get(Math.max(0,left-1)).getValue(),"post"),a);
        float[] after=vector(side(frames.get(Math.min(frames.size()-1,right+1)).getValue(),"pre"),b);
        for(int i=0;i<3;i++) result[i]=cubic ? .5f*((2*a[i])+(-before[i]+b[i])*t+(2*before[i]-5*a[i]+4*b[i]-after[i])*t*t+(-before[i]+3*a[i]-3*b[i]+after[i])*t*t*t) : a[i]+(b[i]-a[i])*t;
        return result;
    }
    private static JsonElement side(JsonElement key,String side) {
        if(key.isJsonObject()) {
            JsonObject o=key.getAsJsonObject();
            if(o.has(side))return o.get(side);
            if(o.has("vector"))return o.get("vector");
            if(o.has("post"))return o.get("post");
            if(o.has("pre"))return o.get("pre");
        }
        return key;
    }
    private static float[] vector(JsonElement value,float[] fallback) {
        value=side(value,"post");
        if(value.isJsonPrimitive() && value.getAsJsonPrimitive().isNumber()) {float f=value.getAsFloat();return new float[]{f,f,f};}
        if(!value.isJsonArray() || value.getAsJsonArray().size()!=3) throw new IllegalArgumentException("Unsupported animation expression: "+value);
        float[] out=new float[3];
        for(int i=0;i<3;i++) {
            JsonElement component=value.getAsJsonArray().get(i);
            try {out[i]=Float.parseFloat(component.getAsString());}
            catch(NumberFormatException error) {throw new IllegalArgumentException("Molang expression needs an explicit evaluator: "+component,error);}
        }
        return out;
    }
}
