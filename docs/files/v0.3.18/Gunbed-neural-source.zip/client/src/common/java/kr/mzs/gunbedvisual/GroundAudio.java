package kr.mzs.gunbedvisual;
/** Predict the local landing; authoritative packets settle double-jump launch height. */
public final class GroundAudio {
 private static double peak=Double.NaN,launch=Double.NaN;private static long quietUntil;private static boolean air;
 public static void launch(double y){launch=y;air=true;}
 public static void landing(boolean quiet){quietUntil=quiet?System.nanoTime()+500_000_000L:0;}
 public static void tick(double y,boolean ground){if(Double.isNaN(peak))peak=y;if(!ground){air=true;peak=Math.max(peak,y);}else{if(air){double drop=(Double.isNaN(launch)?peak:launch)-y;landing(drop<=10);launch=Double.NaN;}air=false;peak=y;}}
 public static boolean mute(String sound,double y){if(!(sound.endsWith(".fall")||sound.equals("entity.player.small_fall")||sound.equals("entity.player.big_fall")))return false;double drop=(Double.isNaN(launch)?peak:launch)-y;return air&&Double.isFinite(drop)&&drop<=10||System.nanoTime()<quietUntil;}
 public static void clear(){peak=Double.NaN;launch=Double.NaN;quietUntil=0;air=false;}
}
