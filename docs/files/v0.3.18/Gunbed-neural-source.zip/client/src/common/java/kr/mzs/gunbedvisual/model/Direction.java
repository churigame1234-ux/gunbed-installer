package kr.mzs.gunbedvisual.model;
import org.joml.Vector3f;
public enum Direction {
    DOWN(0,-1,0), UP(0,1,0), NORTH(0,0,-1), SOUTH(0,0,1), WEST(-1,0,0), EAST(1,0,0);
    private final float x,y,z;
    Direction(float x,float y,float z) { this.x=x; this.y=y; this.z=z; }
    public Vector3f step() { return new Vector3f(x,y,z); }
}
