package kr.mzs.gunbedvisual;

import net.minecraft.world.item.ItemStack;
import net.minecraft.core.component.DataComponents;

/** Render the owned bundle count while leaving vanilla durability and cooldown bars intact. */
public final class ItemCounts {
    private ItemCounts(){}
    public static String label(ItemStack item,String original){if(!HudState.INSTANCE.active()||item.isEmpty())return original;var custom=item.get(DataComponents.CUSTOM_DATA);if(custom==null)return original;long extra=custom.copyTag().getCompoundOrEmpty("PublicBukkitValues").getLongOr("gunbedcore:stack_extra",0);return extra>0?Long.toString(Math.min(99,item.getCount()+extra)):original;}
}
