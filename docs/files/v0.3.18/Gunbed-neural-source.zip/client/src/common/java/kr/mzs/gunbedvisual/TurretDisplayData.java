package kr.mzs.gunbedvisual;
public interface TurretDisplayData {String gunbed$kind();void gunbed$kind(String kind);float gunbed$pitch();void gunbed$pitch(float pitch);}
