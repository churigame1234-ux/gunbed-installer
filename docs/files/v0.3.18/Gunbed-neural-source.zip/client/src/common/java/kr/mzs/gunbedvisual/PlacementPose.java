package kr.mzs.gunbedvisual;
import org.joml.Matrix4f;
public final class PlacementPose {
 public static Matrix4f arm(boolean left,float progress){float work=(float)Math.sin(progress*30)*.025f;return new Matrix4f().translation(left?-.28f:.32f,-.20f+work,-.72f).rotateX(-.35f).rotateZ(left?-.45f:.30f).scale(.55f,1f,.55f).translate(left?-.375f:.375f,-.75f,0);}
}
