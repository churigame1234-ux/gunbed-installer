package kr.mzs.gunbedvisual;
import kr.mzs.gunbedvisual.model.GunMesh;
import org.joml.Matrix4f;
final class LegacyMeleePose {
    static GunMesh.Frame apply(GunMesh.Frame frame){Matrix4f right=new Matrix4f().translation(.30f,-.28f,-.63f).rotateX(-.35f).rotateZ(.15f).scale(.65f,1.2f,.65f).translate(.375f,-.75f,0);return new GunMesh.Frame(frame.vertices(),null,right,frame.muzzle(),frame.surfaces());}
    static GunMesh.Frame retarget(GunMesh.Frame legacy,GunMesh.Frame pose,GunMesh.Frame rest){
        if(legacy.rightArm()==null||pose.rightArm()==null||rest.rightArm()==null)return legacy;
        Matrix4f align=new Matrix4f(legacy.rightArm()).mul(new Matrix4f(rest.rightArm()).invert());
        Matrix4f delta=new Matrix4f(align).mul(pose.rightArm()).mul(new Matrix4f(legacy.rightArm()).invert());
        GunMesh.Frame moved=ModePose.transform(legacy,delta);
        return new GunMesh.Frame(moved.vertices(),pose.leftArm()==null?moved.leftArm():new Matrix4f(align).mul(pose.leftArm()),new Matrix4f(align).mul(pose.rightArm()),moved.muzzle(),moved.surfaces());
    }
}
