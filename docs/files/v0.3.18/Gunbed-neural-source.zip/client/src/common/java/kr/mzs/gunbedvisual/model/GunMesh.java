package kr.mzs.gunbedvisual.model;

import com.google.gson.*;
import org.joml.*;
import java.util.*;
import java.lang.Math;

/** Minecraft-independent mesh and pose evaluation, shared by every client build. */
public final class GunMesh {
    private static final Gson GSON=new Gson();
    private static final float RAD=(float)(Math.PI/180);
    private static final float[] ZERO={0,0,0}, ONE={1,1,1};
    private final LinkedHashMap<String,Bone> bones=new LinkedHashMap<>();
    private final Map<String,AnimationClip> clips=new HashMap<>();
    private final int width,height;
    private final SourceTriangleMesh triangles;
    private final Matrix4f idleInverse,aimInverse;
    private record Cube(BedrockCube geometry,Matrix4f transform) {}
    private static final class Bone {
        final String name,parent; final float[] pivot,rotation; final List<Cube> cubes=new ArrayList<>();
        Bone(JsonObject o) {name=o.get("name").getAsString();parent=o.has("parent")?o.get("parent").getAsString():null;pivot=vec(o,"pivot",ZERO);rotation=vec(o,"rotation",ZERO);}
    }
    private final boolean attachment;
    public GunMesh(JsonObject geo,JsonObject animations){this(geo,animations,false);}
    public GunMesh(JsonObject geo,JsonObject animations,boolean attachment) {
        this.attachment=attachment;
        if(geo.has("gunbed:source_mesh")){triangles=new SourceTriangleMesh(geo);width=height=1;idleInverse=new Matrix4f();aimInverse=new Matrix4f();for(var e:animations.getAsJsonObject("animations").entrySet())clips.put(e.getKey(),new AnimationClip(e.getValue().getAsJsonObject()));return;}
        triangles=null;
        JsonObject model=geo.getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject();
        JsonObject desc=model.getAsJsonObject("description");width=desc.get("texture_width").getAsInt();height=desc.get("texture_height").getAsInt();
        for(JsonElement e:model.getAsJsonArray("bones")){Bone b=new Bone(e.getAsJsonObject());bones.put(b.name,b);}
        for(JsonElement e:model.getAsJsonArray("bones")) {
            JsonObject o=e.getAsJsonObject();Bone bone=bones.get(o.get("name").getAsString());
            if(!o.has("cubes"))continue;
            for(JsonElement c:o.getAsJsonArray("cubes")) {
                JsonObject cube=c.getAsJsonObject();float[] origin=vec(cube,"origin",ZERO),size=vec(cube,"size",ZERO),pivot=cube.has("rotation")?vec(cube,"pivot",bone.pivot):bone.pivot;
                Matrix4f transform=new Matrix4f();
                if(cube.has("rotation")) {
                    float[] r=vec(cube,"rotation",ZERO);transform.translate((pivot[0]-bone.pivot[0])/16,(bone.pivot[1]-pivot[1])/16,(pivot[2]-bone.pivot[2])/16).rotateZYX(r[2]*RAD,r[1]*RAD,r[0]*RAD);
                }
                float x=origin[0]-pivot[0],y=pivot[1]-origin[1]-size[1],z=origin[2]-pivot[2],inflate=cube.has("inflate")?cube.get("inflate").getAsFloat():0;
                boolean mirror=cube.has("mirror")?cube.get("mirror").getAsBoolean():o.has("mirror")&&o.get("mirror").getAsBoolean();
                JsonElement uv=cube.get("uv");BedrockCube geometry;
                if(uv.isJsonObject())geometry=new BedrockCubePerFace(x,y,z,size[0],size[1],size[2],inflate,width,height,GSON.fromJson(uv,FaceUVsItem.class));
                else geometry=new BedrockCubeBox(uv.getAsJsonArray().get(0).getAsFloat(),uv.getAsJsonArray().get(1).getAsFloat(),x,y,z,size[0],size[1],size[2],inflate,mirror,width,height);
                bone.cubes.add(new Cube(geometry,transform));
            }
        }
        for(var e:animations.getAsJsonObject("animations").entrySet())clips.put(e.getKey(),new AnimationClip(e.getValue().getAsJsonObject()));
        var defaults=pose(null,0);
        idleInverse=new Matrix4f(defaults.getOrDefault("idle_view",new Matrix4f())).invert();
        aimInverse=new Matrix4f(defaults.getOrDefault("iron_view",defaults.getOrDefault("idle_view",new Matrix4f()))).invert();
    }
    public boolean hasClip(String name){return triangles!=null?triangles.has(name):clips.containsKey(name);}
    public double duration(String name){return clips.containsKey(name)?clips.get(name).duration:1;}
    public List<String> sounds(String clip,double from,double to){return clips.containsKey(clip)?clips.get(clip).sounds(from,to):List.of();}
    public record Frame(List<Vertex> vertices,Matrix4f leftArm,Matrix4f rightArm,Matrix4f muzzle,Map<String,List<Vertex>> surfaces) {public Frame(List<Vertex> vertices,Matrix4f leftArm,Matrix4f rightArm,Matrix4f muzzle){this(vertices,leftArm,rightArm,muzzle,Map.of());}}
    public record Vertex(float x,float y,float z,float u,float v,float nx,float ny,float nz) {}
    public Frame frame(String clip,double time,float aim) {
        if(triangles!=null)return triangles.frame(clip,time);
        Map<String,Matrix4f> current=pose(clip,time);
        Matrix4f view=new Matrix4f().rotationZ((float)Math.PI).mul(new Matrix4f(idleInverse).lerp(aimInverse,Math.max(0,Math.min(1,aim))));
        List<Vertex> vertices=new ArrayList<>();
        for(Bone bone:bones.values()) {
            if(hidden(bone.name,clip))continue;
            Matrix4f world=new Matrix4f(view).mul(current.get(bone.name));
            if(Math.abs(world.determinant())<1e-8)continue;
            for(Cube cube:bone.cubes) {
                MeshPose pose=new MeshPose(new Matrix4f(world).mul(cube.transform));
                cube.geometry.compile(pose,(x,y,z,color,u,v,overlay,light,nx,ny,nz)->vertices.add(new Vertex(x,y,z,u,v,nx,ny,nz)),0,0,1,1,1,1);
            }
        }
        Matrix4f left=arm(current,view,"lefthand_pos"),right=arm(current,view,"righthand_pos");
        Matrix4f muzzle=current.containsKey("muzzle_flash")?new Matrix4f(view).mul(current.get("muzzle_flash")):current.containsKey("muzzle_pos")?new Matrix4f(view).mul(current.get("muzzle_pos")):null;
        return new Frame(vertices,left,right,muzzle);
    }
    public static Frame flash(Matrix4f muzzle,float scale,float angle){Matrix4f transform=new Matrix4f(muzzle).rotateZ(angle);List<Vertex> vertices=new ArrayList<>();float half=scale*.45f;float[][] corners={{-half,-half,0,1},{half,-half,1,1},{half,half,1,0},{-half,half,0,0}};for(int i:new int[]{0,1,2,3,3,2,1,0}){float[] c=corners[i];Vector3f p=transform.transformPosition(new Vector3f(c[0],c[1],0));Vector3f n=transform.transformDirection(new Vector3f(0,0,1)).normalize();vertices.add(new Vertex(p.x,p.y,p.z,c[2],c[3],n.x,n.y,n.z));}return new Frame(vertices,null,null,null);}
    public Frame attach(Frame frame,String clip,double time,float aim,Frame attachment,String gunTexture,String texture){
        var current=pose(clip,time);Matrix4f mount=current.get("scope_pos");if(mount==null)return frame;
        Matrix4f transform=new Matrix4f().rotationZ((float)Math.PI).mul(new Matrix4f(idleInverse).lerp(aimInverse,Math.max(0,Math.min(1,aim)))).mul(mount).translate(0,-1.5f,0).rotateZ((float)Math.PI);
        List<Vertex> vertices=new ArrayList<>();Vector3f p=new Vector3f(),n=new Vector3f();for(Vertex v:attachment.vertices){transform.transformPosition(v.x,v.y,v.z,p);transform.transformDirection(v.nx,v.ny,v.nz,n).normalize();vertices.add(new Vertex(p.x,p.y,p.z,v.u,v.v,n.x,n.y,n.z));}
        Map<String,List<Vertex>> surfaces=new LinkedHashMap<>();surfaces.put(gunTexture,frame.vertices);surfaces.put(texture,vertices);return new Frame(frame.vertices,frame.leftArm,frame.rightArm,frame.muzzle,surfaces);
    }
    private Matrix4f arm(Map<String,Matrix4f> poses,Matrix4f view,String name) {
        return poses.containsKey(name)?new Matrix4f(view).mul(poses.get(name)).rotateZ((float)Math.PI):null;
    }
    private boolean hidden(String name,String clip) {
        if(attachment){boolean body=false;for(Bone b=bones.get(name);b!=null;b=b.parent==null?null:bones.get(b.parent))if(b.name.equals("scope_body"))body=true;return !body;}
        for(Bone bone=bones.get(name);bone!=null;bone=bone.parent==null?null:bones.get(bone.parent)) {
            String n=bone.name;
            // TaCZ replaces these placeholder cubes with the player's skin renderer.
            if(n.equals("lefthand_pos")||n.equals("righthand_pos"))return true;
            if(n.startsWith("mag_extended") || n.equals("sight_folded") || n.equals("mount") || n.equals("handguard_tactical"))return true;
            if((n.equals("mag_additional")||n.equals("additional_magazine")) && (clip==null||!clip.startsWith("reload")))return true;
        }
        return false;
    }
    private Map<String,Matrix4f> pose(String name,double time) {
        var result=new HashMap<String,Matrix4f>();
        for(String bone:bones.keySet())matrix(bone,name,time,result,new HashSet<>());
        return result;
    }
    private Matrix4f matrix(String name,String clip,double time,Map<String,Matrix4f> cache,Set<String> visiting) {
        if(cache.containsKey(name))return cache.get(name);
        if(!visiting.add(name))throw new IllegalArgumentException("Cyclic bone hierarchy");
        Bone bone=bones.get(name);Bone parent=bone.parent==null?null:bones.get(bone.parent);
        Matrix4f matrix=parent==null?new Matrix4f():new Matrix4f(matrix(parent.name,clip,time,cache,visiting));
        float px=parent==null?0:parent.pivot[0],py=parent==null?24:parent.pivot[1],pz=parent==null?0:parent.pivot[2];
        float[] position=channel(bone.name,"position",clip,time,ZERO),rotation=channel(bone.name,"rotation",clip,time,ZERO),scale=channel(bone.name,"scale",clip,time,ONE);
        matrix.translate((bone.pivot[0]-px+position[0])/16,(py-bone.pivot[1]-position[1])/16,(bone.pivot[2]-pz+position[2])/16)
                .rotateZYX(bone.rotation[2]*RAD,bone.rotation[1]*RAD,bone.rotation[0]*RAD)
                .rotateZYX(rotation[2]*RAD,rotation[1]*RAD,rotation[0]*RAD).scale(scale[0],scale[1],scale[2]);
        cache.put(name,matrix);visiting.remove(name);return matrix;
    }
    private float[] channel(String bone,String channel,String action,double time,float[] fallback) {
        AnimationClip idle=clips.get("static_idle");float[] base=idle==null?fallback:idle.sample(bone,channel,0,fallback);
        AnimationClip clip=action==null?null:clips.get(action);
        return clip==null?base:clip.sample(bone,channel,time,base);
    }
    private static float[] vec(JsonObject object,String key,float[] fallback) {
        if(!object.has(key))return fallback.clone();JsonArray a=object.getAsJsonArray(key);return new float[]{a.get(0).getAsFloat(),a.get(1).getAsFloat(),a.get(2).getAsFloat()};
    }
}
