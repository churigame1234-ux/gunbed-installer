package kr.mzs.gunbedvisual;

import java.util.*;

/** Track pack generations so a proxy transition never removes another backend's replacement. */
public final class PackOwnership {
    private static final Map<UUID,Integer> generations=new HashMap<>();
    private static final Map<UUID,String> urls=new HashMap<>();
    private static UUID owned,pending;
    private static int remaining,generation,ownedGeneration;
    private static long lastConfirm;
    public static void pushed(UUID id,String url){generations.merge(id,1,Integer::sum);urls.put(id,url);}
    public static void confirm(String id,String url){try{UUID next=UUID.fromString(id);if(urls.containsKey(next)&&!urls.get(next).equals(url))return;owned=next;ownedGeneration=generations.getOrDefault(next,0);lastConfirm=System.nanoTime();remaining=0;pending=null;}catch(IllegalArgumentException ignored){}}
    public static void transition(){if(owned!=null){pending=owned;generation=ownedGeneration;remaining=40;}}
    public static UUID tick(){if(owned!=null&&remaining==0&&System.nanoTime()-lastConfirm>10_000_000_000L){pending=owned;generation=ownedGeneration;remaining=1;}if(remaining==0||--remaining>0)return null;UUID remove=pending;pending=null;owned=null;return remove!=null&&generation==generations.getOrDefault(remove,0)?remove:null;}
    public static void clear(){owned=null;pending=null;remaining=0;generations.clear();urls.clear();}
}
