// Adapted from TACZ-FabricContinued, GPL-3.0; see client/THIRD-PARTY.md.
package kr.mzs.gunbedvisual.model;




public interface BedrockCube {
    void compile(MeshPose pose, VertexSink consumer, int light, int overlay, float red, float green, float blue, float alpha);
}
