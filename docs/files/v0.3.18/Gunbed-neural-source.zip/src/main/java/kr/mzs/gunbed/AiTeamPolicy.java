package kr.mzs.gunbed;
import java.util.*;

/** Pure composition sampler. Collector exclusivity is structural, not an index convention. */
final class AiTeamPolicy {
    // 0 rush, 1 diamonds, 2 emeralds, 3 both, 4 defence
    static int[] sample(int size,boolean early,Random random){
        if(size<1||size>8)throw new IllegalArgumentException("AI team size must be 1..8");
        if(size==1)return new int[]{0};
        List<int[]> candidates=new ArrayList<>();List<Double> weights=new ArrayList<>();double total=0;
        for(int d=0;d<=1;d++)for(int e=0;e<=1;e++)for(int both=0;both<=1;both++){
            if(both==1&&(d>0||e>0))continue;
            for(int defense=0;defense<=size-d-e-both;defense++){
                int rush=size-d-e-both-defense;if(rush<1)continue;
                int[] composition={rush,d,e,both,defense};
                double weight=Math.pow(early?3.2:1.7,rush)/(1+defense*.7);
                candidates.add(composition);weights.add(weight);total+=weight;
            }
        }
        double draw=random.nextDouble()*total;int[] choice=candidates.getLast();for(int i=0;i<candidates.size();i++){draw-=weights.get(i);if(draw<=0){choice=candidates.get(i);break;}}
        List<Integer> roles=new ArrayList<>();for(int i=0;i<5;i++)for(int j=0;j<choice[i];j++)roles.add(i);Collections.shuffle(roles,random);return roles.stream().mapToInt(Integer::intValue).toArray();
    }
}
