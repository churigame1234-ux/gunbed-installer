package kr.mzs.gunbed;

import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.game.Game;

/** Arena waypoints, committed fly-through attacks, and smooth recovery turns. */
final class DragonFlightMotion {
    static final Map<UUID,State> states=new HashMap<>();
    static final class State {
        int phase,until,waypoint,dives; Location goal; Vector velocity=new Vector(); double distance;
    }
    static Location advance(EnderDragon dragon,Location center,int index,List<Player> targets,int tick,Game game) {
        if(tick%100==0)states.keySet().removeIf(id->{Entity e=Bukkit.getEntity(id);return e==null||!e.isValid()||e.isDead();});
        State s=states.computeIfAbsent(dragon.getUniqueId(),id->new State());
        Location at=dragon.getLocation(); double radius=32;
        for(var team:game.getRunningTeams())radius=Math.max(radius,Math.hypot(team.getTeamSpawn().getX()-center.getX(),team.getTeamSpawn().getZ()-center.getZ()));
        radius=Math.min(110,radius);
        if(s.until==0){s.phase=0;s.until=tick+120+index%4*20;}
        if(tick>=s.until) {
            s.phase=(s.phase+1)%4;
            if(targets.isEmpty())s.phase=0;
            s.until=tick+switch(s.phase){case 0->140;case 1->55;case 2->70;default->65;};
            s.goal=null;
        }
        if(s.phase==0&&(s.goal==null||tick>=s.waypoint||at.distanceSquared(s.goal)<64)) {
            double angle=tick*.009+index*2.4;
            s.goal=center.clone().add(Math.cos(angle)*radius,4+Math.sin(angle*.8)*5,Math.sin(angle)*radius);
            s.waypoint=tick+65;
        } else if(s.phase==1&&!targets.isEmpty()) {
            Player target=targets.get(Math.floorMod(index+s.dives,targets.size()));
            Vector side=at.toVector().subtract(target.getLocation().toVector()).setY(0);
            if(side.lengthSquared()<.1)side=new Vector(1,0,0);
            s.goal=target.getLocation().add(side.normalize().multiply(18)).add(0,15,0);
            if(at.distanceSquared(s.goal)<36){s.until=tick;}
        } else if(s.phase==2&&s.goal==null&&!targets.isEmpty()) {
            Location target=targets.get(Math.floorMod(index+s.dives,targets.size())).getLocation().add(0,1.5,0);
            Vector through=target.toVector().subtract(at.toVector());
            if(through.lengthSquared()<.1)through=new Vector(1,0,0);
            s.goal=target.add(through.normalize().multiply(22));s.dives++;
            dragon.getWorld().playSound(at,Sound.ENTITY_ENDER_DRAGON_GROWL,.65f,.85f);
        } else if(s.phase==3&&s.goal==null) {
            Vector ahead=s.velocity.clone().setY(0);
            if(ahead.lengthSquared()<.1)ahead=new Vector(1,0,0);
            s.goal=at.clone().add(ahead.normalize().multiply(28));s.goal.setY(center.getY()+12);
        }
        if(s.goal==null)s.goal=center.clone();
        // Keep waypoints inside this arena; never load or damage other maps.
        Location lo=game.getPos1(),hi=game.getPos2();
        s.goal.setX(clamp(s.goal.getX(),Math.min(lo.getX(),hi.getX())+5,Math.max(lo.getX(),hi.getX())-5));
        s.goal.setZ(clamp(s.goal.getZ(),Math.min(lo.getZ(),hi.getZ())+5,Math.max(lo.getZ(),hi.getZ())-5));
        s.goal.setY(clamp(s.goal.getY(),Math.min(lo.getY(),hi.getY())+4,Math.max(lo.getY(),hi.getY())-4));
        Vector desired=s.goal.toVector().subtract(at.toVector());
        double speed=s.phase==2?1.25:.8;
        if(desired.lengthSquared()>.01)desired.normalize().multiply(speed);
        s.velocity.multiply(.88).add(desired.multiply(.12));
        Location next=at.clone().add(s.velocity);s.distance+=s.velocity.length();
        if(s.velocity.lengthSquared()>.001)next.setDirection(s.velocity);
        return next;
    }
    private static double clamp(double n,double min,double max){return Math.max(min,Math.min(max,n));}
}
