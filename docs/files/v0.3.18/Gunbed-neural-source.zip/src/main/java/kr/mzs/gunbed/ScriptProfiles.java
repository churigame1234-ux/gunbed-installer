package kr.mzs.gunbed;

import com.google.gson.*;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.screamingsandals.bedwars.api.events.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Typed identity/XP data and chat snapshots; no Skript runtime or delayed variable lookups. */
final class ScriptProfiles implements Listener {
    private final GunbedCore plugin;
    private final Map<UUID,String> prefixes=new ConcurrentHashMap<>();
    private final File catalogFile;
    private final YamlConfiguration catalog;
    private record Titles(List<String> names) implements InventoryHolder {public Inventory getInventory(){throw new UnsupportedOperationException();}}
    private static final long[] THRESHOLDS={0,500,1000,3000,4500,9000,30000,50000,70000,100000,150000,300000,600000,1000000,3000000,7000000,10000000,50000000,100000000};
    private static final String[] RANKS={"신입","왕초보","초보","초보+","중수","중수+","고수","고수+","초고수","초고수+","Killer","Great Killer","Agile Killer","Brave Killer","Ambitious Killer","Ambitious Killer+","Versatile Killer","Versatile Killer+","Versatile Killer++"};
    ScriptProfiles(GunbedCore p){
        plugin=p;catalogFile=new File(p.getDataFolder(),"identity-titles.yml");catalog=YamlConfiguration.loadConfiguration(catalogFile);importData();
        Bukkit.getPluginManager().registerEvents(this,p);
        for(String name:List.of("rank","경험치","칭호","nickset","nickdel","nickdelcon","teamchat","참가","ㅈ","ㄱ"))Objects.requireNonNull(p.getCommand(name)).setExecutor(this::command);
        for(Player player:Bukkit.getOnlinePlayers())cache(player);Bukkit.getScheduler().runTaskTimer(plugin,()->Bukkit.getOnlinePlayers().forEach(this::cache),100,100);
    }
    private void importData(){
        var file=plugin.getDataFolder().toPath().resolve("script-profiles.json");if(!Files.exists(file))return;
        try(var reader=Files.newBufferedReader(file,StandardCharsets.UTF_8)){
            var root=JsonParser.parseReader(reader).getAsJsonObject();
            for(var entry:root.getAsJsonObject("players").entrySet()){
                UUID id=UUID.fromString(entry.getKey());if(plugin.profiles.get(id).getBoolean("identity.imported",false))continue;
                JsonObject data=entry.getValue().getAsJsonObject();boolean reset=plugin.getConfig().getBoolean("levels.reset-legacy-identity",false);
                for(String key:List.of("xp","title","nickname"))if((!reset||key.equals("nickname"))&&data.has(key)&&!plugin.profiles.get(id).contains("identity."+key))plugin.profiles.set(id,"identity."+key,key.equals("xp")?data.get(key).getAsLong():data.get(key).getAsString());
                List<String> owned=new ArrayList<>(plugin.profiles.get(id).getStringList("identity.titles"));if(!reset&&data.has("titles"))for(JsonElement title:data.getAsJsonArray("titles"))if(!owned.contains(title.getAsString()))owned.add(title.getAsString());
                plugin.profiles.set(id,"identity.titles",owned);plugin.profiles.set(id,"identity.imported",true);
            }
            if(!catalog.getBoolean("legacy-imported",false)){
                List<String> titles=new ArrayList<>(catalog.getStringList("titles"));if(!plugin.getConfig().getBoolean("levels.reset-legacy-identity",false))for(JsonElement value:root.getAsJsonArray("titles"))if(!titles.contains(value.getAsString()))titles.add(value.getAsString());catalog.set("titles",titles);catalog.set("legacy-imported",true);saveCatalog();
            }
            if(!plugin.profiles.saved())throw new IOException("Identity import did not finish saving");
        }catch(IOException|RuntimeException e){throw new IllegalStateException("Could not import script identities; source data was preserved",e);}
    }
    private void saveCatalog(){try{catalog.save(catalogFile);}catch(IOException e){throw new UncheckedIOException(e);}}
    long xp(UUID id){return plugin.levels.xp(id);}
    private int rank(UUID id){return plugin.levels.level(id);}
    private void add(Player p,long value){plugin.profiles.set(p.getUniqueId(),"bedwars-levels.xp",Math.addExact(xp(p.getUniqueId()),value));cache(p);}
    private void cache(Player p){p.displayName(TeamPalette.name(p));UUID id=p.getUniqueId();String title=plugin.profiles.get(id).getString("identity.title","");prefixes.put(id,plugin.levels.badge(id)+(title.isBlank()?"":ChatColor.translateAlternateColorCodes('&',title)+" ")+"§r");}
    @EventHandler public void join(PlayerJoinEvent e){cache(e.getPlayer());}
    @EventHandler public void quit(PlayerQuitEvent e){prefixes.remove(e.getPlayer().getUniqueId());}
    @EventHandler(priority=EventPriority.HIGH,ignoreCancelled=true)public void chat(AsyncPlayerChatEvent e){String name=net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().serialize(TeamPalette.name(e.getPlayer()));e.setFormat((prefixes.getOrDefault(e.getPlayer().getUniqueId(),"§e[신입] §r")+name+"§f » ").replace("%","%%")+"%2$s");}
    private OfflinePlayer known(String name){Player live=Bukkit.getPlayerExact(name);if(live!=null)return live;return Arrays.stream(Bukkit.getOfflinePlayers()).filter(p->name.equalsIgnoreCase(p.getName())).findFirst().orElse(null);}
    private void showTitles(Player p){List<String> names=plugin.profiles.get(p.getUniqueId()).getStringList("identity.titles");Inventory inv=Bukkit.createInventory(new Titles(List.copyOf(names)),54,"내 칭호");inv.setItem(0,label(Material.ARROW,"§c장착 해제"));for(int i=0;i<Math.min(53,names.size());i++)inv.setItem(i+1,label(Material.BOOK,names.get(i)));p.openInventory(inv);}
    private ItemStack label(Material type,String value){ItemStack item=new ItemStack(type);var meta=item.getItemMeta();meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',value));item.setItemMeta(meta);return item;}
    @EventHandler public void click(InventoryClickEvent e){if(!(e.getView().getTopInventory().getHolder() instanceof Titles menu))return;e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p)||e.getRawSlot()<0||e.getRawSlot()>=54)return;int i=e.getRawSlot()-1;if(i>=menu.names.size())return;plugin.profiles.set(p.getUniqueId(),"identity.title",i<0?"":menu.names.get(i));cache(p);p.closeInventory();p.sendMessage("§a칭호를 변경했습니다.");}
    @EventHandler public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof Titles)e.setCancelled(true);}
    private boolean command(CommandSender sender,Command command,String label,String[] args){
        String name=command.getName();
        try{
            if(sender instanceof Player p){
                if(name.equals("참가")){plugin.bedwars.quickJoin(p);return true;}
                if(name.equals("ㅈ")||name.equals("ㄱ")){p.performCommand((name.equals("ㅈ")?"essentials:msg ":"essentials:r ")+String.join(" ",args));return true;}
                if(name.equals("teamchat")){var game=org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getGameOfPlayer(p);var team=game==null?null:game.getTeamOfPlayer(p);if(team==null||args.length==0){p.sendMessage("§e/tc <내용> · 경기 팀원에게만 전달합니다.");return true;}var line=net.kyori.adventure.text.Component.text("[TEAM] ",net.kyori.adventure.text.format.NamedTextColor.AQUA).append(TeamPalette.name(p)).append(net.kyori.adventure.text.Component.text(" » "+String.join(" ",args),net.kyori.adventure.text.format.NamedTextColor.WHITE));for(Player recipient:game.getConnectedPlayers())if(team.isPlayerInTeam(recipient))recipient.sendMessage(line);return true;}
            }
            if(name.equals("rank")&&sender instanceof Player p){p.sendMessage(plugin.levels.badge(p.getUniqueId())+"§7경험치 "+xp(p.getUniqueId())+" · 다음 레벨까지 "+BedwarsLevels.next(xp(p.getUniqueId())));return true;}
            if(name.equals("칭호")&&(args.length==0||args[0].equals("설정"))&&sender instanceof Player p){showTitles(p);return true;}
            if(name.equals("nickset")&&sender instanceof Player p){if(!p.hasPermission("mzs.닉네임")&&!plugin.points.owns(p.getUniqueId(),"cosmetic:nickname")){p.sendMessage("§c권한이 없습니다.");return true;}String nick=args.length==0?"":String.join(" ",args);if(nick.codePointCount(0,nick.length())>16||nick.chars().anyMatch(Character::isISOControl))throw new IllegalArgumentException("닉네임은 16자 이내로 입력하세요.");plugin.profiles.set(p.getUniqueId(),"identity.nickname",nick);p.sendMessage("§a닉네임을 변경했습니다.");return true;}
            if(!sender.hasPermission("gunbedcore.admin")){sender.sendMessage("§c운영자 전용입니다.");return true;}
            if(name.startsWith("nickdel")){if(args.length!=1)throw new IllegalArgumentException("/"+name+" <플레이어>");OfflinePlayer target=known(args[0]);if(target==null)throw new IllegalArgumentException("접속 기록이 있는 플레이어를 입력하세요.");plugin.profiles.set(target.getUniqueId(),"identity.nickname","");Bukkit.dispatchCommand(Bukkit.getConsoleSender(),"essentials:nick "+target.getName()+" off");return true;}
            if(name.equals("경험치")){if(args.length!=3||!Set.of("지급","차감").contains(args[0]))throw new IllegalArgumentException("/경험치 <지급|차감> <플레이어> <수량>");OfflinePlayer target=known(args[1]);if(target==null)throw new IllegalArgumentException("플레이어를 찾을 수 없습니다.");long amount=Long.parseLong(args[2]);if(amount<1||amount>1_000_000_000L)throw new IllegalArgumentException("수량은 1~1,000,000,000입니다.");UUID id=target.getUniqueId();plugin.profiles.set(id,"bedwars-levels.xp",args[0].equals("지급")?Math.addExact(xp(id),amount):Math.max(0,xp(id)-amount));if(target.isOnline())cache(target.getPlayer());sender.sendMessage("§a경험치를 변경했습니다: "+xp(id));return true;}
            if(name.equals("칭호")){
                List<String> titles=new ArrayList<>(catalog.getStringList("titles"));
                if(args.length==1&&args[0].equals("목록")){for(int i=0;i<titles.size();i++)sender.sendMessage((i+1)+". "+titles.get(i));return true;}
                if(args.length==2&&args[0].equals("생성")){String value=ChatColor.translateAlternateColorCodes('&',args[1].replace('_',' '));if(value.length()>80)throw new IllegalArgumentException("칭호가 너무 깁니다.");if(!titles.contains(value))titles.add(value);catalog.set("titles",titles);saveCatalog();return true;}
                if(args.length==3&&Set.of("지급","삭제").contains(args[0])){int index=Integer.parseInt(args[1])-1;if(index<0||index>=titles.size())throw new IllegalArgumentException("칭호 목록의 번호를 입력하세요.");OfflinePlayer target=known(args[2]);if(target==null)throw new IllegalArgumentException("플레이어를 찾을 수 없습니다.");List<String> owned=new ArrayList<>(plugin.profiles.get(target.getUniqueId()).getStringList("identity.titles"));String title=titles.get(index);if(args[0].equals("지급")){if(!owned.contains(title))owned.add(title);}else{owned.remove(title);if(plugin.profiles.get(target.getUniqueId()).getString("identity.title","").equals(title))plugin.profiles.set(target.getUniqueId(),"identity.title","");}plugin.profiles.set(target.getUniqueId(),"identity.titles",owned);if(target.isOnline())cache(target.getPlayer());return true;}
                throw new IllegalArgumentException("/칭호 설정 | 목록 | 생성 <이름> | 지급/삭제 <번호> <플레이어>");
            }
        }catch(IllegalArgumentException|ArithmeticException e){sender.sendMessage("§c"+e.getMessage());}
        return true;
    }
}
