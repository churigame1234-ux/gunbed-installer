package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import java.util.*;

/** Cancelling damage alone is insufficient: skip friendly impacts before the gun engine sees them. */
final class FriendlyProjectiles implements Listener,AutoCloseable {
    private final GunbedCore plugin;
    FriendlyProjectiles(GunbedCore p){plugin=p;if(p.visuals!=null)for(var l:ProjectileHitEvent.getHandlerList().getRegisteredListeners())if(l.getPlugin()==p.visuals.cs.getHandle())ProjectileHitEvent.getHandlerList().unregister(l);Bukkit.getPluginManager().registerEvents(this,p);}
    static boolean ally(Player a,Entity entity){if(!(entity instanceof Player b))return false;if(a.equals(b))return true;var api=BedwarsAPI.getInstance();var g=api.getGameOfPlayer(a);return g!=null&&g==api.getGameOfPlayer(b)&&g.getTeamOfPlayer(a)!=null&&g.getTeamOfPlayer(a)==g.getTeamOfPlayer(b);}
    static boolean hittable(Player a,Entity entity){return entity!=a&&!ally(a,entity)&&(!(entity instanceof Player p)||p.getGameMode()!=GameMode.SPECTATOR);}
    @EventHandler(priority=EventPriority.LOWEST)public void pass(ProjectileHitEvent e){if(e.getEntity().getShooter() instanceof Player p&&ally(p,e.getHitEntity()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.NORMAL,ignoreCancelled=true)public void crackshot(ProjectileHitEvent e){if(plugin.visuals!=null){DragonCrackShotImpact.impact(plugin,e);plugin.visuals.cs.getHandle().onProjectileHit(e);}}
    @EventHandler(priority=EventPriority.LOWEST)public void damage(EntityDamageByEntityEvent e){if(e.getDamager() instanceof Projectile q&&q.getShooter() instanceof Player p&&ally(p,e.getEntity()))e.setCancelled(true);}
    @Override public void close(){}
}
