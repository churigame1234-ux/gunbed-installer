package kr.mzs.gunbed;
import com.google.gson.*;
import org.bukkit.*;
import java.nio.file.*;
import java.util.*;

/** Public game results only. Never exports balances, ownership, IPs or account UUIDs. */
final class PublicStatistics implements AutoCloseable {
    private final GunbedCore plugin;
    private final java.util.concurrent.ExecutorService writer=java.util.concurrent.Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"Gunbed public statistics");t.setDaemon(true);return t;});
    PublicStatistics(GunbedCore p){plugin=p;Bukkit.getScheduler().runTaskTimer(p,this::export,200,1200);}
    private void export(){JsonArray rows=new JsonArray();var manager=org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getStatisticsManager();for(OfflinePlayer player:Bukkit.getOfflinePlayers()){if(player.getName()==null||player.getName().startsWith("GBProbe"))continue;var stats=manager.getStatistic(player.getUniqueId());var profile=plugin.profiles.get(player.getUniqueId());JsonObject row=new JsonObject();row.addProperty("name",player.getName());row.addProperty("nickname",profile.getString("identity.nickname",""));row.addProperty("level",plugin.levels.level(player.getUniqueId()));row.addProperty("xp",plugin.levels.xp(player.getUniqueId()));row.addProperty("kills",stats==null?0:stats.getKills());row.addProperty("finals",plugin.bedwars.extra(player,"final_kills"));row.addProperty("finalDeaths",plugin.bedwars.extra(player,"final_deaths"));row.addProperty("deaths",stats==null?0:stats.getDeaths());row.addProperty("wins",stats==null?0:stats.getWins());row.addProperty("losses",stats==null?0:stats.getLoses());row.addProperty("games",stats==null?0:stats.getGames());row.addProperty("beds",stats==null?0:stats.getDestroyedBeds());row.addProperty("headshots",profile.getLong("combat.headshots",0));row.addProperty("headshotKills",profile.getLong("combat.headshot-kills",0));row.addProperty("parkourMs",profile.getLong("parkour.best-ms",0));rows.add(row);}JsonObject root=new JsonObject();root.addProperty("schema",1);root.addProperty("server","mzs123.mcv.kr");root.add("players",rows);String text=root.toString();writer.submit(()->{try{Path file=plugin.getDataFolder().toPath().resolve("web-public/server.json");Files.createDirectories(file.getParent());Path temp=file.resolveSibling("server.tmp");Files.writeString(temp,text);Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);}catch(java.io.IOException e){plugin.getLogger().warning("Public stats export failed: "+e.getMessage());}});}
    @Override public void close(){writer.shutdown();try{writer.awaitTermination(5,java.util.concurrent.TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
}
