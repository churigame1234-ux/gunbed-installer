package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.events.BedwarsGameEndEvent;
import org.screamingsandals.bedwars.api.game.Game;
import java.util.*;

/** Observations are evidence, not permission to read a hidden enemy's live position. */
final class AiPerception implements Listener {
    record Seen(Location point,int tick,String cue){}
    record Threat(UUID entity,int tick,Location point){}
    record Alarm(Location point,int until,Set<UUID> responders){}
    private final GunbedCore plugin;private final AiBrain brain;
    private final Map<UUID,Map<UUID,Seen>> sightings=new HashMap<>();
    private final Map<UUID,Threat> incoming=new HashMap<>();
    private final Map<Game,Map<String,Alarm>> alarms=new HashMap<>();
    AiPerception(GunbedCore p,AiBrain b){plugin=p;brain=b;Bukkit.getPluginManager().registerEvents(this,p);}
    boolean view(Player observer,Location point,boolean peripheral){
        if(observer.getWorld()!=point.getWorld()||observer.getEyeLocation().distanceSquared(point)>16384)return false;
        Vector delta=point.toVector().subtract(observer.getEyeLocation().toVector());
        Vector flat=delta.clone().setY(0),facing=observer.getEyeLocation().getDirection().setY(0);return (peripheral||flat.lengthSquared()<1||facing.lengthSquared()<.01||facing.angle(flat)<Math.toRadians(80))&&AiTerrain.visible(observer.getEyeLocation(),point);
    }
    private void remember(Player bot,LivingEntity target,Location point,String cue){
        var memory=sightings.computeIfAbsent(bot.getUniqueId(),k->new HashMap<>());Seen old=memory.put(target.getUniqueId(),new Seen(point.clone(),Bukkit.getCurrentTick(),cue));
        if(old==null||!old.cue.equals(cue)||Bukkit.getCurrentTick()-old.tick>20)plugin.learning.telemetry.record(bot,"sighting",Map.of("target",target.getUniqueId().toString(),"type",target.getType().name(),"cue",cue,"point",List.of(point.getX(),point.getY(),point.getZ())));
        memory.entrySet().removeIf(e->Bukkit.getCurrentTick()-e.getValue().tick>100);
    }
    void particle(Player target,Location at,String cue){
        Game game=BedwarsAPI.getInstance().getGameOfPlayer(target);if(game==null)return;
        for(AiBrain.State s:brain.all())if(s.room.game==game){Player bot=s.bot.getPlayer();if(!FriendlyProjectiles.ally(bot,target)&&view(bot,at,false))remember(bot,target,at.clone().add(0,.7,0),cue);}
    }
    LivingEntity enemy(AiBrain.State s){
        Player p=s.bot.getPlayer();Game g=s.room.game;var own=g.getTeamOfPlayer(p);if(own==null)return null;
        Set<LivingEntity> candidates=new LinkedHashSet<>(p.getWorld().getNearbyLivingEntities(p.getLocation(),48));candidates.addAll(g.getConnectedPlayers());candidates.addAll(plugin.turrets.bodies(g));
        LivingEntity best=null;double bestScore=Double.MAX_VALUE;int tick=Bukkit.getCurrentTick();
        for(LivingEntity q:candidates){if(q==p||q.isDead()||!q.isValid()||q.getWorld()!=p.getWorld()||q instanceof Player player&&player.getGameMode()==GameMode.SPECTATOR)continue;
            String team=BattleTargets.team(plugin,g,q);if(team==null||team.equals(own.getName()))continue;
            double distance=p.getLocation().distanceSquared(q.getLocation());if(distance>16384)continue;
            Threat threat=incoming.get(p.getUniqueId());boolean retaliation=threat!=null&&threat.entity.equals(q.getUniqueId())&&tick-threat.tick<80;
            boolean hidden=q instanceof Player player&&(player.isInvisible()||player.hasPotionEffect(PotionEffectType.INVISIBILITY));
            boolean visible=view(p,q.getEyeLocation(),false);if(!visible&&!hidden&&retaliation&&AiTerrain.visible(p.getEyeLocation(),q.getEyeLocation())){brain.look(s,q.getEyeLocation());visible=true;}
            if(hidden){Player player=(Player)q;boolean item=!player.getInventory().getItemInMainHand().getType().isAir()||!player.getInventory().getItemInOffHand().getType().isAir();
                Seen seen=sightings.getOrDefault(p.getUniqueId(),Map.of()).get(q.getUniqueId());
                if(item&&visible)remember(p,q,q.getEyeLocation(),"visible-held-item");else if(seen==null||tick-seen.tick>4||!view(p,seen.point,false))continue;
                // A fresh particle/item observation permits a short shot, never remote tracking.
                if(!AiTerrain.visible(p.getEyeLocation(),q.getEyeLocation()))continue;
            }else{
                if(!visible){if(retaliation&&AiTerrain.visible(p.getEyeLocation(),q.getEyeLocation())){s.reason="turn-toward-attacker";brain.look(s,q.getEyeLocation());}continue;}
                remember(p,q,q.getEyeLocation(),"visible-body");
            }
            double score=Math.sqrt(distance)-(retaliation?65:0)-(q.getLocation().distanceSquared(own.getTargetBlock())<324?45:0);
            if(s.combat.target!=null&&s.combat.target.equals(q.getUniqueId()))score-=3;
            if(score<bestScore){best=q;bestScore=score;}
        }
        return best;
    }
    Location lastKnown(AiBrain.State s,int age){Player p=s.bot.getPlayer();var records=sightings.getOrDefault(p.getUniqueId(),Map.of());return records.entrySet().stream().filter(e->Bukkit.getCurrentTick()-e.getValue().tick<=age&&Bukkit.getPlayer(e.getKey())!=null&&!Bukkit.getPlayer(e.getKey()).isDead()&&Bukkit.getPlayer(e.getKey()).getGameMode()!=GameMode.SPECTATOR&&BattleTargets.team(plugin,s.room.game,Bukkit.getPlayer(e.getKey()))!=null&&!FriendlyProjectiles.ally(p,Bukkit.getPlayer(e.getKey()))).max(Comparator.comparingInt(e->e.getValue().tick)).map(e->e.getValue().point.clone()).orElse(null);}
    Location incomingPoint(AiBrain.State s){Threat hit=incoming.get(s.bot.getPlayer().getUniqueId());return hit!=null&&Bukkit.getCurrentTick()-hit.tick<80?hit.point.clone():null;}
    boolean threatening(AiBrain.State s,LivingEntity target){if(target==null)return false;Player p=s.bot.getPlayer();var own=s.room.game.getTeamOfPlayer(p);Threat hit=incoming.get(p.getUniqueId());return p.getLocation().distanceSquared(target.getLocation())<144||hit!=null&&hit.entity.equals(target.getUniqueId())&&Bukkit.getCurrentTick()-hit.tick<80||own!=null&&target.getLocation().distanceSquared(own.getTargetBlock())<324;}
    Alarm alarm(AiBrain.State s){var team=s.room.game.getTeamOfPlayer(s.bot.getPlayer());if(team==null)return null;Alarm a=alarms.getOrDefault(s.room.game,Map.of()).get(team.getName());return a!=null&&Bukkit.getCurrentTick()<a.until&&a.responders.contains(s.bot.getPlayer().getUniqueId())?a:null;}
    List<Location> teamObserved(AiBrain.State source,int maxAge){List<Location> out=new ArrayList<>();int tick=Bukkit.getCurrentTick();for(var s:brain.all())if(s.room==source.room)for(var seen:sightings.getOrDefault(s.bot.getPlayer().getUniqueId(),Map.of()).values())if(tick-seen.tick<=maxAge)out.add(seen.point.clone());return out;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void drink(PlayerItemConsumeEvent e){
        if(!(e.getItem().getItemMeta() instanceof PotionMeta meta)||meta.getCustomEffects().stream().noneMatch(effect->effect.getType().equals(PotionEffectType.INVISIBILITY)))return;
        Player target=e.getPlayer();Game g=BedwarsAPI.getInstance().getGameOfPlayer(target);if(g==null)return;
        Map<String,List<AiBrain.State>> teams=new HashMap<>();
        for(var s:brain.all())if(s.room.game==g&&!FriendlyProjectiles.ally(s.bot.getPlayer(),target)&&view(s.bot.getPlayer(),target.getEyeLocation(),false)){var team=g.getTeamOfPlayer(s.bot.getPlayer());if(team!=null)teams.computeIfAbsent(team.getName(),k->new ArrayList<>()).add(s);remember(s.bot.getPlayer(),target,target.getEyeLocation(),"witnessed-invisibility-drink");}
        for(String team:teams.keySet()){Location bed=g.getTeamFromName(team).getTargetBlock();Set<UUID> responders=new LinkedHashSet<>();brain.all().stream().filter(s->s.room.game==g&&g.getTeamOfPlayer(s.bot.getPlayer())!=null&&g.getTeamOfPlayer(s.bot.getPlayer()).getName().equals(team)&&!s.bot.getPlayer().isDead()&&s.bot.getPlayer().getGameMode()!=GameMode.SPECTATOR).sorted(Comparator.comparingDouble(s->s.bot.getPlayer().getLocation().distanceSquared(bed))).limit(2).forEach(s->responders.add(s.bot.getPlayer().getUniqueId()));alarms.computeIfAbsent(g,k->new HashMap<>()).put(team,new Alarm(target.getLocation().clone(),Bukkit.getCurrentTick()+400,responders));for(var witness:teams.get(team))plugin.learning.telemetry.record(witness.bot.getPlayer(),"invisibility-alarm",Map.of("responders",responders.size(),"lastSeen",List.of(target.getX(),target.getY(),target.getZ())));}
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void hit(EntityDamageByEntityEvent e){if(!(e.getEntity() instanceof Player p)||!BotRuntime.bot(p)||e.getFinalDamage()<=0)return;Entity source=e.getDamager();if(source instanceof Projectile shot&&shot.getShooter() instanceof Entity owner)source=owner;Entity turret=plugin.turrets.attackingBody();if(turret!=null)source=turret;LivingEntity enemy=BattleTargets.living(source);if(enemy!=null){incoming.put(p.getUniqueId(),new Threat(enemy.getUniqueId(),Bukkit.getCurrentTick(),enemy.getEyeLocation().clone()));if(source instanceof Player attacker&&!BotRuntime.bot(attacker)&&e.getFinalDamage()>=p.getHealth()){String gun=AiGuns.damageId(plugin,attacker,e.getDamager());brain.all().stream().filter(s->s.bot.getPlayer()==p).forEach(s->s.plan.lastKiller=gun);}}}
    @EventHandler public void end(BedwarsGameEndEvent e){alarms.remove(e.getGame());for(Player p:e.getGame().getConnectedPlayers()){sightings.remove(p.getUniqueId());incoming.remove(p.getUniqueId());}}
}


