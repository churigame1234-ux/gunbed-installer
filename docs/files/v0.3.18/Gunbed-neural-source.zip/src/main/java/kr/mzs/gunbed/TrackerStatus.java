package kr.mzs.gunbed;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.screamingsandals.bedwars.api.RunningTeam;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

final class TrackerStatus implements Listener {
    private final GunbedCore plugin;
    private static final Set<GunbedCore> installed=Collections.newSetFromMap(new IdentityHashMap<>());
    private TrackerStatus(GunbedCore plugin){this.plugin=plugin;}
    static void install(GunbedCore plugin){if(installed.add(plugin))Bukkit.getPluginManager().registerEvents(new TrackerStatus(plugin),plugin);}
    static void clear(GunbedCore plugin,Player player){plugin.protocol.emit(player,Map.of("event","tracking","name",""));player.sendActionBar(Component.empty());}
    static void show(GunbedCore plugin,Player player,RunningTeam team,Player target){
        var game=BedwarsAPI.getInstance().getGameOfPlayer(player);var color=TeamPalette.of(game,team);
        String name=target==null?"???":TeamPalette.display(target);double distance=target==null?0:player.getLocation().distance(target.getLocation());
        player.sendActionBar(Component.text("Tracking: ",NamedTextColor.WHITE).append(color.text(name).decorate(TextDecoration.BOLD))
                .append(Component.text(" - Distance: ",NamedTextColor.WHITE))
                .append(Component.text(target==null?"???":Math.round(distance)+"m",NamedTextColor.GREEN).decorate(TextDecoration.BOLD)));
        plugin.protocol.emit(player,Map.of("event","tracking","name",name,"distance",distance,"waiting",target==null));
    }
    static void tick(GunbedCore plugin,Map<UUID,UUID> targets){
        for(Player player:Bukkit.getOnlinePlayers()){
            RunningTeam team=plugin.tracker.selectedTeam(player);
            if(team==null){plugin.protocol.emit(player,Map.of("event","tracking","name",""));continue;}
            UUID id=targets.get(player.getUniqueId());Player target=id==null?null:Bukkit.getPlayer(id);
            show(plugin,player,team,target);
        }
    }
    @EventHandler(priority=EventPriority.LOWEST)public void death(PlayerDeathEvent event){plugin.tracker.clear(event.getEntity());}
}
