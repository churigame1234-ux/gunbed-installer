package kr.mzs.gunbed;

import kr.mzs.botcore.MZSBotCorePlugin;
import kr.mzs.botcore.api.MzsBot;
import kr.mzs.botcore.api.MzsClickMode;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import java.util.*;

/** The same in-memory player runtime used by MZS zombies; no login tokens. */
final class BotRuntime {
    private final MZSBotCorePlugin core;
    BotRuntime(){core=(MZSBotCorePlugin)Bukkit.getPluginManager().getPlugin("MZSBotCore");}
    static boolean bot(Player p){return p!=null&&(p.getScoreboardTags().contains("mzs_ai")||p.getPersistentDataContainer().has(new NamespacedKey("mzsbotcore","bot"),PersistentDataType.BYTE));}
    MzsBot spawn(Location at,String name){return core.getBotApi().spawnBot(at,name).orElseThrow(()->new IllegalStateException("Could not spawn "+name));}
    void remove(MzsBot bot){core.getBotApi().despawnBot(bot.getName());}
    void move(MzsBot bot,double dx,double dz,boolean jump,boolean sprint,boolean sneak){var attribute=bot.getPlayer().getAttribute(org.bukkit.attribute.Attribute.MOVEMENT_SPEED);var key=new NamespacedKey("gunbedcore","ai_sneak_input");if(attribute!=null){attribute.removeModifier(key);if(sneak)attribute.addTransientModifier(new org.bukkit.attribute.AttributeModifier(key,-.7,org.bukkit.attribute.AttributeModifier.Operation.ADD_SCALAR));}if(Math.hypot(dx,dz)<1.0e-6)bot.setMovementInput(0,0,jump,sprint,sneak);else bot.setWorldMovementInput(dx,dz,jump,sprint,sneak);}
    void stop(MzsBot bot){bot.clearMovementInput();var a=bot.getPlayer().getAttribute(org.bukkit.attribute.Attribute.MOVEMENT_SPEED);if(a!=null)a.removeModifier(new NamespacedKey("gunbedcore","ai_sneak_input"));}
    void look(MzsBot bot,Location target){Player p=bot.getPlayer();var direction=target.toVector().subtract(p.getEyeLocation().toVector());var at=p.getLocation().setDirection(direction);core.getBotApi().setHeadYaw(p,at.getYaw());p.setRotation(at.getYaw(),at.getPitch());}
    void left(MzsBot bot){core.getBotApi().leftClick(bot,MzsClickMode.ONCE);}
    boolean useBlock(MzsBot bot,org.bukkit.block.Block block,org.bukkit.block.BlockFace face){return core.getBotApi().useBlock(bot,block,face);}
    void right(MzsBot bot){core.getBotApi().rightClick(bot,MzsClickMode.ONCE);}
    /** Paper's item API respects normal use/consume listeners without ticking the entire fake player. */
    boolean beginUse(MzsBot bot){Player p=bot.getPlayer();var event=new org.bukkit.event.player.PlayerInteractEvent(p,org.bukkit.event.block.Action.RIGHT_CLICK_AIR,p.getInventory().getItemInMainHand(),null,null,org.bukkit.inventory.EquipmentSlot.HAND);Bukkit.getPluginManager().callEvent(event);if(event.useItemInHand()==org.bukkit.event.Event.Result.DENY)return false;p.startUsingItem(org.bukkit.inventory.EquipmentSlot.HAND);return p.hasActiveItem();}
    boolean finishUse(MzsBot bot){Player p=bot.getPlayer();if(!p.hasActiveItem())return false;p.completeUsingActiveItem();return true;}
}
