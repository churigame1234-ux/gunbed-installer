package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import java.util.*;

/** One timeline and one stable capped pile per physical resource generator. */
final class ArenaFlow implements Listener,AutoCloseable {
    private static final int[] EVENTS={360,720,1080,1440,1800,2400,3000};
    private static final String[] NAMES={"다이아몬드 II","에메랄드 II","다이아몬드 III","에메랄드 III","침대 파괴","서든 데스","게임 종료"};
    private static final class State {int ticks,event;List<Generator> generators=new ArrayList<>();}
    private static final class Generator {org.screamingsandals.bedwars.api.game.ItemSpawner source;Location at;Material material;Item pile;TextDisplay label;int next;}
    private final GunbedCore plugin;final SuddenDragons dragons;private final Map<Game,State> games=new HashMap<>();private final NamespacedKey generated;
    ArenaFlow(GunbedCore p){plugin=p;dragons=new SuddenDragons(p);generated=new NamespacedKey(p,"generator_pile");Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,1);}
    int seconds(Game g){State s=games.get(g);return s==null?0:s.ticks/20;}
    String next(Game g){int elapsed=seconds(g);for(int i=0;i<EVENTS.length;i++)if(elapsed<EVENTS[i]){int left=EVENTS[i]-elapsed;return "§f"+NAMES[i]+" §a"+left/60+":"+String.format(Locale.ROOT,"%02d",left%60);}return "§c게임 종료";}
    int tier(Game g,Material m){int t=seconds(g);return m==Material.DIAMOND?(t>=1080?3:t>=360?2:1):m==Material.EMERALD?(t>=1440?3:t>=720?2:1):1;}
    private int interval(Game game,Generator gen){int tier=tier(game,gen.material);int base=switch(gen.material){case IRON_INGOT->plugin.getConfig().getInt("generators.iron-ticks",27);case GOLD_INGOT->plugin.getConfig().getInt("generators.gold-ticks",160);case DIAMOND->new int[]{600,460,240}[tier-1];case EMERALD->new int[]{1300,1000,700}[tier-1];default->1200;};if(plugin.aiRules!=null)base*=plugin.aiRules.generatorFactor(game,gen.source.getTeam());double factor=gen.source.getStartLevel()>0?gen.source.getCurrentLevel()/gen.source.getStartLevel():1;return Set.of(Material.IRON_INGOT,Material.GOLD_INGOT).contains(gen.material)?Math.max(1,(int)Math.ceil(base/Math.max(1,factor))):base;}
    private int cap(Material m){return switch(m){case IRON_INGOT->48;case GOLD_INGOT->16;case DIAMOND->8;case EMERALD->2;default->64;};}
    @EventHandler(priority=EventPriority.HIGHEST)public void vanilla(BedwarsResourceSpawnEvent e){if(games.containsKey(e.getGame()))e.setCancelled(true);}
    @EventHandler public void start(BedwarsGameStartedEvent e){Game game=e.getGame();remove(game);State state=new State();Set<String> seen=new HashSet<>();for(var source:game.getItemSpawners()){
        Material m=source.getItemSpawnerType().getMaterial();if(!Set.of(Material.IRON_INGOT,Material.GOLD_INGOT,Material.DIAMOND,Material.EMERALD).contains(m))continue;
        Location at=source.getLocation().clone();String key=(source.getTeam()==null?at.getBlockX()+","+at.getBlockY()+","+at.getBlockZ():"team:"+source.getTeam().getName())+"/"+m;if(!seen.add(key))continue;
        Generator gen=new Generator();gen.source=source;gen.material=m;gen.at=new Location(at.getWorld(),at.getBlockX()+.5,at.getY()+.15,at.getBlockZ()+.5);
        for(int i=0;i<5&&!gen.at.getBlock().isPassable();i++)gen.at.add(0,1,0);
        gen.next=interval(game,gen);if(m==Material.DIAMOND||m==Material.EMERALD){gen.label=gen.at.getWorld().spawn(gen.at.clone().add(0,1.25,0),TextDisplay.class,d->{d.setPersistent(false);d.setBillboard(Display.Billboard.CENTER);d.setShadowed(true);d.setDefaultBackground(false);d.setViewRange(.75f);});BedwarsAPI.getInstance().registerEntityToGame(gen.label,game);}
        state.generators.add(gen);
    }games.put(game,state);}
    boolean claimGenerated(Game game,Item item){State s=games.get(game);if(s==null)return false;for(Generator gen:s.generators)if(gen.pile!=null&&gen.pile.getUniqueId().equals(item.getUniqueId())){gen.pile=null;return gen.source.getTeam()!=null;}return false;}
    private void tick(){for(var entry:List.copyOf(games.entrySet())){Game game=entry.getKey();State s=entry.getValue();if(game.getStatus()!=GameStatus.RUNNING)continue;s.ticks++;
        if(s.event<EVENTS.length&&s.ticks>=EVENTS[s.event]*20){int event=s.event++;for(Player p:game.getConnectedPlayers())p.sendMessage("§e"+NAMES[event]);
            if(event==4){BedAlerts.all(game);for(var team:game.getRunningTeams()){var block=team.getTargetBlock().getBlock();if(block.getBlockData() instanceof org.bukkit.block.data.type.Bed data){Location partner=block.getRelative(data.getPart()==org.bukkit.block.data.type.Bed.Part.HEAD?data.getFacing().getOppositeFace():data.getFacing()).getLocation();game.getRegion().putOriginalBlock(block.getLocation(),block.getState());game.getRegion().putOriginalBlock(partner,partner.getBlock().getState());block.setType(Material.AIR,false);partner.getBlock().setType(Material.AIR,false);}if(team instanceof org.screamingsandals.bedwars.game.CurrentTeam implementation)implementation.isBed=false;}}
            if(event==5){dragons.start(game);for(Player p:game.getConnectedPlayers())p.playSound(p.getLocation(),Sound.ENTITY_ENDER_DRAGON_GROWL,.8f,1);}
            if(event==6){game.stop();((org.screamingsandals.bedwars.game.Game)game).rebuild();LegacyActions.clear(game);game.start();continue;}
        }
        for(Generator gen:s.generators){if(gen.pile!=null&&(gen.pile.isDead()||!gen.pile.isValid()))gen.pile=null;
            if(gen.pile!=null&&s.ticks%5==0){gen.pile.setVelocity(new org.bukkit.util.Vector());if(gen.pile.getLocation().distanceSquared(gen.at)>.01)gen.pile.teleport(gen.at);}
            if(s.ticks>=gen.next){gen.next=s.ticks+Math.max(1,interval(game,gen));int current=gen.pile==null?0:gen.pile.getItemStack().getAmount();if(current<cap(gen.material)){
                if(gen.pile!=null){var stack=gen.pile.getItemStack();stack.setAmount(current+1);gen.pile.setItemStack(stack);}else{gen.pile=gen.at.getWorld().dropItem(gen.at,new org.bukkit.inventory.ItemStack(gen.material,1));gen.pile.setVelocity(new org.bukkit.util.Vector());gen.pile.setGravity(false);gen.pile.setPickupDelay(15);gen.pile.setUnlimitedLifetime(true);gen.pile.getPersistentDataContainer().set(generated,PersistentDataType.BYTE,(byte)1);BedwarsAPI.getInstance().registerEntityToGame(gen.pile,game);}
            }}
            if(gen.label!=null&&gen.label.isValid()&&s.ticks%20==0){int tier=tier(game,gen.material),left=Math.max(0,(gen.next-s.ticks+19)/20);int color=gen.material==Material.DIAMOND?0x46D8EC:0x39D98A;gen.label.text(Component.text("티어 "+new String[]{"I","II","III"}[tier-1]+"\n",TextColor.color(0xFFF38A)).append(Component.text(gen.material==Material.DIAMOND?"다이아몬드":"에메랄드",TextColor.color(color))).append(Component.text("\n"+(gen.pile!=null&&gen.pile.getItemStack().getAmount()>=cap(gen.material)?"생성기 가득 참":left+"초 후 생성"),TextColor.color(0xE3E8E3))));}
        }
    }}
    @EventHandler public void deathMessage(BedwarsPlayerDeathMessageSendEvent e){e.setCancelled(true);}
    @EventHandler(ignoreCancelled=true)public void merge(ItemMergeEvent e){if(e.getEntity().getPersistentDataContainer().has(generated)||e.getTarget().getPersistentDataContainer().has(generated))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void friendly(EntityDamageByEntityEvent e){if(!(e.getEntity() instanceof Player victim))return;Entity attacker=e.getDamager();if(attacker instanceof Projectile projectile&&projectile.getShooter() instanceof Entity source)attacker=source;if(!(attacker instanceof Player source)||source.equals(victim))return;Game game=BedwarsAPI.getInstance().getGameOfPlayer(victim);if(game!=null&&game.getStatus()==GameStatus.RUNNING&&game==BedwarsAPI.getInstance().getGameOfPlayer(source)&&game.getTeamOfPlayer(victim)!=null&&game.getTeamOfPlayer(victim).isPlayerInTeam(source))e.setCancelled(true);}
    @EventHandler public void disabled(BedWarsGameDisabledEvent e){remove(e.getGame());}
    @EventHandler public void end(BedwarsGameEndEvent e){remove(e.getGame());}
    private void remove(Game g){dragons.clear(g);State state=games.remove(g);if(state!=null)for(Generator gen:state.generators){if(gen.label!=null)gen.label.remove();if(gen.pile!=null)gen.pile.remove();}}
    @Override public void close(){for(Game game:List.copyOf(games.keySet()))remove(game);}
}
