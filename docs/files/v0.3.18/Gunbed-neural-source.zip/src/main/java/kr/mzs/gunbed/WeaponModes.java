package kr.mzs.gunbed;

import com.shampaggon.crackshot.events.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.events.*;
import java.util.*;

/** Server-authoritative fire modes. Inventory A/B and weapon A/B are independent. */
final class WeaponModes implements Listener,AutoCloseable {
    private static final Map<String,String> ALTERNATES=Map.of("골데","골데B","VSS","VSS-B","더블배럴","더블배럴B");
    private static final Set<String> RETIRED=Set.of("프로스트브레스","할로우드스태프");
    private static final Set<String> SIEGE=Set.of("g36","바스티온");
    private enum Phase {DEPLOYING,DEPLOYED,UNDEPLOYING}
    private static final class Siege {String title;Phase phase;long until;Location anchor;int slot;boolean priorFlight;}
    private record Switch(String from,String to,String instance,long midpoint,long end,boolean committed){}
    private record Shot(boolean siege,int expiry){}
    private final GunbedCore plugin;
    private final Map<UUID,Siege> sieges=new HashMap<>();
    private final Map<UUID,Switch> switches=new HashMap<>();
    private final Map<UUID,Shot> shots=new HashMap<>();
    private final Map<UUID,Map<String,Long>> fireCooldown=new HashMap<>();
    private final NamespacedKey instance;
    WeaponModes(GunbedCore plugin){this.plugin=plugin;instance=new NamespacedKey(plugin,"weapon_instance");Bukkit.getPluginManager().registerEvents(this,plugin);Bukkit.getScheduler().runTaskTimer(plugin,this::tick,1,1);}
    static boolean retired(String title){return title!=null&&RETIRED.contains(title);}
    static boolean alternate(String title){return title!=null&&ALTERNATES.containsValue(title);}
    static String base(String title){for(var entry:ALTERNATES.entrySet())if(entry.getValue().equals(title))return entry.getKey();return title;}
    static String ammoId(String title){return "cs:"+base(title);}
    static boolean auxiliary(String title){return title!=null&&(SIEGE.contains(title)||ALTERNATES.containsKey(base(title)));}
    boolean anchored(Player p){return sieges.containsKey(p.getUniqueId());}
    boolean deployed(Player p){Siege s=sieges.get(p.getUniqueId());return s!=null&&s.phase==Phase.DEPLOYED;}
    boolean transitioning(Player p){Siege s=sieges.get(p.getUniqueId());return switches.containsKey(p.getUniqueId())||s!=null&&s.phase!=Phase.DEPLOYED;}
    String phase(Player p){Siege s=sieges.get(p.getUniqueId());return s==null?(switches.containsKey(p.getUniqueId())?"switching":"mobile"):s.phase.name().toLowerCase(Locale.ROOT);}
    String model(Player p,String title){String family=base(title);return switch(family){case "골데"->alternate(title)?"gunbed_gold_b":"gunbed_gold_a";case "VSS"->alternate(title)?"gunbed_vss_b":"gunbed_vss_a";case "더블배럴"->alternate(title)?"gunbed_double_b":"gunbed_double_a";case "g36"->deployedModel(p)?"gunbed_g36_siege":"gunbed_g36_mobile";case "바스티온"->deployedModel(p)?"gunbed_bastion_siege":"gunbed_bastion_mobile";default->null;};}
    private boolean deployedModel(Player p){Siege s=sieges.get(p.getUniqueId());return s!=null&&(s.phase==Phase.DEPLOYED||s.phase==Phase.UNDEPLOYING||System.currentTimeMillis()>=s.until-deployMillis(s.title)/2);}
    private long deployMillis(String title){return Math.max(250,Math.min(10000,(long)(plugin.getConfig().getDouble("weapons.siege.deploy-seconds",2.2)*1000)));}
    private long undeployMillis(){return Math.max(250,Math.min(5000,(long)(plugin.getConfig().getDouble("weapons.siege.undeploy-seconds",1.5)*1000)));}
    private String held(Player p){return plugin.visuals==null?null:plugin.visuals.cs.getWeaponTitle(p.getInventory().getItemInMainHand());}
    void rightClick(Player p,String title){
        if(retired(title)||p.isDead()||p.getGameMode()==GameMode.SPECTATOR||plugin.inventories.locked(p)||plugin.ammo.reloading(p))return;
        if(SIEGE.contains(title)){Siege s=sieges.get(p.getUniqueId());if(s!=null){if(s.phase==Phase.DEPLOYED){s.phase=Phase.UNDEPLOYING;s.until=System.currentTimeMillis()+undeployMillis();animate(p,"undeploy",undeployMillis());}return;}if(!supported(p)){p.sendActionBar("§e지면에 닿아야 시즈를 전개할 수 있습니다.");return;}s=new Siege();s.title=title;s.phase=Phase.DEPLOYING;s.until=System.currentTimeMillis()+deployMillis(title);s.anchor=p.getLocation();s.slot=p.getInventory().getHeldItemSlot();s.priorFlight=p.getAllowFlight();sieges.put(p.getUniqueId(),s);p.setFlying(false);p.setAllowFlight(false);p.setVelocity(new Vector());animate(p,"deploy",deployMillis(title));p.sendMessage("§e시즈 전개 중 · 이동/넉백 차단 · 전개 후 우클릭으로 해제");return;}
        String family=base(title);if(!ALTERNATES.containsKey(family)||switches.containsKey(p.getUniqueId()))return;
        ItemStack item=p.getInventory().getItemInMainHand();var meta=item.getItemMeta();String token=meta.getPersistentDataContainer().get(instance,PersistentDataType.STRING);if(token==null){token=UUID.randomUUID().toString();meta.getPersistentDataContainer().set(instance,PersistentDataType.STRING,token);item.setItemMeta(meta);p.getInventory().setItemInMainHand(item);}long now=System.currentTimeMillis();switches.put(p.getUniqueId(),new Switch(title,title.equals(family)?ALTERNATES.get(family):family,token,now+450,now+900,false));animate(p,"switch",900);
    }
    private void animate(Player p,String kind,long ms){plugin.protocol.emit(p,Map.of("event","modeSwitch","phase",kind,"durationMs",ms));p.playSound(p.getLocation(),Sound.BLOCK_PISTON_EXTEND,.45f,kind.equals("switch")?1.6f:.8f);}
    private void tick(){long now=System.currentTimeMillis();
        for(var entry:List.copyOf(switches.entrySet())){Player p=Bukkit.getPlayer(entry.getKey());Switch s=entry.getValue();String expected=s.committed?s.to:s.from;if(p==null||p.isDead()||!Objects.equals(held(p),expected)){switches.remove(entry.getKey());continue;}ItemStack old=p.getInventory().getItemInMainHand();if(!s.instance.equals(old.getItemMeta().getPersistentDataContainer().get(instance,PersistentDataType.STRING))){switches.remove(entry.getKey());continue;}
            if(!s.committed&&now>=s.midpoint){ItemStack next=plugin.visuals.create(s.to);if(next==null){switches.remove(entry.getKey());continue;}int loaded=plugin.visuals.cs.getHandle().getAmmoBetweenBrackets(p,s.from,old);var meta=next.getItemMeta();old.getItemMeta().getPersistentDataContainer().copyTo(meta.getPersistentDataContainer(),true);meta.getPersistentDataContainer().set(new NamespacedKey(plugin,"cs_weapon"),PersistentDataType.STRING,s.to);next.setItemMeta(meta);plugin.visuals.cs.getHandle().ammoOperation(p,s.to,loaded+1,next);p.getInventory().setItemInMainHand(next);p.updateInventory();plugin.protocol.refreshHeld(p);switches.put(entry.getKey(),new Switch(s.from,s.to,s.instance,s.midpoint,s.end,true));p.sendActionBar(net.kyori.adventure.text.Component.text("발사 모드 "+(alternate(s.to)?"B":"A")+" · 우클릭 전환"));}
            if(now>=s.end)switches.remove(entry.getKey());
        }
        for(var entry:List.copyOf(sieges.entrySet())){Player p=Bukkit.getPlayer(entry.getKey());Siege s=entry.getValue();if(p==null||p.isDead()||p.getGameMode()==GameMode.SPECTATOR||!Objects.equals(s.title,held(p))){clear(entry.getKey());continue;}if(!supported(p)){clear(entry.getKey());p.sendActionBar("§e지지 블록이 없어 시즈를 해제했습니다.");continue;}p.setFallDistance(0);p.setVelocity(new Vector());p.setAllowFlight(false);if(now>=s.until){if(s.phase==Phase.DEPLOYING){s.phase=Phase.DEPLOYED;p.sendMessage("§a시즈 전개 완료 · 피해 강화 · 우클릭 해제 후 이동 가능");p.playSound(p.getLocation(),Sound.BLOCK_ANVIL_PLACE,.4f,1.2f);}else if(s.phase==Phase.UNDEPLOYING){clear(entry.getKey());p.sendActionBar(net.kyori.adventure.text.Component.text("시즈 해제 완료 · 이동 가능"));}}}
        if(Bukkit.getCurrentTick()%100==0)shots.entrySet().removeIf(e->e.getValue().expiry<Bukkit.getCurrentTick());
    }
    private boolean supported(Player p){return p.getVelocity().getY()<=.08&&!p.getLocation().subtract(0,.12,0).getBlock().isPassable();}
    private void clear(UUID id){Siege state=sieges.remove(id);switches.remove(id);Player p=Bukkit.getPlayer(id);if(state!=null&&p!=null&&p.isOnline()&&p.getGameMode()!=GameMode.SPECTATOR)p.setAllowFlight(state.priorFlight);}
    @EventHandler(priority=EventPriority.LOWEST)public void prepare(WeaponPrepareShootEvent e){if(retired(e.getWeaponTitle())||transitioning(e.getPlayer())||System.currentTimeMillis()<fireCooldown.getOrDefault(e.getPlayer().getUniqueId(),Map.of()).getOrDefault(base(e.getWeaponTitle()),0L))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGH,ignoreCancelled=true)public void spread(WeaponPreShootEvent e){if(SIEGE.contains(e.getWeaponTitle())&&deployed(e.getPlayer()))e.setBulletSpread(e.getBulletSpread()*Math.max(.05,Math.min(1,plugin.getConfig().getDouble("weapons.siege.spread-multiplier",.5))));}
    @EventHandler(priority=EventPriority.MONITOR)public void shot(WeaponShootEvent e){if(SIEGE.contains(e.getWeaponTitle())&&e.getProjectile()!=null)shots.put(e.getProjectile().getUniqueId(),new Shot(deployed(e.getPlayer()),Bukkit.getCurrentTick()+200));String family=base(e.getWeaponTitle());if(ALTERNATES.containsKey(family))fireCooldown.computeIfAbsent(e.getPlayer().getUniqueId(),id->new HashMap<>()).put(family,System.currentTimeMillis()+plugin.visuals.cs.getHandle().getInt(e.getWeaponTitle()+".Shooting.Delay_Between_Shots")*50L);}
    @EventHandler(priority=EventPriority.HIGH,ignoreCancelled=true)public void damage(WeaponDamageEntityEvent e){if(retired(e.getWeaponTitle())){e.setCancelled(true);return;}if(SIEGE.contains(e.getWeaponTitle())){Shot snapshot=e.getDamager()==null?null:shots.get(e.getDamager().getUniqueId());if(snapshot!=null?snapshot.siege:deployed(e.getPlayer()))e.setDamage(e.getDamage()*Math.max(1,Math.min(5,plugin.getConfig().getDouble("weapons.siege.damage-multiplier",2))));}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void melee(EntityDamageByEntityEvent e){if(e.getDamager() instanceof Player p&&retired(held(p)))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void move(PlayerMoveEvent e){Siege s=sieges.get(e.getPlayer().getUniqueId());if(s==null||e instanceof PlayerTeleportEvent||e.getTo()==null)return;Location to=s.anchor.clone();to.setYaw(e.getTo().getYaw());to.setPitch(e.getTo().getPitch());e.setTo(to);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void velocity(PlayerVelocityEvent e){if(anchored(e.getPlayer())){e.setCancelled(true);e.getPlayer().setVelocity(new Vector());}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void knockback(EntityKnockbackEvent e){if(e.getEntity() instanceof Player p&&anchored(p)){e.setFinalKnockback(new Vector());e.setCancelled(true);}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void jump(PlayerToggleFlightEvent e){if(anchored(e.getPlayer()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void slot(PlayerItemHeldEvent e){Siege s=sieges.get(e.getPlayer().getUniqueId());if(s!=null&&s.slot!=e.getNewSlot()){e.setCancelled(true);e.getPlayer().sendActionBar(net.kyori.adventure.text.Component.text("우클릭으로 시즈를 해제한 뒤 무기를 바꾸세요."));}else switches.remove(e.getPlayer().getUniqueId());}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void teleport(PlayerTeleportEvent e){Siege s=sieges.get(e.getPlayer().getUniqueId());if(s==null)return;Location destination=e.getTo();if(destination!=null&&destination.getWorld().equals(s.anchor.getWorld())&&destination.distanceSquared(s.anchor)<.01)return;clear(e.getPlayer().getUniqueId());}
    @EventHandler(priority=EventPriority.LOWEST)public void death(PlayerDeathEvent e){clear(e.getEntity().getUniqueId());}
    @EventHandler(priority=EventPriority.LOWEST)public void leave(BedwarsPlayerLeaveEvent e){clear(e.getPlayer().getUniqueId());}
    @EventHandler(priority=EventPriority.LOWEST)public void end(BedwarsGameEndEvent e){for(Player p:e.getGame().getConnectedPlayers())clear(p.getUniqueId());}
    @EventHandler public void quit(PlayerQuitEvent e){clear(e.getPlayer().getUniqueId());fireCooldown.remove(e.getPlayer().getUniqueId());}
    @EventHandler(priority=EventPriority.MONITOR)public void join(PlayerJoinEvent e){Bukkit.getScheduler().runTask(plugin,()->{Player p=e.getPlayer();for(int i=0;i<p.getInventory().getSize();i++){ItemStack item=p.getInventory().getItem(i);if(item!=null&&plugin.visuals!=null&&retired(plugin.visuals.cs.getWeaponTitle(item)))p.getInventory().setItem(i,null);}});}
    @Override public void close(){for(UUID id:List.copyOf(sieges.keySet()))clear(id);switches.clear();shots.clear();}
}
