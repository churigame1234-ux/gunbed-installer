package kr.mzs.gunbed;

import java.lang.reflect.*;
import java.util.*;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.game.Game;

/** Shared feedback for direct health damage and grenade coverage of multipart dragons. */
final class DragonHitFeedback {
    private static final Map<UUID,Integer> sounds=new HashMap<>();
    @SuppressWarnings("unchecked")
    static void hit(GunbedCore plugin,Game game,String team,EnderDragon dragon,Player source,double amount) {
        var palette=TeamPalette.of(game,game.getTeamFromName(team));String label=palette.name()+"팀 엔더드래곤";
        dragon.customName(palette.text(label));
        // Direct setHealth does not send vanilla hurt animation or update hurtTime.
        dragon.playHurtAnimation(source.getLocation().getYaw());
        try {
            Object handle=dragon.getClass().getMethod("getHandle").invoke(dragon);
            handle.getClass().getField("hurtTime").setInt(handle,10);
            handle.getClass().getField("hurtDuration").setInt(handle,10);
            int tick=Bukkit.getCurrentTick();
            if(tick-sounds.getOrDefault(dragon.getUniqueId(),-100)>=6){sounds.put(dragon.getUniqueId(),tick);dragon.getWorld().playSound(dragon.getLocation(),Sound.ENTITY_ENDER_DRAGON_HURT,.75f,1);}
            if(sounds.size()>64)sounds.keySet().removeIf(id->{Entity e=Bukkit.getEntity(id);return e==null||e.isDead();});
            // Reuse the existing per-attacker bar and its four-second expiry. This
            // avoids stacking separate player-health and dragon-health bars.
            Object presentation=plugin.combatPresentation;Field field=CombatPresentation.class.getDeclaredField("bars");field.setAccessible(true);
            Map<UUID,Object> bars=(Map<UUID,Object>)field.get(presentation);Object old=bars.get(source.getUniqueId());
            Class<?> record=Class.forName("kr.mzs.gunbed.CombatPresentation$EnemyBar",false,plugin.getClass().getClassLoader());
            BossBar bar;if(old==null)bar=BossBar.bossBar(Component.empty(),0,BossBar.Color.GREEN,BossBar.Overlay.NOTCHED_20);
            else {Method accessor=record.getDeclaredMethod("bar");accessor.setAccessible(true);bar=(BossBar)accessor.invoke(old);}
            double health=dragon.getHealth(),max=dragon.getAttribute(Attribute.MAX_HEALTH).getValue();float progress=(float)Math.max(0,Math.min(1,health/max));
            String detail=" · "+Math.round(health)+"/"+Math.round(max)+" ("+Math.round(progress*100)+"%) · −"+Math.round(amount);
            bar.name(palette.text(label).append(Component.text(detail,NamedTextColor.WHITE)));bar.progress(progress);
            bar.color(progress<=.33?BossBar.Color.RED:progress<=.66?BossBar.Color.YELLOW:BossBar.Color.GREEN);
            source.showBossBar(bar);Constructor<?> constructor=record.getDeclaredConstructor(BossBar.class,long.class);constructor.setAccessible(true);
            bars.put(source.getUniqueId(),constructor.newInstance(bar,System.currentTimeMillis()+4000));
            plugin.protocol.emit(source,Map.of("event","enemyHealth","name",palette.legacy()+label+"§f"+detail,"progress",progress));
            if(plugin.profiles.get(source.getUniqueId()).getBoolean("settings.hit-sound",true))source.playSound(source.getLocation(),Sound.UI_BUTTON_CLICK,.15f,1.8f);
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Dragon damage feedback failed",e);}
    }
    static void throwable(GunbedCore plugin,Player source,Game game,Location at,String kind) {
        double power=switch(kind){case "he"->plugin.damageProfiles.he();case "fire"->plugin.damageProfiles.fireTick();case "flash"->plugin.damages.value("throwables.flash",0);default->0;};
        if(power<=0)return;double radius=kind.equals("he")?8:kind.equals("fire")?3.5:20;
        try {
            Object engine=plugin.flow.dragons;Field list=SuddenDragons.class.getDeclaredField("flights");list.setAccessible(true);
            for(Object flight:(List<?>)list.get(engine)) {
                Field gf=flight.getClass().getDeclaredField("game"),df=flight.getClass().getDeclaredField("dragon");gf.setAccessible(true);df.setAccessible(true);
                EnderDragon dragon=(EnderDragon)df.get(flight);
                if(gf.get(flight)!=game||dragon==null||dragon.isDead()||dragon.getWorld()!=at.getWorld())continue;
                double nearest=radius;
                for(ComplexEntityPart part:dragon.getParts()) {
                    var box=part.getBoundingBox();Vector point=new Vector(Math.max(box.getMinX(),Math.min(box.getMaxX(),at.getX())),Math.max(box.getMinY(),Math.min(box.getMaxY(),at.getY())),Math.max(box.getMinZ(),Math.min(box.getMaxZ(),at.getZ())));
                    Vector delta=point.subtract(at.toVector());double distance=delta.length();
                    if(distance<nearest&&(distance<.05||at.getWorld().rayTraceBlocks(at,delta.clone().normalize(),distance,FluidCollisionMode.NEVER,true)==null))nearest=distance;
                }
                if(nearest>=radius)continue;
                double value=kind.equals("he")?power*(1-nearest/radius):kind.equals("flash")?power*Math.min(1,(radius-nearest)/8):power;
                plugin.flow.dragons.damage(dragon,source,value);
            }
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Dragon throwable damage failed",e);}
    }
}
