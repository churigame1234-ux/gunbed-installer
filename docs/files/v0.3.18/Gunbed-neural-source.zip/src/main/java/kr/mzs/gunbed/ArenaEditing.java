package kr.mzs.gunbed;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.Game;
import org.screamingsandals.bedwars.api.game.GameStatus;

/** Creative map editing without weakening normal match protections. */
final class ArenaEditing implements Listener {
    private final BedwarsAPI api = BedwarsAPI.getInstance();

    ArenaEditing(GunbedCore plugin) {
        // BedWars protects its arena at HIGHEST. Register after all plugins have
        // enabled so this narrowly scoped exception runs after that protection.
        plugin.getServer().getScheduler().runTask(plugin,
                () -> plugin.getServer().getPluginManager().registerEvents(this, plugin));
    }

    private boolean playing(Player player) {
        Game game = api.getGameOfPlayer(player);
        return game != null && game.getStatus() == GameStatus.RUNNING;
    }

    private Game activeArena(Block block) {
        Location p = block.getLocation();
        for (Game game : api.getGames()) {
            if (game.getStatus() != GameStatus.RUNNING || !game.getGameWorld().equals(block.getWorld())) continue;
            Location a = game.getPos1(), b = game.getPos2();
            if (p.getX() >= Math.min(a.getX(), b.getX()) && p.getX() <= Math.max(a.getX(), b.getX())
                    && p.getY() >= Math.min(a.getY(), b.getY()) && p.getY() <= Math.max(a.getY(), b.getY())
                    && p.getZ() >= Math.min(a.getZ(), b.getZ()) && p.getZ() <= Math.max(a.getZ(), b.getZ())) return game;
        }
        return null;
    }

    private boolean mayEdit(Player player, Block block) {
        return player.getGameMode() == GameMode.CREATIVE
                && (player.isOp() || (!playing(player) && activeArena(block) == null));
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void beforeBreak(BlockBreakEvent event) {
        if (mayEdit(event.getPlayer(), event.getBlock())) LegacyActions.recordBlock(event.getBlock());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBreak(BlockBreakEvent event) {
        if (!mayEdit(event.getPlayer(), event.getBlock())) {
            if (!playing(event.getPlayer())) event.setCancelled(true);
            return;
        }
        Game game = activeArena(event.getBlock());
        if (game != null) {
            var region = game.getRegion();
            region.removeBlockBuiltDuringGame(event.getBlock().getLocation());
            // Normal enemy-bed breaks already went through BedWars. If an
            // editor removes a protected own bed, keep its logical state in sync
            // without awarding the administrator a bed-destruction reward.
            Location target = event.getBlock().getLocation();
            if (region.isBedBlock(event.getBlock().getState()) && !region.isBedHead(event.getBlock().getState())) {
                target = region.getBedNeighbor(event.getBlock()).getLocation();
            }
            for (var team : game.getRunningTeams()) {
                if (team.isTargetBlockExists() && team.getTargetBlock().getBlock().getLocation().equals(target)
                        && game instanceof org.screamingsandals.bedwars.game.Game implementation) {
                    implementation.bedDestroyed(target, null, region.isBedBlock(event.getBlock().getState()),
                            false, false, region.isDoorBlock(event.getBlock().getState()));
                    break;
                }
            }
        }
        event.setCancelled(false);
        event.setDropItems(false);
        event.setExpToDrop(0);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlace(BlockPlaceEvent event) {
        if (!mayEdit(event.getPlayer(), event.getBlock())) {
            if (!playing(event.getPlayer())) event.setCancelled(true);
            return;
        }
        Game game = activeArena(event.getBlock());
        if (game != null && !game.getRegion().isBlockAddedDuringGame(event.getBlock().getLocation())) {
            game.getRegion().putOriginalBlock(event.getBlock().getLocation(), event.getBlockReplacedState());
            game.getRegion().addBuiltDuringGame(event.getBlock().getLocation());
        }
        event.setBuild(true);
        event.setCancelled(false);
    }
}
