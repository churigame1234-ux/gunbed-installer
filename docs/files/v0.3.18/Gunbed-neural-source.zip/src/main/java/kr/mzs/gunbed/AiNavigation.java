package kr.mzs.gunbed;
import org.bukkit.*;
import org.screamingsandals.bedwars.api.game.Game;
import java.util.*;

/** Bounded ground A*: planned bridge cells still require actual block placement. */
final class AiNavigation {
    record Cell(int x,int y,int z){Location at(World w){return new Location(w,x+.5,y,z+.5);}Cell offset(int x,int y,int z){return new Cell(this.x+x,this.y+y,this.z+z);}}
    private record Node(Cell cell,double g,double f){}
    static List<Location> path(Game game,Location from,Location target,boolean bridge,boolean jump,AiLearning learning,org.bukkit.entity.Player bot){
        return path(game,from,target,bridge,jump,learning,bot,List.of());
    }
    static List<Location> path(Game game,Location from,Location target,boolean bridge,boolean jump,AiLearning learning,org.bukkit.entity.Player bot,Collection<Location> avoided){
        return path(game,from,target,bridge,jump,learning,bot,avoided,null,6);
    }
    static List<Location> path(Game game,Location from,Location target,boolean bridge,boolean jump,AiLearning learning,org.bukkit.entity.Player bot,Collection<Location> avoided,Location bridgeOrigin,int cadence){
        Set<Cell> avoidedCells=new HashSet<>();for(Location at:avoided)avoidedCells.add(new Cell(at.getBlockX(),at.getBlockY(),at.getBlockZ()));World world=from.getWorld();Cell start=new Cell(from.getBlockX(),(int)Math.ceil(from.getY()-.05),from.getBlockZ());
        // A sneaking player can stand with their centre over the next air block.
        // Start at the block supporting the player's actual body, otherwise A*
        // omits the unbuilt block under that centre and deadlocks one cell later.
        if(!world.getBlockAt(start.x,start.y-1,start.z).getType().isSolid()){
            Cell supported=null;double nearest=Double.MAX_VALUE;var body=bot.getBoundingBox();
            for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++){Cell c=start.offset(dx,0,dz);var floor=world.getBlockAt(c.x,c.y-1,c.z);if(!floor.getType().isSolid()||body.getMaxX()<=c.x||body.getMinX()>=c.x+1||body.getMaxZ()<=c.z||body.getMinZ()>=c.z+1)continue;double distance=c.at(world).distanceSquared(from);if(distance<nearest){supported=c;nearest=distance;}}
            if(supported!=null)start=supported;
        }
        if(bridge){var existing=path(game,from,target,false,false,null,bot,avoided,null,cadence);if(!existing.isEmpty()&&existing.getLast().distanceSquared(target)<4)return existing;var direct=stairRoute(game,world,start,target,bridgeOrigin==null?from:bridgeOrigin,cadence,avoidedCells);if(direct!=null)return direct;}
        PriorityQueue<Node> open=new PriorityQueue<>(Comparator.comparingDouble(Node::f));Map<Cell,Cell> parent=new HashMap<>();Map<Cell,Double> score=new HashMap<>();open.add(new Node(start,0,0));score.put(start,0.0);Cell best=start;double distance=metric(start,target);int budget=3000;long deadline=System.nanoTime()+(bridge?2_000_000:5_000_000);
        while(!open.isEmpty()&&budget-->0){if(budget<2900&&(budget&31)==0&&System.nanoTime()>deadline)break;Node node=open.poll();Cell c=node.cell;if(node.g>score.getOrDefault(c,Double.MAX_VALUE))continue;double remaining=metric(c,target);if(remaining<distance){best=c;distance=remaining;}if(remaining<.6)break;
            for(int[] delta:new int[][]{{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}})for(int dy:new int[]{0,1,-1,-2,-3,-4,-5}){
                Cell next=c.offset(delta[0],dy,delta[1]);if(next.y<39||next.y>65||!world.isChunkLoaded(next.x>>4,next.z>>4)||!game.isLocationInArena(next.at(world)))continue;
                var feet=world.getBlockAt(next.x,next.y,next.z);if(!feet.isPassable()||!feet.getRelative(0,1,0).isPassable())continue;boolean ground=world.getBlockAt(next.x,next.y-1,next.z).getType().isSolid();if(dy< -1&&!dropClear(world,next.x,next.z,next.y,c.y))continue;
                boolean diagonal=delta[0]!=0&&delta[1]!=0;
                if(diagonal&&(dy!=0||!ground||!world.getBlockAt(c.x+delta[0],next.y,c.z).isPassable()||!world.getBlockAt(c.x,next.y,c.z+delta[1]).isPassable()))continue;
                Location origin=bridgeOrigin==null?from:bridgeOrigin;double travelled=Math.abs(next.x+.5-origin.getX())+Math.abs(next.z+.5-origin.getZ());int desired=(int)Math.ceil(origin.getY()-.05)+Math.min(3,(int)(travelled/Math.max(3,cadence)));
                if(!ground&&(!bridge||dy<0||next.y<Math.ceil(origin.getY()-.05)||next.y>desired||next.y>Math.ceil(origin.getY()-.05)+3))continue;if(dy>0&&!world.getBlockAt(c.x,c.y+2,c.z).isPassable())continue;
                double cost=node.g-(learning==null?0:learning.edgeScore(game,bot,c.at(world),next.at(world)))+(ground?(diagonal?1.42:1):3.5+Math.abs(next.y-desired)*1.8)+(!ground?lineOffset(next,origin,target)*.12:0)+(avoidedCells.contains(next)?12:0)+(dy==0?0:.25)-(learning==null?0:learning.routeScore(game,bot,next.at(world)));if(cost>=score.getOrDefault(next,Double.MAX_VALUE))continue;
                score.put(next,cost);parent.put(next,c);open.add(new Node(next,cost,cost+metric(next,target)));
            }
            if(jump)for(int[] delta:new int[][]{{2,0},{-2,0},{0,2},{0,-2},{3,0},{-3,0},{0,3},{0,-3}}){Cell next=c.offset(delta[0],0,delta[1]);if(!world.isChunkLoaded(next.x>>4,next.z>>4)||!game.isLocationInArena(next.at(world))||!world.getBlockAt(next.x,next.y-1,next.z).getType().isSolid()||!world.getBlockAt(next.x,next.y,next.z).isPassable()||!world.getBlockAt(next.x,next.y+1,next.z).isPassable())continue;var fromEye=c.at(world).add(0,1.5,0);var direction=next.at(world).add(0,1.5,0).toVector().subtract(fromEye.toVector());if(world.rayTraceBlocks(fromEye,direction,direction.length(),FluidCollisionMode.NEVER,true)!=null)continue;double cost=node.g+Math.abs(delta[0])+Math.abs(delta[1])+1.2;if(cost>=score.getOrDefault(next,Double.MAX_VALUE))continue;score.put(next,cost);parent.put(next,c);open.add(new Node(next,cost,cost+metric(next,target)));}
        }
        if(best.equals(start)){Cell initial=start;best=score.keySet().stream().filter(c->!c.equals(initial)&&!avoidedCells.contains(c)).min(Comparator.comparingDouble(c->metric(c,target)+score.get(c)*.15)).orElse(start);}
        LinkedList<Location> result=new LinkedList<>();for(Cell c=best;!c.equals(start);c=parent.get(c)){if(c==null)return List.of();result.addFirst(c.at(world));}return result;
    }
    private static List<Location> stairRoute(Game game,World world,Cell start,Location target,Location origin,int cadence,Set<Cell> avoided){
        if(Math.hypot(start.x+.5-target.getX(),start.z+.5-target.getZ())<6)return null;List<Location> route=new ArrayList<>();Cell at=start;boolean built=false;
        for(int step=0;step<96;step++){if(Math.hypot(at.x+.5-target.getX(),at.z+.5-target.getZ())<.8)return built?route:null;
            List<int[]> directions=new ArrayList<>();int dx=Integer.compare(target.getBlockX(),at.x),dz=Integer.compare(target.getBlockZ(),at.z);if(dx!=0)directions.add(new int[]{dx,0});if(dz!=0)directions.add(new int[]{0,dz});Cell previous=at;directions.sort(Comparator.comparingDouble(d->lineOffset(previous.offset(d[0],0,d[1]),origin,target)));
            Cell selected=null;boolean unbuilt=false;for(var direction:directions){int x=at.x+direction[0],z=at.z+direction[1];if(!world.isChunkLoaded(x>>4,z>>4))return null;
                for(int dy:new int[]{0,-1,1,-2,-3,-4,-5}){Cell candidate=new Cell(x,at.y+dy,z);if(avoided.contains(candidate)||!game.isLocationInArena(candidate.at(world)))continue;var feet=world.getBlockAt(x,candidate.y,z);if(feet.isPassable()&&feet.getRelative(0,1,0).isPassable()&&feet.getRelative(0,-1,0).getType().isSolid()&&(dy>=-1||dropClear(world,x,z,candidate.y,at.y))){selected=candidate;break;}}
                if(selected==null){int rise=Math.min(3,(int)((Math.abs(x+.5-origin.getX())+Math.abs(z+.5-origin.getZ()))/Math.max(3,cadence)));int y=Math.min(at.y+1,Math.max(at.y,(int)Math.ceil(origin.getY()-.05)+rise));Cell candidate=new Cell(x,y,z);var feet=world.getBlockAt(x,y,z);if(y<=65&&!avoided.contains(candidate)&&game.isLocationInArena(candidate.at(world))&&feet.isPassable()&&feet.getRelative(0,1,0).isPassable()&&feet.getRelative(0,-1,0).isPassable()){selected=candidate;unbuilt=true;}}
                if(selected!=null)break;
            }if(selected==null)return null;built|=unbuilt;route.add(selected.at(world));at=selected;
        }return null;
    }
    private static boolean dropClear(World world,int x,int z,int low,int high){for(int y=low;y<=high+1;y++)if(!world.getBlockAt(x,y,z).isPassable())return false;return true;}
    private static double lineOffset(Cell c,Location origin,Location target){double x=target.getX()-origin.getX(),z=target.getZ()-origin.getZ();return Math.abs((c.x+.5-origin.getX())*z-(c.z+.5-origin.getZ())*x)/Math.max(1,Math.hypot(x,z));}
    private static double metric(Cell c,Location at){return Math.max(Math.abs(c.x+.5-at.getX()),Math.abs(c.z+.5-at.getZ()))+Math.abs(c.y-at.getY())*.5;}
}
