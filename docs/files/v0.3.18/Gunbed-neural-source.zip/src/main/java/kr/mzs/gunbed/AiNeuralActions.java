package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.util.Vector;
import java.util.*;

/** Learned motor output executes real weapon inputs with the same legality/safety gates. */
final class AiNeuralActions {
    private final GunbedCore plugin;private final AiBrain brain;private final BotRuntime runtime;
    private final Map<UUID,Integer> last=new HashMap<>();
    AiNeuralActions(GunbedCore p,AiBrain b,BotRuntime r){plugin=p;brain=b;runtime=r;}
    boolean act(AiBrain.State s,LivingEntity foe,int tick){if(plugin.neural==null)return false;var d=plugin.neural.decision(s);Player p=s.bot.getPlayer();if(d==null||d.confidence()<.5||d.buttons().size()!=12||d.aim().size()!=2||plugin.inventories.locked(p)||plugin.weaponModes.anchored(p)||plugin.turrets.building(p)||s.strategy.consumeUntil>0||s.mining!=null||s.throwUntil>0||AiGuns.reloading(plugin,p))return false;
        // Long-term economic assignments and near-bed commitments remain coherent across frames.
        if(!Set.of("fight","retreat","rush","bridge","infiltrate").contains(d.task())||d.task().equals("fight")&&foe==null||brain.teams.committed(s)&&d.task().equals("retreat"))return false;
        var buttons=d.buttons();boolean fire=buttons.get(7)>.65,use=buttons.get(8)>.65;
        double forward=(buttons.get(0)>.6?1:0)-(buttons.get(1)>.6?1:0),side=(buttons.get(3)>.6?1:0)-(buttons.get(2)>.6?1:0);
        Vector move=p.getLocation().getDirection().setY(0);if(move.lengthSquared()>.01)move.normalize();Vector right=new Vector(-move.getZ(),0,move.getX());move.multiply(forward).add(right.multiply(side));
        if(move.lengthSquared()<.01&&!fire&&!use&&buttons.get(4)<=.7)return false;
        boolean bridge=d.task().equals("bridge");if(move.lengthSquared()>.01&&!AiTerrain.safeStep(p.getLocation(),move)&&!bridge)return false;
        float yaw=p.getYaw()+(float)Math.max(-12,Math.min(12,d.aim().get(0)*90)),pitch=(float)Math.max(-89,Math.min(89,p.getPitch()+Math.max(-10,Math.min(10,d.aim().get(1)*90))));Location aim=p.getEyeLocation().clone();aim.setYaw(yaw);aim.setPitch(pitch);runtime.look(s.bot,p.getEyeLocation().add(aim.getDirection().multiply(12)));
        if(bridge){if(!brain.utilityWool(p))return false;if(use){var hit=p.rayTraceBlocks(4.5);if(hit!=null&&hit.getHitBlock()!=null&&hit.getHitBlockFace()!=null)runtime.useBlock(s.bot,hit.getHitBlock(),hit.getHitBlockFace());}if(move.lengthSquared()>.01&&!AiTerrain.safeStep(p.getLocation(),move))return false;}
        else if(d.slot()>=0&&d.slot()<3){plugin.inventories.mode(p,true);brain.slot(p,d.slot());}
        boolean canFire=foe!=null&&brain.senses.view(p,foe.getEyeLocation(),false)&&p.hasLineOfSight(foe);
        // Learned fire is still a native input; it neither fabricates hits nor fires at hidden coordinates.
        if(bridge){/* actual useBlock above; never interpret the wool click as a gun input */}
        else if(plugin.throwables.held(p)!=null)plugin.throwables.input(p,fire&&canFire,use&&canFire);
        else if(plugin.addonMelee.held(p)!=null)plugin.addonMelee.input(p,fire&&canFire);
        else{plugin.taWeapons.input(p,fire&&canFire,use);if(plugin.visuals!=null)plugin.visuals.input(p,fire&&canFire,use,false);}
        int prior=last.getOrDefault(p.getUniqueId(),-100);if(tick-prior>=10){if(buttons.get(9)>.7)AiGuns.reload(plugin,p);if(buttons.get(10)>.8)Bukkit.getPluginManager().callEvent(new PlayerSwapHandItemsEvent(p,p.getInventory().getItemInOffHand(),p.getInventory().getItemInMainHand()));last.put(p.getUniqueId(),tick);}
        boolean jump=buttons.get(4)>.7&&p.isOnGround();runtime.move(s.bot,move.getX(),move.getZ(),jump,buttons.get(5)>.6,buttons.get(6)>.6);s.action="neural-"+d.task();s.reason="validated-human-pixel-policy:"+d.version();plugin.learning.telemetry.record(p,"neural-action",Map.of("task",d.task(),"confidence",d.confidence(),"model",d.version(),"fireAllowed",canFire,"learnedButtons",buttons));return true;
    }
}
