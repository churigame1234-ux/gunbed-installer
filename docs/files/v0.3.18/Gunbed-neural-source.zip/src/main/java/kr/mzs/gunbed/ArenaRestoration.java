package kr.mzs.gunbed;
import com.google.gson.*;
import org.bukkit.*;
import org.bukkit.block.data.BlockData;
import org.bukkit.event.*;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.Game;
import java.util.*;
import java.nio.file.*;

/** Drain the engine's change journal once, then restore a bounded amount each tick. */
final class ArenaRestoration implements Listener {
    private record Change(Location at,BlockData data){}
    private record Job(Game game,ArrayDeque<Change> changes,Path journal,int total,long started){}
    private final Map<Game,Job> jobs=new LinkedHashMap<>();
    private final GunbedCore plugin;
    ArenaRestoration(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,1);}
    private String id(Game g){return UUID.nameUUIDFromBytes(g.getName().getBytes(java.nio.charset.StandardCharsets.UTF_8)).toString();}
    boolean busy(Game g){return jobs.containsKey(g);}
    @SuppressWarnings("unchecked")
    @EventHandler(priority=EventPriority.HIGHEST)public void prepare(BedwarsPreRebuildingEvent e){try{
        var region=e.getGame().getRegion();if(!region.getClass().getName().endsWith("FlatteningRegion"))return;
        var builtField=region.getClass().getDeclaredField("builtBlocks");var brokenField=region.getClass().getDeclaredField("brokenOriginalBlocks");builtField.setAccessible(true);brokenField.setAccessible(true);
        List<Location> built=(List<Location>)builtField.get(region);Map<Location,BlockData> broken=(Map<Location,BlockData>)brokenField.get(region);
        LinkedHashMap<Location,BlockData> desired=new LinkedHashMap<>();for(Location at:built)desired.put(at.clone(),Material.AIR.createBlockData());for(var entry:broken.entrySet())desired.put(entry.getKey().clone(),entry.getValue().clone());if(desired.isEmpty())return;
        List<Change> sorted=desired.entrySet().stream().map(x->new Change(x.getKey(),x.getValue())).sorted(Comparator.comparingInt((Change x)->x.at.getBlockX()>>4).thenComparingInt(x->x.at.getBlockZ()>>4).thenComparingInt(x->x.at.getBlockY())).toList();
        Path file=plugin.getDataFolder().toPath().resolve("restore-journals").resolve(id(e.getGame())+".json");Files.createDirectories(file.getParent());RestorePacer.save(plugin,file,sorted);
        jobs.put(e.getGame(),new Job(e.getGame(),new ArrayDeque<>(sorted),file,sorted.size(),System.nanoTime()));built.clear();broken.clear();
    }catch(ReflectiveOperationException|java.io.IOException error){plugin.getLogger().log(java.util.logging.Level.SEVERE,"Batched restore unavailable; using engine journal",error);}}
    private void tick(){RestorePacer.tick(this,plugin);}
    void recover(){Path dir=plugin.getDataFolder().toPath().resolve("restore-journals");if(!Files.isDirectory(dir))return;try(var paths=Files.list(dir)){for(Path path:paths.filter(x->x.toString().endsWith(".json")).toList()){String id=path.getFileName().toString().replace(".json","");Game game=org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getGames().stream().filter(g->id(g).equals(id)).findFirst().orElse(null);if(game==null&&id.equals(UUID.nameUUIDFromBytes("AI_Orchestra_Shared".getBytes(java.nio.charset.StandardCharsets.UTF_8)).toString()))continue;if(game==null)throw new IllegalStateException("Orphan restore journal "+id);ArrayDeque<Change> changes=new ArrayDeque<>();for(JsonElement value:JsonParser.parseString(Files.readString(path)).getAsJsonArray()){JsonArray r=value.getAsJsonArray();World w=Bukkit.getWorld(r.get(0).getAsString());if(w==null)throw new IllegalStateException("Restore world missing");changes.add(new Change(new Location(w,r.get(1).getAsInt(),r.get(2).getAsInt(),r.get(3).getAsInt()),Bukkit.createBlockData(r.get(4).getAsString())));}jobs.put(game,new Job(game,changes,path,changes.size(),System.nanoTime()));}}catch(java.io.IOException e){throw new java.io.UncheckedIOException(e);}}
    @EventHandler(priority=EventPriority.LOWEST)public void join(BedwarsPlayerJoinEvent e){if(busy(e.getGame())){e.setCancelled(true);e.getPlayer().sendMessage("§e경기장을 복구하고 있습니다. 잠시 후 다시 참가하세요.");}}
}
