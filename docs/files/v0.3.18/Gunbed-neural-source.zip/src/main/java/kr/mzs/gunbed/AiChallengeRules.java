package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.potion.*;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.*;
import java.util.*;

/** Human-only Gunbed adaptations of the challenge catalogue. No rules affect the opposing bots. */
final class AiChallengeRules implements Listener {
    private static final class Match {
        AiPractice.Room room;boolean failed,success;String failure="";int began,beds;UUID president;
        final Map<UUID,Double> health=new HashMap<>(),stamina=new HashMap<>();
        final Map<UUID,Integer> exposure=new HashMap<>(),lastAttack=new HashMap<>(),appleUntil=new HashMap<>(),nextRain=new HashMap<>(),defusing=new HashMap<>(),defused=new HashMap<>();
        final Map<UUID,Set<Material>> collected=new HashMap<>();final Map<String,Integer> bought=new HashMap<>();
        final Map<Location,String> builders=new HashMap<>();final Set<Material> colors=new HashSet<>();
    }
    private record Result(List<String> lines,int until){} private final Map<UUID,Result> results=new HashMap<>();private final GunbedCore plugin;private final Map<Game,Match> matches=new HashMap<>();
    AiChallengeRules(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,4,4);}
    private Game game(Player p){return BedwarsAPI.getInstance().getGameOfPlayer(p);}
    private Match match(Player p){Game g=game(p);Match m=matches.get(g);return m!=null&&!BotRuntime.bot(p)&&m.room.enrolled.contains(p.getUniqueId())?m:null;}
    AiChallenge rule(Player p){Match m=match(p);return m==null||p.getGameMode()==GameMode.SPECTATOR?AiChallenge.NONE:m.room.challenge;}
    private boolean living(Player p){return p.isOnline()&&!p.isDead()&&p.getGameMode()!=GameMode.SPECTATOR;}
    private void fail(Match m,String reason){if(m.failed)return;m.failed=true;m.failure=reason;for(Player p:plugin.practice.humans(m.room)){p.sendMessage("§c챌린지 실패: "+reason+" §7· 경기는 계속되지만 이번 해금은 받을 수 없습니다.");p.sendTitle("§c챌린지 실패",reason,5,40,10);}}
    List<String> sidebar(Player p){Match m=match(p);if(m==null){Result previous=results.get(p.getUniqueId());return previous!=null&&Bukkit.getCurrentTick()<previous.until?previous.lines:List.of();}if(m.room.challenge==AiChallenge.NONE)return List.of();AiChallenge c=m.room.challenge;List<String> lines=new ArrayList<>();String title=c.title.contains(" · ")?c.title.substring(c.title.indexOf(" · ")+3):c.title;lines.add("§6챌린지 §f"+title);String text=c.description;int width=22;for(int from=0;from<Math.min(text.length(),width*3);from+=width)lines.add("§7"+text.substring(from,Math.min(text.length(),from+width)));lines.add(m.failed?"§c실패: "+m.failure:m.success?"§a성공!":"§e진행 중 · 조건을 지키고 승리");if(!m.failed&&!m.success){if(c==AiChallenge.COLLECTOR){Set<Material> needed=m.colors;long done=m.collected.getOrDefault(p.getUniqueId(),Set.of()).stream().filter(needed::contains).count();lines.add("§f팀 양털 제출 §a"+done+"/"+needed.size());}if(c==AiChallenge.RED_LIGHT_GREEN_LIGHT)lines.add(red(m)?"§c멈춤 · "+((500-(Bukkit.getCurrentTick()-m.began)%500+19)/20)+"초":"§a이동 가능");if(c==AiChallenge.STAMINA)lines.add("§f스태미나 §a"+(int)(double)m.stamina.getOrDefault(p.getUniqueId(),100d)+"/100");if(c==AiChallenge.DEFUSER)lines.add(m.defused.getOrDefault(p.getUniqueId(),0)>Bukkit.getCurrentTick()?"§a해체 완료 · "+((m.defused.get(p.getUniqueId())-Bukkit.getCurrentTick()+19)/20)+"초":"§f침대 해체 §e"+(m.defusing.containsKey(p.getUniqueId())?Math.max(0,100-Bukkit.getCurrentTick()+m.defusing.get(p.getUniqueId()))/20d:5)+"초");if(c==AiChallenge.CANT_TOUCH_THIS)lines.add("§f적 침대 파괴 §a"+m.beds+"/1");if(c==AiChallenge.PROTECT_THE_PRESIDENT){Player president=Bukkit.getPlayer(m.president);lines.add("§f대통령 §a"+(president==null?"접속 종료":TeamPalette.display(president)));}}return lines;}
    private boolean wood(Material type){String n=type.name();return n.contains("PLANKS")||n.contains("_LOG")||n.contains("WOODEN_")||n.contains("_WOOD");}
    boolean container(Player p){return !Set.of(AiChallenge.SELFISH,AiChallenge.WOODWORKER).contains(rule(p));}
    boolean resource(Player p,Material type){return rule(p)!=AiChallenge.RENEGADE||type!=Material.DIAMOND;}
    boolean killResources(UUID id,Material type){for(Match m:matches.values())if(m.room.enrolled.contains(id)){AiChallenge c=m.room.challenge;if(c==AiChallenge.PATRIOT||c==AiChallenge.CAPPED_RESOURCES||c==AiChallenge.RENEGADE&&type==Material.DIAMOND)return false;}return true;}
    boolean single(Player p){return rule(p)==AiChallenge.SLEIGHT_OF_HAND;}
    boolean compact(Player p,Inventory inventory){if(!single(p))return true;List<ItemStack> items=Arrays.stream(inventory.getStorageContents()).filter(Objects::nonNull).filter(i->!i.getType().isAir()&&!plugin.containers.button(i)&&!FixedTracker.item(i)).toList();if(items.size()>6)return false;ItemStack[] contents=new ItemStack[36];for(int n=0;n<items.size();n++)contents[n==0?0:n+8]=items.get(n);contents[MatchContainers.BUTTON_SLOT]=plugin.containers.button();inventory.setStorageContents(contents);return true;}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void held(PlayerItemHeldEvent e){if(single(e.getPlayer())&&e.getNewSlot()!=0)e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void limitedClick(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p)||!single(p)||!(e.getClickedInventory() instanceof PlayerInventory))return;int slot=e.getSlot();if(slot>=0&&slot<36&&slot!=0&&(slot<9||slot>13)&&slot!=MatchContainers.BUTTON_SLOT)e.setCancelled(true);if(e.isShiftClick())e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void limitedDrag(InventoryDragEvent e){if(!(e.getWhoClicked() instanceof Player p)||!single(p))return;for(int raw:e.getRawSlots())if(e.getView().getInventory(raw) instanceof PlayerInventory){int slot=e.getView().convertSlot(raw);if(slot!=0&&(slot<9||slot>13))e.setCancelled(true);}}
    boolean movementSkill(Player p){return !Set.of(AiChallenge.OLD_MAN,AiChallenge.WEIGHTED_ITEMS,AiChallenge.BRIDGING_FOR_DUMMIES,AiChallenge.RED_LIGHT_GREEN_LIGHT).contains(rule(p))&&(rule(p)!=AiChallenge.STAMINA||match(p).stamina.getOrDefault(p.getUniqueId(),100.0)>=15);}
    boolean healing(Player p){return rule(p)!=AiChallenge.NO_HEALING;}
    boolean weapon(Player p){return weaponItem(p,p.getInventory().getItemInMainHand());}
    boolean weaponItem(Player p,ItemStack item){
        if(item==null)return true;AiChallenge c=rule(p);String id=plugin.ammo.id(item),role=plugin.inventories.role(item);boolean melee="melee".equals(role)||plugin.addonMelee.id(item)!=null||item.getType().name().endsWith("_SWORD")||plugin.arsenal.weapons().stream().anyMatch(w->w.id().equals(id)&&w.role().equals("melee"));boolean gun=!id.isEmpty()&&!melee;
        return switch(c){
            case WOODWORKER->wood(item.getType());
            case MARKSMAN->item.getType()==Material.BOW;
            case SOCIAL_DISTANCING->item.getType()==Material.STICK||item.getType()==Material.BOW&&item.containsEnchantment(org.bukkit.enchantments.Enchantment.PUNCH);
            case PACIFIST->!gun&&!melee&&item.getType()!=Material.BOW;
            case SWORDLESS->!melee||id.equals("cs:망치")||item.getType().name().endsWith("_AXE");
            default->true;
        };
    }
    boolean buy(Player p,String id,Map<?,?> entry){
        AiChallenge c=rule(p);if(c==AiChallenge.NONE)return true;
        String data=entry.toString().toLowerCase(Locale.ROOT);boolean utility=entry.containsKey("throwable-kind")||entry.containsKey("turret-kind")||Boolean.TRUE.equals(entry.get("grappling-hook"))||data.contains("special-id=");
        boolean deny=switch(c){
            case RENEGADE->data.contains("spawner-id=diamond");
            case WARMONGER->utility;
            case WOODWORKER->!data.contains("planks")&&!data.contains("wooden_");
            case BRIDGING_FOR_DUMMIES->utility||data.contains("products")&&!id.equals("wool")&&!data.contains("sponge")&&!data.contains("bow")&&!data.contains("armor");
            case NO_WOOL->id.equals("wool")||data.contains("tower")||data.contains("egg-bridger");
            case NO_HEALING->id.contains("gapple")||data.contains("turret-kind=healing");
            case WEIGHTED_ITEMS,OLD_MAN,RED_LIGHT_GREEN_LIGHT->Boolean.TRUE.equals(entry.get("grappling-hook"))||data.contains("egg-bridger");
            case MARKSMAN->entry.containsKey("addon-melee")||entry.containsKey("throwable-kind")||entry.containsKey("turret-kind")&&!data.contains("healing");
            case SOCIAL_DISTANCING->entry.containsKey("addon-melee")||entry.containsKey("throwable-kind")||entry.containsKey("turret-kind")&&!data.contains("healing")||id.contains("sword");
            case SWORDLESS->id.contains("sword")||entry.containsKey("addon-melee");
            case PACIFIST->id.contains("sword")||entry.containsKey("addon-melee")||entry.containsKey("turret-kind")&&!data.contains("healing");
            case CAPPED_RESOURCES->match(p).bought.getOrDefault(id,0)>=8;
            default->false;
        };
        if(deny){p.sendMessage("§c현재 챌린지에서는 이 상품을 구매할 수 없습니다.");return false;}return true;
    }
    void bought(Player p,String id){Match m=match(p);if(m!=null)m.bought.merge(id,1,Integer::sum);}
    boolean upgrade(Player p,String id){AiChallenge c=rule(p);boolean allow=c!=AiChallenge.RENEGADE&&!(c==AiChallenge.MINIMUM_WAGE&&id.equals("spawner-multiplier"))&&!(c==AiChallenge.NO_HEALING&&id.contains("heal"));if(!allow)p.sendMessage("§c챌린지에서 제한된 팀 업그레이드입니다.");return allow;}
    int generatorFactor(Game g,org.screamingsandals.bedwars.api.Team team){Match m=matches.get(g);return m!=null&&m.room.challenge==AiChallenge.MINIMUM_WAGE&&team!=null&&team.getName().equals(m.room.humanTeam)?2:1;}
    boolean invisibleShop(Player p){return rule(p)==AiChallenge.INVISIBLE_SHOP;}
    long shopSeed(Player p){Match m=match(p);return m==null?0:m.began;}
    @EventHandler(priority=EventPriority.MONITOR)public void start(BedwarsGameStartedEvent e){if(plugin.practice==null)return;var room=plugin.practice.room(e.getGame());if(room==null)return;Match m=new Match();m.room=room;m.began=Bukkit.getCurrentTick();m.president=room.host;for(var team:e.getGame().getRunningTeams())m.colors.add(Material.valueOf(TeamPalette.of(e.getGame(),team).dye().name()+"_WOOL"));matches.put(e.getGame(),m);if(room.challenge==AiChallenge.TOXIC_RAIN){e.getGame().getGameWorld().setStorm(true);e.getGame().getGameWorld().setWeatherDuration(100000);}for(Player p:plugin.practice.humans(room))p.sendMessage("§e챌린지: "+room.challenge.title+" §7· "+room.challenge.description);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void collect(PlayerInteractEntityEvent e){Player p=e.getPlayer();Match m=match(p);if(rule(p)!=AiChallenge.COLLECTOR||m==null)return;Game g=game(p);boolean own=g.getGameStores().stream().anyMatch(s->s.getEntity()==e.getRightClicked()&&s.getTeam()!=null&&s.getTeam().getName().equals(m.room.humanTeam));if(!own)return;Set<Material> collected=m.collected.computeIfAbsent(p.getUniqueId(),k->new HashSet<>());ItemStack[] items=plugin.inventories.utility(p);for(int i=0;i<items.length;i++){ItemStack item=items[i];if(item==null||!item.getType().name().endsWith("_WOOL")||collected.contains(item.getType()))continue;collected.add(item.getType());long count=plugin.stacks.count(item);items[i]=count>1?plugin.stacks.sized(item,count-1):null;}plugin.inventories.utility(p,items);p.sendMessage("§e양털 제출: "+collected.size()+"/"+g.getAvailableTeams().size());}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void place(BlockPlaceEvent e){Player p=e.getPlayer();Game g=game(p);Match m=matches.get(g);if(m!=null){var t=g.getTeamOfPlayer(p);if(t!=null)m.builders.put(e.getBlockPlaced().getLocation(),t.getName());}AiChallenge c=rule(p);if(c==AiChallenge.NO_WOOL&&e.getBlock().getType().name().endsWith("_WOOL")||c==AiChallenge.WOODWORKER&&!wood(e.getBlock().getType())||c==AiChallenge.BRIDGING_FOR_DUMMIES&&e.getBlock().getType()!=Material.SPONGE)e.setCancelled(true);}
    boolean pickupAllowed(Player p,Item entity){AiChallenge c=rule(p);Material type=entity.getItemStack().getType();
        if(c==AiChallenge.RENEGADE&&type==Material.DIAMOND||c==AiChallenge.NO_WOOL&&type.name().endsWith("_WOOL")||c==AiChallenge.WOODWORKER&&!wood(type)&&!ResourceWallet.TYPES.contains(type)||c==AiChallenge.BRIDGING_FOR_DUMMIES&&type.isBlock()&&type!=Material.SPONGE)return false;
        if(Set.of(AiChallenge.PATRIOT,AiChallenge.CAPPED_RESOURCES).contains(c)){
            Game g=game(p);var own=g.getTeamOfPlayer(p);
            if(ResourceWallet.TYPES.contains(type)){boolean home=g.getItemSpawners().stream().anyMatch(s->s.getTeam()!=null&&s.getTeam().getName().equals(own.getName())&&s.getLocation().getWorld()==entity.getWorld()&&s.getLocation().distanceSquared(entity.getLocation())<9);if(!home)return false;}
            UUID thrower=entity.getThrower();if(thrower!=null){Player source=Bukkit.getPlayer(thrower);if(source!=null&&!own.isPlayerInTeam(source))return false;}
        }return true;
    }
    @EventHandler(priority=EventPriority.LOW,ignoreCancelled=true)public void pickup(EntityPickupItemEvent e){if(e.getEntity() instanceof Player p&&!pickupAllowed(p,e.getItem()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void drop(PlayerDropItemEvent e){if(rule(e.getPlayer())==AiChallenge.SELFISH)e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void container(InventoryOpenEvent e){if(e.getPlayer() instanceof Player p&&Set.of(AiChallenge.SELFISH,AiChallenge.WOODWORKER).contains(rule(p))&&(e.getInventory().getHolder() instanceof org.bukkit.block.Chest||e.getInventory().getType()==InventoryType.ENDER_CHEST))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST)public void customContainer(PlayerInteractEvent e){if(e.getClickedBlock()!=null&&Set.of(Material.CHEST,Material.TRAPPED_CHEST,Material.ENDER_CHEST).contains(e.getClickedBlock().getType())&&Set.of(AiChallenge.SELFISH,AiChallenge.WOODWORKER).contains(rule(e.getPlayer()))){e.setCancelled(true);e.setUseInteractedBlock(Event.Result.DENY);}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void flight(PlayerToggleFlightEvent e){if(!movementSkill(e.getPlayer()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void sprint(PlayerToggleSprintEvent e){if(e.isSprinting()&&rule(e.getPlayer())==AiChallenge.OLD_MAN)e.setCancelled(true);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void sneak(PlayerToggleSneakEvent e){if(e.isSneaking()&&rule(e.getPlayer())==AiChallenge.STANDING_TALL)fail(match(e.getPlayer()),"웅크리기");}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void use(PlayerInteractEvent e){AiChallenge c=rule(e.getPlayer());if(c==AiChallenge.NONE)return;ItemStack item=e.getItem();if(item==null)return;String data=item.toString().toLowerCase(Locale.ROOT);if(c==AiChallenge.WARMONGER&&(plugin.throwables.kind(item)!=null||data.contains("turret")||data.contains("grappl")||Set.of(Material.FIRE_CHARGE,Material.EGG,Material.SNOWBALL,Material.TNT).contains(item.getType())))e.setCancelled(true);if(c==AiChallenge.NO_WOOL&&(item.getType()==Material.EGG||item.getType()==Material.CHEST))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void consume(PlayerItemConsumeEvent e){Player p=e.getPlayer();ItemStack item=e.getItem();boolean heal=item.getType()==Material.GOLDEN_APPLE;if(item.getItemMeta() instanceof org.bukkit.inventory.meta.PotionMeta pm){String base=pm.getBasePotionType()==null?"":pm.getBasePotionType().name();heal|=base.contains("HEALING")||base.contains("REGENERATION")||pm.getCustomEffects().stream().anyMatch(f->f.getType()==PotionEffectType.INSTANT_HEALTH||f.getType()==PotionEffectType.REGENERATION);}if(!healing(p)&&heal)e.setCancelled(true);if(rule(p)==AiChallenge.STAMINA&&item.getType()==Material.GOLDEN_APPLE)match(p).appleUntil.put(p.getUniqueId(),Bukkit.getCurrentTick()+200);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void regain(EntityRegainHealthEvent e){if(e.getEntity() instanceof Player p&&!healing(p))e.setCancelled(true);}
    private Player attacker(Entity entity){return entity instanceof Player p?p:entity instanceof Projectile a&&a.getShooter() instanceof Player p?p:null;}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void attack(EntityDamageByEntityEvent e){Player p=attacker(e.getDamager());if(p==null)p=attacker(e.getDamageSource().getCausingEntity());if(p==null||rule(p)==AiChallenge.NONE)return;AiChallenge c=rule(p);boolean arrow=e.getDamager() instanceof AbstractArrow;
        boolean utility=plugin.throwables.damageKind()!=null||e.getDamager() instanceof TNTPrimed||e.getDamager() instanceof Fireball||BlastExposure.applying();
        if(c==AiChallenge.MARKSMAN&&!arrow||c==AiChallenge.PACIFIST&&!utility||c==AiChallenge.SOCIAL_DISTANCING&&!(arrow&&((AbstractArrow)e.getDamager()).getKnockbackStrength()>0||e.getDamager() instanceof Player&&p.getInventory().getItemInMainHand().getType()==Material.STICK)||!arrow&&!utility&&!weapon(p)){e.setCancelled(true);return;}Match m=match(p);int tick=Bukkit.getCurrentTick(),last=m.lastAttack.getOrDefault(p.getUniqueId(),-1000);if(c==AiChallenge.SLOW_REFLEXES&&tick!=last&&tick-last<40){e.setCancelled(true);return;}if(c==AiChallenge.STAMINA){double stamina=m.stamina.getOrDefault(p.getUniqueId(),100.0);if(stamina<3){e.setCancelled(true);return;}m.stamina.put(p.getUniqueId(),stamina-3);}m.lastAttack.put(p.getUniqueId(),tick);if(c==AiChallenge.SWORDLESS&&p.getInventory().getItemInMainHand().getType().name().endsWith("_AXE")&&plugin.ammo.id(p.getInventory().getItemInMainHand()).isEmpty())e.setDamage(Math.min(500,e.getDamage()));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void damaged(EntityDamageEvent e){if(!(e.getEntity() instanceof Player p)||e.getFinalDamage()<=0)return;if(rule(p)==AiChallenge.CANT_TOUCH_THIS)fail(match(p),"피해를 받음");}
    @EventHandler(priority=EventPriority.MONITOR)public void killed(BedwarsPlayerKilledEvent e){Player p=e.getPlayer();Match m=match(p);if(m==null)return;if(m.room.challenge==AiChallenge.PROTECT_THE_PRESIDENT&&p.getUniqueId().equals(m.president))fail(m,"대통령 사망");if(m.room.challenge==AiChallenge.REGULAR_SHOPPER)plugin.bedwars.shop.forgetEquipment(p,e.getGame());}
    @EventHandler public void respawn(BedwarsPlayerRespawnedIngameEvent e){Match m=match(e.getPlayer());if(m!=null){m.health.remove(e.getPlayer().getUniqueId());m.stamina.put(e.getPlayer().getUniqueId(),100.0);m.defusing.remove(e.getPlayer().getUniqueId());}if(rule(e.getPlayer())!=AiChallenge.REGULAR_SHOPPER)return;Bukkit.getScheduler().runTaskLater(plugin,()->{if(!living(e.getPlayer()))return;e.getPlayer().getInventory().setLeggings(new ItemStack(Material.LEATHER_LEGGINGS));e.getPlayer().getInventory().setBoots(new ItemStack(Material.LEATHER_BOOTS));MatchVitals.armor(e.getPlayer(),false);},3);}
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void breakBlock(BlockBreakEvent e){Player p=e.getPlayer();Match m=match(p);if(m==null||!(e.getBlock().getBlockData() instanceof org.bukkit.block.data.type.Bed))return;AiChallenge c=rule(p);if(c==AiChallenge.PROTECT_THE_PRESIDENT&&!p.getUniqueId().equals(m.president)){e.setCancelled(true);return;}if(c==AiChallenge.DEFUSER&&m.defused.getOrDefault(p.getUniqueId(),0)<Bukkit.getCurrentTick()){e.setCancelled(true);m.defusing.putIfAbsent(p.getUniqueId(),Bukkit.getCurrentTick());p.sendActionBar("§e침대 옆 5초 해체 중 · 침대를 바라보며 기다리세요.");}}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void bed(BedwarsTargetBlockDestroyedEvent e){Match m=matches.get(e.getGame());if(m!=null&&e.getPlayer()!=null&&!BotRuntime.bot(e.getPlayer()))m.beds++;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void move(PlayerMoveEvent e){Player p=e.getPlayer();AiChallenge c=rule(p);if(c==AiChallenge.NONE||e.getTo()==null||e.getFrom().distanceSquared(e.getTo())<.0004)return;Match m=match(p);if(c==AiChallenge.RED_LIGHT_GREEN_LIGHT&&red(m))fail(m,"빨간 신호에 이동");if(c==AiChallenge.PATRIOT&&p.isOnGround()){String team=m.builders.get(p.getLocation().subtract(0,.2,0).getBlock().getLocation());if(team!=null&&!team.equals(m.room.humanTeam))fail(m,"적이 설치한 블록을 밟음");}if(c==AiChallenge.STAMINA)m.stamina.merge(p.getUniqueId(),-e.getFrom().distance(e.getTo())*(p.isSprinting()?4:2),Double::sum);}
    private boolean red(Match m){return (Bukkit.getCurrentTick()-m.began)%500>=400;}
    private void tick(){for(var entry:matches.entrySet()){Game g=entry.getKey();Match m=entry.getValue();if(g.getStatus()!=GameStatus.RUNNING)continue;for(Player p:plugin.practice.humans(m.room)){if(!living(p))continue;AiChallenge c=m.room.challenge;UUID id=p.getUniqueId();
        if(c==AiChallenge.LAZY_MINER)p.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE,40,0,false,false,false));
        if(c==AiChallenge.NO_HEALING){Double old=m.health.put(id,p.getHealth());if(old!=null&&p.getHealth()>old){p.setHealth(old);m.health.put(id,old);}}
        if(c==AiChallenge.OLD_MAN)p.setSprinting(false);
        if(c==AiChallenge.WEIGHTED_ITEMS){long weight=Arrays.stream(plugin.inventories.utility(p)).filter(Objects::nonNull).mapToLong(plugin.stacks::count).sum()+plugin.wallet.snapshot(p).values().stream().mapToLong(Long::longValue).sum();p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,8,(int)Math.min(3,weight/64),false,false,false));}
        if(c==AiChallenge.STAMINA){double v=Math.max(0,Math.min(100,m.stamina.getOrDefault(id,100.0)+(p.getVelocity().lengthSquared()<.01?3:.4)*(m.appleUntil.getOrDefault(id,0)>Bukkit.getCurrentTick()?2:1)));m.stamina.put(id,v);if(v<5)p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,8,4,false,false,false));p.sendActionBar("§e스태미나 §f"+(int)v+"/100");}
        if(c==AiChallenge.RED_LIGHT_GREEN_LIGHT)p.sendActionBar(red(m)?"§c빨간 신호 · 멈추세요!":"§a초록 신호 · 이동 가능");
        if(c==AiChallenge.DEFUSER&&m.defusing.containsKey(id)){Block target=p.getTargetBlockExact(4);if(target==null||!(target.getBlockData() instanceof org.bukkit.block.data.type.Bed)){m.defusing.remove(id);continue;}int left=100-(Bukkit.getCurrentTick()-m.defusing.get(id));p.sendActionBar("§e해체까지 "+Math.max(0,(left+19)/20)+"초");if(left<=0){m.defused.put(id,Bukkit.getCurrentTick()+2400);m.defusing.remove(id);p.sendMessage("§a해체 완료 · 2분 안에 침대를 파괴하세요.");}}
        if(c==AiChallenge.TOXIC_RAIN){boolean exposed=p.getWorld().getHighestBlockYAt(p.getLocation())<=p.getY();int n=exposed?m.exposure.merge(id,4,Integer::sum):0;if(!exposed)m.exposure.remove(id);if(n>0&&Bukkit.getCurrentTick()>=m.nextRain.getOrDefault(id,0)){m.nextRain.put(id,Bukkit.getCurrentTick()+Math.max(4,40/(1+n/200)));ItemStack[] items=plugin.inventories.utility(p);for(int i=0;i<items.length;i++)if(items[i]!=null&&!plugin.inventories.protectedItem(items[i])&&!plugin.containers.button(items[i])){long count=plugin.stacks.count(items[i]);items[i]=count>1?plugin.stacks.sized(items[i],count-1):null;plugin.inventories.utility(p,items);break;}}}
    }}}
    @EventHandler(priority=EventPriority.MONITOR)public void ending(BedwarsGameEndingEvent e){Match m=matches.get(e.getGame());if(m==null||m.room.challenge==AiChallenge.NONE||m.failed)return;if(e.getWinningTeam()==null||!e.getWinningTeam().getName().equals(m.room.humanTeam)){fail(m,"경기에서 승리하지 못함");return;}if(m.room.challenge==AiChallenge.CANT_TOUCH_THIS&&m.beds==0){fail(m,"적 침대 파괴 조건 미달");return;}
        if(m.room.challenge==AiChallenge.COLLECTOR){Set<Material> needed=m.colors;for(UUID id:m.room.enrolled)if(!m.collected.getOrDefault(id,Set.of()).containsAll(needed)){fail(m,"참가 팀 양털 제출 조건 미달");return;}}m.success=true;for(UUID id:m.room.enrolled)plugin.practice.recordCompletion(id,m.room.challenge);for(Player p:plugin.practice.humans(m.room)){p.sendMessage("§a챌린지 성공! §f"+m.room.challenge.title);p.sendTitle("§a챌린지 성공!",m.room.challenge.title,5,60,10);}}
    @EventHandler public void end(BedwarsGameEndEvent e){Match live=matches.get(e.getGame());if(live!=null&&live.room.challenge!=AiChallenge.NONE)for(UUID id:live.room.enrolled){Player player=Bukkit.getPlayer(id);if(player!=null)results.put(id,new Result(sidebar(player),Bukkit.getCurrentTick()+200));}Match m=matches.remove(e.getGame());if(m!=null&&m.room.challenge==AiChallenge.TOXIC_RAIN)e.getGame().getGameWorld().setStorm(false);}
}
