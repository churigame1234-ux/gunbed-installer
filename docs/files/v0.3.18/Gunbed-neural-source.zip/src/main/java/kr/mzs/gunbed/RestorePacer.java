package kr.mzs.gunbed;

import com.google.gson.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import org.bukkit.*;
import org.bukkit.block.data.BlockData;
import org.screamingsandals.bedwars.api.game.Game;

/** Slow, load-aware world edits; journal I/O and unloaded chunks never block a tick. */
final class RestorePacer {
    private static final Map<Path,CompletableFuture<Void>> saving=new HashMap<>();
    private static final Map<Object,CompletableFuture<Void>> deleting=new IdentityHashMap<>();
    private static final Map<String,CompletableFuture<Chunk>> loading=new HashMap<>();
    private static final Map<Game,Chunk> pinned=new IdentityHashMap<>();
    private static final Set<Path> warned=new HashSet<>();
    static long applied,maxBatch;
    static void save(GunbedCore plugin,Path file,List<?> changes) {
        CompletableFuture<Void> ready=new CompletableFuture<>();saving.put(file,ready);
        Bukkit.getScheduler().runTaskAsynchronously(plugin,()->{try{
            JsonArray json=new JsonArray();for(Object c:changes){Location at=(Location)value(c,"at");BlockData data=(BlockData)value(c,"data");JsonArray row=new JsonArray();row.add(at.getWorld().getName());row.add(at.getBlockX());row.add(at.getBlockY());row.add(at.getBlockZ());row.add(data.getAsString());json.add(row);}
            Path temp=file.resolveSibling(file.getFileName()+".tmp");Files.writeString(temp,json.toString());Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);ready.complete(null);
        }catch(Throwable e){ready.completeExceptionally(e);}});
    }
    private static Object value(Object record,String name)throws ReflectiveOperationException {Method m=record.getClass().getDeclaredMethod(name);m.setAccessible(true);return m.invoke(record);}
    @SuppressWarnings("unchecked")
    static void tick(ArenaRestoration controller,GunbedCore plugin) {
        try {
            Field field=ArenaRestoration.class.getDeclaredField("jobs");field.setAccessible(true);Map<Game,Object> jobs=(Map<Game,Object>)field.get(controller);
            if(jobs.isEmpty())return;
            // Prefer gameplay over restoration during an already busy tick period.
            if(Bukkit.getAverageTickTime()>45)return;
            int cap=Math.clamp(plugin.getConfig().getInt("restoration.max-blocks-per-tick",16),1,64),count=0;
            long limit=System.nanoTime()+(long)(Math.clamp(plugin.getConfig().getDouble("restoration.time-budget-ms",.5),.1,1)*1_000_000);
            for(var it=jobs.entrySet().iterator();it.hasNext();) {
                var entry=it.next();Game game=entry.getKey();Object job=entry.getValue();Path file=(Path)value(job,"journal");
                var saved=saving.get(file);if(saved!=null&&!saved.isDone())continue;
                if(saved!=null&&saved.isCompletedExceptionally()){if(warned.add(file))plugin.getLogger().severe("Restore journal save failed; arena remains locked: "+file);continue;}
                ArrayDeque<?> changes=(ArrayDeque<?>)value(job,"changes");
                while(!changes.isEmpty()&&count<cap&&System.nanoTime()<limit) {
                    Object change=changes.peekFirst();Location at=(Location)value(change,"at");World world=at.getWorld();int x=at.getBlockX()>>4,z=at.getBlockZ()>>4;
                    if(!world.isChunkLoaded(x,z)) {
                        String key=world.getUID()+":"+x+":"+z;
                        CompletableFuture<Chunk> pending=loading.computeIfAbsent(key,k->world.getChunkAtAsync(x,z,false));
                        if(!pending.isDone())break;
                        if(pending.isCompletedExceptionally()||pending.getNow(null)==null){if(warned.add(file))plugin.getLogger().severe("Restore chunk unavailable; arena remains locked: "+key);break;}
                        loading.remove(key);if(!world.isChunkLoaded(x,z))break;
                    }
                    Chunk chunk=world.getChunkAt(x,z);Chunk old=pinned.get(game);
                    if(old!=chunk){chunk.addPluginChunkTicket(plugin);if(old!=null)old.removePluginChunkTicket(plugin);pinned.put(game,chunk);}
                    // The chunk is loaded and ticketed, so this cannot synchronously
                    // generate/load a chunk while applying the original block data.
                    chunk.getBlock(at.getBlockX()&15,at.getBlockY(),at.getBlockZ()&15).setBlockData((BlockData)value(change,"data"),false);
                    changes.removeFirst();count++;applied++;
                }
                if(changes.isEmpty()) {
                    CompletableFuture<Void> removed=deleting.get(job);
                    if(removed==null){removed=new CompletableFuture<>();deleting.put(job,removed);final var done=removed;Bukkit.getScheduler().runTaskAsynchronously(plugin,()->{try{Files.deleteIfExists(file);done.complete(null);}catch(Throwable e){done.completeExceptionally(e);}});}
                    if(removed.isDone()&&!removed.isCompletedExceptionally()) {
                        Chunk chunk=pinned.remove(game);if(chunk!=null)chunk.removePluginChunkTicket(plugin);
                        plugin.getLogger().info("Restored "+value(job,"total")+" changed arena blocks in "+(System.nanoTime()-(long)value(job,"started"))/1_000_000+"ms: "+game.getName());
                        deleting.remove(job);saving.remove(file);warned.remove(file);it.remove();
                    }
                }
                if(count>=cap||System.nanoTime()>=limit)break;
            }
            maxBatch=Math.max(maxBatch,count);
            loading.entrySet().removeIf(e->e.getValue().isDone()&&!e.getValue().isCompletedExceptionally());
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Paced restoration failed",e);}
    }
}
