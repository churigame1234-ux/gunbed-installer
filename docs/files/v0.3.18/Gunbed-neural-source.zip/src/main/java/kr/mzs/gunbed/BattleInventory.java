package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.GameStatus;
import org.screamingsandals.bedwars.api.events.*;
import java.util.*;

/** One server-owned weapon bank and one utility bank; only one is exposed. */
final class BattleInventory implements Listener,AutoCloseable {
    static final List<String> ROLES=List.of("primary","secondary","melee","throwable");
    static final class State {ItemStack[] weapons=new ItemStack[36],utility=new ItemStack[36];boolean a=true,locked=true;Location anchor;int utilitySlot;long protectionUntil;}
    private final GunbedCore plugin;
    private final Map<UUID,State> states=new HashMap<>();
    private final Map<UUID,org.screamingsandals.bedwars.api.game.Game> deathGames=new HashMap<>();
    private final NamespacedKey role;
    private final NamespacedKey throwable;
    BattleInventory(GunbedCore p){plugin=p;role=new NamespacedKey(p,"weapon_role");throwable=new NamespacedKey(p,"throwable");Bukkit.getPluginManager().registerEvents(this,p);}
    private boolean match(Player p){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);return g!=null&&g.getStatus()==GameStatus.RUNNING&&g.getTeamOfPlayer(p)!=null&&p.getGameMode()!=GameMode.SPECTATOR;}
    static ItemStack[] copy(ItemStack[] source){return Arrays.stream(source).map(i->i==null?null:i.clone()).toArray(ItemStack[]::new);}
    ItemStack mark(ItemStack item,String value){var meta=item.getItemMeta();meta.getPersistentDataContainer().set(role,PersistentDataType.STRING,value);item.setItemMeta(meta);return item;}
    String role(ItemStack item){return item!=null&&item.hasItemMeta()?item.getItemMeta().getPersistentDataContainer().get(role,PersistentDataType.STRING):null;}
    boolean protectedItem(ItemStack item){return item!=null&&(FixedTracker.item(item)||role(item)!=null||plugin.addonMelee.id(item)!=null||item.hasItemMeta()&&item.getItemMeta().getPersistentDataContainer().has(throwable)||!plugin.ammo.id(item).isEmpty()||item.getType().name().endsWith("_SWORD"));}
    boolean locked(Player p){State s=states.get(p.getUniqueId());return s!=null&&s.locked&&match(p);}
    boolean modeA(Player p){State s=states.get(p.getUniqueId());return s!=null&&s.a;}
    boolean rememberable(Player p){State s=states.get(p.getUniqueId());return s!=null&&!s.locked;}
    ItemStack[] utility(Player p){State s=states.get(p.getUniqueId());return s!=null&&s.a?copy(s.utility):copy(p.getInventory().getStorageContents());}
    void utility(Player p,ItemStack[] contents){State s=states.get(p.getUniqueId());if(s!=null&&s.a)s.utility=copy(contents);else p.getInventory().setStorageContents(copy(contents));}
    List<ItemStack> weapons(Player p){if(plugin.aiRules!=null&&plugin.aiRules.single(p))return Arrays.stream(p.getInventory().getStorageContents()).filter(Objects::nonNull).filter(this::protectedItem).toList();State s=states.get(p.getUniqueId());if(s==null)return Arrays.stream(p.getInventory().getStorageContents()).filter(Objects::nonNull).filter(this::protectedItem).toList();ItemStack[] bank=s.a?p.getInventory().getStorageContents():s.weapons;return Arrays.stream(bank).filter(Objects::nonNull).toList();}
    void begin(Player p){if(!match(p)||plugin.weaponLab.testing(p))return;if(plugin.hotbar!=null)plugin.hotbar.capture(p);State old=states.remove(p.getUniqueId());State s=new State();s.anchor=p.getLocation();s.protectionUntil=System.currentTimeMillis()+10000;p.setInvulnerable(false);p.setNoDamageTicks(0);var current=BedwarsAPI.getInstance().getGameOfPlayer(p);if(current instanceof org.screamingsandals.bedwars.game.Game impl)impl.removeProtectedPlayer(p);s.utility=old==null?utility(p):old.a?copy(old.utility):copy(p.getInventory().getStorageContents());for(int i=0;i<36;i++)if(protectedItem(s.utility[i])||legacyJunk(s.utility[i])||plugin.containers!=null&&plugin.containers.button(s.utility[i]))s.utility[i]=null;states.put(p.getUniqueId(),s);plugin.ammo.reset(p);p.getInventory().setStorageContents(new ItemStack[36]);p.getInventory().setItemInOffHand(null);p.setVelocity(new org.bukkit.util.Vector());}
    private boolean legacyJunk(ItemStack i){return i!=null&&(Set.of(Material.REDSTONE_BLOCK,Material.GHAST_TEAR).contains(i.getType())||i.hasItemMeta()&&ChatColor.stripColor(i.getItemMeta().getDisplayName()).toLowerCase(Locale.ROOT).contains("zombie grenade"));}
    void equip(Player p,Map<String,ItemStack> selected){State s=states.get(p.getUniqueId());if(s==null){begin(p);s=states.get(p.getUniqueId());}if(s==null)return;s.weapons=new ItemStack[36];for(var e:selected.entrySet()){int slot=ROLES.indexOf(e.getKey());if(slot>=0)s.weapons[slot]=mark(e.getValue(),e.getKey());}s.a=true;s.locked=false;s.protectionUntil=System.currentTimeMillis()+3000;p.getInventory().setStorageContents(copy(s.weapons));if(plugin.aiRules!=null&&plugin.aiRules.single(p)){ItemStack chosen=s.weapons[0]!=null?s.weapons[0]:s.weapons[2];s.a=false;s.weapons=new ItemStack[36];p.getInventory().setStorageContents(copy(s.utility));p.getInventory().setItem(0,chosen);plugin.aiRules.compact(p,p.getInventory());}p.getInventory().setHeldItemSlot(0);p.setVelocity(new org.bukkit.util.Vector());FixedTracker.ensure(plugin,p);p.updateInventory();}
    boolean addUtility(Player p,ItemStack item){if(plugin.mechanics!=null)plugin.mechanics.lore(item);Inventory simulation=Bukkit.createInventory(null,36);simulation.setStorageContents(utility(p));if(plugin.stacks!=null?!plugin.stacks.add(simulation,item):!simulation.addItem(item.clone()).isEmpty())return false;if(plugin.aiRules!=null&&!plugin.aiRules.compact(p,simulation))return false;utility(p,simulation.getStorageContents());return true;}
    String throwableRefusal(Player p,ItemStack item){
        State s=states.get(p.getUniqueId());
        if(s==null||s.locked||!match(p))return "경기에서 무기를 선택한 뒤 구매하세요.";
        if(item==null||plugin.throwables==null||plugin.throwables.kind(item)==null||item.getAmount()<1)return "올바른 투척무기가 아닙니다.";
        ItemStack[] bank=s.a?p.getInventory().getStorageContents():s.weapons;ItemStack old=bank[3];if(plugin.aiRules!=null&&plugin.aiRules.single(p))old=Arrays.stream(p.getInventory().getStorageContents()).filter(Objects::nonNull).filter(i->plugin.throwables.kind(i)!=null).findFirst().orElse(null);
        if(old!=null&&!old.getType().isAir()&&!(plugin.stacks==null?old.isSimilar(item):plugin.stacks.same(old,item)))return "투척무기는 한 종류만 보유할 수 있습니다. 현재 종류를 모두 사용한 뒤 구매하세요.";
        if(plugin.stacks!=null&&plugin.stacks.count(item)+plugin.stacks.count(old)>VirtualStacks.LIMIT)return "투척무기 보유 한도입니다.";
        return null;
    }
    boolean addThrowable(Player p,ItemStack item){
        String refusal=throwableRefusal(p,item);if(refusal!=null){p.sendMessage("§c"+refusal);return false;}
        State s=states.get(p.getUniqueId());if(plugin.aiRules!=null&&plugin.aiRules.single(p))return addUtility(p,mark(item,"throwable"));ItemStack[] bank=s.a?p.getInventory().getStorageContents():copy(s.weapons);ItemStack old=bank[3];
        bank[3]=mark(plugin.stacks!=null?(old==null||old.getType().isAir()?plugin.stacks.sized(item,plugin.stacks.count(item)):plugin.stacks.merge(old,item)):item.clone(),"throwable");
        if(s.a)p.getInventory().setStorageContents(bank);else s.weapons=bank;return true;
    }
    boolean protectedLife(Player p){State state=states.get(p.getUniqueId());return state!=null&&match(p)&&System.currentTimeMillis()<state.protectionUntil;}
    void replaceWeapon(Player p,String role,ItemStack item){if(plugin.aiRules!=null&&plugin.aiRules.single(p)){p.getInventory().setItem(0,mark(item,role));plugin.protocol.refreshHeld(p);return;}State s=states.get(p.getUniqueId());if(s==null||s.locked)return;int slot=ROLES.indexOf(role);if(slot<0)return;if(s.a)p.getInventory().setItem(slot,mark(item,role));else s.weapons[slot]=mark(item,role);plugin.protocol.refreshHeld(p);}
    void mode(Player p,boolean a){if(plugin.aiRules!=null&&plugin.aiRules.single(p))return;if(modeA(p)!=a)toggle(p);}
    @EventHandler(priority=EventPriority.HIGHEST)public void lifeDamage(EntityDamageEvent e){if(e.getEntity() instanceof Player p&&protectedLife(p)&&e.getCause()!=EntityDamageEvent.DamageCause.VOID)e.setCancelled(true);}
    void toggle(Player p){if(plugin.aiRules!=null&&plugin.aiRules.single(p)){p.sendActionBar("§e한 손 챌린지 · 한 칸의 핫바와 다섯 칸의 보관함만 사용");return;}if(!modeA(p)&&plugin.hotbar!=null)plugin.hotbar.capture(p);if(plugin.weaponModes!=null&&plugin.weaponModes.anchored(p)){p.sendMessage("§e우클릭으로 시즈를 해제한 뒤 인벤토리를 바꾸세요.");return;}State s=states.get(p.getUniqueId());if(s==null||s.locked||!match(p))return;plugin.ammo.switchSlot(p);if(plugin.throwables!=null)plugin.throwables.cancel(p);if(s.a){s.weapons=copy(p.getInventory().getStorageContents());p.getInventory().setStorageContents(copy(s.utility));p.getInventory().setHeldItemSlot(s.utilitySlot);}else{s.utility=copy(p.getInventory().getStorageContents());s.utilitySlot=p.getInventory().getHeldItemSlot();p.getInventory().setStorageContents(copy(s.weapons));p.getInventory().setHeldItemSlot(0);}s.a=!s.a;FixedTracker.ensure(plugin,p);p.getInventory().setItemInOffHand(null);p.updateInventory();p.sendActionBar(net.kyori.adventure.text.Component.text(s.a?"A · 무기 모드  |  F: 아이템 모드":"B · 아이템 모드  |  F: 무기 모드"));}
    @EventHandler(priority=EventPriority.HIGHEST)public void swap(PlayerSwapHandItemsEvent e){if(states.containsKey(e.getPlayer().getUniqueId())){e.setCancelled(true);if(e.getPlayer().getOpenInventory().getType()==InventoryType.CRAFTING)toggle(e.getPlayer());}else if(protectedItem(e.getMainHandItem())||protectedItem(e.getOffHandItem()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void move(PlayerMoveEvent e){if(locked(e.getPlayer())&&e.getTo()!=null&&e.getFrom().toVector().distanceSquared(e.getTo().toVector())>0){Location hold=e.getFrom().clone();hold.setYaw(e.getTo().getYaw());hold.setPitch(e.getTo().getPitch());e.setTo(hold);}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void velocity(PlayerVelocityEvent e){if(locked(e.getPlayer())||protectedLife(e.getPlayer())){e.setCancelled(true);e.getPlayer().setVelocity(new org.bukkit.util.Vector());}}
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void pickup(EntityPickupItemEvent e){if(!(e.getEntity() instanceof Player p))return;if(locked(p)||protectedItem(e.getItem().getItemStack())){e.setCancelled(true);return;}if(!modeA(p)||ResourceWallet.TYPES.contains(e.getItem().getItemStack().getType()))return;e.setCancelled(true);if(addUtility(p,e.getItem().getItemStack())){e.getItem().remove();p.playSound(p.getLocation(),Sound.ENTITY_ITEM_PICKUP,.3f,1.2f);}}
    @EventHandler(priority=EventPriority.LOWEST)public void drop(PlayerDropItemEvent e){if(protectedItem(e.getItemDrop().getItemStack()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void click(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p))return;if(states.containsKey(p.getUniqueId())&&e.getView().getTopInventory().getType()==InventoryType.CRAFTING&&e.getRawSlot()>=0&&e.getRawSlot()<5){e.setCancelled(true);return;}boolean own=e.getClickedInventory() instanceof PlayerInventory;ItemStack hot=e.getHotbarButton()<0?null:p.getInventory().getItem(e.getHotbarButton());boolean protectedMove=protectedItem(e.getCurrentItem())||protectedItem(e.getCursor())||protectedItem(hot);if(modeA(p)&&own||protectedMove&&(e.getClick()==ClickType.SWAP_OFFHAND||own&&e.getSlot()==40||e.getAction()==InventoryAction.DROP_ALL_SLOT||e.getAction()==InventoryAction.DROP_ONE_SLOT||e.getClick()==ClickType.DROP||e.getClick()==ClickType.CONTROL_DROP||!own||e.getView().getTopInventory().getType()!=InventoryType.CRAFTING))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void drag(InventoryDragEvent e){if(!(e.getWhoClicked() instanceof Player p))return;if(modeA(p)||protectedItem(e.getOldCursor())&&e.getRawSlots().stream().anyMatch(slot->slot<e.getView().getTopInventory().getSize()||e.getView().getInventory(slot) instanceof PlayerInventory&&e.getView().convertSlot(slot)==40))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void hopperPickup(InventoryPickupItemEvent e){if(protectedItem(e.getItem().getItemStack()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void hopperMove(InventoryMoveItemEvent e){if(protectedItem(e.getItem()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void open(InventoryOpenEvent e){if(e.getPlayer() instanceof Player p&&modeA(p)){var holder=e.getInventory().getHolder();if(holder==null||!holder.getClass().getName().startsWith("kr.mzs.gunbed")){e.setCancelled(true);p.sendMessage("§eF를 눌러 B 모드에서 보관함을 이용하세요.");}}}
    @EventHandler(priority=EventPriority.LOWEST)public void death(PlayerDeathEvent e){Player p=e.getEntity();if(plugin.arsenal!=null)plugin.arsenal.remember(p);if(plugin.hotbar!=null)plugin.hotbar.capture(p);State s=states.remove(p.getUniqueId());if(s!=null){
        // The shared world keeps inventory, but BedWars clears it for a round death.
        // Rebuild from the owned utility bank in either mode, once, before wallet settlement.
        deathGames.put(p.getUniqueId(),BedwarsAPI.getInstance().getGameOfPlayer(p));ItemStack[] utility=s.a?s.utility:p.getInventory().getStorageContents();e.getDrops().clear();
        for(ItemStack item:utility)if(item!=null&&(plugin.containers==null||!plugin.containers.button(item)))e.getDrops().add(item.clone());
    }e.getDrops().removeIf(this::protectedItem);plugin.ammo.reset(p);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void settledDeathDrops(PlayerDeathEvent e){
        var game=deathGames.remove(e.getEntity().getUniqueId());if(game==null)return;
        // BedWars makes a live spectator inside this event. Emit the final filtered
        // bundles ourselves rather than relying on the now-spectating vanilla player.
        List<ItemStack> drops=e.getDrops().stream().filter(i->ResourceWallet.TYPES.contains(i.getType())).map(ItemStack::clone).toList();e.getDrops().clear();
        for(ItemStack item:drops){var drop=e.getEntity().getWorld().dropItemNaturally(e.getEntity().getLocation(),item);drop.setPickupDelay(20);BedwarsAPI.getInstance().registerEntityToGame(drop,game);}
    }
    @EventHandler(priority=EventPriority.LOWEST)public void end(BedwarsGameEndEvent e){for(Player p:e.getGame().getConnectedPlayers())restore(p);}
    @EventHandler public void leave(BedwarsPlayerLeaveEvent e){if(plugin.hotbar!=null){plugin.hotbar.capture(e.getPlayer());plugin.profiles.saved();}states.remove(e.getPlayer().getUniqueId());plugin.ammo.reset(e.getPlayer());}
    private void restore(Player p){if(plugin.hotbar!=null)plugin.hotbar.capture(p);State s=states.remove(p.getUniqueId());if(s!=null&&s.a)p.getInventory().setStorageContents(copy(s.utility));plugin.ammo.reset(p);}
    @Override public void close(){for(Player p:Bukkit.getOnlinePlayers())restore(p);states.clear();deathGames.clear();}
    @EventHandler(priority=EventPriority.HIGHEST)public void crafting(InventoryClickEvent e){if(e.getView().getType()==InventoryType.CRAFTING&&e.getRawSlot()>=0&&e.getRawSlot()<=4)e.setCancelled(true);}
}
