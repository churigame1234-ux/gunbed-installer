package kr.mzs.gunbed;
import com.google.gson.*;
import org.bukkit.entity.Player;
import java.util.*;

/** Per-class handling-normalised base damage; siege/team bonuses follow the base cap. */
final class DamageProfiles {
    record Profile(String group,double body,double head,double legs,double difficulty){}
    record Handling(String id,String group,double capacity,double rpm,double recoil,double spread,int pellets){}
    private final Map<String,Profile> profiles=new LinkedHashMap<>();
    private final Map<String,Handling> handling=new LinkedHashMap<>();
    private final GunbedCore plugin;
    DamageProfiles(GunbedCore p){plugin=p;
        for(var gun:p.taWeapons.definitions()){
            var d=gun.data();double recoil=0;JsonObject r=d.getAsJsonObject("recoil");
            if(r!=null&&r.has("pitch"))for(JsonElement row:r.getAsJsonArray("pitch")){var values=row.getAsJsonObject().getAsJsonArray("value");if(values!=null)for(JsonElement n:values)recoil+=Math.abs(n.getAsDouble());}
            if(r!=null&&r.has("pitch"))recoil/=Math.max(1,r.getAsJsonArray("pitch").size()*2);
            var inaccurate=d.getAsJsonObject("inaccuracy");var bullet=d.getAsJsonObject("bullet");
            handling.put("ta:"+gun.id(),new Handling("ta:"+gun.id(),group(gun.id(),gun.type()),num(d,"ammo_amount",30),num(d,"rpm",600),recoil,num(inaccurate,"stand",0),(int)Math.max(1,num(bullet,"bullet_amount",1))));
        }
        Map<String,String> legacyRoles=new HashMap<>();try(var input=p.getResource("legacy-armory.json")){for(var item:JsonParser.parseReader(new java.io.InputStreamReader(Objects.requireNonNull(input),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject().getAsJsonArray("weapons")){var row=item.getAsJsonObject();legacyRoles.put(row.get("title").getAsString(),row.get("group").getAsString());}}catch(java.io.IOException e){throw new java.io.UncheckedIOException(e);}
        if(p.visuals!=null)for(String id:p.visuals.titles()){if(WeaponModes.retired(id)||"throwable".equals(legacyRoles.get(id)))continue;
            var cs=p.visuals.cs.getHandle();double delay=cs.getInt(id+".Shooting.Delay_Between_Shots");double auto=cs.getInt(id+".Fully_Automatic.Fire_Rate");
            double rpm=auto>0?Math.min(1200,Math.max(300,240+auto*60)):1200/Math.max(1,delay);
            handling.put("cs:"+id,new Handling("cs:"+id,group(id,cs.getBoolean(id+".Item_Information.Melee_Mode")||"melee".equals(legacyRoles.get(id))?"melee":""),Math.max(1,cs.getInt(id+".Reload.Reload_Amount")),rpm,Math.abs(cs.getDouble(id+".Shooting.Recoil_Amount")),Math.abs(cs.getDouble(id+".Shooting.Bullet_Spread")),Math.max(1,cs.getInt(id+".Shooting.Projectile_Amount"))));
        }
        for(String id:AddonMelee.names().keySet())handling.put("lr:"+id,new Handling("lr:"+id,"melee",1,id.equals("baseball_bat")?66.7:100,0,0,1));
        for(Handling h:handling.values()){
            List<Handling> peers=handling.values().stream().filter(a->a.group.equals(h.group)).toList();
            double score=(rank(peers,h,h.capacity,0,true)+rank(peers,h,h.rpm,1,true)+rank(peers,h,h.recoil,2,false)+rank(peers,h,h.spread,3,false))/4;
            double body,head;switch(h.group){
                case "sniper"->{body=3200+2800*score;head=6000+4000*score;}
                case "shotgun"->{body=(300+500*score)*h.pellets;head=(500+500*score)*h.pellets;}
                case "pistol"->{body=300+500*score;head=500+500*score;}
                case "rpg"->{body=h.id.equals("ta:rpg7")?4500:4000+1000*score;head=body;}
                case "melee"->{body=900+900*score;head=body;}
                default->{body=350+450*score;head=550+450*score;}
            }
            profiles.put(h.id,new Profile(h.group,Math.round(body)/20.0,Math.round(head)/20.0,Math.round(body*.75)/20.0,1));
        }
    }
    private static double num(JsonObject o,String key,double fallback){return o!=null&&o.has(key)?o.get(key).getAsDouble():fallback;}
    private double rank(List<Handling> peers,Handling h,double value,int metric,boolean inverse){
        if(peers.size()<2)return .5;double below=0,equal=0;for(Handling p:peers){double v=switch(metric){case 0->p.capacity;case 1->p.rpm;case 2->p.recoil;default->p.spread;};if(v<value)below++;else if(v==value)equal++;}double result=(below+(equal-1)/2)/Math.max(1,peers.size()-1);return inverse?1-result:result;
    }
    private String group(String id,String original){String s=id.toLowerCase(Locale.ROOT);
        if(Set.of("골데b","소드오프","rpg7","rpg_7","m79").contains(s)||original.equals("rpg"))return "rpg";
        if(original.equals("melee"))return "melee";
        if(Set.of("trg","awp","m24","vss","vss-b").contains(s)||Set.of("sniper","marksman","dmr").contains(original))return "sniper";
        if(Set.of("더블배럴","더블배럴b","spas-12","aa12").contains(s)||original.equals("shotgun"))return "shotgun";
        if(Set.of("glock17","eagle","m950","골데","flare").contains(s)||original.equals("pistol"))return "pistol";
        return "rifle";
    }
    Profile profile(String id){Profile p=profiles.get(id);if(p==null||plugin.damages==null)return p;var h=handling.get(id);double pellets=h==null?1:h.pellets;String key=DamageSettings.weapon(id);return new Profile(p.group,plugin.damages.value(key+".body",p.body*20/pellets)*pellets/20,plugin.damages.value(key+".head",p.head*20/pellets)*pellets/20,plugin.damages.value(key+".legs",p.legs*20/pellets)*pellets/20,p.difficulty);}
    double gun(Player source,String id,CombatBalance.Part part,double range,int pellets,double falloff){
        Profile p=profile(id);if(p==null)p=new Profile("rifle",25,40,18,1);
        double raw=switch(part){case HEAD->p.head;case LEGS->p.legs;default->p.body;};
        double distance=p.group.equals("shotgun")?Math.max(.2,1-range/30):p.group.equals("pistol")?Math.max(.65,1-Math.max(0,range-20)/180):1;
        double cap=p.group.equals("rpg")?5000:part==CombatBalance.Part.HEAD?(p.group.equals("sniper")?10000:1000):8000;
        if(plugin.damages!=null)cap=Math.max(cap,raw*20/Math.max(1,pellets));
        double value=Math.min(cap,raw*20*distance*Math.clamp(falloff,0,1.5)/Math.max(1,pellets));
        if(id.startsWith("cs:")&&plugin.weaponModes!=null&&plugin.weaponModes.deployed(source))value*=plugin.damages==null?2:plugin.damages.value(DamageSettings.weapon(id)+".siege-multiplier",2);
        return value;
    }
    double other(double original){return original*.4;}
    double melee(String id,double fallback){Profile p=profile(id);return p!=null&&p.group.equals("melee")?p.body*20:other(fallback);}
    double launcher(String id){return blast(id,"center");}
    double blast(String id,String band){Profile p=profile(id);double base=p==null?1600:p.body*20;return plugin.damages==null?base*(band.equals("center")?1:band.equals("middle")?.5:.25):plugin.damages.value(DamageSettings.weapon(id)+".explosion."+band,base*(band.equals("center")?1:band.equals("middle")?.5:.25));}
    double launcher(){return 1600;}
    double he(){return plugin.damages==null?3200:plugin.damages.value("throwables.he",3200);}
    double fireTick(){return plugin.damages==null?200:plugin.damages.value("throwables.fire-tick",200);}
    Collection<Map<String,Object>> describe(){List<Map<String,Object>> rows=new ArrayList<>();for(var e:profiles.entrySet()){var p=profile(e.getKey());var h=handling.get(e.getKey());rows.add(Map.of("id",e.getKey(),"class",p.group,"body",p.body*20,"head",p.head*20,"legs",p.legs*20,"difficulty",p.difficulty,"pellets",h.pellets,"capacity",h.capacity,"rpm",h.rpm));}return rows;}
}
