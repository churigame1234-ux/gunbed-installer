package kr.mzs.gunbed;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.events.BedwarsPlayerKilledEvent;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;

/** Preserve existing ajLeaderboards/Hologram names while using the new engine's live statistics. */
final class LegacyStats extends PlaceholderExpansion implements Listener {
    private final GunbedCore plugin;
    private JsonObject legacy = new JsonObject();
    LegacyStats(GunbedCore plugin) {
        this.plugin = plugin;
        var file = plugin.getDataFolder().toPath().resolve("legacy-stats.json");
        if (Files.exists(file)) try {
            legacy = JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (java.io.IOException ex) { throw new java.io.UncheckedIOException(ex); }
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    void save() {
        try { Files.writeString(plugin.getDataFolder().toPath().resolve("legacy-stats.json"), legacy.toString(), StandardCharsets.UTF_8); }
        catch (java.io.IOException ex) { plugin.getLogger().severe("Could not save legacy final-kill counters: " + ex.getMessage()); }
    }

    String extra(OfflinePlayer player, String id) {
        var values = legacy.getAsJsonObject(player.getUniqueId().toString());
        if (values == null || !values.has("bedwars:" + id)) return "0";
        return Long.toString(values.getAsJsonObject("bedwars:" + id).get("value").getAsLong());
    }

    private void increment(OfflinePlayer player, String id) {
        if (player == null) return;
        String uuid = player.getUniqueId().toString();
        if (!legacy.has(uuid)) legacy.add(uuid, new JsonObject());
        var values = legacy.getAsJsonObject(uuid);
        long value = Long.parseLong(extra(player, id)) + 1;
        var entry = new JsonObject(); entry.addProperty("value", value); values.add("bedwars:" + id, entry);
    }

    @EventHandler public void onKilled(BedwarsPlayerKilledEvent event) {
        var team = event.getGame().getTeamOfPlayer(event.getPlayer());
        if (plugin.combatPresentation.finalDeath(event.getPlayer())) {
            increment(event.getPlayer(), "final_deaths"); increment(event.getKiller(), "final_kills"); save();
        }
    }
    @Override public String getIdentifier() { return "mbedwars"; }
    @Override public String getAuthor() { return "MZS"; }
    @Override public String getVersion() { return plugin.getPluginMeta().getVersion(); }
    @Override public boolean persist() { return true; }
    @Override public String onRequest(OfflinePlayer player, String params) {
        if (player == null) return "0";
        var stats = BedwarsAPI.getInstance().getStatisticsManager().getStatistic(player.getUniqueId());
        if (stats == null) return "0";
        return switch (params.toLowerCase(java.util.Locale.ROOT)) {
            case "stats-final_kills" -> extra(player, "final_kills");
            case "stats-final_deaths" -> extra(player, "final_deaths");
            case "stats-wins" -> Integer.toString(stats.getWins());
            case "stats-kills" -> Integer.toString(stats.getKills());
            case "stats-deaths" -> Integer.toString(stats.getDeaths());
            case "stats-loses" -> Integer.toString(stats.getLoses());
            case "stats-beds_destroyed" -> Integer.toString(stats.getDestroyedBeds());
            case "stats-rounds_played" -> Integer.toString(stats.getGames());
            case "stats-score" -> Integer.toString(stats.getScore());
            default -> null;
        };
    }
}
