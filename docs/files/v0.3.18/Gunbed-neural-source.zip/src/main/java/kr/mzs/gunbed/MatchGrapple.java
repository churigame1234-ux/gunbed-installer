package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.game.*;
import org.screamingsandals.bedwars.api.events.*;
import java.util.*;

/** Round-only three-use hooks; old throw/pull speed and cooldown, no old-plugin item tag. */
final class MatchGrapple implements Listener,AutoCloseable {
    private static final NamespacedKey KEY=new NamespacedKey("gunbedcore","grapple_hook"),INSTANCE=new NamespacedKey("gunbedcore","hook_instance");
    private static final class Cast {FishHook hook;Game game;String instance;Location anchor;org.bukkit.block.Block block;int began;}
    private static final class Flight {Game game;boolean prior,airborne;int began;}
    private final Map<UUID,Cast> casts=new HashMap<>();
    private final Map<UUID,Flight> flights=new HashMap<>();
    private final Map<UUID,Integer> cooldown=new HashMap<>();
    private final GunbedCore plugin;
    MatchGrapple(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,1);}
    boolean item(ItemStack item){return item!=null&&item.hasItemMeta()&&item.getItemMeta().getPersistentDataContainer().has(KEY);}
    private String instance(ItemStack item){return item.getItemMeta().getPersistentDataContainer().get(INSTANCE,PersistentDataType.STRING);}
    ItemStack create(){ItemStack item=new ItemStack(Material.FISHING_ROD);var meta=(Damageable)item.getItemMeta();meta.setDisplayName("§e그래플링 훅");meta.setLore(List.of("§7우클릭: 줄 던지기 · 다시 우클릭: 당기기","§7고정된 블록을 향해 당겨졌을 때만 1회 사용","§7훅 한 개당 3회 · 사용 후 1초 재사용 대기","§c사용 후 땅에 닿을 때까지 팀색 발광 · 모두에게 표시"));meta.setMaxDamage(3);meta.setDamage(0);meta.setUnbreakable(false);meta.getPersistentDataContainer().set(KEY,PersistentDataType.BYTE,(byte)1);meta.getPersistentDataContainer().set(INSTANCE,PersistentDataType.STRING,UUID.randomUUID().toString());item.setItemMeta(meta);return plugin.stacks.sized(item,1);}
    private Game game(Player p){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);return g!=null&&g.getStatus()==GameStatus.RUNNING&&g.getTeamOfPlayer(p)!=null&&p.getGameMode()!=GameMode.SPECTATOR?g:null;}
    boolean buy(Player p,List<ItemStack> cost){if(game(p)==null||plugin.inventories.locked(p))return false;Inventory sim=plugin.wallet.purchaseInventory(p);if(!plugin.hotbar.place(p,sim,create())){p.sendMessage("§c기억한 핫바 자리로 배치할 공간이 부족합니다. 재료는 차감하지 않았습니다.");return false;}if(!plugin.wallet.pay(p,cost)){p.sendMessage("§c철 16개 · 금 8개 · 다이아몬드 1개 · 에메랄드 1개가 모두 필요합니다.");p.playSound(p.getLocation(),Sound.ENTITY_VILLAGER_NO,1,1);return false;}plugin.inventories.utility(p,sim.getStorageContents());plugin.hotbar.changed(p);p.playSound(p.getLocation(),Sound.BLOCK_NOTE_BLOCK_PLING,1,2);return true;}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void fish(PlayerFishEvent e){Player p=e.getPlayer();if(!item(p.getInventory().getItemInMainHand()))return;Game game=game(p);if(game==null||plugin.aiRules!=null&&!plugin.aiRules.movementSkill(p)||plugin.inventories.modeA(p)||plugin.inventories.locked(p)||plugin.weaponModes.anchored(p)||plugin.turrets!=null&&plugin.turrets.building(p)){e.setCancelled(true);e.getHook().remove();return;}
        if(e.getState()==PlayerFishEvent.State.FISHING){if(Bukkit.getCurrentTick()<cooldown.getOrDefault(p.getUniqueId(),0)){e.setCancelled(true);return;}cancelCast(p);Cast cast=new Cast();cast.hook=e.getHook();cast.game=game;cast.instance=instance(p.getInventory().getItemInMainHand());cast.began=Bukkit.getCurrentTick();casts.put(p.getUniqueId(),cast);cast.hook.setMaxWaitTime(12000);cast.hook.setMinWaitTime(12000);cast.hook.setApplyLure(false);cast.hook.setVelocity(cast.hook.getVelocity().normalize().multiply(3));return;}
        if(e.getState()==PlayerFishEvent.State.BITE||e.getState()==PlayerFishEvent.State.FAILED_ATTEMPT){e.setCancelled(true);return;}
        Cast cast=casts.remove(p.getUniqueId());e.setCancelled(true);e.getHook().remove();if(cast==null||cast.anchor==null||cast.block==null||cast.block.isPassable())return;pull(p,cast.anchor);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void hit(ProjectileHitEvent e){if(!(e.getEntity() instanceof FishHook hook)||!(hook.getShooter() instanceof Player p)||e.getHitBlock()==null)return;Cast c=casts.get(p.getUniqueId());if(c==null||c.hook!=hook)return;c.block=e.getHitBlock();c.anchor=hook.getLocation().clone();if(e.getHitBlockFace()!=null)c.anchor.add(e.getHitBlockFace().getDirection().multiply(.05));hook.setVelocity(new Vector());hook.setGravity(false);}
    boolean pull(Player p,Location target){if(plugin.aiRules!=null&&!plugin.aiRules.movementSkill(p))return false;Game game=game(p);if(game==null||plugin.aiRules!=null&&!plugin.aiRules.movementSkill(p)||plugin.inventories.modeA(p)||plugin.inventories.locked(p)||plugin.inventories.protectedLife(p)||plugin.weaponModes.anchored(p)||plugin.turrets!=null&&plugin.turrets.building(p)||Bukkit.getCurrentTick()<cooldown.getOrDefault(p.getUniqueId(),0))return false;ItemStack item=p.getInventory().getItemInMainHand();if(!item(item)||target.getWorld()!=p.getWorld())return false;Vector delta=target.toVector().subtract(p.getLocation().toVector());double distance=delta.length();if(distance<1||distance>32)return false;Vector velocity=delta.normalize().multiply(2.25);velocity.setY(Math.max(.42,velocity.getY()));p.setVelocity(velocity);long[] stock=plugin.stacks.stock(item);if(stock[0]>0)stock[0]--;else if(stock[1]>0){stock[1]--;stock[0]++;}else{stock[2]--;stock[1]++;}p.getInventory().setItemInMainHand(plugin.stacks.hookStock(item,stock));int ticks=(int)Math.max(1,plugin.getConfig().getDouble("items.grapple.cooldown-seconds",1)*20);cooldown.put(p.getUniqueId(),Bukkit.getCurrentTick()+ticks);p.setCooldown(Material.FISHING_ROD,ticks);Flight flight=flights.get(p.getUniqueId());boolean prior=flight==null?p.isGlowing():flight.prior;flight=new Flight();flight.game=game;flight.prior=prior;flight.began=Bukkit.getCurrentTick();flights.put(p.getUniqueId(),flight);p.setGlowing(true);glow(p,flight);p.getWorld().playSound(p.getLocation(),Sound.ENTITY_FISHING_BOBBER_RETRIEVE,.8f,1);p.updateInventory();return true;}
    private void glow(Player p,Flight flight){int rgb=TeamPalette.of(p).rgb();for(Player viewer:flight.game.getConnectedPlayers())plugin.protocol.emit(viewer,Map.of("event","entityGlow","uuid",p.getUniqueId().toString(),"color",rgb));}
    private void cancelCast(Player p){Cast old=casts.remove(p.getUniqueId());if(old!=null&&old.hook.isValid())old.hook.remove();}
    private void clear(Player p){cancelCast(p);Flight flight=flights.remove(p.getUniqueId());if(flight!=null)p.setGlowing(flight.prior||p.hasPotionEffect(org.bukkit.potion.PotionEffectType.GLOWING));}
    private void tick(){int tick=Bukkit.getCurrentTick();for(var entry:List.copyOf(casts.entrySet())){Player p=Bukkit.getPlayer(entry.getKey());Cast c=entry.getValue();if(p==null){if(c.hook.isValid())c.hook.remove();casts.remove(entry.getKey());continue;}if(!c.hook.isValid()||game(p)!=c.game||!item(p.getInventory().getItemInMainHand())||!Objects.equals(c.instance,instance(p.getInventory().getItemInMainHand()))||tick-c.began>400)cancelCast(p);}
        for(var entry:List.copyOf(flights.entrySet())){Player p=Bukkit.getPlayer(entry.getKey());Flight f=entry.getValue();if(p==null){flights.remove(entry.getKey());continue;}if(game(p)!=f.game||p.isDead()){clear(p);continue;}if(!p.isOnGround())f.airborne=true;if(p.isOnGround()&&(f.airborne||tick-f.began>=5)){clear(p);continue;}p.setGlowing(true);if(tick%10==0)glow(p,f);}
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void fall(EntityDamageEvent e){if(e.getEntity() instanceof Player p&&e.getCause()==EntityDamageEvent.DamageCause.FALL&&flights.containsKey(p.getUniqueId())&&plugin.getConfig().getBoolean("items.grapple.safe-first-landing",false))e.setCancelled(true);}
    @EventHandler public void slot(PlayerItemHeldEvent e){cancelCast(e.getPlayer());}
    @EventHandler public void quit(PlayerQuitEvent e){clear(e.getPlayer());cooldown.remove(e.getPlayer().getUniqueId());}
    @EventHandler public void death(PlayerDeathEvent e){clear(e.getEntity());}
    @EventHandler public void leave(BedwarsPlayerLeaveEvent e){clear(e.getPlayer());cooldown.remove(e.getPlayer().getUniqueId());}
    @EventHandler public void end(BedwarsGameEndEvent e){for(Player p:e.getGame().getConnectedPlayers()){clear(p);cooldown.remove(p.getUniqueId());p.setCooldown(Material.FISHING_ROD,0);}}
    @Override public void close(){for(Player p:Bukkit.getOnlinePlayers())clear(p);casts.clear();flights.clear();cooldown.clear();}
}
