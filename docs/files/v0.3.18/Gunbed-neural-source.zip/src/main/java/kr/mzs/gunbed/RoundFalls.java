package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.damage.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.GameStatus;
import java.util.*;

/** Physical fall tracking also works while flight permission is armed for double-jump. */
final class RoundFalls implements Listener {
    private static final ThreadLocal<Boolean> APPLYING=ThreadLocal.withInitial(()->false);
    private static final class Air {double peak;boolean airborne;Air(double y){peak=y;}}
    private final Map<UUID,Air> air=new HashMap<>();private final GunbedCore plugin;
    static boolean applying(){return APPLYING.get();}
    RoundFalls(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,1);}
    private void tick(){for(Player p:Bukkit.getOnlinePlayers()){
        var g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(g==null||g.getStatus()!=GameStatus.RUNNING||p.isDead()||p.getGameMode()==GameMode.SPECTATOR||p.getGameMode()==GameMode.CREATIVE){air.remove(p.getUniqueId());DoubleJumpFallGrace.clear(p);continue;}
        Air a=air.computeIfAbsent(p.getUniqueId(),id->new Air(p.getY()));
        if(p.isInWater()||p.isClimbing()||p.isInsideVehicle()){a.peak=p.getY();a.airborne=false;DoubleJumpFallGrace.clear(p);continue;}
        if(!p.isOnGround()){a.airborne=true;a.peak=Math.max(a.peak,p.getY());continue;}
        double distance=a.airborne?DoubleJumpFallGrace.landing(p,a.peak-p.getY()):a.peak-p.getY();boolean landed=a.airborne;if(!landed)DoubleJumpFallGrace.ground(p);a.peak=p.getY();a.airborne=false;
        if(landed)plugin.protocol.emit(p,Map.of("event","fallLanding","quiet",distance<=3));
        Material floor=p.getLocation().subtract(0,.1,0).getBlock().getType();
        if(!landed||distance<=3||Set.of(Material.SLIME_BLOCK,Material.WATER,Material.POWDER_SNOW).contains(floor))continue;
        int tier=plugin.bedwars.shop.level(p,"cushioned-boots");double ratio=tier>=2?1.0/3:tier==1?.5:2.0/3;
        double damage=Math.ceil(distance-3)*plugin.damages.value("environment.fall-per-vanilla-point",500)*ratio;if(floor==Material.HAY_BLOCK)damage*=.2;if(floor.name().endsWith("_BED"))damage*=.5;
        boolean flight=p.getAllowFlight();try{APPLYING.set(true);p.setAllowFlight(false);p.damage(damage,DamageSource.builder(DamageType.FALL).build());}finally{APPLYING.remove();if(p.isOnline()&&!p.isDead()&&p.getGameMode()!=GameMode.SPECTATOR)p.setAllowFlight(flight);}
    }}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void teleport(PlayerTeleportEvent e){air.remove(e.getPlayer().getUniqueId());DoubleJumpFallGrace.clear(e.getPlayer());}
    @EventHandler public void quit(PlayerQuitEvent e){air.remove(e.getPlayer().getUniqueId());DoubleJumpFallGrace.clear(e.getPlayer());}
}
