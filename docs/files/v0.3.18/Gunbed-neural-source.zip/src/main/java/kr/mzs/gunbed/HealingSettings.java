package kr.mzs.gunbed;
import java.lang.reflect.Field;
import java.util.*;

/** Seed just the new healing keys for an already-running DamageSettings instance. */
final class HealingSettings {
 @SuppressWarnings("unchecked") static void install(GunbedCore plugin){try{Field f=DamageSettings.class.getDeclaredField("defaults");f.setAccessible(true);Map<String,Double> defaults=(Map<String,Double>)f.get(plugin.damages);var u=plugin.turrets.definition("healing").getUpgrade(1);var c=u.getCriticalHit();defaults.putIfAbsent("turrets.healing.minimum",(double)u.getMinHeal());defaults.putIfAbsent("turrets.healing.maximum",(double)u.getMaxHeal());defaults.putIfAbsent("turrets.healing.critical-minimum",c==null?0d:(double)c.getMinHeal());defaults.putIfAbsent("turrets.healing.critical-maximum",c==null?0d:(double)c.getMaxHeal());if(!plugin.damages.reload(null))throw new IllegalStateException("Healing settings validation failed");}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}}
}
