package kr.mzs.gunbed;
import com.google.gson.*;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.potion.*;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import java.util.*;

/** Land/air knockback and legacy slow debuffs; hammer keeps its 0.6s hard stun. */
final class WeaponImpacts implements Listener {
    private final GunbedCore plugin;private final JsonObject legacy;
    private final Map<String,Integer> pending=new HashMap<>();
    private final Map<UUID,LivingEntity> stunTargets=new HashMap<>();
    private record Hit(UUID source,String weapon,int tick){}
    private final Map<UUID,Hit> hits=new HashMap<>();
    private final Map<UUID,Integer> stunned=new HashMap<>();private final NamespacedKey stun;
    WeaponImpacts(GunbedCore p){plugin=p;stun=new NamespacedKey(p,"weapon_stun");try(var in=p.getResource("legacy-impacts.json")){legacy=JsonParser.parseReader(new java.io.InputStreamReader(Objects.requireNonNull(in),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();}catch(java.io.IOException e){throw new java.io.UncheckedIOException(e);}Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,()->{for(var e:List.copyOf(stunned.entrySet()))if(Bukkit.getCurrentTick()>=e.getValue()){LivingEntity target=stunTargets.remove(e.getKey());if(target!=null)for(Attribute kind:List.of(Attribute.MOVEMENT_SPEED,Attribute.JUMP_STRENGTH)){var attribute=target.getAttribute(kind);if(attribute!=null)attribute.removeModifier(stun);}stunned.remove(e.getKey());}},1,1);}
    private String plain(String s){String n=ChatColor.stripColor(s.replace('&','§')).replaceAll("\\[[^]]*]","").replaceAll("\\s+","").toLowerCase(Locale.ROOT);return switch(n){case "deserteagle"->"eagle";case "golddeagle","golddeserteagle","골드데저트이글"->"골데";case "glock17"->"glock17";case "hammer"->"망치";case "chainsaw"->"전기톱";case "nataknife"->"나타나이프";case "m134minigun"->"minigun";case "vssvintorez"->"vss";case "vssvintorezb"->"vss-b";case "doublebarrelshotgun"->"더블배럴";default->n;};}
    private JsonObject tuning(String title){String label=Objects.requireNonNullElse(plugin.visuals.cs.getHandle().getString(title+".Item_Information.Item_Name"),title).replace('&','§').split("«",2)[0].toLowerCase(Locale.ROOT);if(legacy.has(label))return legacy.getAsJsonObject(label);String id=plain(title);for(var entry:legacy.entrySet())if(plain(entry.getKey()).equals(id))return entry.getValue().getAsJsonObject();return new JsonObject();}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void crackshot(com.shampaggon.crackshot.events.WeaponDamageEntityEvent e){hits.put(e.getVictim().getUniqueId(),new Hit(e.getPlayer().getUniqueId(),e.getWeaponTitle(),Bukkit.getCurrentTick()));}
    boolean immune(LivingEntity entity){return entity instanceof Player p&&(plugin.inventories.locked(p)||plugin.inventories.protectedLife(p)||plugin.weaponModes.anchored(p)||plugin.turrets.building(p));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void hit(EntityDamageByEntityEvent e){if(!(e.getEntity() instanceof LivingEntity target)||e.getFinalDamage()<=0||plugin.turrets.damageContext()||plugin.throwables.damageKind()!=null)return;Player source=e.getDamager() instanceof Player p?p:e.getDamager() instanceof Projectile q&&q.getShooter() instanceof Player p?p:null;if(source==null||source==target||FriendlyProjectiles.ally(source,target)||immune(target))return;
        Hit recorded=hits.remove(target.getUniqueId());var ta=plugin.taWeapons.damageDefinition();String held=plugin.visuals.cs.getWeaponTitle(source.getInventory().getItemInMainHand());boolean recordedShot=recorded!=null&&recorded.source.equals(source.getUniqueId())&&recorded.tick==Bukkit.getCurrentTick();String cs=ta!=null?null:recordedShot?recorded.weapon:e.getDamager()==source&&held!=null&&plugin.arsenal.meleeTitle(held)?held:null;String melee=e.getDamager()==source?plugin.addonMelee.held(source):null;boolean stick=e.getDamager()==source&&source.getInventory().getItemInMainHand().getType()==Material.STICK&&source.getInventory().getItemInMainHand().getEnchantmentLevel(org.bukkit.enchantments.Enchantment.KNOCKBACK)>0;if(cs==null&&ta==null&&melee==null&&!stick)return;
        JsonObject row=cs==null?new JsonObject():tuning(cs);String id=ta!=null?"ta:"+ta.id():cs!=null?"cs:"+cs:"lr:"+melee;
        String key=stick?"items.knockback-stick":DamageSettings.weapon(id);
        push(target,source.getLocation(),key);
        if(row.has("slow"))target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,(int)Math.max(1,Math.min(200,20*(row.has("seconds")?row.get("seconds").getAsDouble():1))),Math.max(0,row.get("slow").getAsInt()-1),false,false));
    }
    void push(LivingEntity target,Location from,String key){
        if(immune(target))return;String stamp=target.getUniqueId()+":"+key;int tick=Bukkit.getCurrentTick();
        if(pending.getOrDefault(stamp,-1)==tick)return;pending.put(stamp,tick);
        boolean ground=target.isOnGround()||target.getWorld().getBlockAt(target.getLocation().subtract(0,.08,0)).getType().isSolid();
        var force=plugin.knockbacks.force(key);Vector direction=target.getLocation().toVector().subtract(from.toVector()).setY(0);
        if(direction.lengthSquared()<.001)direction=from.getDirection().setY(0);if(direction.lengthSquared()<.001)direction=new Vector(0,0,1);
        Vector velocity=direction.normalize().multiply(ground?force.ground():force.air()).setY(ground?force.up():force.airUp());
        Bukkit.getScheduler().runTask(plugin,()->{
            if(!target.isValid()||target.isDead()||immune(target))return;
            target.setVelocity(velocity);
            if(force.stun()>0){for(Attribute kind:List.of(Attribute.MOVEMENT_SPEED,Attribute.JUMP_STRENGTH)){var attribute=target.getAttribute(kind);if(attribute!=null){attribute.removeModifier(stun);attribute.addTransientModifier(new org.bukkit.attribute.AttributeModifier(stun,-1,org.bukkit.attribute.AttributeModifier.Operation.ADD_SCALAR));}}stunTargets.put(target.getUniqueId(),target);stunned.put(target.getUniqueId(),Bukkit.getCurrentTick()+(int)Math.ceil(force.stun()*20));}
            pending.entrySet().removeIf(e->Bukkit.getCurrentTick()-e.getValue()>2);
        });
    }
    void blast(LivingEntity target,Location at,String kind,double strength){
        Vector direction=target.getBoundingBox().getCenter().subtract(at.toVector());if(direction.lengthSquared()<.001)direction=new Vector(0,1,0);direction.normalize();
        double horizontal=plugin.knockbacks.value("explosions."+kind+".horizontal",1.3),vertical=plugin.knockbacks.value("explosions."+kind+".vertical",1.65);
        Vector velocity=direction.clone().setY(0).multiply(horizontal*strength).setY(vertical*strength*Math.max(.65,direction.getY()));
        Bukkit.getScheduler().runTask(plugin,()->{if(target.isValid()&&!target.isDead()&&!immune(target))target.setVelocity(velocity);});
    }

    @EventHandler public void quit(org.bukkit.event.player.PlayerQuitEvent e){clear(e.getPlayer());}
    @EventHandler public void leave(org.screamingsandals.bedwars.api.events.BedwarsPlayerLeaveEvent e){clear(e.getPlayer());}
    @EventHandler public void disable(org.bukkit.event.server.PluginDisableEvent e){if(e.getPlugin()==plugin)for(Player p:Bukkit.getOnlinePlayers())clear(p);}
    private void clear(Player p){stunned.remove(p.getUniqueId());stunTargets.remove(p.getUniqueId());for(Attribute kind:List.of(Attribute.MOVEMENT_SPEED,Attribute.JUMP_STRENGTH)){var a=p.getAttribute(kind);if(a!=null)a.removeModifier(stun);}}
}
