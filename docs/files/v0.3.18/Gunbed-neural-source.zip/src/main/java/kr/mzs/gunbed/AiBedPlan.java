package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.block.data.type.Bed;
import java.util.*;
import java.util.Comparator;

/** Twelve core blocks and eight glass wings, built with paid materials and ordinary block events. */
final class AiBedPlan {
    record Piece(Block block,Material material){}
    private final GunbedCore plugin;private final AiBrain brain;
    AiBedPlan(GunbedCore p,AiBrain b){plugin=p;brain=b;}
    List<Piece> layout(AiBrain.State s,boolean obsidian){if(!obsidian&&brain.teams.opening(s))return openingLayout(s);return butterfly(s,obsidian);}
    private List<Piece> butterfly(AiBrain.State s,boolean obsidian){var team=s.room.game.getTeamOfPlayer(s.bot.getPlayer());Block foot=team.getTargetBlock().getBlock();BlockFace forward=BlockFace.SOUTH;if(foot.getBlockData() instanceof Bed bed){forward=bed.getFacing();if(bed.getPart()==Bed.Part.HEAD)foot=foot.getRelative(forward.getOppositeFace());}int fx=forward.getModX(),fz=forward.getModZ(),rx=fz,rz=-fx;Material core=obsidian?Material.OBSIDIAN:s.plan.defenseKind.equals("wood")?Material.OAK_PLANKS:s.plan.defenseKind.equals("wool")?Material.valueOf(TeamPalette.of(s.bot.getPlayer()).dye().name()+"_WOOL"):Material.END_STONE;
        List<Piece> out=new ArrayList<>();List<int[]> coreCells=new ArrayList<>();for(int z=0;z<=1;z++)for(int x:new int[]{-1,1})coreCells.add(new int[]{x,0,z});for(int z:new int[]{-1,2})coreCells.add(new int[]{0,0,z});for(int z=0;z<=1;z++)coreCells.add(new int[]{0,1,z});if(!obsidian)for(int z:new int[]{-1,2})for(int x:new int[]{-1,1})coreCells.add(new int[]{x,0,z});
        coreCells.sort(Comparator.comparingInt(a->a[1]));for(var a:coreCells)out.add(new Piece(foot.getRelative(rx*a[0]+fx*a[2],a[1],rz*a[0]+fz*a[2]),core));if(!obsidian)for(int y=0;y<=1;y++)for(int x:new int[]{-1,1})for(int z=0;z<=1;z++){int width=y==0?2:1;int side=x<0?-width:width;out.add(new Piece(foot.getRelative(rx*side+fx*z,y,rz*side+fz*z),Material.GLASS));}return out;
    }
    private boolean correct(Piece p){return p.block.getType()==p.material||p.block.getType()==Material.OBSIDIAN;}
    private List<Piece> openingLayout(AiBrain.State s){List<Piece> core=butterfly(s,true);List<Piece> out=new ArrayList<>();Set<Block> bases=new HashSet<>();for(Piece p:core){out.add(new Piece(p.block,Material.OAK_PLANKS));bases.add(p.block);}Material wool=Material.valueOf(TeamPalette.of(s.bot.getPlayer()).dye().name()+"_WOOL");Set<Block> outer=new LinkedHashSet<>();for(Piece p:core)for(BlockFace f:List.of(BlockFace.NORTH,BlockFace.SOUTH,BlockFace.EAST,BlockFace.WEST,BlockFace.UP)){Block b=p.block.getRelative(f);if(!bases.contains(b)&&!(b.getBlockData() instanceof Bed)&&b.getY()>=p.block.getY())outer.add(b);}outer.stream().sorted(Comparator.comparingInt(Block::getY)).forEach(b->out.add(new Piece(b,wool)));return out;}
    private boolean satisfied(AiBrain.State s,Piece p){return correct(p)||!p.block.isPassable()&&!(p.block.getBlockData() instanceof Bed)&&!s.room.game.getRegion().isBlockAddedDuringGame(p.block.getLocation());}
    boolean openingDone(AiBrain.State s){return openingLayout(s).stream().allMatch(p->satisfied(s,p));}
    boolean pendingLayout(AiBrain.State s){return butterfly(s,false).stream().anyMatch(p->!satisfied(s,p));}
    boolean obsidianDone(AiBrain.State s){return layout(s,true).stream().allMatch(p->p.block.getType()==Material.OBSIDIAN);}
    boolean pending(AiBrain.State s){return brain.plans.duty(s)==AiPlan.Duty.DEFENDER&&s.room.game.getTeamOfPlayer(s.bot.getPlayer()).isTargetBlockExists()&&layout(s,false).stream().anyMatch(p->!satisfied(s,p));}
    private String shopId(Piece piece,AiBrain.State s){return piece.material==Material.GLASS?"glass":piece.material==Material.OAK_PLANKS?"wood":piece.material.name().endsWith("_WOOL")?"wool":s.plan.defenseKind;}
    String needed(AiBrain.State s){var p=s.bot.getPlayer();for(Piece piece:layout(s,false))if(!satisfied(s,piece)&&brain.strategy.count(p,piece.material)==0)return shopId(piece,s);return "";}
    boolean reserve(AiBrain.State s){if(!pending(s))return false;String id=needed(s);if(!id.isEmpty()&&plugin.bedwars.shop.botCanBuy(s.bot.getPlayer(),id))brain.strategy.buy(s,id);return true;}
    boolean tick(AiBrain.State s,int tick){boolean obsidian=brain.plans.duty(s)==AiPlan.Duty.EMERALD&&brain.strategy.count(s.bot.getPlayer(),Material.OBSIDIAN)>0;boolean butterfly=pending(s);if(!obsidian&&!butterfly)return false;var p=s.bot.getPlayer();
        List<Piece> missing=layout(s,obsidian).stream().filter(piece->!satisfied(s,piece)).toList();
        // Build reachable faces before travelling. A single occluded far-side cell must not starve the rest.
        for(Piece piece:missing)if(piece.block.isPassable()&&brain.strategy.count(p,piece.material)>0&&brain.strategy.place(s,piece.block,piece.material,tick)){s.strategy.placedDefense++;s.action=obsidian?"obsidian-defense":"bed-defense";s.reason="native-paid-reachable-defense-face";return true;}
        for(Piece piece:missing){
            if(brain.strategy.count(p,piece.material)==0){if(obsidian)return false;String id=shopId(piece,s);boolean afford=plugin.bedwars.shop.botCanBuy(p,id);brain.strategy.travel(s,afford?brain.strategy.store(s,false):brain.strategy.forge(s),tick,afford?"shop":"gather","prepare-bed-defense-"+id);if(afford&&brain.strategy.nearStore(s,false))brain.strategy.buy(s,id);return true;}
            if(!piece.block.isPassable()){if(!s.room.game.getRegion().isBlockAddedDuringGame(piece.block.getLocation()))continue;if(p.getEyeLocation().distanceSquared(piece.block.getLocation().add(.5,.5,.5))<18&&brain.mine(s,piece.block.getLocation(),tick))return true;Location access=mineStand(s,piece.block);if(access!=null)brain.navigate(s,access,tick,false,false);s.action="butterfly";s.reason="approach-owned-wool-replacement";return true;}
            else if(brain.strategy.place(s,piece.block,piece.material,tick)){s.strategy.placedDefense++;s.action=obsidian?"obsidian-defense":"butterfly";s.reason="paid-core-and-blastproof-glass-wings";return true;}
            Location stand=brain.strategy.stand(s,piece.block.getLocation());if(stand!=null){approach(s,stand,tick);s.action="bed-defense";s.reason="approach-native-build-face";return true;}
        }if(!missing.isEmpty()){s.action="bed-defense";s.reason="no-current-visible-face-reposition";brain.navigate(s,s.room.game.getTeamOfPlayer(p).getTeamSpawn(),tick,false,false);return true;}return false;
    }
    private Location mineStand(AiBrain.State s,Block target){var p=s.bot.getPlayer();List<Location> candidates=new ArrayList<>();for(int x=-3;x<=3;x++)for(int z=-3;z<=3;z++)for(int y=0;y<=2;y++){Location at=target.getLocation().add(x+.5,y,z+.5);if(AiTerrain.floor(at)&&s.room.game.isLocationInArena(at)&&at.distanceSquared(target.getLocation())>1)candidates.add(at);}return candidates.stream().sorted(Comparator.comparingDouble(at->at.distanceSquared(p.getLocation()))).filter(at->{Location eye=at.clone().add(0,1.62,0);var d=target.getLocation().add(.5,.5,.5).toVector().subtract(eye.toVector());var ray=target.getWorld().rayTraceBlocks(eye,d.clone().normalize(),d.length()+.01,FluidCollisionMode.NEVER,true);return ray!=null&&target.equals(ray.getHitBlock());}).findFirst().orElse(null);}
    private void approach(AiBrain.State s,Location at,int tick){var p=s.bot.getPlayer();var d=at.toVector().subtract(p.getLocation().toVector());if(Math.abs(d.getY())<.6&&d.clone().setY(0).lengthSquared()<1&&d.clone().setY(0).lengthSquared()>.0064){brain.buildMove(s,d.getX(),d.getZ());}else brain.navigate(s,at,tick,false,false);}
}
