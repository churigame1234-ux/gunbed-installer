package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.screamingsandals.bedwars.api.game.*;
import java.util.*;
import java.util.function.DoubleUnaryOperator;

/** One team/range policy for players, registered summons, dragons and turret blast receivers. */
final class BattleTargets {
 static LivingEntity living(Entity entity){return entity instanceof ComplexEntityPart part?part.getParent():entity instanceof LivingEntity l?l:null;}
 static String team(GunbedCore p,Game g,Entity entity){LivingEntity e=living(entity);if(e==null)return null;if(e instanceof Player player){var t=g.getTeamOfPlayer(player);return t==null?null:t.getName();}String t=p.summons==null?null:p.summons.team(e);if(t==null&&p.flow!=null)t=p.flow.dragons.team(e);if(t==null&&p.turrets!=null)t=p.turrets.team(e);return t;}
 static List<LivingEntity> enemies(GunbedCore p,Game g,String team,Location at,double range){return at.getWorld().getNearbyLivingEntities(at,range,e->{String other=team(p,g,e);return other!=null&&!other.equals(team)&&!e.isDead()&&!(e instanceof Player player&&player.getGameMode()==GameMode.SPECTATOR)&&!(e instanceof ArmorStand);}).stream().sorted(Comparator.comparingDouble(e->e.getLocation().distanceSquared(at))).toList();}
 static boolean hurt(GunbedCore p,LivingEntity target,Player owner,double value){if(p.flow.dragons.damage(target,owner,value))return true;if(p.turrets!=null&&p.turrets.damage(target,owner,value))return true;target.setNoDamageTicks(0);target.damage(value,owner);return true;}
 static void blastTurrets(GunbedCore p,Player owner,Game game,Location at,double radius,DoubleUnaryOperator damage){if(p.turrets==null||owner==null||game==null)return;for(ArmorStand body:p.turrets.bodies(game)){double distance=BlastExposure.distance(at,body,radius);if(distance<=radius)p.turrets.damage(body,owner,damage.applyAsDouble(distance));}}
 static void emeraldBurst(Location at,double radius){at.getWorld().playSound(at,Sound.ENTITY_GENERIC_EXPLODE,SoundCategory.BLOCKS,1.1f,.85f);var dust=new Particle.DustOptions(Color.fromRGB(0x32ED83),1.8f);for(int ring=0;ring<3;ring++){double y=.08+ring*.35;for(int n=0;n<72;n++){double angle=n*Math.PI/36;Location point=at.clone().add(Math.cos(angle)*radius,y,Math.sin(angle)*radius);at.getWorld().spawnParticle(Particle.DUST,point,1,0,0,0,0,dust,true);if(ring==1&&n%3==0)at.getWorld().spawnParticle(Particle.FIREWORK,point,1,0,0,0,.025,null,true);}}}
}
