package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.screamingsandals.bedwars.api.game.Game;
import org.screamingsandals.bedwars.api.Team;
import org.screamingsandals.bedwars.api.events.*;
import net.kyori.adventure.text.*;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;

final class BedAlerts implements Listener {
    BedAlerts(GunbedCore p){Bukkit.getPluginManager().registerEvents(this,p);}
    @EventHandler public void destroyed(BedwarsTargetBlockDestroyedEvent e){alert(e.getGame(),e.getTeam());}
    static void alert(Game g,Team victim){for(Player p:g.getConnectedPlayers()){boolean own=g.getTeamOfPlayer(p)==victim;if(own){p.playSound(p.getLocation(),Sound.ENTITY_WITHER_DEATH,1,1);p.showTitle(Title.title(Component.text("침대가 파괴되었습니다!",NamedTextColor.RED),Component.text("이제 사망하면 부활할 수 없습니다.",NamedTextColor.YELLOW)));}else p.playSound(p.getLocation(),Sound.ENTITY_ENDER_DRAGON_GROWL,1,1);}}
    static void all(Game g){for(Player p:g.getConnectedPlayers()){p.playSound(p.getLocation(),Sound.ENTITY_WITHER_DEATH,1,1);p.showTitle(Title.title(Component.text("모든 침대가 파괴되었습니다!",NamedTextColor.RED),Component.text("이제 사망하면 부활할 수 없습니다.",NamedTextColor.YELLOW)));}}
}
