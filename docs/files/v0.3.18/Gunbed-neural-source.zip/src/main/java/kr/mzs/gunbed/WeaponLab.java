package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.GameStatus;
import java.util.*;

/** Reversible OP test loadout. Overflow guns stay in the paged portable armoury. */
final class WeaponLab implements Listener,AutoCloseable {
    private final GunbedCore plugin;
    private final NamespacedKey box;
    private final Map<UUID,String> sessions=new HashMap<>();
    private record Menu(String engine,int page,List<String> ids,String category) implements InventoryHolder{public Inventory getInventory(){throw new UnsupportedOperationException();}}
    WeaponLab(GunbedCore plugin){this.plugin=plugin;box=new NamespacedKey(plugin,"lab_box");Bukkit.getPluginManager().registerEvents(this,plugin);for(String command:List.of("크랙샷무기지급","ta무기지급","실험종료"))plugin.getCommand(command).setExecutor((sender,c,l,args)->{if(!(sender instanceof Player p))return true;if(c.getName().equals("실험종료"))restore(p);else enter(p,c.getName().startsWith("ta")?"ta":"cs");return true;});}
    boolean testing(Player p){return sessions.containsKey(p.getUniqueId());}
    private List<String> ids(String engine){return engine.equals("ta")?plugin.taWeapons.definitions().stream().map(TaczWeapons.Definition::id).toList():plugin.visuals==null?List.of():List.copyOf(plugin.visuals.titles());}
    private ItemStack create(String engine,String id){if(id.startsWith("lr:"))return plugin.addonMelee.create(id.substring(3));return engine.equals("ta")?plugin.taWeapons.create(id):plugin.visuals.create(id);}
    private void enter(Player p,String engine){if(!p.isOp()){p.sendMessage("§c운영자 시험 명령어입니다.");return;}if(Bukkit.getPluginManager().isPluginEnabled("BedWars")){var game=BedwarsAPI.getInstance().getGameOfPlayer(p);if(game!=null&&game.getStatus()==GameStatus.RUNNING){p.sendMessage("§c경기를 나간 뒤 무기 실험을 시작해주세요.");return;}}List<String> ids=ids(engine);if(ids.isEmpty()){p.sendMessage("§c해당 무기 엔진이 활성화되어 있지 않습니다.");return;}
        if(!testing(p)){List<ItemStack> snapshot=Arrays.stream(p.getInventory().getContents()).map(i->i==null?null:i.clone()).toList();plugin.profiles.set(p.getUniqueId(),"lab.inventory",snapshot);if(!plugin.profiles.saved()){p.sendMessage("§c기존 인벤토리를 저장하지 못해 실험을 시작하지 않았습니다.");return;}}
        sessions.put(p.getUniqueId(),engine);p.getInventory().clear();for(int i=0;i<Math.min(27,ids.size());i++)p.getInventory().setItem(i,create(engine,ids.get(i)));
        ItemStack container=new ItemStack(Material.CHEST);var meta=container.getItemMeta();meta.setDisplayName("§6실험 무기 보관함 §7("+ids.size()+"종)");meta.getPersistentDataContainer().set(box,PersistentDataType.STRING,engine);container.setItemMeta(meta);p.getInventory().setItem(35,container);if(engine.equals("cs")&&plugin.visuals!=null)plugin.visuals.ensureReserve(p,ids.get(0));p.sendMessage("§a"+ids.size()+"종을 실험 보관함에 지급했습니다. 우클릭으로 전체 목록을 여세요. §e재장전 유지 / 예비 탄약 무한");p.sendMessage("§7/실험종료: 실험 전 인벤토리 복구");open(p,engine,0);
    }
    void restore(Player p){Object stored=plugin.profiles.get(p.getUniqueId()).get("lab.inventory");if(stored instanceof List<?> list){ItemStack[] contents=new ItemStack[p.getInventory().getContents().length];for(int i=0;i<Math.min(contents.length,list.size());i++)if(list.get(i) instanceof ItemStack item)contents[i]=item.clone();p.getInventory().setContents(contents);plugin.profiles.set(p.getUniqueId(),"lab.inventory",null);}sessions.remove(p.getUniqueId());}
    private void open(Player p,String engine,int page){open(p,engine,page,"");}
    private String category(String engine,String id){if(id.startsWith("lr:"))return "melee";String key=engine+":"+id;var weapon=plugin.arsenal.weapons().stream().filter(w->w.id().equals(key)).findFirst().orElse(null);return weapon!=null&&!weapon.role().equals("primary")?weapon.role():plugin.arsenal.category(key);}
    private void open(Player p,String engine,int page,String category){
        List<String> all=new ArrayList<>(ids(engine));if(engine.equals("ta"))all.addAll(List.of("lr:dagger","lr:karambit","lr:baseball_bat"));else all.removeIf(id->plugin.arsenal.weapons().stream().noneMatch(w->w.id().equals("cs:"+id)));
        List<String> classes=List.of("rifle","shotgun","sniper","secondary","melee"),names=List.of("라이플","샷건","스나이퍼","보조무기","근접무기");
        if(category.isEmpty()){Inventory inv=Bukkit.createInventory(new Menu(engine,0,List.of(),""),54,"실험 무기고 · 종류 선택");int[] slots={20,22,24,30,32};Material[] icons={Material.IRON_HOE,Material.CROSSBOW,Material.SPYGLASS,Material.TRIPWIRE_HOOK,Material.IRON_SWORD};for(int i=0;i<classes.size();i++){String type=classes.get(i);long count=all.stream().filter(id->category(engine,id).equals(type)).count();inv.setItem(slots[i],label(icons[i],"§e"+names.get(i)+" §7("+count+"종)"));}inv.setItem(49,label(Material.BARRIER,"§c실험 종료 · 인벤토리 복구"));p.openInventory(inv);return;}
        List<String> ids=all.stream().filter(id->category(engine,id).equals(category)).toList();Inventory inv=Bukkit.createInventory(new Menu(engine,page,ids,category),54,names.get(classes.indexOf(category))+" · "+(page+1));for(int i=page*45;i<Math.min(ids.size(),(page+1)*45);i++)inv.setItem(i%45,create(engine,ids.get(i)));if(page>0)inv.setItem(45,label(Material.ARROW,"§e이전"));inv.setItem(48,label(Material.CHEST,"§e무기 종류 선택"));inv.setItem(49,label(Material.BARRIER,"§c실험 종료 · 인벤토리 복구"));if((page+1)*45<ids.size())inv.setItem(53,label(Material.ARROW,"§e다음"));p.openInventory(inv);
    }
    private ItemStack label(Material m,String s){ItemStack i=new ItemStack(m);var meta=i.getItemMeta();meta.setDisplayName(s);i.setItemMeta(meta);return i;}
    @EventHandler public void click(InventoryClickEvent e){if(!(e.getView().getTopInventory().getHolder() instanceof Menu menu))return;e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p))return;int slot=e.getRawSlot();if(menu.category.isEmpty()&&slot!=49){int c=List.of(20,22,24,30,32).indexOf(slot);if(c>=0)open(p,menu.engine,0,List.of("rifle","shotgun","sniper","secondary","melee").get(c));return;}if(slot==48){open(p,menu.engine,0);return;}if(slot==49){p.closeInventory();restore(p);return;}if(slot==45&&menu.page>0){open(p,menu.engine,menu.page-1,menu.category);return;}if(slot==53&&(menu.page+1)*45<menu.ids.size()){open(p,menu.engine,menu.page+1,menu.category);return;}int index=menu.page*45+slot;if(slot<0||slot>=45||index>=menu.ids.size())return;p.getInventory().setItemInMainHand(create(menu.engine,menu.ids.get(index)));if(menu.engine.equals("cs"))plugin.visuals.ensureReserve(p,menu.ids.get(index));p.closeInventory();}
    @EventHandler public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof Menu)e.setCancelled(true);}
    @EventHandler public void use(PlayerInteractEvent e){ItemStack item=e.getItem();if(testing(e.getPlayer())&&item!=null&&item.hasItemMeta()&&item.getItemMeta().getPersistentDataContainer().has(box)){e.setCancelled(true);open(e.getPlayer(),sessions.get(e.getPlayer().getUniqueId()),0);}}
    @EventHandler(priority=EventPriority.LOWEST)public void quit(PlayerQuitEvent e){if(testing(e.getPlayer()))restore(e.getPlayer());}
    @EventHandler(priority=EventPriority.LOWEST)public void join(PlayerJoinEvent e){restore(e.getPlayer());}
    @EventHandler(priority=EventPriority.LOWEST)public void gameJoin(org.screamingsandals.bedwars.api.events.BedwarsPlayerJoinEvent e){if(testing(e.getPlayer())){e.setCancelled(true);e.setCancelMessage("§c/실험종료 후 경기에 참가해주세요.");}}
    @Override public void close(){for(UUID id:Set.copyOf(sessions.keySet())){Player p=Bukkit.getPlayer(id);if(p!=null)restore(p);}}
}
