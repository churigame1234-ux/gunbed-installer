package kr.mzs.gunbed;

import java.util.*;
import com.shampaggon.crackshot.events.WeaponDamageEntityEvent;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.Game;

/** Vanilla zero-damage snowballs hit dragon parts without creating a damage event. */
final class DragonCrackShotImpact {
    private static final NamespacedKey DONE=new NamespacedKey("gunbedcore","cs_dragon_impact");
    static boolean spent(Entity projectile){return projectile!=null&&projectile.getPersistentDataContainer().has(DONE);}
    static void mark(Entity projectile){if(projectile instanceof Projectile)projectile.getPersistentDataContainer().set(DONE,PersistentDataType.BYTE,(byte)1);}
    private static EnderDragon owned(GunbedCore plugin,Entity entity) {
        if(entity instanceof ComplexEntityPart part)entity=part.getParent();
        if(!(entity instanceof EnderDragon dragon))return null;
        try{var method=SuddenDragons.class.getDeclaredMethod("own",Entity.class);method.setAccessible(true);return (boolean)method.invoke(plugin.flow.dragons,dragon)?dragon:null;}
        catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
    }
    static void impact(GunbedCore plugin,ProjectileHitEvent event) {
        Projectile projectile=event.getEntity();EnderDragon dragon=owned(plugin,event.getHitEntity());
        if(dragon==null||spent(projectile)||!(projectile.getShooter() instanceof Player source)||!projectile.hasMetadata("projParentNode"))return;
        Game game=BedwarsAPI.getInstance().getGameOfPlayer(source);if(game==null||BedwarsAPI.getInstance().getGameOfEntity(dragon)!=game)return;
        String title=projectile.getMetadata("projParentNode").stream().filter(v->v.getOwningPlugin()==plugin.visuals.cs.getHandle()).map(v->v.asString()).findFirst().orElse("");
        if(title.isEmpty()||Set.of("골데B","소드오프").contains(title))return; // the explosion impact owns these
        boolean head=false;
        if(event.getHitEntity() instanceof ComplexEntityPart part)try{Object handle=part.getClass().getMethod("getHandle").invoke(part);head="head".equals(handle.getClass().getField("name").get(handle));}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
        var hit=new WeaponDamageEntityEvent(source,dragon,projectile,title,plugin.visuals.cs.getHandle().getDouble(title+".Shooting.Projectile_Damage"),head,false,false);
        // Existing damage.yml values, weapon mode modifiers, and feedback listeners
        // handle this event; never add a second hard-coded damage calculation.
        Bukkit.getPluginManager().callEvent(hit);
    }
    static void blast(GunbedCore plugin,Player source,Game game,String title,Location at,double radius) {
        for(EnderDragon dragon:at.getWorld().getEntitiesByClass(EnderDragon.class)) {
            if(dragon.isDead()||BedwarsAPI.getInstance().getGameOfEntity(dragon)!=game||owned(plugin,dragon)==null)continue;
            double nearest=radius+1;
            for(ComplexEntityPart part:dragon.getParts()){
                var box=part.getBoundingBox();var near=new org.bukkit.util.Vector(Math.max(box.getMinX(),Math.min(box.getMaxX(),at.getX())),Math.max(box.getMinY(),Math.min(box.getMaxY(),at.getY())),Math.max(box.getMinZ(),Math.min(box.getMaxZ(),at.getZ())));
                var delta=near.subtract(at.toVector());double distance=delta.length();
                if(distance<nearest&&(distance<.05||at.getWorld().rayTraceBlocks(at,delta.clone().normalize(),distance,FluidCollisionMode.NEVER,true)==null))nearest=distance;
            }
            if(nearest<=radius)plugin.flow.dragons.damage(dragon,source,plugin.damageProfiles.blast("cs:"+title,nearest<=radius/3?"center":nearest<=radius*2/3?"middle":"outer"));
        }
    }
}
