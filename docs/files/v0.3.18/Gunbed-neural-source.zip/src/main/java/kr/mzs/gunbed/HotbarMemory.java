package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.GameStatus;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;

/** Remember utility hotbar positions, never the contents or the fixed weapon bank. */
final class HotbarMemory implements Listener {
    private final GunbedCore plugin;
    private final Set<UUID> pending=new HashSet<>();
    private final Map<UUID,String[]> previous=new HashMap<>();
    HotbarMemory(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);}
    private boolean playing(Player p){var game=BedwarsAPI.getInstance().getGameOfPlayer(p);return game!=null&&game.getStatus()==GameStatus.RUNNING&&game.getTeamOfPlayer(p)!=null&&p.getGameMode()!=GameMode.SPECTATOR&&!plugin.inventories.locked(p);}
    String key(ItemStack item){
        if(item==null||item.getType().isAir()||plugin.containers!=null&&plugin.containers.button(item))return "";
        var meta=item.getItemMeta();String tool=meta.getPersistentDataContainer().get(new NamespacedKey(plugin,"shop_tool"),PersistentDataType.STRING);if(tool!=null)return "tool/"+tool;
        String type=item.getType().name();for(String suffix:List.of("_WOOL","_CONCRETE","_TERRACOTTA","_STAINED_GLASS"))if(type.endsWith(suffix))return "block/"+suffix;
        ItemStack base=plugin.stacks.base(item);if(base.getItemMeta() instanceof Damageable damage){damage.setDamage(0);base.setItemMeta(damage);}
        return "item/"+base.getType().name()+"/"+base.getItemMeta().getAsString();
    }
    private String path(ItemStack item){try{return "hotbar-v1."+HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(key(item).getBytes(StandardCharsets.UTF_8)));}catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}}
    int preferred(Player p,ItemStack item){if(key(item).isEmpty())return -1;return plugin.profiles.get(p.getUniqueId()).getInt(path(item),-1);}
    void capture(Player p){if(!playing(p)&&!plugin.inventories.rememberable(p))return;ItemStack[] items=plugin.inventories.utility(p);String[] keys=new String[9],old=previous.get(p.getUniqueId());boolean changed=false;for(int slot=0;slot<9;slot++){ItemStack item=items[slot];keys[slot]=item==null?"":key(item);if(item==null||keys[slot].isEmpty()||plugin.inventories.role(item)!=null||old!=null&&Objects.equals(old[slot],keys[slot]))continue;String path=path(item);if(plugin.profiles.get(p.getUniqueId()).getInt(path,-1)!=slot){plugin.profiles.set(p.getUniqueId(),path,slot);changed=true;}}previous.put(p.getUniqueId(),keys);if(changed)plugin.profiles.flush();}
    void changed(Player p){if(!pending.add(p.getUniqueId()))return;Bukkit.getScheduler().runTask(plugin,()->{pending.remove(p.getUniqueId());if(p.isOnline())capture(p);});}
    boolean place(Player p,Inventory inventory,ItemStack item){return plugin.stacks.add(inventory,item,preferred(p,item));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void click(InventoryClickEvent e){if(e.getWhoClicked() instanceof Player p&&e.getClickedInventory() instanceof PlayerInventory)changed(p);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void drag(InventoryDragEvent e){if(e.getWhoClicked() instanceof Player p)changed(p);}
    @EventHandler(priority=EventPriority.MONITOR)public void close(InventoryCloseEvent e){if(e.getPlayer() instanceof Player p)capture(p);}
    @EventHandler(priority=EventPriority.LOWEST)public void quit(PlayerQuitEvent e){capture(e.getPlayer());plugin.profiles.saved();pending.remove(e.getPlayer().getUniqueId());}
}
