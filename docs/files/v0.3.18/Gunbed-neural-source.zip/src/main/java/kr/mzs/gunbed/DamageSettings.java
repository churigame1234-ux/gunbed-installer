package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.EquipmentSlot;
import java.nio.file.*;
import java.util.*;

/** One damage-only file. Reload validates a full snapshot before replacing any live values. */
final class DamageSettings implements Listener {
    private final GunbedCore plugin;private final Path file;
    private final Map<String,Double> defaults=new LinkedHashMap<>();private Map<String,Double> live=Map.of();
    DamageSettings(GunbedCore p){plugin=p;file=p.getDataFolder().toPath().resolve("damage.yml");
        for(var row:p.damageProfiles.describe()){
            String id=row.get("id").toString(),key=weapon(id);double pellets=((Number)row.get("pellets")).doubleValue();
            for(String part:row.get("class").equals("melee")?List.of("body"):List.of("body","head","legs"))add(key+"."+part,((Number)row.get(part)).doubleValue()/pellets);
            if(row.get("class").equals("rpg")){double body=((Number)row.get("body")).doubleValue();add(key+".explosion.center",body);if(id.startsWith("cs:")){add(key+".explosion.middle",body*.5);add(key+".explosion.outer",body*.25);}}
            if(Set.of("cs:g36","cs:바스티온").contains(id))add(key+".siege-multiplier",2);
        }
        for(var entry:Map.of("he",3200d,"fire-tick",200d,"flash",0d).entrySet())add("throwables."+entry.getKey(),entry.getValue());
        add("throwables.labs_he",3600);add("throwables.labs_impact",3000);add("throwables.labs-gas-tick",300);add("items.bow.normal",4500);add("items.bow.power",6000);add("items.bow.punch",6000);add("items.tnt.maximum",4000);add("items.fireball.maximum",2000);add("items.unarmed",1);
        for(Material m:Material.values())if(m.name().endsWith("_SWORD")||m.name().endsWith("_AXE")||m.name().endsWith("_PICKAXE")||m.name().endsWith("_HOE")||m.name().endsWith("_SHOVEL")||Set.of(Material.STICK,Material.SHEARS,Material.TRIDENT,Material.MACE).contains(m)){
            double amount=switch(m){case WOODEN_SWORD->800;case STONE_SWORD->1000;case IRON_SWORD->1200;case DIAMOND_SWORD,NETHERITE_SWORD->1400;default->1;};
            if(!m.name().endsWith("_SWORD"))for(var modifier:m.getDefaultAttributeModifiers(EquipmentSlot.HAND).get(Attribute.ATTACK_DAMAGE))if(modifier.getOperation()==org.bukkit.attribute.AttributeModifier.Operation.ADD_NUMBER)amount+=modifier.getAmount();
            add("items.melee."+m.name().toLowerCase(Locale.ROOT),amount);
        }
        add("summons.golem",1500);add("summons.silverfish",500);add("sudden-death.dragon",2000);add("environment.fall-per-vanilla-point",500);
        add("modifiers.sharpness-min-percent",1);add("modifiers.sharpness-max-percent",5);
        for(String kind:List.of("burst","slowness","siege")){var def=p.turrets==null?null:p.turrets.definition(kind);var u=def==null?null:def.getUpgrade(1);add("turrets."+kind+".minimum",u==null?0:u.getMinDamage()*(kind.equals("slowness")?1:.4));add("turrets."+kind+".maximum",u==null?0:u.getMaxDamage()*(kind.equals("slowness")?1:.4));var critical=u==null?null:u.getCriticalHit();add("turrets."+kind+".critical-minimum",critical==null?0:critical.getMinDamage()*.4);add("turrets."+kind+".critical-maximum",critical==null?0:critical.getMaxDamage()*.4);}
        {var def=p.turrets==null?null:p.turrets.definition("healing");var u=def==null?null:def.getUpgrade(1);var c=u==null?null:u.getCriticalHit();add("turrets.healing.minimum",u==null?0:u.getMinHeal());add("turrets.healing.maximum",u==null?0:u.getMaxHeal());add("turrets.healing.critical-minimum",c==null?0:c.getMinHeal());add("turrets.healing.critical-maximum",c==null?0:c.getMaxHeal());}
        for(var cause:EntityDamageEvent.DamageCause.values())if(!Set.of("VOID","SUICIDE","KILL","FALL").contains(cause.name()))add("environment.vanilla-multipliers."+cause.name().toLowerCase(Locale.ROOT),1);
        if(!reload(null))throw new IllegalStateException("damage.yml has invalid damage values; nothing was loaded");Bukkit.getPluginManager().registerEvents(this,p);
    }
    private void add(String key,double value){defaults.put(key,value);}
    static String weapon(String id){return "weapons."+id.replaceFirst(":",".");}
    double value(String path,double fallback){return live.getOrDefault(path,fallback);}
    double melee(org.bukkit.inventory.ItemStack item,double fallback){return item==null?value("items.unarmed",1):value("items.melee."+item.getType().name().toLowerCase(Locale.ROOT),fallback);}
    boolean reload(CommandSender sender){try{
        YamlConfiguration yaml=new YamlConfiguration();yaml.options().parseComments(true);if(Files.exists(file))yaml.load(file.toFile());Map<String,Double> next=new LinkedHashMap<>(defaults);boolean added=false;
        for(String key:yaml.getKeys(true)){if(yaml.isConfigurationSection(key))continue;if(!defaults.containsKey(key))throw new IllegalArgumentException("알 수 없는 항목: "+key);Object raw=yaml.get(key);if(!(raw instanceof Number n)||!Double.isFinite(n.doubleValue())||n.doubleValue()<0||n.doubleValue()>1_000_000)throw new IllegalArgumentException(key+": 0~1,000,000 범위의 숫자를 입력하세요.");next.put(key,n.doubleValue());}
        for(String kind:List.of("burst","slowness","siege","healing"))for(String critical:List.of("","critical-"))if(next.get("turrets."+kind+"."+critical+"minimum")>next.get("turrets."+kind+"."+critical+"maximum"))throw new IllegalArgumentException("turrets."+kind+": 최소 피해가 최대 피해보다 큽니다.");
        double min=next.get("modifiers.sharpness-min-percent"),max=next.get("modifiers.sharpness-max-percent");if(min>max||min!=Math.rint(min)||max!=Math.rint(max))throw new IllegalArgumentException("날카로움 추가 피해는 최소≤최대인 정수 퍼센트여야 합니다.");
        for(var entry:defaults.entrySet())if(!yaml.contains(entry.getKey())){yaml.set(entry.getKey(),entry.getValue());added=true;}
        if(added||!Files.exists(file)){
            for(var row:plugin.damageProfiles.describe()){String id=row.get("id").toString();String name=plugin.arsenal.weapons().stream().filter(w->w.id().equals(id)).map(w->w.title()).findFirst().orElse(id);yaml.setComments(weapon(id),List.of(ChatColor.stripColor(name)+" · "+row.get("class"),row.get("class").equals("melee")?"근접 무기는 body 피해만 사용합니다.":"한 발당 피해 / 샷건은 펠렛 1개당 피해"));}
            yaml.options().setHeader(List.of("Gunbed 대미지 전용 설정 · 체력 10,000 기준 · 방어/거리 감쇠/팀 추가 피해 적용 전", "weapons: 한 발(샷건은 펠렛 1개)당 몸통/머리/다리 피해. CS의 B 무기는 별도 무기 ID입니다.","explosion: 중심/중간/외곽 피해. TA 발사기는 직격 body와 주변 폭발 center를 따로 사용합니다.","siege-multiplier: 시즈 전개 피해 배수. 다른 반동/연사/장전/범위/넉백은 변경하지 않습니다.","turrets: burst=철, slowness=금, siege=에메랄드. healing=회복량. minimum/maximum과 critical-minimum/maximum을 수정하세요.","throwables.fire-tick은 화염 장판의 1회 피해. 골렘/좀벌레/드래곤은 1회 공격 피해입니다.","environment의 나머지는 관리되지 않는 바닐라 피해의 배수. 공허·초기화 즉사는 수치가 없습니다.","수정 후 OP /총리로드: 경기 유지 즉시 적용. /초기화: 전체 경기 종료·로비 복귀와 함께 검증된 값을 적용합니다.","잘못된 숫자/오타/최소>최대는 적용을 거부하고 이전 값을 유지합니다."));Files.createDirectories(file.getParent());Path tmp=file.resolveSibling("damage.yml.tmp");Files.writeString(tmp,yaml.saveToString());Files.move(tmp,file,StandardCopyOption.REPLACE_EXISTING);
        }
        live=Map.copyOf(next);if(plugin.specs!=null)plugin.specs.invalidate();if(sender!=null)sender.sendMessage("§a대미지 설정 "+live.size()+"개 적용: plugins/GunbedCore/damage.yml");return true;
    }catch(Exception e){plugin.getLogger().warning("damage.yml: "+e.getMessage());if(sender!=null)sender.sendMessage("§cdamage.yml 적용 실패 · 이전 값 유지: "+e.getMessage());return false;}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void vanilla(EntityDamageEvent e){if(!(e.getEntity() instanceof Player p)||org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getGameOfPlayer(p)==null||RoundFalls.applying())return;if(e instanceof EntityDamageByEntityEvent hit){Entity d=hit.getDamager();if(d instanceof Player||d instanceof EnderDragon||d instanceof ComplexEntityPart||d.getPersistentDataContainer().has(SummonCreatures.OWNER)||d.getPersistentDataContainer().has(ShopExplosions.OWNER)||d instanceof Projectile q&&q.getShooter() instanceof Player)return;}e.setDamage(e.getDamage()*value("environment.vanilla-multipliers."+e.getCause().name().toLowerCase(Locale.ROOT),1));}
}
