package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import java.util.*;
import net.kyori.adventure.text.*;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;

/** Player-facing menus are reached through lobby items; three chat shortcuts remain. */
final class PlayerMenuRoutes implements Listener {
    private final GunbedCore plugin;
    private final Set<String> blocked=Set.of("즐겨찾기","무기즐겨찾기","gunbed상점","gunbed설정","자원창고","rank","추천포인트","후원포인트","참가","join","random","map");
    PlayerMenuRoutes(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);}
    private void vote(Player p){p.sendMessage(Component.text("[ 마인리스트 추천 ]",NamedTextColor.AQUA).clickEvent(ClickEvent.openUrl("https://minelist.kr/servers/mzs123.mcv.kr")));p.sendMessage(Component.text("[ Minecraft-MP 추천 ]",NamedTextColor.GREEN).clickEvent(ClickEvent.openUrl("https://minecraft-mp.com/server-s329129")));}
    @EventHandler(priority=EventPriority.LOWEST)public void command(PlayerCommandPreprocessEvent e){String[] args=e.getMessage().substring(1).toLowerCase(Locale.ROOT).split("\\s+");String c=args[0];if(c.contains(":"))c=c.substring(c.indexOf(':')+1);if(Set.of("설정","set").contains(c)){e.setCancelled(true);plugin.controls.settings(e.getPlayer());return;}if(Set.of("vote","추천").contains(c)){e.setCancelled(true);vote(e.getPlayer());return;}boolean adminArgs=args.length>1&&e.getPlayer().hasPermission("gunbedcore.admin");if(blocked.contains(c)&&!adminArgs||c.equals("gunbed")&&(args.length==1||Set.of("arenas","quick","join").contains(args[1]))){e.setCancelled(true);e.getPlayer().sendMessage("§e로비 아이템에서 이용하세요. 개인 설정은 채팅에 설정 또는 set을 입력하세요.");}}
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void chat(AsyncPlayerChatEvent e){String c=e.getMessage().strip().toLowerCase(Locale.ROOT);if(!Set.of("설정","set","vote","추천").contains(c))return;e.setCancelled(true);Bukkit.getScheduler().runTask(plugin,()->{if(c.equals("vote")||c.equals("추천"))vote(e.getPlayer());else plugin.controls.settings(e.getPlayer());});}
}
