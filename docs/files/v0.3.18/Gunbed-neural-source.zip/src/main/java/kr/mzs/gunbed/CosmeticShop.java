package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import java.util.*;

/** Permanent unlocks: point deduction and ownership are one SQLite transaction. */
final class CosmeticShop implements Listener {
    private record Menu(String kind,String selected,List<String> ids) implements InventoryHolder {public Inventory getInventory(){throw new UnsupportedOperationException();}}
    private record CategoryMenu(String currency,String category,List<String> ids) implements InventoryHolder {public Inventory getInventory(){throw new UnsupportedOperationException();}}
    private record Cosmetic(String id,String category,String title,Material icon,PointLedger.Currency currency,long price){}
    private static final List<Cosmetic> OPTIONS=List.of(
        new Cosmetic("killsound:chime","killsound","수정 처치 알림음",Material.AMETHYST_SHARD,PointLedger.Currency.RECOMMEND,15),
        new Cosmetic("killsound:bell","killsound","종 처치 알림음",Material.BELL,PointLedger.Currency.RECOMMEND,25),
        new Cosmetic("killsound:levelup","killsound","레벨업 처치 알림음",Material.EXPERIENCE_BOTTLE,PointLedger.Currency.DONATION,1000),
        new Cosmetic("upgrade:loadout-slots","loadouts","무기 즐겨찾기 12세트 확장권",Material.BOOKSHELF,PointLedger.Currency.DONATION,10000),
        new Cosmetic("jump:chime","jump","수정 더블점프 소리",Material.AMETHYST_SHARD,PointLedger.Currency.RECOMMEND,15),
        new Cosmetic("jump:breeze","jump","바람 더블점프 소리",Material.WIND_CHARGE,PointLedger.Currency.DONATION,1000),
        new Cosmetic("jump:note","jump","음표 더블점프 소리",Material.NOTE_BLOCK,PointLedger.Currency.RECOMMEND,15),
        new Cosmetic("cosmetic:nickname","nickname","닉네임 변경권",Material.NAME_TAG,PointLedger.Currency.DONATION,10000),
        new Cosmetic("shopkeeper:desert","shopkeeper","사막 주민",Material.SAND,PointLedger.Currency.RECOMMEND,25),
        new Cosmetic("shopkeeper:taiga","shopkeeper","타이가 주민",Material.SPRUCE_SAPLING,PointLedger.Currency.RECOMMEND,25),
        new Cosmetic("shopkeeper:snow","shopkeeper","설원 주민",Material.SNOWBALL,PointLedger.Currency.DONATION,1000),
        new Cosmetic("shopkeeper:jungle","shopkeeper","정글 주민",Material.JUNGLE_SAPLING,PointLedger.Currency.DONATION,1000),
        new Cosmetic("effect:hearts","kill","하트 처치 효과",Material.APPLE,PointLedger.Currency.RECOMMEND,25),
        new Cosmetic("effect:flame","kill","불꽃 처치 효과",Material.BLAZE_POWDER,PointLedger.Currency.DONATION,10000),
        new Cosmetic("final:lightning","final","번개 파이널 효과",Material.LIGHTNING_ROD,PointLedger.Currency.DONATION,1000),
        new Cosmetic("final:soul","final","영혼 파이널 효과",Material.SOUL_LANTERN,PointLedger.Currency.RECOMMEND,50),
        new Cosmetic("victory:champion","victory","챔피언 승리 포즈",Material.ARMOR_STAND,PointLedger.Currency.RECOMMEND,50),
        new Cosmetic("victory:fireworks","victory","폭죽 승리 효과",Material.FIREWORK_ROCKET,PointLedger.Currency.DONATION,1000));
    private record PurchaseMenu(UUID buyer,UUID nonce,String id,PointLedger.Currency currency,long price,String category) implements InventoryHolder {public Inventory getInventory(){throw new UnsupportedOperationException();}}
    private final Map<UUID,PurchaseMenu> pending=new HashMap<>();
    private final GunbedCore plugin;
    CosmeticShop(GunbedCore plugin){this.plugin=plugin;Bukkit.getPluginManager().registerEvents(this,plugin);plugin.getCommand("gunbed상점").setExecutor((s,c,l,a)->{if(s instanceof Player p)open(p);return true;});}
    static String entitlement(String id){return switch(id){case "cs:VSS-B"->"cs:VSS";case "cs:골데B"->"cs:골데";default->id;};}
    private ItemStack label(Material type,String title,String...lore){ItemStack item=new ItemStack(type);var meta=item.getItemMeta();meta.setDisplayName(title);meta.setLore(List.of(lore));item.setItemMeta(meta);return item;}
    void open(Player p){Inventory inv=Bukkit.createInventory(new Menu("home","",List.of()),27,"Gunbed 추천 · 후원 상점");inv.setItem(11,label(Material.NETHER_STAR,"§e추천 상점","§7좀비서버와 공통 추천 기록 사용","§f누적 "+plugin.points.votes(p.getUniqueId())+"회 · 추천포인트 "+plugin.points.balance(p.getUniqueId(),PointLedger.Currency.RECOMMEND)));inv.setItem(15,label(Material.EMERALD,"§d후원 상점","§7무기·처치 효과 영구 해금","§f후원포인트 "+plugin.points.balance(p.getUniqueId(),PointLedger.Currency.DONATION)));inv.setItem(13,label(Material.ENDER_CHEST,"§b내 마이룸","§7보유 무기·치장 확인 및 장착"));p.openInventory(inv);}
    private void recommend(Player p){int goal=plugin.getConfig().getInt("points.recommend-goal",100);boolean owned=plugin.points.owns(p.getUniqueId(),"effect:starlight");Inventory inv=Bukkit.createInventory(new Menu("recommend","",List.of()),54,"추천 상점 · 누적 "+goal+"회 보상");inv.setItem(13,label(Material.NETHER_STAR,"§e별빛 처치 효과",owned?"§a해금됨 · 클릭하여 장착":"§f누적 추천 "+plugin.points.votes(p.getUniqueId())+" / "+goal+"회","§7누적 횟수 보상이므로 포인트를 차감하지 않습니다."));categories(inv);inv.setItem(31,label(Material.NOTE_BLOCK,"§e더블점프 소리"));inv.setItem(49,label(Material.ARROW,"§e돌아가기"));p.openInventory(inv);}
    private void donorWeapons(Player p){if(games(p)<10){donors(p);return;}List<String> ids=new ArrayList<>(plugin.arsenal.weapons().stream().filter(Arsenal.Weapon::donor).map(Arsenal.Weapon::id).filter(id->entitlement(id).equals(id)).toList());Inventory inv=Bukkit.createInventory(new Menu("donorweapons","",ids),54,"후원 상점 · 보유 "+plugin.points.balance(p.getUniqueId(),PointLedger.Currency.DONATION)+" P");long price=plugin.getConfig().getLong("points.donation-weapon-price",10000);for(int i=0;i<ids.size()&&i<21;i++){String id=ids.get(i);ItemStack item=id.equals("effect:flame")?label(Material.BLAZE_POWDER,"§6불꽃 처치 효과"):plugin.arsenal.create(id);if(item==null)continue;var meta=item.getItemMeta();List<String> lore=new ArrayList<>(meta.hasLore()?meta.getLore():List.of());lore.add(plugin.points.owns(p.getUniqueId(),id)?"§a보유 중 · 추가 결제 없음":"§d가격: "+price+" 후원포인트");lore.add("§7영구 해금 · 경기 무기 즐겨찾기에서 사용");meta.setLore(lore);item.setItemMeta(meta);inv.setItem(grid(i),item);}inv.setItem(49,label(Material.ARROW,"§e돌아가기"));p.openInventory(inv);}
    private void confirmation(Player p,String id){confirm(p,id,PointLedger.Currency.DONATION,plugin.getConfig().getLong("points.donation-weapon-price",10000),"weapon");}
    private void confirm(Player p,String id,PointLedger.Currency currency,long price,String category){
        var holder=new PurchaseMenu(p.getUniqueId(),UUID.randomUUID(),id,currency,price,category);
        Inventory inv=Bukkit.createInventory(holder,27,"정말 구매하시겠습니까?");
        Cosmetic option=OPTIONS.stream().filter(o->o.id.equals(id)).findFirst().orElse(null);
        inv.setItem(13,option==null?plugin.arsenal.create(id):label(option.icon,"§e"+option.title));
        inv.setItem(11,label(Material.RED_CONCRETE,"§cNo · 취소","§7포인트를 사용하지 않고 돌아갑니다."));
        inv.setItem(15,label(Material.LIME_CONCRETE,"§aYes · 구매 확정","§f가격: "+price+(currency==PointLedger.Currency.RECOMMEND?" 추천포인트":" 후원포인트"),"§7영구 해금 · 확인 시에만 차감됩니다."));
        p.openInventory(inv);pending.put(p.getUniqueId(),holder);
    }
    private void returnTo(Player p,PurchaseMenu m){if(m.category.equals("weapon"))donorWeapons(p);else category(p,m.currency.name(),m.category);}
    @EventHandler public void purchaseClick(InventoryClickEvent e){
        if(!(e.getView().getTopInventory().getHolder() instanceof PurchaseMenu m))return;
        e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p)||!m.buyer.equals(p.getUniqueId())||pending.get(p.getUniqueId())!=m)return;
        int slot=e.getRawSlot();if(slot!=11&&slot!=15)return;pending.remove(p.getUniqueId());
        if(slot==11){returnTo(p,m);return;}
        if(m.category.equals("weapon")&&games(p)<10){donors(p);return;}
        try {
            if(!plugin.points.owns(p.getUniqueId(),m.id)&&!plugin.points.purchase(p.getUniqueId(),m.id,m.currency,m.price)){
                p.sendMessage("§c포인트가 부족합니다. 구매되지 않았습니다.");p.playSound(p.getLocation(),Sound.ENTITY_VILLAGER_NO,1,1);returnTo(p,m);return;
            }
            p.sendMessage("§a영구 해금 완료: "+m.id);
            if(m.category.equals("weapon")){returnTo(p,m);return;}
            Cosmetic option=OPTIONS.stream().filter(o->o.id.equals(m.id)).findFirst().orElseThrow();apply(p,option);
        }catch(IllegalStateException error){plugin.getLogger().log(java.util.logging.Level.SEVERE,"Cosmetic purchase failed",error);p.sendMessage("§c구매 저장에 실패했습니다. 운영자에게 알려주세요.");p.closeInventory();}
    }
    @EventHandler public void purchaseClose(InventoryCloseEvent e){if(e.getInventory().getHolder() instanceof PurchaseMenu m)pending.remove(e.getPlayer().getUniqueId(),m);}
    @EventHandler public void purchaseDrag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof PurchaseMenu)e.setCancelled(true);}
    @EventHandler public void purchaseQuit(org.bukkit.event.player.PlayerQuitEvent e){pending.remove(e.getPlayer().getUniqueId());}
    private void apply(Player p,Cosmetic option){
        if(option.category.equals("loadouts")){p.sendMessage("§a무기 즐겨찾기 12세트가 해금됐습니다.");category(p,option.currency.name(),option.category);return;}
        if(option.category.equals("nickname")){plugin.wardrobe.nickname(p);return;}
        String key="cosmetics."+(option.category.equals("shopkeeper")?"shopkeeper":option.category+"-effect");
        plugin.profiles.set(p.getUniqueId(),key,option.id.substring(option.id.indexOf(':')+1));p.sendMessage("§a장착: "+option.title);category(p,option.currency.name(),option.category);
    }
    private void equip(Player p,String effect){plugin.profiles.set(p.getUniqueId(),"cosmetics.kill-effect",effect);p.sendMessage("§a처치 효과를 장착했습니다.");}
    @EventHandler public void click(InventoryClickEvent e){if(!(e.getView().getTopInventory().getHolder() instanceof Menu menu))return;e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p)||e.getRawSlot()<0||e.getRawSlot()>=e.getView().getTopInventory().getSize())return;int slot=e.getRawSlot();if(slot==23&&(menu.kind.equals("recommend")||menu.kind.equals("donors"))){category(p,menu.kind.equals("recommend")?"RECOMMEND":"DONATION","killsound");return;}if((menu.kind.equals("recommend")||menu.kind.equals("donors"))&&((slot>=45&&slot<=48)||(slot>=19&&slot<=22))){category(p,menu.kind.equals("recommend")?"RECOMMEND":"DONATION",new String[]{"shopkeeper","kill","final","victory"}[slot>=45?slot-45:slot-19]);return;}try{switch(menu.kind){case "home"->{if(slot==11)recommend(p);if(slot==15)donors(p);if(slot==13)plugin.wardrobe.open(p);}case "recommend"->{if(slot==22||slot==49)open(p);if(slot==31)category(p,"RECOMMEND","jump");if(slot==13){if(plugin.points.claimRecommendation(p.getUniqueId(),"effect:starlight")){equip(p,"starlight");recommend(p);}else p.sendMessage("§c아직 추천 목표에 도달하지 않았습니다.");}}case "donors"->{if(slot==13)donorWeapons(p);if(slot==31)category(p,"DONATION","jump");if(slot==33)category(p,"DONATION","nickname");if(slot==35)category(p,"DONATION","loadouts");if(slot==49)open(p);}case "donorweapons"->{if(slot==49){open(p);return;}int index=-1;for(int i=0;i<21;i++)if(grid(i)==slot)index=i;if(index<0||index>=menu.ids.size()||games(p)<10)return;String id=menu.ids.get(index);if(plugin.points.owns(p.getUniqueId(),id)){if(id.startsWith("effect:"))equip(p,id.substring(7));else {p.sendMessage("§a이미 보유한 무기입니다. 무기 즐겨찾기에서 선택해주세요.");plugin.arsenal.favorites(p);}}else confirmation(p,id);}default->{}}}catch(IllegalStateException error){plugin.getLogger().log(java.util.logging.Level.SEVERE,"Cosmetic purchase failed",error);p.sendMessage("§c구매 저장에 실패했습니다. 운영자에게 알려주세요.");}}
    private int grid(int i){return 10+(i/7)*9+i%7;}
    private int games(Player p){var s=org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getStatisticsManager().getStatistic(p.getUniqueId());return s==null?0:s.getGames();}
    private void donors(Player p){Inventory inv=Bukkit.createInventory(new Menu("donors","",List.of()),54,"후원 상점 · 분류 선택");inv.setItem(13,label(games(p)>=10?Material.CROSSBOW:Material.BARRIER,games(p)>=10?"§e후원 무기":"§c후원 무기 잠김","§7구 서버 포함 완료 경기 "+games(p)+" / 10판","§7나머지 치장 상품은 바로 이용 가능"));categories(inv);inv.setItem(31,label(Material.NOTE_BLOCK,"§e더블점프 소리"));inv.setItem(33,label(Material.NAME_TAG,"§e닉네임 변경권","§d10,000 후원포인트"));inv.setItem(35,label(Material.BOOKSHELF,"§e무기 즐겨찾기 12세트 확장","§d10,000 후원포인트 · 기본은 2세트"));inv.setItem(49,label(Material.ARROW,"§e돌아가기"));p.openInventory(inv);}
    private void categories(Inventory inv){inv.setItem(23,label(Material.NOTE_BLOCK,"§e처치 알림음","§7기본: 띵 · 처치한 본인에게만 재생"));inv.setItem(19,label(Material.VILLAGER_SPAWN_EGG,"§e주민 스킨"));inv.setItem(20,label(Material.IRON_SWORD,"§a일반 처치 효과"));inv.setItem(21,label(Material.DIAMOND_SWORD,"§b파이널 처치 효과"));inv.setItem(22,label(Material.FIREWORK_ROCKET,"§d승리 포즈 · 효과"));}
    private void category(Player p,String currency,String category){var list=OPTIONS.stream().filter(o->o.category.equals(category)&&o.currency.name().equals(currency)).toList();Inventory inv=Bukkit.createInventory(new CategoryMenu(currency,category,list.stream().map(Cosmetic::id).toList()),27,"꾸미기 · "+switch(category){case "killsound"->"처치 알림음";case "jump"->"더블점프 소리";case "shopkeeper"->"주민 스킨";case "kill"->"일반 처치";case "final"->"파이널 처치";case "loadouts"->"즐겨찾기 확장";default->"승리";});for(int i=0;i<list.size();i++){Cosmetic option=list.get(i);inv.setItem(10+i,label(option.icon,"§e"+option.title,plugin.points.owns(p.getUniqueId(),option.id)?"§a보유 중 · 클릭하여 장착":"§f가격: "+option.price+(option.currency==PointLedger.Currency.RECOMMEND?" 추천포인트":" 후원포인트"),"§7클릭: 영구 구매 후 장착"));}inv.setItem(22,label(Material.BARRIER,"§c이 분류 장착 해제"));inv.setItem(26,label(Material.ARROW,"§e돌아가기"));p.openInventory(inv);}
    @EventHandler public void cosmeticClick(InventoryClickEvent e){if(!(e.getView().getTopInventory().getHolder() instanceof CategoryMenu menu))return;e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p))return;int slot=e.getRawSlot();if(slot==26){open(p);return;}String key="cosmetics."+(menu.category.equals("shopkeeper")?"shopkeeper":menu.category+"-effect");if(slot==22){plugin.profiles.set(p.getUniqueId(),key,null);p.sendMessage("§a기본 설정으로 되돌렸습니다.");return;}slot-=10;if(slot<0||slot>=menu.ids.size())return;String selectedId=menu.ids.get(slot);Cosmetic option=OPTIONS.stream().filter(o->o.id.equals(selectedId)).findFirst().orElseThrow();if(!plugin.points.owns(p.getUniqueId(),option.id)){confirm(p,option.id,option.currency,option.price,option.category);return;}apply(p,option);}
    @EventHandler public void cosmeticDrag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof CategoryMenu)e.setCancelled(true);}
    @EventHandler public void won(org.screamingsandals.bedwars.api.events.BedwarsGameEndingEvent e){if(e.getWinningTeam()==null)return;for(Player p:e.getWinningTeam().getConnectedPlayers()){String effect=plugin.profiles.get(p.getUniqueId()).getString("cosmetics.victory-effect","");if(!plugin.points.owns(p.getUniqueId(),"victory:"+effect))continue;if(effect.equals("fireworks")){p.getWorld().spawnParticle(Particle.FIREWORK,p.getLocation().add(0,1,0),100,1,1,1,.2);p.playSound(p.getLocation(),Sound.UI_TOAST_CHALLENGE_COMPLETE,.7f,1);}else if(effect.equals("champion")){var stand=p.getWorld().spawn(p.getLocation(),org.bukkit.entity.ArmorStand.class,a->{a.setPersistent(false);a.setGravity(false);a.setArms(true);a.setInvulnerable(true);a.setBasePlate(false);a.setLeftArmPose(new org.bukkit.util.EulerAngle(-2.7,0,-.3));a.setRightArmPose(new org.bukkit.util.EulerAngle(-2.7,0,.3));var head=new ItemStack(Material.PLAYER_HEAD);var meta=(org.bukkit.inventory.meta.SkullMeta)head.getItemMeta();meta.setOwningPlayer(p);head.setItemMeta(meta);a.getEquipment().setHelmet(head);a.getEquipment().setChestplate(p.getInventory().getChestplate());a.customName(TeamPalette.name(p));a.setCustomNameVisible(true);});org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().registerEntityToGame(stand,e.getGame());Bukkit.getScheduler().runTaskLater(plugin,stand::remove,100);}}}
    @EventHandler public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof Menu)e.setCancelled(true);}
    private void killSound(Player killer){
        if(BotRuntime.bot(killer))return;
        String selected=plugin.profiles.get(killer.getUniqueId()).getString("cosmetics.killsound-effect","");
        if(!plugin.points.owns(killer.getUniqueId(),"killsound:"+selected))selected="";
        Sound sound=switch(selected){case "chime"->Sound.BLOCK_AMETHYST_BLOCK_CHIME;case "bell"->Sound.BLOCK_BELL_USE;case "levelup"->Sound.ENTITY_PLAYER_LEVELUP;default->Sound.ENTITY_EXPERIENCE_ORB_PICKUP;};
        killer.playSound(killer.getLocation(),sound,SoundCategory.PLAYERS,.85f,selected.isEmpty()?1.7f:1.25f);
    }
    void killed(Player killer,Player victim){killed(killer,victim,false);}
    void killed(Player killer,Player victim,boolean finalKill){killSound(killer);if(finalKill){String finalEffect=plugin.profiles.get(killer.getUniqueId()).getString("cosmetics.final-effect","");if(plugin.points.owns(killer.getUniqueId(),"final:"+finalEffect)){if(finalEffect.equals("lightning"))victim.getWorld().strikeLightningEffect(victim.getLocation());else if(finalEffect.equals("soul"))victim.getWorld().spawnParticle(Particle.SOUL,victim.getLocation().add(0,1,0),35,.4,.6,.4,.05);return;}}String effect=plugin.profiles.get(killer.getUniqueId()).getString("cosmetics.kill-effect","");if(effect.isEmpty()||!plugin.points.owns(killer.getUniqueId(),"effect:"+effect))return;Location at=victim.getLocation().add(0,.9,0);if(effect.equals("starlight"))at.getWorld().spawnParticle(Particle.END_ROD,at,25,.4,.7,.4,.03);else if(effect.equals("hearts"))at.getWorld().spawnParticle(Particle.HEART,at,12,.4,.5,.4,.02);else if(effect.equals("flame"))at.getWorld().spawnParticle(Particle.SMALL_FLAME,at,35,.4,.6,.4,.02);}
}
