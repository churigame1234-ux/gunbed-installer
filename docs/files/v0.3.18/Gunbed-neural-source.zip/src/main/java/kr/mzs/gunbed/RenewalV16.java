package kr.mzs.gunbed;
import java.nio.file.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.GameStatus;

final class RenewalV16 implements Listener {
 private final GunbedCore p;private static final Map<UUID,Integer> clicks=new HashMap<>();
 static boolean click(Player player){int now=Bukkit.getCurrentTick();Integer old=clicks.put(player.getUniqueId(),now);return old==null||now-old>2;}
 static void install(GunbedCore p){new ParkourV16(p);new RenewalV16(p);}
 private RenewalV16(GunbedCore p){this.p=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,()->{for(Player player:Bukkit.getOnlinePlayers()){var g=org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getGameOfPlayer(player);if(g!=null&&g.getStatus()==GameStatus.RUNNING)tip(player);}},1200,1200);p.getCommand("gbhint").setExecutor((sender,c,l,a)->{if(sender instanceof Player player){p.profiles.set(player.getUniqueId(),"tutorial-v16.hide.controls",true);player.sendMessage("§a총기 조작 안내를 더 이상 표시하지 않습니다.");}return true;});resetNicknames();}
 private void tip(Player player){if(p.profiles.get(player.getUniqueId()).getBoolean("tutorial-v16.hide.controls",false))return;player.sendMessage(net.kyori.adventure.text.Component.text("총기 조작: 좌클릭 = 발사 · 우클릭 = 줌/모드 전환 · R = 재장전 ",net.kyori.adventure.text.format.NamedTextColor.AQUA).append(net.kyori.adventure.text.Component.text("[더 이상 표시 안 함]",net.kyori.adventure.text.format.NamedTextColor.GRAY).clickEvent(net.kyori.adventure.text.event.ClickEvent.runCommand("/gunbedcore:gbhint"))));}
 @EventHandler public void start(BedwarsGameStartedEvent e){for(Player player:e.getGame().getConnectedPlayers())tip(player);}
 private void resetNicknames(){Path marker=p.getDataFolder().toPath().resolve("nickname-reset-v16.done");if(Files.exists(marker))return;try{Path backup=p.getDataFolder().toPath().resolve("backups/nickname-reset-v16");Files.createDirectories(backup);Path dir=p.getDataFolder().toPath().resolve("players");try(var files=Files.list(dir)){for(Path file:files.filter(f->f.getFileName().toString().endsWith(".yml")).toList()){UUID id=UUID.fromString(file.getFileName().toString().replace(".yml",""));Files.copy(file,backup.resolve(file.getFileName()),StandardCopyOption.REPLACE_EXISTING);p.profiles.set(id,"identity.nickname","");p.profiles.set(id,"identity.imported",true);}}var essentials=Bukkit.getPluginManager().getPlugin("Essentials");if(essentials!=null){Path users=essentials.getDataFolder().toPath().resolve("userdata");Path eb=backup.resolve("essentials");Files.createDirectories(eb);if(Files.isDirectory(users))try(var files=Files.list(users)){for(Path f:files.filter(n->n.toString().endsWith(".yml")).toList()){var y=org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(f.toFile());if(y.contains("nickname")){Files.copy(f,eb.resolve(f.getFileName()),StandardCopyOption.REPLACE_EXISTING);y.set("nickname",null);y.save(f.toFile());}}}}if(!p.profiles.saved())throw new IllegalStateException("Nickname reset profile writes failed");for(Player player:Bukkit.getOnlinePlayers()){if(essentials!=null)Bukkit.dispatchCommand(Bukkit.getConsoleSender(),"essentials:nick "+player.getName()+" off");player.displayName(TeamPalette.name(player));}Files.writeString(marker,"Reset Gunbed nickname values only; ownership, balances, stats and other backends preserved.\n");}catch(Exception e){throw new IllegalStateException("Nickname reset failed; backups retained",e);}}
}
