package kr.mzs.gunbed;

import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;

/** Original Gunbed armor health tiers, expressed in HP instead of Skript's hearts. */
final class MatchVitals {
    private MatchVitals(){}
    static void ensureBotArmor(Player player){
        if(!BotRuntime.bot(player)||player.isDead()||player.getGameMode()==org.bukkit.GameMode.SPECTATOR)return;
        var inv=player.getInventory();var armor=inv.getArmorContents();boolean changed=false;
        var types=new org.bukkit.Material[]{org.bukkit.Material.LEATHER_BOOTS,org.bukkit.Material.LEATHER_LEGGINGS,org.bukkit.Material.LEATHER_CHESTPLATE,org.bukkit.Material.LEATHER_HELMET};
        for(int n=0;n<armor.length;n++)if(armor[n]==null||armor[n].getType().isAir()){armor[n]=new org.bukkit.inventory.ItemStack(types[n]);changed=true;}
        if(changed){inv.setArmorContents(armor);armor(player,false);player.updateInventory();}
    }
    static void syncBotArmor(Player p){if(!BotRuntime.bot(p)||p.isDead())return;java.util.Map<org.bukkit.inventory.EquipmentSlot,org.bukkit.inventory.ItemStack> equipment=new java.util.EnumMap<>(org.bukkit.inventory.EquipmentSlot.class);for(var slot:java.util.List.of(org.bukkit.inventory.EquipmentSlot.HEAD,org.bukkit.inventory.EquipmentSlot.CHEST,org.bukkit.inventory.EquipmentSlot.LEGS,org.bukkit.inventory.EquipmentSlot.FEET))equipment.put(slot,p.getInventory().getItem(slot));for(Player viewer:p.getWorld().getPlayers())if(viewer!=p&&viewer.getLocation().distanceSquared(p.getLocation())<16384)viewer.sendEquipmentChange(p,equipment);}
    static void armor(Player player,boolean full){var palette=TeamPalette.of(player);var armor=player.getInventory().getArmorContents();for(int n=0;n<armor.length;n++){var item=armor[n];if(item==null||item.getType().isAir())continue;var meta=item.getItemMeta();var equipment=meta.getEquippable();equipment.setSlot(new org.bukkit.inventory.EquipmentSlot[]{org.bukkit.inventory.EquipmentSlot.FEET,org.bukkit.inventory.EquipmentSlot.LEGS,org.bukkit.inventory.EquipmentSlot.CHEST,org.bukkit.inventory.EquipmentSlot.HEAD}[n]);equipment.setModel(new org.bukkit.NamespacedKey("minecraft",n<2?switch(item.getType()){case CHAINMAIL_BOOTS,CHAINMAIL_LEGGINGS->"chainmail";case IRON_BOOTS,IRON_LEGGINGS->"iron";case DIAMOND_BOOTS,DIAMOND_LEGGINGS->"diamond";case NETHERITE_BOOTS,NETHERITE_LEGGINGS->"netherite";default->"leather";}:"leather"));if(n>=2)equipment.setModel(new org.bukkit.NamespacedKey("gunbed","churi_cloth"));meta.setEquippable(equipment);item.setItemMeta(meta);item.setData(io.papermc.paper.datacomponent.DataComponentTypes.DYED_COLOR,io.papermc.paper.datacomponent.item.DyedItemColor.dyedItemColor(org.bukkit.Color.fromRGB(palette.rgb())));armor[n]=item;}player.getInventory().setArmorContents(armor);var attribute=player.getAttribute(Attribute.MAX_HEALTH);if(attribute==null)return;double ratio=player.getHealth()/attribute.getValue();var leggings=player.getInventory().getLeggings();double maximum=leggings==null?10000:switch(leggings.getType()){case CHAINMAIL_LEGGINGS->11000;case IRON_LEGGINGS->13000;case DIAMOND_LEGGINGS,NETHERITE_LEGGINGS->15000;default->10000;};attribute.setBaseValue(maximum);player.setHealth(full?attribute.getValue():Math.max(.01,Math.min(attribute.getValue(),attribute.getValue()*ratio)));player.setHealthScaled(true);player.setHealthScale(20);syncBotArmor(player);}
}
