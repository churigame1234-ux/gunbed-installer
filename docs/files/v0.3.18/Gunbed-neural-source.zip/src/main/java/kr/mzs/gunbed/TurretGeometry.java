package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;

/** Raw supplied meshes use different forward axes. DisplayRenderer rotates Y by -entityYaw. */
final class TurretGeometry {
 static float offset(String kind){return switch(kind){case "siege"->90;case "slowness"->-90;default->180;};}
 static Vector axis(String kind){return switch(kind){case "siege"->new Vector(1,0,0);case "slowness"->new Vector(-1,0,0);default->new Vector(0,0,-1);};}
 static Vector forward(ItemDisplay model,String kind){return axis(kind).rotateAroundY(-Math.toRadians(model.getLocation().getYaw()));}
 static boolean aligned(ItemDisplay model,String kind,Location target){Vector d=target.toVector().subtract(model.getLocation().toVector()).setY(0);return d.lengthSquared()<.001||forward(model,kind).dot(d.normalize())>.985;}
 static float pitch(String kind,float desired){return kind.equals("burst")||kind.equals("healing")?-desired:0;}
 static Location muzzle(ItemDisplay model,String kind,float pitch){Vector tip=axis(kind).multiply(.76);tip.setY(kind.equals("healing")?.93:.91);if(kind.equals("burst")||kind.equals("healing")){tip.setY(tip.getY()-.55);tip.rotateAroundX(Math.toRadians(pitch(kind,pitch)));tip.setY(tip.getY()+.55);}return model.getLocation().clone().add(tip.rotateAroundY(-Math.toRadians(model.getLocation().getYaw())));}
}
