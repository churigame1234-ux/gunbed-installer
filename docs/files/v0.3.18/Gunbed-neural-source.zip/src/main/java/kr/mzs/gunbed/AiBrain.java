package kr.mzs.gunbed;

import kr.mzs.botcore.api.MzsBot;
import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.game.*;
import java.util.*;
import java.util.Comparator;

/** Local objective/cover controller using the normal shops, weapons and physics. */
final class AiBrain implements AutoCloseable {
    static final class State {final AiPlan.Memory plan=new AiPlan.Memory();final AiStrategy.Memory strategy=new AiStrategy.Memory();final AiCombat.Memory combat=new AiCombat.Memory();final Map<Location,Integer> avoided=new LinkedHashMap<>();boolean canPlan,wasActive;int progressTick,stuck;Location progressAt;double throwStrength=1;String reason="",pathReason="",throwKind="";AiPractice.Room room;MzsBot bot;int index,seenAt,target,nextPlan,nextBuild,nextShop,nextThrow,throwUntil,healUntil,mineUntil,nextJump,jumpAt,placed;Location goal,throwAim,bridgeOrigin;int bridgeCadence=5;Deque<Location> path=new ArrayDeque<>();Block mining;String action="idle",buildReason="";}
    private final GunbedCore plugin;private final BotRuntime runtime;private final Map<UUID,State> states=new LinkedHashMap<>();private int planner;private final AiCombat tactics;final AiStrategy strategy;final AiPerception senses;final AiPlan plans;final AiBedPlan beds;final AiTeamPlans teams;private final AiNeuralActions neuralActions;final AiAssault assault;
    AiBrain(GunbedCore p,BotRuntime r){plugin=p;runtime=r;tactics=new AiCombat(this,p,r);strategy=new AiStrategy(this,p,r);senses=new AiPerception(p,this);teams=new AiTeamPlans(p,this,r);plans=new AiPlan(p,this,r);beds=new AiBedPlan(p,this);neuralActions=new AiNeuralActions(p,this,r);assault=new AiAssault(p,this,r);}
    void add(AiPractice.Room room,MzsBot bot,int index){State s=new State();s.room=room;s.bot=bot;s.index=index;states.put(bot.getPlayer().getUniqueId(),s);}
    void remove(MzsBot bot){states.remove(bot.getPlayer().getUniqueId());}
    void placed(Player p){State s=states.get(p.getUniqueId());if(s!=null)s.placed++;}
    String action(Player p){State s=states.get(p.getUniqueId());return s==null?"none":s.action;}
    Map<String,Object> describe(Player p){State s=states.get(p.getUniqueId());if(s==null)return Map.of();Map<String,Object> out=new LinkedHashMap<>();out.put("duty",plans.duty(s).name());out.put("primaryFamily",s.plan.family);out.put("style",s.plan.style.name());out.put("life",s.plan.life);out.put("rescues",s.plan.rescues);out.put("placed",s.placed);out.put("strategy",s.strategy.phase);out.put("bedCover",strategy.defenseCount(s));out.put("defensePlaced",s.strategy.placedDefense);out.put("purchases",s.strategy.purchases);out.put("upgrades",s.strategy.upgrades);out.put("itemUses",s.strategy.uses);out.put("path",s.path.stream().limit(3).map(a->List.of(a.getX(),a.getY(),a.getZ())).toList());out.put("goal",s.goal==null?List.of():List.of(s.goal.getX(),s.goal.getY(),s.goal.getZ()));out.put("buildReason",s.buildReason);out.put("velocity",List.of(p.getVelocity().getX(),p.getVelocity().getY(),p.getVelocity().getZ()));out.put("ground",p.isOnGround());out.put("allowFlight",p.getAllowFlight());out.put("floor",p.getLocation().subtract(0,.2,0).getBlock().getType().name());return out;}
    List<State> all(){return List.copyOf(states.values());}
    void look(State s,Location at){runtime.look(s.bot,at);}
    void buildMove(State s,double x,double z){runtime.move(s.bot,x,z,false,false,true);}
    private LivingEntity enemy(State s){return senses.enemy(s);}
    private boolean nearShop(State s){Player p=s.bot.getPlayer();return s.room.game.getGameStores().stream().anyMatch(store->store.getStoreLocation().getWorld()==p.getWorld()&&store.getStoreLocation().distanceSquared(p.getLocation())<49);}
    private int woolSlot(Player p){ItemStack[] items=plugin.inventories.utility(p);for(int n=0;n<36;n++)if(items[n]!=null&&items[n].getType().name().endsWith("_WOOL")&&plugin.stacks.count(items[n])>0)return n;return -1;}
    long wool(Player p){return Arrays.stream(plugin.inventories.utility(p)).filter(Objects::nonNull).filter(i->i.getType().name().endsWith("_WOOL")).mapToLong(plugin.stacks::count).sum();}
    boolean utility(Player p,Material type){ItemStack[] items=plugin.inventories.utility(p);for(int n=0;n<36;n++)if(items[n]!=null&&items[n].getType()==type){plugin.inventories.mode(p,false);p.getInventory().setHeldItemSlot(n<9?n:0);if(n>=9){ItemStack old=p.getInventory().getItem(0);p.getInventory().setItem(0,items[n]);p.getInventory().setItem(n,old);}return true;}return false;}
    boolean utilityWool(Player p){for(ItemStack item:plugin.inventories.utility(p))if(item!=null&&item.getType().name().endsWith("_WOOL"))return utility(p,item.getType());return false;}
    private void pickup(Player p){
        // In-memory players do not receive client-driven item collision pickup ticks.
        // Dispatch the ordinary event; the wallet, locks and challenge rules remain authoritative.
        for(Entity entity:p.getNearbyEntities(1,.7,1))if(entity instanceof Item item&&item.isValid()&&item.getPickupDelay()<=0){
            var event=new org.bukkit.event.entity.EntityPickupItemEvent(p,item,0);Bukkit.getPluginManager().callEvent(event);
            if(!event.isCancelled()&&ResourceWallet.TYPES.contains(item.getItemStack().getType())){
                var overflow=p.getInventory().addItem(item.getItemStack());if(overflow.isEmpty())item.remove();
            }
        }
    }
    void tick(int tick){teams.tick(tick);List<State> all=List.copyOf(states.values());if(all.isEmpty())return;int planIndex=Math.floorMod(planner++,all.size());for(int n=0;n<all.size();n++){State s=all.get(n);s.canPlan=n==planIndex;Player p=s.bot.getPlayer();Game game=s.room.game;try{if(game.getStatus()!=GameStatus.RUNNING||!p.isOnline()||p.isDead()||p.getGameMode()==GameMode.SPECTATOR||game.getTeamOfPlayer(p)==null){runtime.stop(s.bot);if(s.wasActive){s.combat.wallPieces.clear();s.combat.wallBase=null;s.combat.clear();s.path.clear();s.progressAt=null;s.wasActive=false;s.throwUntil=0;plugin.throwables.cancel(p);s.strategy.consumeUntil=0;s.strategy.arrived=0;s.strategy.phase=s.strategy.openingDone?"ready":"opening";}continue;}if(!s.wasActive)plans.spawn(s,tick);s.wasActive=true;MatchVitals.ensureBotArmor(p);if(tick%40==(s.index*2)%40)MatchVitals.syncBotArmor(p);progress(s,tick);if(MatchVoid.below(p)){runtime.stop(s.bot);continue;}if(plans.gapActive(s,tick)||plans.rescue(s,tick))continue;if(p.getY()<Math.min(game.getPos1().getY(),game.getPos2().getY())-1){runtime.stop(s.bot);p.setNoDamageTicks(0);p.damage(p.getHealth()+p.getAbsorptionAmount()+1000,org.bukkit.damage.DamageSource.builder(org.bukkit.damage.DamageType.OUT_OF_WORLD).build());continue;}if(plugin.arsenal.pending(p)){plugin.arsenal.botLoadout(p,s.index%3==0?"ta:ak47":s.index%3==1?"cs:AK-47":"ta:m4a1");s.path.clear();continue;}if(plugin.inventories.locked(p)){runtime.stop(s.bot);continue;}MatchVitals.ensureBotArmor(p);pickup(p);strategy.refresh(s,tick);strategy.shop(s,tick);
        LivingEntity foe=enemy(s);if(tactics.blockWall(s,tick))continue;if(s.throwUntil>0&&tactics.throwing(s,foe,tick))continue;if(strategy.consume(s,foe,tick))continue;if(teams.respond(s,tick))continue;if(plans.before(s,foe,tick))continue;
        if(assault.exposed(s,foe,tick))continue;if(plans.stealth(s,foe,tick))continue;if(assault.tick(s,foe,tick))continue;
        if(strategy.urgent(s,foe,tick))continue;if(neuralActions.act(s,foe,tick))continue;if(plans.bow(s,foe,tick))continue;if(strategy.combatUtility(s,foe,tick))continue;
        if(foe!=null){if(s.target!=foe.getEntityId()){s.target=foe.getEntityId();s.seenAt=tick;}double distance=p.getLocation().distance(foe.getLocation());if(distance<=AiGuns.reach(plugin,p,AiGuns.slot(plugin,p,0))){if(tick-s.seenAt<AiPractice.Difficulty.HARD.reaction){runtime.stop(s.bot);look(s,foe.getEyeLocation());s.action="observe";s.reason="keep-visible-contact-during-reaction-delay";continue;}tactics.fight(s,foe,tick);continue;}}else{if(tactics.breakCover(s,tick)||tactics.search(s,tick))continue;s.target=0;plugin.taWeapons.input(p,false,false);if(plugin.visuals!=null)plugin.visuals.input(p,false,false,false);}
        strategy.objective(s,tick);plans.scan(s,tick);
    }finally{diagnose(s,tick);}}}
    void navigate(State s,Location target,int tick,boolean bridge,boolean jump){
        Player p=s.bot.getPlayer();if(jump&&plans.gap(s,target,tick))return;if(s.goal==null||s.goal.getWorld()!=target.getWorld()||s.goal.distanceSquared(target)>4){s.path.clear();s.nextPlan=0;}
        var foot=p.getLocation().clone();foot.setY(Math.ceil(p.getY()-.05)-1);if(p.isOnGround()&&foot.getBlock().getType().isSolid()&&!s.room.game.getRegion().isBlockAddedDuringGame(foot.getBlock().getLocation())){s.bridgeOrigin=p.getLocation().clone();s.bridgeCadence=plugin.learning.bridgeCadence();}
        if(s.canPlan&&(tick>=s.nextPlan||s.goal==null)){s.path=new ArrayDeque<>(AiNavigation.path(s.room.game,p.getLocation(),target,bridge,jump,plugin.learning,p,s.avoided.keySet(),s.bridgeOrigin,s.bridgeCadence));s.goal=target.clone();s.nextPlan=tick+30;if(s.path.isEmpty()&&p.getLocation().distanceSquared(target)>2){s.pathReason="no-safe-path";s.avoided.put(target.getBlock().getLocation(),tick+80);if(s.combat.cover!=null&&s.combat.cover.distanceSquared(target)<1)s.combat.cover=null;plugin.learning.telemetry.blocked(p,s.pathReason,target);}}
        follow(s,tick);
    }
    private void progress(State s,int tick){
        Player p=s.bot.getPlayer();s.avoided.entrySet().removeIf(e->e.getValue()<tick);
        if(s.progressAt==null||s.progressAt.getWorld()!=p.getWorld()||s.progressAt.distanceSquared(p.getLocation())>.12){s.progressAt=p.getLocation();s.progressTick=tick;return;}
        if(s.path.isEmpty()||Set.of("fire","secondary","melee","reload","healing","heal","mine","throw").contains(s.action)){s.progressTick=tick;return;}
        if(tick-s.progressTick>=40){Location blocked=s.path.peekFirst().getBlock().getLocation();s.avoided.put(blocked,tick+200);while(s.avoided.size()>24)s.avoided.remove(s.avoided.keySet().iterator().next());s.stuck++;s.pathReason="no-progress-replan";plugin.learning.telemetry.blocked(p,s.pathReason,blocked);s.path.clear();s.nextPlan=0;s.progressTick=tick;}
    }
    private void diagnose(State s,int tick){
        Player p=s.bot.getPlayer();if(!p.isOnline()||s.room.game.getStatus()!=GameStatus.RUNNING)return;var previous=plugin.learning.telemetry.stats(p);if(tick%10!=0&&s.action.equals(previous.decision)&&s.reason.equals(previous.reason))return;
        AiGuns.Gun gun=AiGuns.held(plugin,p);Map<String,Object> data=new LinkedHashMap<>();data.put("style",s.plan.style.name());data.put("rescues",s.plan.rescues);data.put("strategy",s.strategy.phase);data.put("bedCover",strategy.defenseCount(s));data.put("defensePlaced",s.strategy.placedDefense);data.put("purchases",s.strategy.purchases);data.put("upgrades",s.strategy.upgrades);data.put("itemUses",s.strategy.uses);data.put("resources",plugin.wallet.snapshot(p));data.put("weapon",gun.id());data.put("loaded",gun.loaded());data.put("reserve",gun.reserve());data.put("reload",AiGuns.reloading(plugin,p));data.put("reloadProgress",AiGuns.progress(plugin,p));data.put("target",s.combat.target==null?"":s.combat.target.toString());data.put("targetVisible",s.combat.seenTick==tick);data.put("lastSeenAgeTicks",s.combat.lastSeen==null?-1:tick-s.combat.seenTick);data.put("goal",s.goal==null?List.of():List.of(s.goal.getX(),s.goal.getY(),s.goal.getZ()));data.put("pathNodes",s.path.size());data.put("pathReason",s.pathReason);data.put("buildReason",s.buildReason);data.put("stuckRecoveries",s.stuck);data.put("motion",s.combat.motion==null?"none":s.combat.motion.name());plugin.learning.telemetry.decision(p,tick,s.action,s.reason,data);
    }
    void slot(Player p,int slot){int old=p.getInventory().getHeldItemSlot();if(old==slot)return;var event=new org.bukkit.event.player.PlayerItemHeldEvent(p,old,slot);Bukkit.getPluginManager().callEvent(event);if(!event.isCancelled())p.getInventory().setHeldItemSlot(slot);}
    private void follow(State s,int tick){Player p=s.bot.getPlayer();while(!s.path.isEmpty()){Location at=s.path.peekFirst();boolean supported=at.getBlock().getRelative(0,-1,0).getType().isSolid();if(supported&&Math.abs(p.getY()-at.getY())<1.1&&p.getLocation().toVector().subtract(at.toVector()).setY(0).lengthSquared()<.16)s.path.removeFirst();else break;}if(s.path.isEmpty()){runtime.stop(s.bot);return;}Location next=s.path.peekFirst();Block floor=next.getBlock().getRelative(0,-1,0);if(!floor.getType().isSolid()){if(woolSlot(p)<0){runtime.stop(s.bot);s.nextPlan=0;return;}s.action="bridge";bridge(s,floor,tick);return;}Vector move=next.toVector().subtract(p.getLocation().toVector()).setY(0);
        if(s.jumpAt>0&&tick>=s.jumpAt){s.jumpAt=0;if(!p.isOnGround()&&p.getAllowFlight())Bukkit.getPluginManager().callEvent(new org.bukkit.event.player.PlayerToggleFlightEvent(p,true));}
        if(move.lengthSquared()>3.3&&move.lengthSquared()<11&&p.isOnGround()&&tick>=s.nextJump){Vector direction=move.clone().normalize();boolean gap=p.getLocation().add(direction.clone().multiply(.9)).getBlock().getRelative(0,-1,0).getType().isAir();if(gap){runtime.look(s.bot,next.clone().add(0,1.3,0));runtime.move(s.bot,move.getX(),move.getZ(),true,true,false);s.jumpAt=tick+4;s.nextJump=tick+60;return;}}
        runtime.look(s.bot,next.clone().add(0,1.3,0));runtime.move(s.bot,move.getX(),move.getZ(),next.getY()>p.getY()+.35,true,false);}
    private void bridge(State s,Block floor,int tick){
        Player p=s.bot.getPlayer();
        if(floor.getY()>=Math.ceil(p.getY()-.05)&&floor.getY()<=Math.ceil(p.getY()-.05)+1){Block below=floor.getRelative(BlockFace.DOWN);if(!below.getType().isSolid()){bridge(s,below,tick);return;}if(tick<s.nextBuild)return;if(p.getBoundingBox().overlaps(new org.bukkit.util.BoundingBox(floor.getX(),floor.getY(),floor.getZ(),floor.getX()+1,floor.getY()+1,floor.getZ()+1))){Location back=null;for(BlockFace side:List.of(BlockFace.NORTH,BlockFace.SOUTH,BlockFace.EAST,BlockFace.WEST)){Location at=floor.getRelative(side).getLocation().add(.5,0,.5);if(AiTerrain.floor(at)&&(back==null||at.distanceSquared(p.getLocation())<back.distanceSquared(p.getLocation())))back=at;}if(back!=null){runtime.move(s.bot,back.getX()-p.getX(),back.getZ()-p.getZ(),false,false,true);s.buildReason="make-room-for-stair-top";return;}}if(!p.getBoundingBox().overlaps(new org.bukkit.util.BoundingBox(floor.getX(),floor.getY(),floor.getZ(),floor.getX()+1,floor.getY()+1,floor.getZ()+1))&&utilityWool(p)){runtime.stop(s.bot);runtime.look(s.bot,below.getLocation().add(.5,1,.5));boolean placed=runtime.useBlock(s.bot,below,BlockFace.UP);s.nextBuild=tick+AiPractice.Difficulty.HARD.build;s.buildReason="stair-top="+placed;if(placed)plugin.learning.telemetry.record(p,"bridge-step",Map.of("rise",1,"cadence",s.bridgeCadence));return;}}
        List<BlockFace> faces=new ArrayList<>(List.of(BlockFace.EAST,BlockFace.WEST,BlockFace.NORTH,BlockFace.SOUTH));
        faces.removeIf(face->!floor.getRelative(face.getOppositeFace()).getType().isSolid());
        faces.sort(Comparator.comparingDouble(face->floor.getRelative(face.getOppositeFace()).getLocation().add(.5,1,.5).distanceSquared(p.getLocation())));
        for(BlockFace face:faces){
            Block support=floor.getRelative(face.getOppositeFace());
            if(p.getY()<floor.getY()+.9&&p.isOnGround()){s.bot.setMovementInput(0,0,true,false,true);return;}
            double dx=face.getModX(),dz=face.getModZ();
            double ox=p.getX()-support.getX()-.5,oz=p.getZ()-support.getZ()-.5;
            double along=ox*dx+oz*dz,across=ox*(-dz)+oz*dx;
            s.buildReason="edge "+Math.round(along*100)+"/"+Math.round(across*100);
            // Align on the supporting block first, then expose the real side face.
            // Being merely close to the edge is insufficient: the top face still
            // blocks the ray until the player's centre passes that side plane.
            if(Math.abs(across)>.18){runtime.move(s.bot,dz*across,-dx*across,false,false,true);return;}
            if(along<.515){runtime.move(s.bot,dx,dz,false,false,true);return;}
            if(along>.72){runtime.move(s.bot,-dx,-dz,false,false,true);return;}
            s.bot.setMovementInput(0,0,false,false,true);p.setSneaking(true);
            if(tick<s.nextBuild)return;
            int slot=woolSlot(p);if(slot<0)return;plugin.inventories.mode(p,false);
            if(slot>=9){ItemStack item=p.getInventory().getItem(slot),old=p.getInventory().getItem(4);p.getInventory().setItem(4,item);p.getInventory().setItem(slot,old);slot=4;}
            p.getInventory().setHeldItemSlot(slot);
            Location hit=new Location(support.getWorld(),support.getX()+.5+dx*.499,(support.getBoundingBox().getMinY()+support.getBoundingBox().getMaxY())/2,support.getZ()+.5+dz*.499);
            runtime.look(s.bot,hit);
            boolean placed=runtime.useBlock(s.bot,support,face);
            s.buildReason="place="+placed+" at "+floor.getX()+","+floor.getY()+","+floor.getZ();
            s.nextBuild=tick+AiPractice.Difficulty.HARD.build;return;
        }
        s.buildReason="no adjacent support";runtime.stop(s.bot);s.nextPlan=0;
    }
    private boolean defend(State s,int tick){Player p=s.bot.getPlayer();Location bed=s.room.game.getTeamOfPlayer(p).getTargetBlock();List<Block> candidates=new ArrayList<>(plugin.learning.defense(s.room.game,p));for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)if(Math.abs(x)+Math.abs(z)<=1)candidates.add(bed.getBlock().getRelative(x,0,z));candidates.add(bed.getBlock().getRelative(0,1,0));for(Block target:candidates){if(!target.getType().isAir()||!s.room.game.isLocationInArena(target.getLocation())||p.getBoundingBox().overlaps(target.getBoundingBox()))continue;Block support=target.getRelative(BlockFace.DOWN);if(!support.getType().isSolid()||p.getEyeLocation().distanceSquared(support.getLocation().add(.5,1,.5))>19)continue;if(tick<s.nextBuild)return false;int slot=woolSlot(p);if(slot<0)return false;plugin.inventories.mode(p,false);if(slot>=9){ItemStack item=p.getInventory().getItem(slot),old=p.getInventory().getItem(4);p.getInventory().setItem(4,item);p.getInventory().setItem(slot,old);slot=4;}p.getInventory().setHeldItemSlot(slot);runtime.look(s.bot,support.getLocation().add(.5,1,.5));runtime.stop(s.bot);if(runtime.useBlock(s.bot,support,BlockFace.UP)){s.nextBuild=tick+AiPractice.Difficulty.HARD.build;s.action="defend";return true;}}return false;}
    boolean mine(State s,Location bed,int tick){Player p=s.bot.getPlayer();plugin.inventories.mode(p,false);runtime.look(s.bot,bed.clone().add(0,.3,0));Block hit=p.getTargetBlockExact(4);if(hit==null)return false;boolean placed=s.room.game.getRegion().isBlockAddedDuringGame(hit.getLocation()),target=hit.getBlockData() instanceof org.bukkit.block.data.type.Bed;if(!placed&&!target)return false;String name=hit.getType().name(),tool=name.endsWith("_WOOL")?"SHEARS":name.contains("PLANK")||name.contains("LOG")?"_AXE":"_PICKAXE";ItemStack best=Arrays.stream(plugin.inventories.utility(p)).filter(Objects::nonNull).filter(i->tool.equals("SHEARS")?i.getType()==Material.SHEARS:i.getType().name().endsWith(tool)).max(Comparator.comparingInt(i->i.getType().name().startsWith("DIAMOND")?4:i.getType().name().startsWith("IRON")?3:i.getType().name().startsWith("STONE")?2:1)).orElse(null);if(best!=null)utility(p,best.getType());int duration=target?12:name.endsWith("_WOOL")?(best==null?24:8):name.equals("OBSIDIAN")?(best!=null&&best.getType()==Material.DIAMOND_PICKAXE?180:1200):name.equals("END_STONE")?(best==null?100:60):name.contains("PLANK")?(best==null?80:35):30;
        if(s.mining==null||!s.mining.equals(hit)){s.mining=hit;s.mineUntil=tick+duration;}runtime.stop(s.bot);s.action="mine";s.reason="use-"+(best==null?"hand":best.getType().name().toLowerCase(Locale.ROOT));p.swingMainHand();if(tick>=s.mineUntil){LegacyActions.recordBlock(hit);p.breakBlock(hit);s.mining=null;s.nextPlan=0;}return true;
    }
    @Override public void close(){for(State s:states.values())runtime.stop(s.bot);states.clear();}
}
