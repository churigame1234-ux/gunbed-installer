package kr.mzs.gunbed;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/** Normal server shutdown replaces the old script's forced unloading of individual plugins. */
final class DailyRestart {
    private final GunbedCore plugin;
    private final File stateFile;
    private final YamlConfiguration state;
    private String warnedDate = "";

    DailyRestart(GunbedCore plugin) {
        this.plugin = plugin;
        stateFile = new File(plugin.getDataFolder(), "restart-state.yml");
        state = YamlConfiguration.loadConfiguration(stateFile);
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20, 20);
    }

    private void tick() {
        if (!plugin.getConfig().getBoolean("daily-restart.enabled", true)) return;
        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Asia/Seoul"));
        LocalTime target = LocalTime.parse(plugin.getConfig().getString("daily-restart.time", "06:00"));
        String date = now.toLocalDate().toString();
        if (now.toLocalTime().isAfter(target.minusMinutes(5)) && now.toLocalTime().isBefore(target) && !warnedDate.equals(date)) {
            warnedDate = date;
            Bukkit.broadcastMessage("§e[Gunbed] 매일 오전 6시 정기 재시작이 곧 진행됩니다.");
        }
        if (!now.toLocalTime().isBefore(target) && now.toLocalTime().isBefore(target.plusMinutes(1))
                && !state.getString("last-date", "").equals(date)) {
            state.set("last-date", date);
            try { state.save(stateFile); }
            catch (java.io.IOException ex) { plugin.getLogger().severe("Restart state could not be saved; restart skipped."); return; }
            Bukkit.broadcastMessage("§e[Gunbed] 정기 재시작 중입니다. 잠시 후 다시 접속해 주세요.");
            Bukkit.shutdown();
        }
    }
}
