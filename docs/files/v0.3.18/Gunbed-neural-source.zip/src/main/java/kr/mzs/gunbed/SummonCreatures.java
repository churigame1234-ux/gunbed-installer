package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.*;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.game.*;
import java.util.*;

/** Round-owned summons with proportional attacks and a five-minute declining health ceiling. */
final class SummonCreatures implements Listener {
    private record Owned(Mob mob,Game game,UUID owner,String team,int born,double health,double damage){}
    static final NamespacedKey OWNER=new NamespacedKey("gunbedcore","summon_owner");
    private final List<Owned> mobs=new ArrayList<>();private final GunbedCore plugin;
    private final Map<UUID,Integer> nextTurretHit=new HashMap<>();
    String team(Entity e){return mobs.stream().filter(o->o.mob==e).map(Owned::team).findFirst().orElse(null);}
    private boolean reachable(Owned o,LivingEntity target){if(target.getWorld()!=o.mob.getWorld()||target.getLocation().distanceSquared(o.mob.getLocation())>2304)return false;if(target.getLocation().distanceSquared(o.mob.getLocation())<6.25&&o.mob.hasLineOfSight(target))return true;var path=o.mob.getPathfinder().findPath(target.getLocation());return path!=null&&path.canReachFinalPoint();}
    SummonCreatures(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,10);}
    void spawn(Player p,Game game,Location at,boolean golem){
        Mob mob=golem?at.getWorld().spawn(at,IronGolem.class):at.getWorld().spawn(at,Silverfish.class);double hp=golem?20000:5000;
        mob.getAttribute(Attribute.MAX_HEALTH).setBaseValue(hp);mob.setHealth(hp);mob.getAttribute(Attribute.FOLLOW_RANGE).setBaseValue(48);
        mob.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,6000,2,false,false));mob.setPersistent(false);mob.setCollidable(false);
        mob.getPersistentDataContainer().set(OWNER,PersistentDataType.STRING,p.getUniqueId().toString());
        if(mob instanceof IronGolem iron)iron.setPlayerCreated(true);
        BedwarsAPI.getInstance().registerEntityToGame(mob,game);mobs.add(new Owned(mob,game,p.getUniqueId(),game.getTeamOfPlayer(p).getName(),Bukkit.getCurrentTick(),hp,golem?1500:500));
    }
    private boolean enemy(Owned o,Player p){var team=o.game.getTeamOfPlayer(p);return team!=null&&!team.getName().equals(o.team)&&!p.isDead()&&p.getGameMode()!=GameMode.SPECTATOR&&p.getWorld()==o.mob.getWorld();}
    private void tick(){int now=Bukkit.getCurrentTick();for(var it=mobs.iterator();it.hasNext();){Owned o=it.next();int age=now-o.born;
        if(!o.mob.isValid()||o.mob.isDead()||o.game.getStatus()!=GameStatus.RUNNING||age>=6000){if(o.mob.isValid()){o.mob.getWorld().spawnParticle(Particle.POOF,o.mob.getLocation().add(0,.5,0),12,.4,.4,.4,.01);o.mob.remove();}it.remove();continue;}
        double cap=o.health*(1-.9*Math.min(1,age/6000.0));o.mob.getAttribute(Attribute.MAX_HEALTH).setBaseValue(cap);if(o.mob.getHealth()>cap)o.mob.setHealth(cap);
        LivingEntity target=o.game.getConnectedPlayers().stream().filter(p->enemy(o,p)&&reachable(o,p)).min(Comparator.comparingDouble(p->p.getLocation().distanceSquared(o.mob.getLocation()))).orElse(null);
        if(target==null&&plugin.turrets!=null)target=plugin.turrets.bodies(o.game).stream().filter(t->!o.team.equals(plugin.turrets.team(t))&&reachable(o,t)).min(Comparator.comparingDouble(t->t.getLocation().distanceSquared(o.mob.getLocation()))).orElse(null);
        o.mob.setTarget(target);if(target instanceof ArmorStand&&target.getLocation().distanceSquared(o.mob.getLocation())<7&&o.mob.hasLineOfSight(target)&&now>=nextTurretHit.getOrDefault(o.mob.getUniqueId(),0)){Player owner=Bukkit.getPlayer(o.owner);if(owner!=null){nextTurretHit.put(o.mob.getUniqueId(),now+(o.mob instanceof IronGolem?20:10));o.mob.swingMainHand();plugin.turrets.damage(target,owner,plugin.damages.value(o.mob instanceof IronGolem?"summons.golem":"summons.silverfish",o.damage));}}
    }}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void target(EntityTargetLivingEntityEvent e){Owned o=mobs.stream().filter(m->m.mob==e.getEntity()).findFirst().orElse(null);if(o!=null&&e.getTarget()!=null){String team=BattleTargets.team(plugin,o.game,e.getTarget());if(e.getTarget() instanceof EnderDragon||team==null||team.equals(o.team)||!(e.getTarget() instanceof Player||e.getTarget() instanceof ArmorStand))e.setCancelled(true);}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void hit(EntityDamageByEntityEvent e){Owned o=mobs.stream().filter(m->m.mob==e.getDamager()).findFirst().orElse(null);if(o==null)return;if(!(e.getEntity() instanceof Player p)||!enemy(o,p)){e.setCancelled(true);return;}e.setDamage(plugin.damages.value(o.mob instanceof IronGolem?"summons.golem":"summons.silverfish",o.damage));}
    @EventHandler public void death(EntityDeathEvent e){if(e.getEntity().getPersistentDataContainer().has(OWNER)){e.getDrops().clear();e.setDroppedExp(0);}}
}
