package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.Team;
import org.screamingsandals.bedwars.api.game.Game;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;

/** Exact RGB values from churi's colour-preview configuration. */
final class TeamPalette {
    record Entry(String name,int rgb,DyeColor dye) {
        Component text(String value){return Component.text(value,TextColor.color(rgb));}
        String legacy(){String h=String.format("%06x",rgb);StringBuilder s=new StringBuilder("§x");for(char c:h.toCharArray())s.append('§').append(c);return s.toString();}
    }
    private static final Entry RED=new Entry("빨강",0xF40404,DyeColor.RED),BLUE=new Entry("파랑",0x0C48CC,DyeColor.LIGHT_BLUE),GREEN=new Entry("연두",0x2CB494,DyeColor.LIME),PURPLE=new Entry("보라",0x88409C,DyeColor.PINK),ORANGE=new Entry("주황",0xF88C14,DyeColor.CYAN),BROWN=new Entry("갈색",0x703014,DyeColor.GRAY),WHITE=new Entry("하양",0xCCE0D0,DyeColor.WHITE),YELLOW=new Entry("노랑",0xFCFC38,DyeColor.YELLOW);
    static Entry of(Game game,Team team){if(team==null)return WHITE;return switch(team.getColor().name()){
        case "RED"->RED;case "BLUE"->BLUE;case "LIGHT_BLUE"->BLUE;
        case "GREEN","LIME","LIGHT_GREEN"->GREEN;case "PINK","MAGENTA","PURPLE"->PURPLE;case "CYAN","ORANGE"->ORANGE;case "BROWN","GRAY","LIGHT_GRAY","BLACK"->BROWN;case "YELLOW"->YELLOW;default->WHITE;};}
    static Entry of(Player player){Game g=BedwarsAPI.getInstance().getGameOfPlayer(player);Team team=g==null?null:g.getTeamOfPlayer(player);var core=org.bukkit.plugin.java.JavaPlugin.getPlugin(GunbedCore.class);if(team==null&&core.roundChat!=null)team=core.roundChat.originalTeam(player);return of(g,team);}
    static String display(Player player){var core=org.bukkit.plugin.java.JavaPlugin.getPlugin(GunbedCore.class);String nick=core.profiles.get(player.getUniqueId()).getString("identity.nickname","");return nick.isBlank()?player.getName():nick;}
    static Component name(Player player){return of(player).text(display(player));}
}
