package kr.mzs.gunbed;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.File;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/** Owned settings/favourites only; legacy account balances are never replaced. */
final class PlayerProfiles implements AutoCloseable {
    private final File directory;
    private final Map<UUID,YamlConfiguration> profiles=new HashMap<>();
    private final Set<UUID> dirty=new HashSet<>();
    private final Queue<UUID> failed=new ConcurrentLinkedQueue<>();
    private final ExecutorService writer=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"Gunbed profile writer");t.setDaemon(true);return t;});
    private final JavaPlugin plugin;
    PlayerProfiles(JavaPlugin plugin){this.plugin=plugin;directory=new File(plugin.getDataFolder(),"players");directory.mkdirs();plugin.getServer().getScheduler().runTaskTimer(plugin,this::flush,100,100);}
    YamlConfiguration get(UUID id){return profiles.computeIfAbsent(id,u->YamlConfiguration.loadConfiguration(new File(directory,u+".yml")));}
    void set(UUID id,String key,Object value){get(id).set(key,value);dirty.add(id);}
    boolean saved(){flush();try{writer.submit(()->{}).get(5,TimeUnit.SECONDS);return failed.isEmpty();}catch(Exception e){plugin.getLogger().severe("Could not finish profile write: "+e.getMessage());return false;}}
    void flush(){for(UUID id;(id=failed.poll())!=null;)dirty.add(id);for(UUID id:Set.copyOf(dirty)){
        String text=get(id).saveToString();dirty.remove(id);
        writer.submit(()->{try{Path target=new File(directory,id+".yml").toPath(),temporary=target.resolveSibling(id+".tmp");Files.writeString(temporary,text);try{Files.move(temporary,target,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(temporary,target,StandardCopyOption.REPLACE_EXISTING);}}catch(Exception e){failed.add(id);plugin.getLogger().severe("Could not save profile "+id+": "+e.getMessage());}});
    }}
    @Override public void close(){flush();writer.shutdown();try{if(!writer.awaitTermination(5,TimeUnit.SECONDS))plugin.getLogger().warning("Profile writes are still finishing.");}catch(InterruptedException e){Thread.currentThread().interrupt();}}
}
