package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.RunningTeam;
import java.util.*;

/** Paid, observable multi-step assaults; cooperative failure does not silently erase the objective. */
final class AiAssault {
    static final class Memory {int started,blastAt,until,choice,hookAt;Location perch,landing;boolean failedPartner;}
    private final GunbedCore plugin;private final AiBrain brain;private final BotRuntime runtime;
    private final Map<UUID,Memory> memories=new HashMap<>();
    AiAssault(GunbedCore p,AiBrain b,BotRuntime r){plugin=p;brain=b;runtime=r;}
    private void stopFire(Player p){plugin.taWeapons.input(p,false,false);plugin.addonMelee.input(p,false);if(plugin.visuals!=null)plugin.visuals.input(p,false,false,false);}
    private RunningTeam enemy(AiBrain.State s){var own=s.room.game.getTeamOfPlayer(s.bot.getPlayer());return s.room.game.getRunningTeams().stream().filter(t->t!=own&&t.isAlive()).findFirst().orElse(null);}
    void spawned(Player p){memories.remove(p.getUniqueId());}
    boolean tick(AiBrain.State s,LivingEntity foe,int tick){Player p=s.bot.getPlayer();RunningTeam target=enemy(s);if(target==null||!target.isTargetBlockExists()||!s.strategy.openingDone)return false;Memory m=memories.computeIfAbsent(p.getUniqueId(),id->new Memory());if(m.started==0){m.started=tick;m.choice=Math.floorMod(s.index+s.plan.life,6);}var tactic=brain.teams.tactic(s);
        if(m.blastAt>0){stopFire(p);if(tick<m.blastAt-12){if(m.perch!=null&&p.getLocation().distanceSquared(m.perch)>1)brain.navigate(s,m.perch,tick,true,false);else runtime.stop(s.bot);s.action="tnt-wait";s.reason="time-descent-to-native-three-second-fuse";return true;}if(tick<m.blastAt+25){Vector down=target.getTargetBlock().toVector().add(new Vector(.5,0,.5)).subtract(p.getLocation().toVector()).setY(0);if(down.lengthSquared()>.1)down.normalize();runtime.look(s.bot,target.getTargetBlock());runtime.move(s.bot,down.getX(),down.getZ(),false,true,false);if(tick>=m.blastAt&&p.getEyeLocation().distanceSquared(target.getTargetBlock())<25)brain.mine(s,target.getTargetBlock(),tick);s.action="tnt-descent";s.reason="descend-as-defense-blocks-disappear";return true;}m.blastAt=0;}
        if((tactic==AiTeamPlans.Tactic.TNT||tactic==AiTeamPlans.Tactic.GLASS_TNT)&&brain.strategy.count(p,Material.TNT)>0&&p.getLocation().distanceSquared(target.getTargetBlock())<625){
            // Only inspect glass already exposed to this bot; don't scan a hidden defence interior.
            Block glass=visibleGlass(s,target);if(glass!=null){boolean partner=brain.teams.hasPartner(s,target.getTargetBlock(),20);if(brain.teams.glassBreaker(s)||!partner&&m.choice<3){stopFire(p);if(p.getEyeLocation().distanceSquared(glass.getLocation().add(.5,.5,.5))<20)return brain.mine(s,glass.getLocation(),tick);brain.strategy.travel(s,glass.getLocation(),tick,"glass-break","open-visible-glass-for-tnt-partner");return true;}if(partner){stopFire(p);runtime.stop(s.bot);s.action="tnt-glass-wait";s.reason="partner-must-open-visible-glass-before-tnt";return true;}m.failedPartner=true;if(m.choice<3)return false;s.reason="partner-lost-risky-tnt-at-visible-weak-side";}
            if(m.perch==null)m.perch=perch(s,target);if(m.perch==null)return false;stopFire(p);
            if(p.getLocation().distanceSquared(m.perch)>4){brain.strategy.travel(s,m.perch,tick,"tnt-approach","ascending-wool-cover-to-bed-overhead");return true;}
            if(s.room.bots.size()>1&&!brain.teams.hasPartner(s,target.getTargetBlock(),24)&&tick-m.started<240&&!m.failedPartner){runtime.stop(s.bot);s.action="tnt-rally";s.reason="wait-for-tool-or-glass-breaking-partner";return true;}
            for(BlockFace side:List.of(BlockFace.NORTH,BlockFace.SOUTH,BlockFace.EAST,BlockFace.WEST)){Block spot=p.getLocation().getBlock().getRelative(side);if(spot.getLocation().distanceSquared(target.getTargetBlock())>90)continue;if(spot.getRelative(BlockFace.DOWN).isPassable()&&brain.strategy.place(s,spot.getRelative(BlockFace.DOWN),null,tick))return true;if(brain.strategy.place(s,spot,Material.TNT,tick)){m.blastAt=tick+60;s.strategy.blastUntil=0;brain.strategy.used(s,"coordinated-overhead-tnt",tick);return true;}}
        }
        if(tactic==AiTeamPlans.Tactic.HOOK&&tick>=m.hookAt&&brain.strategy.count(p,Material.FISHING_ROD)>0&&p.getLocation().distanceSquared(target.getTeamSpawn())<1024&&p.getLocation().distanceSquared(target.getTeamSpawn())>36){Location at=target.getTeamSpawn();if(AiTerrain.visible(p.getEyeLocation(),at.clone().add(0,1,0))){stopFire(p);if(brain.utility(p,Material.FISHING_ROD)){runtime.look(s.bot,at);runtime.right(s.bot);m.hookAt=tick+12;s.action="hook-approach";s.reason="native-throw-and-reel-toward-observed-ground";return true;}}}
        return false;
    }
    private Block visibleGlass(AiBrain.State s,RunningTeam target){Player p=s.bot.getPlayer();if(target.getTargetBlock().distanceSquared(p.getLocation())>900)return null;Block bed=target.getTargetBlock().getBlock();for(int y=0;y<=4;y++)for(int x=-3;x<=3;x++)for(int z=-3;z<=3;z++){Block b=bed.getRelative(x,y,z);if(!b.getType().name().contains("GLASS"))continue;Vector ray=b.getLocation().add(.5,.5,.5).toVector().subtract(p.getEyeLocation().toVector());var hit=p.getWorld().rayTraceBlocks(p.getEyeLocation(),ray.clone().normalize(),ray.length()+.01,FluidCollisionMode.NEVER,true);if(hit!=null&&b.equals(hit.getHitBlock()))return b;}return null;}
    private Location perch(AiBrain.State s,RunningTeam target){Location bed=target.getTargetBlock();for(int y=4;y<=6;y++)for(int x:new int[]{-1,1}){Location at=bed.clone().add(x+.5,y,.5);if(s.room.game.isLocationInArena(at)&&at.getBlock().isPassable()&&at.clone().add(0,1,0).getBlock().isPassable())return at;}return null;}
    boolean exposed(AiBrain.State s,LivingEntity foe,int tick){Player p=s.bot.getPlayer();if(foe==null||!p.isInvisible()||!plugin.learning.telemetry.pressured(p,tick))return false;Memory m=memories.computeIfAbsent(p.getUniqueId(),id->new Memory());RunningTeam target=enemy(s);if(target==null)return false;
        // Stable per-encounter choices avoid changing behaviour every tick.
        if(tick>=m.until){m.until=tick+100;m.choice=Math.floorMod(tick/100+s.index+s.plan.life,6);}
        if(m.choice==0)return false; // continue mining, including accepting risk
        if(m.choice==1){stopFire(p);plugin.inventories.mode(p,true);brain.slot(p,2);runtime.look(s.bot,foe.getEyeLocation());if(plugin.addonMelee.held(p)!=null)plugin.addonMelee.input(p,true);else if(plugin.visuals!=null)plugin.visuals.input(p,true,false,false);s.action="exposed-melee";s.reason="fight-or-knock-off-during-infiltration";return true;}
        if(m.choice==2)return false; // existing stealth block-in handles placement and mining
        if(m.choice==3&&p.hasPotionEffect(org.bukkit.potion.PotionEffectType.JUMP_BOOST)){Location high=p.getLocation().clone().add(0,3,0);brain.navigate(s,high,tick,brain.wool(p)>0,true);s.action="infiltration-high-ground";s.reason="jump-potion-and-wool-to-break-contact";return true;}
        if(m.landing==null||tick>=m.until-1)m.landing=upperFloor(s,target);if(m.landing!=null){stopFire(p);if(p.getLocation().distanceSquared(m.landing)>4){brain.strategy.travel(s,m.landing,tick,"retreat","upper-orchestra-floor-for-recovery-and-diversion");return true;}if(brain.strategy.count(p,Material.GOLDEN_APPLE)>0&&p.getHealth()<9000){s.strategy.nextUse=0;return brain.strategy.consume(s,null,tick);}runtime.look(s.bot,foe.getEyeLocation());s.action="diversion";s.reason="draw-defender-attention-away-from-partner";return false;}return false;
    }
    private Location upperFloor(AiBrain.State s,RunningTeam target){Player p=s.bot.getPlayer();Location best=null;double score=Double.MAX_VALUE;for(int x=-8;x<=8;x+=2)for(int z=-8;z<=8;z+=2)for(int y=3;y<=8;y++){Location at=target.getTeamSpawn().clone().add(x,y,z);if(!s.room.game.isLocationInArena(at)||!AiTerrain.floor(at))continue;double d=at.distanceSquared(p.getLocation());if(d<score){score=d;best=at;}}return best;}
}
