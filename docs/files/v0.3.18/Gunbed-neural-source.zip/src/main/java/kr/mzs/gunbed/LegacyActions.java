package kr.mzs.gunbed;

import me.neznamy.tab.api.TabAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.Location;
import org.bukkit.util.Vector;
import org.bukkit.NamespacedKey;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.block.Block;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.Game;
import org.screamingsandals.bedwars.api.game.GameStatus;
import java.util.*;

/** Trusted server script helpers replacing abandoned Skript addons. Not exposed as player commands. */
public final class LegacyActions {
    private static final Map<UUID, Location[]> selections = new HashMap<>();
    private static final Map<Game, Set<Location>> recorded = new HashMap<>();
    private LegacyActions() { }

    /** Prevent the old four-stage name/inventory script from duplicating native CrackShot reloads. */
    public static boolean nativeReload(String weapon) { return GunVisualBridge.nativeReload(weapon); }
    public static boolean holdingWeapon(Object actor,String allowed){if(!(actor instanceof Player player))return false;GunbedCore plugin=org.bukkit.plugin.java.JavaPlugin.getPlugin(GunbedCore.class);var item=player.getInventory().getItemInMainHand();String title=plugin.visuals==null?null:plugin.visuals.cs.getWeaponTitle(item);for(String candidate:allowed.split("\\|")){if(candidate.equals(title))return true;if(candidate.equals("Sealknife")&&item.getType()==org.bukkit.Material.STONE_SWORD&&item.hasItemMeta()&&org.bukkit.ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains("Sealknife"))return true;}return false;}

    public static void asOp(Player player, String command) {
        if (!Bukkit.isPrimaryThread()) throw new IllegalStateException("Commands must run on the server thread");
        if (player == null || !player.isOnline()) return;
        String lower = command.toLowerCase(java.util.Locale.ROOT);
        if (lower.startsWith("bw arenasgui")) command = "gunbed arenas";
        if (lower.equals("bw forcestart")) command = "gunbed start";
        command = recordScriptSelection(player, command);
        boolean wasOp = player.isOp();
        try {
            if (!wasOp) player.setOp(true);
            player.performCommand(command.startsWith("/") ? command.substring(1) : command);
        } finally {
            if (!wasOp) player.setOp(false);
        }
    }

    private static String modernBlock(String block) {
        return switch (block) {
            case "0" -> "air";
            case "51" -> "fire";
            case "22" -> "lapis_block";
            case "42" -> "iron_block";
            case "35:11" -> "blue_wool";
            case "35:14" -> "red_wool";
            case "35:8" -> "light_gray_wool";
            case "159:14" -> "red_terracotta";
            default -> block;
        };
    }

    private static String recordScriptSelection(Player player, String command) {
        if (command.startsWith("//pos1") || command.startsWith("//pos2")) {
            String[] parts = command.trim().split("\\s+", 2);
            Location location = player.getLocation().getBlock().getLocation();
            if (parts.length == 2) {
                String[] xyz = parts[1].split(",");
                if (xyz.length == 3) location = new Location(player.getWorld(), Double.parseDouble(xyz[0]), Double.parseDouble(xyz[1]), Double.parseDouble(xyz[2]));
            }
            selections.computeIfAbsent(player.getUniqueId(), p -> new Location[2])[command.startsWith("//pos1") ? 0 : 1] = location;
        } else if (command.startsWith("//replace ")) {
            String[] parts = command.trim().split("\\s+", 3);
            if (parts.length != 3) return command;
            String mask = Arrays.stream(parts[1].split(",")).map(LegacyActions::modernBlock).collect(java.util.stream.Collectors.joining(","));
            Location[] corners = selections.get(player.getUniqueId());
            if (corners != null && corners[0] != null && corners[1] != null && Bukkit.getPluginManager().isPluginEnabled("BedWars")) {
                Game game = BedwarsAPI.getInstance().getGameOfPlayer(player);
                if (game != null && game.getStatus() == GameStatus.RUNNING) {
                    Set<org.bukkit.Material> types = new HashSet<>();
                    for (String type : mask.split(",")) {
                        var material = org.bukkit.Material.matchMaterial(type);
                        if (material != null) types.add(material);
                    }
                    int minX = Math.min(corners[0].getBlockX(), corners[1].getBlockX()), maxX = Math.max(corners[0].getBlockX(), corners[1].getBlockX());
                    int minY = Math.min(corners[0].getBlockY(), corners[1].getBlockY()), maxY = Math.max(corners[0].getBlockY(), corners[1].getBlockY());
                    int minZ = Math.min(corners[0].getBlockZ(), corners[1].getBlockZ()), maxZ = Math.max(corners[0].getBlockZ(), corners[1].getBlockZ());
                    if ((long) (maxX-minX+1) * (maxY-minY+1) * (maxZ-minZ+1) > 2000000) throw new IllegalArgumentException("Script selection exceeds the imported arena limit");
                    for (int x=minX; x<=maxX; x++) for (int y=minY; y<=maxY; y++) for (int z=minZ; z<=maxZ; z++) {
                        Block block = player.getWorld().getBlockAt(x,y,z);
                        if (types.contains(block.getType())) recordBlock(block);
                    }
                }
            }
            return "//replace " + mask + " " + modernBlock(parts[2]);
        }
        return command;
    }

    public static void recordBlock(Block block) {
        if (!Bukkit.getPluginManager().isPluginEnabled("BedWars")) return;
        for (Game game : BedwarsAPI.getInstance().getGames()) {
            if (game.getStatus() != GameStatus.RUNNING || !game.getGameWorld().equals(block.getWorld())) continue;
            Location a=game.getPos1(), b=game.getPos2(), p=block.getLocation();
            if (p.getX()<Math.min(a.getX(),b.getX()) || p.getX()>Math.max(a.getX(),b.getX())
                    || p.getY()<Math.min(a.getY(),b.getY()) || p.getY()>Math.max(a.getY(),b.getY())
                    || p.getZ()<Math.min(a.getZ(),b.getZ()) || p.getZ()>Math.max(a.getZ(),b.getZ())) continue;
            recordOne(game, block);
            if (block.getBlockData() instanceof org.bukkit.block.data.type.Bed bed) {
                recordOne(game, block.getRelative(bed.getPart() == org.bukkit.block.data.type.Bed.Part.FOOT ? bed.getFacing() : bed.getFacing().getOppositeFace()));
            }
            return;
        }
    }

    private static void recordOne(Game game, Block block) {
        Location location = block.getLocation();
        if (!game.isBlockAddedDuringGame(location) && recorded.computeIfAbsent(game, g -> new HashSet<>()).add(location)) {
            game.getRegion().putOriginalBlock(location, block.getState());
        }
    }

    static void clear(Game game) { recorded.remove(game); }

    public static void prefix(Player player, String text) {
        if (player == null || !Bukkit.getPluginManager().isPluginEnabled("TAB")) return;
        var api = TabAPI.getInstance();
        var tabPlayer = api.getPlayer(player.getUniqueId());
        if (tabPlayer != null && api.getNameTagManager() != null) {
            api.getNameTagManager().setPrefix(tabPlayer, text == null || text.isEmpty() ? null : text);
        }
    }

    public static void healthScale(Player player, double scale) {
        player.setHealthScale(scale);
        player.setHealthScaled(true);
    }

    public static void damageDelay(LivingEntity entity, double seconds) {
        entity.setNoDamageTicks((int) Math.max(0, Math.round(seconds * 20)));
    }

    public static void home(Projectile projectile, Location destination) {
        if (projectile == null || destination == null || !projectile.getWorld().equals(destination.getWorld())) return;
        Vector vector = destination.toVector().subtract(projectile.getLocation().toVector());
        if (vector.lengthSquared() > 0.0001) {
            projectile.setVelocity(vector.normalize().multiply(Math.max(0.1, projectile.getVelocity().length())));
        }
    }

    public static void pushAway(Entity victim, Entity attacker, double speed) {
        if (victim == null || attacker == null || !victim.getWorld().equals(attacker.getWorld())) return;
        Vector vector = victim.getLocation().toVector().subtract(attacker.getLocation().toVector());
        if (vector.lengthSquared() > 0.0001) victim.setVelocity(vector.normalize().multiply(speed));
    }

    public static void hiddenPotion(LivingEntity entity, String id, int level) {
        PotionEffectType type = PotionEffectType.getByKey(NamespacedKey.minecraft(id));
        if (type != null) entity.addPotionEffect(new PotionEffect(type, 1726272000, Math.max(0, level - 1), false, false, false));
    }

    public static void slow(LivingEntity entity, int level, Object duration) {
        if (duration instanceof java.time.temporal.TemporalAmount amount) {
            long ticks = java.time.Duration.from(amount).toMillis() / 50;
            entity.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,
                    (int) Math.max(1, Math.min(Integer.MAX_VALUE, ticks)), Math.max(0, level - 1)));
        }
    }
}
