package kr.mzs.gunbed;

import java.lang.reflect.Field;
import java.util.*;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.*;

/** OP-only test: never advances the timeline, destroys beds, or restarts a game. */
final class DragonTestCommand extends Command implements Listener {
    private final GunbedCore plugin;
    private final Set<Game> tests=Collections.newSetFromMap(new IdentityHashMap<>());
    DragonTestCommand(GunbedCore plugin){super("드래곤테스트","현재 경기의 드래곤 시험","/드래곤테스트 시작|종료|상태 [플레이어]",List.of("dragontest"));this.plugin=plugin;setPermission("minecraft.command.op");Bukkit.getPluginManager().registerEvents(this,plugin);}
    static void install(GunbedCore plugin) {
        if(Bukkit.getCommandMap().getCommand("드래곤테스트")==null)
            Bukkit.getCommandMap().register("gunbedcore",new DragonTestCommand(plugin));
    }
    @Override public boolean execute(CommandSender sender,String label,String[] args) {
        if(!sender.isOp()){sender.sendMessage("§c운영자만 사용할 수 있습니다.");return true;}
        Player player=args.length>1?Bukkit.getPlayerExact(args[1]):sender instanceof Player p?p:null;
        if(player==null){sender.sendMessage("§e/드래곤테스트 시작|종료|상태 [경기 참가자 이름]");return true;}
        Game game=BedwarsAPI.getInstance().getGameOfPlayer(player);
        if(game==null||game.getStatus()!=GameStatus.RUNNING){sender.sendMessage("§c서로 다른 팀의 두 명 이상이 경기를 시작한 뒤 사용하세요.");return true;}
        try {
            SuddenDragons engine=plugin.flow.dragons;
            Field field=SuddenDragons.class.getDeclaredField("flights");field.setAccessible(true);
            List<?> flights=(List<?>)field.get(engine);
            long count=flights.stream().filter(f->{try{Field g=f.getClass().getDeclaredField("game");g.setAccessible(true);return g.get(f)==game;}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}}).count();
            String action=args.length==0?"상태":args[0].toLowerCase(Locale.ROOT);
            if(action.equals("시작")||action.equals("start")) {
                long teams=game.getConnectedPlayers().stream().filter(p->!p.isDead()&&p.getGameMode()!=GameMode.SPECTATOR).map(game::getTeamOfPlayer).filter(Objects::nonNull).distinct().count();
                if(teams<2){sender.sendMessage("§c생존 플레이어가 서로 다른 두 팀에 있어야 합니다.");return true;}
                if(count>0){sender.sendMessage("§e이미 드래곤이 활동 중입니다. /드래곤테스트 상태");return true;}
                engine.start(game);tests.add(game);
                for(Player p:game.getConnectedPlayers())p.sendMessage("§d드래곤 테스트 시작 · 지형이 파괴됩니다. OP /드래곤테스트 종료로 중지합니다.");
            } else if(action.equals("종료")||action.equals("stop")) {
                if(!tests.remove(game)){sender.sendMessage("§c시험으로 소환한 드래곤만 이 명령으로 종료할 수 있습니다.");return true;}
                engine.clear(game);sender.sendMessage("§a테스트 드래곤 제거 완료. 파괴된 지형은 경기 종료 시 복구됩니다.");
            } else if(action.equals("상태")||action.equals("status")) {
                sender.sendMessage("§b현재 경기 드래곤 "+count+"마리 · "+(tests.contains(game)?"테스트":"일반 서든데스/대기"));
                for(Object f:flights){Field gf=f.getClass().getDeclaredField("game"),df=f.getClass().getDeclaredField("dragon");gf.setAccessible(true);df.setAccessible(true);if(gf.get(f)!=game)continue;EnderDragon d=(EnderDragon)df.get(f);if(d==null){sender.sendMessage("§7부활 대기 중");continue;}var s=DragonFlightMotion.states.get(d.getUniqueId());sender.sendMessage("§f"+d.getEntityId()+" · "+(s==null?"출발":new String[]{"선회","접근","돌진","상승"}[s.phase])+" · 누적 이동 "+(s==null?0:Math.round(s.distance))+"블록 · 체력 "+Math.round(d.getHealth()));}
            } else sender.sendMessage("§e/드래곤테스트 시작|종료|상태");
        }catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
        return true;
    }
    @Override public List<String> tabComplete(CommandSender sender,String alias,String[] args){return sender.isOp()&&args.length==1?List.of("시작","종료","상태"):List.of();}
    @EventHandler public void ended(BedwarsGameEndEvent e){tests.remove(e.getGame());}
    @EventHandler public void disabled(BedWarsGameDisabledEvent e){tests.remove(e.getGame());}
}
