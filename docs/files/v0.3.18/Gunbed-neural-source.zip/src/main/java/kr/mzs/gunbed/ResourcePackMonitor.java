package kr.mzs.gunbed;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.Bukkit;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.*;
import java.io.File;

/** Keep packs from another proxy backend out of gunbed's item models/shaders. */
final class ResourcePackMonitor implements Listener {
    private final GunbedCore plugin;
    private final Set<UUID> acknowledged=new HashSet<>();
    private record Pack(UUID id,String url,byte[] hash) {}
    private final Pack pack;

    ResourcePackMonitor(GunbedCore plugin) {
        this.plugin = plugin;
        Pack found=null;
        if(plugin.getConfig().getBoolean("resource-pack.fallback-from-itemsadder",true)) {
            File folder=new File(plugin.getDataFolder().getParentFile(),"ItemsAdder");
            var config=YamlConfiguration.loadConfiguration(new File(folder,"config.yml"));
            File zip=new File(folder,"output/generated.zip");
            String url=config.getString("resource-pack.hosting.external-host.url","");
            try {
                if(config.getBoolean("resource-pack.hosting.external-host.enabled")&&url.startsWith("https://")&&zip.isFile())
                    found=new Pack(UUID.fromString(config.getString("resource-pack.uuid")),url,MessageDigest.getInstance("SHA-1").digest(Files.readAllBytes(zip.toPath())));
            } catch(Exception error){plugin.getLogger().warning("ItemsAdder pack fallback unavailable: "+error.getClass().getSimpleName());}
        }
        pack=found;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent event) {
        acknowledged.remove(event.getPlayer().getUniqueId());
        if (plugin.getConfig().getBoolean("resource-pack.clear-on-join", true) && pack!=null) {
            // ItemsAdder applies gunbed's pack 40 ticks later, after this reset.
            event.getPlayer().clearResourcePacks();
        }
        if(pack!=null)Bukkit.getScheduler().runTaskLater(plugin,()->{
            var player=event.getPlayer();
            if(player.isOnline()&&!acknowledged.contains(player.getUniqueId())) {
                player.addResourcePack(pack.id,pack.url,pack.hash,"Gunbed 리소스팩",true);
                plugin.getLogger().info("ItemsAdder pack delivered by Paper fallback: "+player.getName());
            }
        },80);
    }

    @EventHandler
    public void onStatus(PlayerResourcePackStatusEvent event) {
        if(pack!=null&&pack.id.equals(event.getID())) {
            String status=event.getStatus().name();
            if(Set.of("ACCEPTED","DOWNLOADED","SUCCESSFULLY_LOADED").contains(status))
                acknowledged.add(event.getPlayer().getUniqueId());
            if(status.equals("DECLINED")||status.startsWith("FAILED")||status.equals("INVALID_URL"))
                event.getPlayer().kick(net.kyori.adventure.text.Component.text("Gunbed 리소스팩을 적용해야 입장할 수 있습니다."));
        }
        plugin.getLogger().info("Resource pack: player=" + event.getPlayer().getName()
                + " id=" + event.getID() + " status=" + event.getStatus());
    }
    @EventHandler public void onQuit(PlayerQuitEvent event){acknowledged.remove(event.getPlayer().getUniqueId());}
}
