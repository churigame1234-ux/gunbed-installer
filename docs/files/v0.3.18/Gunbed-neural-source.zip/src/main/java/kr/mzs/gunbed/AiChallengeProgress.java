package kr.mzs.gunbed;

import java.util.*;

/** Explicit completions, never a highest-stage or highest-unlocked counter. */
final class AiChallengeProgress {
    private static final List<AiChallenge> ORDER = Arrays.stream(AiChallenge.values())
            .filter(AiChallenge::original).toList();
    private final Set<AiChallenge> completed;

    AiChallengeProgress(Collection<String> saved) {
        EnumSet<AiChallenge> entries = EnumSet.noneOf(AiChallenge.class);
        for (AiChallenge challenge : AiChallenge.values()) {
            if (challenge != AiChallenge.NONE && saved.contains(challenge.name())) entries.add(challenge);
        }
        completed = Collections.unmodifiableSet(entries);
    }

    boolean completed(AiChallenge challenge) { return completed.contains(challenge); }

    boolean canSelect(AiChallenge challenge) {
        if (!challenge.original() || completed(challenge)) return true;
        // A guest may have completed C while A and B remain incomplete. C can
        // be replayed, but only the contiguous prefix can unlock the next step.
        for (AiChallenge previous : ORDER) {
            if (previous == challenge) return true;
            if (!completed(previous)) return false;
        }
        return false;
    }

    AiChallengeProgress withCompletion(AiChallenge challenge) {
        if (challenge == AiChallenge.NONE || completed(challenge)) return this;
        List<String> entries = new ArrayList<>(saved());
        entries.add(challenge.name());
        return new AiChallengeProgress(entries);
    }

    List<String> saved() {
        return Arrays.stream(AiChallenge.values()).filter(completed::contains).map(Enum::name).toList();
    }
}
