package kr.mzs.gunbed;

import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;

/** Visual-only arrows and yellow BALL fireworks for the custom CS explosion path. */
final class LauncherEffects implements Listener {
    private static final Set<GunbedCore> installed=Collections.newSetFromMap(new IdentityHashMap<>());
    private static final Map<UUID,Projectile> arrows=new HashMap<>();
    private static final Map<UUID,Location> previous=new HashMap<>();
    private static final Map<UUID,Integer> age=new HashMap<>();
    private static final NamespacedKey COSMETIC=new NamespacedKey("gunbedcore","launcher_firework");
    static void install(GunbedCore p){if(installed.add(p)){Bukkit.getPluginManager().registerEvents(new LauncherEffects(),p);Bukkit.getScheduler().runTaskTimer(p,LauncherEffects::tick,1,1);}}
    static void track(GunbedCore p,Projectile arrow){install(p);if(arrows.size()>=256)return;UUID id=arrow.getUniqueId();arrows.put(id,arrow);previous.put(id,arrow.getLocation());age.put(id,0);}
    private static void draw(Location old,Location at){if(old==null||old.getWorld()!=at.getWorld())return;var delta=at.toVector().subtract(old.toVector());int n=Math.min(48,Math.max(1,(int)Math.ceil(delta.length()*2)));for(int k=0;k<=n;k++){Location point=old.clone().add(delta.clone().multiply(k/(double)n));at.getWorld().spawnParticle(Particle.DUST,point,1,0,0,0,0,new Particle.DustOptions(Color.YELLOW,.8f),true);at.getWorld().spawnParticle(Particle.CRIT,point,1,0,0,0,0,null,true);}}
    static void finish(Projectile arrow,Location at){UUID id=arrow.getUniqueId();draw(previous.remove(id),at);arrows.remove(id);age.remove(id);}
    private static void tick(){for(UUID id:List.copyOf(arrows.keySet())){Projectile arrow=arrows.get(id);if(!arrow.isValid()||arrow.isDead()||age.merge(id,1,Integer::sum)>200){arrows.remove(id);previous.remove(id);age.remove(id);continue;}Location at=arrow.getLocation();draw(previous.put(id,at),at);}}
    static void burst(GunbedCore p,Player owner,Location at){install(p);Firework firework=at.getWorld().spawn(at,Firework.class,f->{f.setPersistent(false);f.setSilent(false);f.setVelocity(new org.bukkit.util.Vector());f.getPersistentDataContainer().set(COSMETIC,PersistentDataType.BYTE,(byte)1);var meta=f.getFireworkMeta();meta.clearEffects();meta.addEffect(FireworkEffect.builder().with(FireworkEffect.Type.BALL).withColor(Color.YELLOW).trail(false).flicker(false).build());meta.setPower(0);f.setFireworkMeta(meta);});var game=BedwarsAPI.getInstance().getGameOfPlayer(owner);if(game!=null)BedwarsAPI.getInstance().registerEntityToGame(firework,game);Bukkit.getScheduler().runTaskLater(p,()->{if(firework.isValid())firework.detonate();},2);}
    @EventHandler(priority=EventPriority.LOWEST)public void damage(EntityDamageByEntityEvent e){if(e.getDamager().getPersistentDataContainer().has(COSMETIC))e.setCancelled(true);}
}
