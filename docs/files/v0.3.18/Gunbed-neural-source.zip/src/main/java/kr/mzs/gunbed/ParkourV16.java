package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import java.util.*;

final class ParkourV16 implements Listener {
 private final GunbedCore p;private final NamespacedKey key;
 ParkourV16(GunbedCore p){this.p=p;key=new NamespacedKey(p,"parkour_exit");Bukkit.getPluginManager().registerEvents(this,p);}
 static boolean active(GunbedCore p,Player player){return p.activities!=null&&p.activities.elapsed(player)>=0;}
 static void begin(GunbedCore p,Player player){player.closeInventory();player.getInventory().clear();ItemStack item=new ItemStack(Material.RED_DYE);var meta=item.getItemMeta();meta.setDisplayName("§c파쿠르 포기 · 로비로 돌아가기");meta.getPersistentDataContainer().set(new NamespacedKey(p,"parkour_exit"),PersistentDataType.BYTE,(byte)1);item.setItemMeta(meta);player.getInventory().setItem(8,item);player.getInventory().setHeldItemSlot(8);}
 static void finish(GunbedCore p,Player player){player.getInventory().clear();p.controls.toolbar(player);p.protocol.emit(player,Map.of("event","parkourEnd"));}
 private boolean button(ItemStack item){return item!=null&&item.hasItemMeta()&&item.getItemMeta().getPersistentDataContainer().has(key);}
 @EventHandler(priority=EventPriority.HIGHEST)public void use(PlayerInteractEvent e){if(e.getHand()!=EquipmentSlot.HAND||!button(e.getItem()))return;e.setCancelled(true);p.activities.cancel(e.getPlayer(),true);}
 @EventHandler public void drop(PlayerDropItemEvent e){if(button(e.getItemDrop().getItemStack()))e.setCancelled(true);}
 @EventHandler public void swap(PlayerSwapHandItemsEvent e){if(active(p,e.getPlayer()))e.setCancelled(true);}
 @EventHandler public void click(InventoryClickEvent e){if(e.getWhoClicked() instanceof Player player&&active(p,player))e.setCancelled(true);}
 @EventHandler public void drag(InventoryDragEvent e){if(e.getWhoClicked() instanceof Player player&&active(p,player))e.setCancelled(true);}
}
