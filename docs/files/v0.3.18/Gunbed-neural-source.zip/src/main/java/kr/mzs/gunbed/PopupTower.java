package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.Ladder;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.screamingsandals.bedwars.api.game.Game;
import org.screamingsandals.bedwars.api.game.GameStatus;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.BiPredicate;

/** Placement adapter for the owner's Extra-Special-Items 3.0.2 tower blueprint. */
final class PopupTower {
    private record Cell(int x,int y,int z,boolean ladder) {}
    private final GunbedCore plugin;
    private final BiPredicate<Game,Location> allowed;
    private final List<Cell> blueprint;
    private final Map<Game,Set<BukkitTask>> tasks=new HashMap<>();

    PopupTower(GunbedCore plugin,BiPredicate<Game,Location> allowed) {
        this.plugin=plugin;this.allowed=allowed;
        try(var source=Objects.requireNonNull(plugin.getResource("popup-tower.csv"));var reader=new BufferedReader(new InputStreamReader(source,StandardCharsets.UTF_8))) {
            blueprint=reader.lines().filter(line->!line.isBlank()&&!line.startsWith("#")).map(line->{String[] p=line.split(",");return new Cell(Integer.parseInt(p[0]),Integer.parseInt(p[1]),Integer.parseInt(p[2]),p[3].equals("1"));}).toList();
        } catch(IOException e){throw new IllegalStateException("Cannot load popup tower blueprint",e);}
    }
    boolean start(Player player,Game game,Block clicked,BlockFace face) {
        if(clicked==null||face==null||face==BlockFace.DOWN)return false;
        Location origin=clicked.getRelative(face).getLocation();
        if(!origin.getBlock().getType().isAir()||!allowed.test(game,origin)||!plugin.volumes.allow(game,origin,player))return false;
        var team=game.getTeamOfPlayer(player);if(team==null)return false;
        Material wool=Material.valueOf(TeamPalette.of(game,team).dye().name()+"_WOOL");
        BlockFace direction=player.getFacing().getOppositeFace();
        ListIterator<Cell> cells=blueprint.listIterator();
        BukkitRunnable building=new BukkitRunnable(){
            @Override public void run(){
                if(game.getStatus()!=GameStatus.RUNNING){finish();return;}
                // Original config: two cells per tick, one tick between batches.
                for(int n=0;n<2;n++){
                    if(!cells.hasNext()){finish();return;}
                    Cell cell=cells.next();int x=cell.x,z=cell.z;
                    int dx=switch(direction){case NORTH->x;case SOUTH->-x;case EAST->-z;case WEST->z;default->throw new IllegalStateException();};
                    int dz=switch(direction){case NORTH->z;case SOUTH->-z;case EAST->x;case WEST->-x;default->throw new IllegalStateException();};
                    Location position=origin.clone().add(dx,cell.y,dz);Block block=position.getBlock();
                    if(!block.getType().isAir()||!allowed.test(game,position)||!plugin.volumes.allow(game,position,player))continue;
                    if(cell.ladder&&!block.getRelative(direction.getOppositeFace()).getType().isSolid())continue;
                    game.getRegion().addBuiltDuringGame(position);
                    if(cell.ladder){Ladder ladder=(Ladder)Material.LADDER.createBlockData();ladder.setFacing(direction);block.setBlockData(ladder,false);}
                    else block.setType(wool,false);
                    position.getWorld().playSound(position,Sound.ENTITY_CHICKEN_EGG,1f,1f);
                }
            }
            private void finish(){Set<BukkitTask> active=tasks.get(game);if(active!=null){active.removeIf(task->task.getTaskId()==getTaskId());if(active.isEmpty())tasks.remove(game);}cancel();}
        };
        BukkitTask task=building.runTaskTimer(plugin,0,1);
        tasks.computeIfAbsent(game,key->new HashSet<>()).add(task);
        return true;
    }
    void cancel(Game game){Set<BukkitTask> active=tasks.remove(game);if(active!=null)active.forEach(BukkitTask::cancel);}
    void close(){new ArrayList<>(tasks.keySet()).forEach(this::cancel);}
}
