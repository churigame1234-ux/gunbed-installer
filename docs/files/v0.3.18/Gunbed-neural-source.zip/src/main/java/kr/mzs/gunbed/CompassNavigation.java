package kr.mzs.gunbed;

import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.Player;

/** FAWE caches navigation items and auto-binds them even after a Bukkit permission change. */
final class CompassNavigation {
    private static ClassLoader loader;
    static void disable(GunbedCore plugin){
        var fawe=Bukkit.getPluginManager().getPlugin("FastAsyncWorldEdit");if(fawe==null)return;loader=fawe.getClass().getClassLoader();
        try{
            Object we=Class.forName("com.sk89q.worldedit.WorldEdit",true,loader).getMethod("getInstance").invoke(null);
            Object config=we.getClass().getMethod("getConfiguration").invoke(we);config.getClass().getField("navigationWand").set(config,"minecraft:structure_void");
            for(Path path:List.of(fawe.getDataFolder().toPath().resolve("worldedit-config.yml"),fawe.getDataFolder().toPath().getParent().resolve("WorldEdit/config.yml"))){
                if(!Files.exists(path))continue;String old=Files.readString(path),next=old.replaceFirst("(?m)(navigation-wand:\\s*\\r?\\n\\s*item:)[^\\r\\n]*","$1 minecraft:structure_void");
                if(!old.equals(next)){Path tmp=path.resolveSibling(path.getFileName()+".gunbed.tmp");Files.writeString(tmp,next);Files.move(tmp,path,StandardCopyOption.REPLACE_EXISTING);}
            }
            for(Player p:Bukkit.getOnlinePlayers())clear(p);
        }catch(ReflectiveOperationException|java.io.IOException e){throw new IllegalStateException("FAWE compass navigation guard",e);}
    }
    static void clear(Player player){if(loader==null)return;try{
        Class<?> weClass=Class.forName("com.sk89q.worldedit.WorldEdit",true,loader),adapter=Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter",true,loader);
        Object we=weClass.getMethod("getInstance").invoke(null),actor=adapter.getMethod("adapt",Player.class).invoke(null,player),manager=weClass.getMethod("getSessionManager").invoke(we);
        Object session=manager.getClass().getMethod("get",Class.forName("com.sk89q.worldedit.session.SessionOwner",true,loader)).invoke(manager,actor);
        Field tools=session.getClass().getDeclaredField("tools");tools.setAccessible(true);Object map=tools.get(session);
        Class<?> types=Class.forName("com.sk89q.worldedit.world.item.ItemTypes",true,loader);Object compass=types.getField("COMPASS").get(null),replacement=types.getField("STRUCTURE_VOID").get(null);
        int id=(int)compass.getClass().getMethod("getInternalId").invoke(compass);map.getClass().getMethod("remove",int.class).invoke(map,id);
        Field nav=session.getClass().getDeclaredField("navWandItem");nav.setAccessible(true);nav.set(session,Class.forName("com.sk89q.worldedit.blocks.BaseItem",true,loader).getConstructor(Class.forName("com.sk89q.worldedit.world.item.ItemType",true,loader)).newInstance(replacement));
    }catch(ReflectiveOperationException e){throw new IllegalStateException("Clear cached FAWE compass",e);}}
}
