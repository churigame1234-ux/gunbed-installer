package kr.mzs.gunbed;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Pose;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public final class CorpseNpcService {
    private static final String HIDE_TEAM_NAME = "mzs_corpsehide";
    private static final Map<UUID, Object> NPCS_BY_ENTITY = new ConcurrentHashMap<>();
    private static final Map<UUID, UUID> ENTITY_BY_PLAYER = new ConcurrentHashMap<>();
    private static final Map<UUID, String> NAME_BY_ENTITY = new ConcurrentHashMap<>();
    private static final AtomicLong SPAWN_SEQUENCE = new AtomicLong();

    private CorpseNpcService() {
    }

    public static UUID spawn(JavaPlugin plugin, Player player, Location location) {
        if (plugin == null || player == null || location == null || location.getWorld() == null) {
            return null;
        }
        if (!plugin.getConfig().getBoolean("corpse.citizens.enabled", true)) {
            return null;
        }
        Plugin citizens = Bukkit.getPluginManager().getPlugin("Citizens");
        if (citizens == null || !citizens.isEnabled()) {
            return null;
        }
        try {
            ClassLoader citizensLoader = citizens.getClass().getClassLoader();
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI", true, citizensLoader);
            Object registry = citizensApi.getMethod("getNPCRegistry").invoke(null);
            String npcName = corpseNpcName(player);
            Object npc = registry.getClass()
                    .getMethod("createNPC", EntityType.class, String.class)
                    .invoke(registry, EntityType.PLAYER, npcName);

            invokeIfPresent(npc, "setProtected", new Class<?>[]{boolean.class}, true);
            invokeIfPresent(npc, "setPersistent", new Class<?>[]{boolean.class}, false);
            invokeIfPresent(npc, "setUseMinecraftAI", new Class<?>[]{boolean.class}, false);
            invokeIfPresent(npc, "setAlwaysUseNameHologram", new Class<?>[]{boolean.class}, false);
            setNpcMetadata(citizensLoader, npc, "NAMEPLATE_VISIBLE", false);
            setNpcMetadata(citizensLoader, npc, "COLLIDABLE", false);
            setNpcMetadata(citizensLoader, npc, "SHOULD_SAVE", false);
            removeTraitIfPresent(citizensLoader, npc, "net.citizensnpcs.trait.ScoreboardTrait");

            applySkin(citizensLoader, npc, player);

            Location corpseLocation = location.clone();
            corpseLocation.setPitch(0.0f);
            Object spawned = npc.getClass().getMethod("spawn", Location.class).invoke(npc, corpseLocation);
            if (spawned instanceof Boolean && !((Boolean) spawned)) {
                destroyNpc(npc);
                return null;
            }
            Entity entity = (Entity) npc.getClass().getMethod("getEntity").invoke(npc);
            if (entity == null) {
                destroyNpc(npc);
                return null;
            }

            configureEntity(plugin, player, entity);
            applyCitizensPose(citizensLoader, npc);
            hideNameplateForAll(npcName);
            hideNameplateForAll(entity.getName());
            forceCrawlPose(plugin, entity.getUniqueId(), npcName, entity.getName());
            UUID oldEntity = ENTITY_BY_PLAYER.put(player.getUniqueId(), entity.getUniqueId());
            if (oldEntity != null && !oldEntity.equals(entity.getUniqueId())) {
                remove(oldEntity);
            }
            NPCS_BY_ENTITY.put(entity.getUniqueId(), npc);
            NAME_BY_ENTITY.put(entity.getUniqueId(), npcName);
            return entity.getUniqueId();
        } catch (Throwable ex) {
            if (plugin.getConfig().getBoolean("corpse.citizens.debug", false)) {
                plugin.getLogger().warning("[MZS-Corpse] Citizens NPC corpse failed: " + ex.getClass().getSimpleName() + ": " + ex.getMessage());
            }
            return null;
        }
    }

    private static String corpseNpcName(Player player) {
        String compact = player.getUniqueId().toString().replace("-", "");
        String suffix = Long.toString(SPAWN_SEQUENCE.incrementAndGet(), 36);
        String base = "MZSD" + compact.substring(0, Math.min(6, compact.length()));
        int maxSuffix = Math.max(1, 16 - base.length());
        if (suffix.length() > maxSuffix) {
            suffix = suffix.substring(suffix.length() - maxSuffix);
        }
        return base + suffix;
    }

    public static boolean remove(UUID entityId) {
        if (entityId == null) {
            return false;
        }
        Object npc = NPCS_BY_ENTITY.remove(entityId);
        if (npc == null) {
            return false;
        }
        ENTITY_BY_PLAYER.entrySet().removeIf(entry -> entityId.equals(entry.getValue()));
        String npcName = NAME_BY_ENTITY.remove(entityId);
        if (npcName != null) {
            removeNameplateEntry(npcName);
        }
        destroyNpc(npc);
        return true;
    }

    private static void hideNameplateForAll(String entry) {
        // Citizens owns the NPC's packet teams. Mixing Bukkit team membership
        // with those packets can disconnect real clients on scoreboard changes.
        // NAMEPLATE_VISIBLE=false and setAlwaysUseNameHologram(false) above hide it.
    }

    private static void hideNameplateOn(Scoreboard scoreboard, String entry) {
        if (scoreboard == null) {
            return;
        }
        try {
            Team team = scoreboard.getEntryTeam(entry);
            if (team == null) {
                team = scoreboard.getTeam(HIDE_TEAM_NAME);
                if (team == null) {
                    team = scoreboard.registerNewTeam(HIDE_TEAM_NAME);
                }
            }
            team.setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.NEVER);
            team.setCanSeeFriendlyInvisibles(false);
            team.setAllowFriendlyFire(true);
            if (!team.hasEntry(entry)) {
                team.addEntry(entry);
            }
        } catch (IllegalArgumentException | IllegalStateException ignored) {
        }
    }

    private static void removeNameplateEntry(String entry) {
        // The NPC registry removes its own packet team when destroying the NPC.
    }

    private static void removeNameplateEntry(Scoreboard scoreboard, String entry) {
        if (scoreboard == null || entry == null) {
            return;
        }
        Team team = scoreboard.getTeam(HIDE_TEAM_NAME);
        if (team != null && team.hasEntry(entry)) {
            team.removeEntry(entry);
        }
    }

    private static void setNpcMetadata(ClassLoader citizensLoader, Object npc, String metadataName, Object value) {
        try {
            Class<?> metadataClass = Class.forName("net.citizensnpcs.api.npc.NPC$Metadata", true, citizensLoader);
            @SuppressWarnings({"unchecked", "rawtypes"})
            Object metadata = Enum.valueOf((Class<Enum>) metadataClass.asSubclass(Enum.class), metadataName);
            Object store = npc.getClass().getMethod("data").invoke(npc);
            store.getClass().getMethod("set", metadataClass, Object.class).invoke(store, metadata, value);
        } catch (ReflectiveOperationException | IllegalArgumentException ignored) {
        }
    }

    private static void removeTraitIfPresent(ClassLoader citizensLoader, Object npc, String traitClassName) {
        try {
            Class<?> traitClass = Class.forName(traitClassName, true, citizensLoader);
            npc.getClass().getMethod("removeTrait", Class.class).invoke(npc, traitClass);
        } catch (ReflectiveOperationException | IllegalArgumentException ignored) {
        }
    }

    private static void applySkin(ClassLoader citizensLoader, Object npc, Player player) throws Exception {
        Class<?> skinTraitClass = Class.forName("net.citizensnpcs.trait.SkinTrait", true, citizensLoader);
        Object skinTrait = npc.getClass().getMethod("getOrAddTrait", Class.class).invoke(npc, skinTraitClass);
        for (var property : player.getPlayerProfile().getProperties()) {
            if (property.getName().equals("textures") && property.getSignature()!=null) {
                skinTraitClass.getMethod("setSkinPersistent",String.class,String.class,String.class).invoke(skinTrait,player.getName(),property.getSignature(),property.getValue());
                return;
            }
        }
        Method best = null;
        for (Method method : skinTraitClass.getMethods()) {
            if (!method.getName().equals("setSkinName")) {
                continue;
            }
            Class<?>[] params = method.getParameterTypes();
            if (params.length == 2 && params[0] == String.class && params[1] == boolean.class) {
                method.invoke(skinTrait, player.getName(), true);
                return;
            }
            if (params.length == 1 && params[0] == String.class) {
                best = method;
            }
        }
        if (best != null) {
            best.invoke(skinTrait, player.getName());
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void applyCitizensPose(ClassLoader citizensLoader, Object npc) throws Exception {
        Class<?> poseTraitClass = Class.forName("net.citizensnpcs.trait.EntityPoseTrait", true, citizensLoader);
        Object poseTrait = npc.getClass().getMethod("getOrAddTrait", Class.class).invoke(npc, poseTraitClass);
        Class<?> poseEnumClass = Class.forName("net.citizensnpcs.trait.EntityPoseTrait$EntityPose", true, citizensLoader);
        Object swimming = Enum.valueOf((Class<Enum>) poseEnumClass.asSubclass(Enum.class), "SWIMMING");
        for (Method method : poseTraitClass.getMethods()) {
            if (method.getName().equals("setPose") && method.getParameterCount() == 1 && method.getParameterTypes()[0].isAssignableFrom(poseEnumClass)) {
                method.invoke(poseTrait, swimming);
                return;
            }
        }
    }

    private static void configureEntity(JavaPlugin plugin, Player player, Entity entity) {
        entity.setCustomName(null);
        entity.setCustomNameVisible(false);
        entity.setInvulnerable(true);
        entity.setSilent(true);
        entity.setGravity(false);
        entity.setPersistent(false);
        entity.setRotation(player.getLocation().getYaw(), 0.0f);
        entity.setPose(Pose.SWIMMING, true);
        if (entity instanceof LivingEntity living) {
            living.setAI(false);
            living.setCollidable(false);
            living.setCanPickupItems(false);
            living.setSwimming(true);
            if (plugin.getConfig().getBoolean("corpse.citizens.copy_armor", false) && living.getEquipment() != null) {
                living.getEquipment().setArmorContents(copyArmor(player.getInventory().getArmorContents()));
                living.getEquipment().setItemInMainHand(player.getInventory().getItemInMainHand().clone());
                living.getEquipment().setItemInOffHand(null);
            }
        }
    }

    private static ItemStack[] copyArmor(ItemStack[] items) {
        if (items == null) {
            return null;
        }
        ItemStack[] copy = new ItemStack[items.length];
        for (int i = 0; i < items.length; i++) {
            copy[i] = items[i] == null ? null : items[i].clone();
        }
        return copy;
    }

    private static void forceCrawlPose(JavaPlugin plugin, UUID entityId, String npcName, String entityName) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Entity entity = Bukkit.getEntity(entityId);
            if (entity == null || !NPCS_BY_ENTITY.containsKey(entityId)) {
                return;
            }
            hideNameplateForAll(npcName);
            hideNameplateForAll(entityName);
            entity.setPose(Pose.SWIMMING, true);
            entity.setGravity(false);
            if (entity instanceof LivingEntity living) {
                living.setSwimming(true);
                living.setAI(false);
            }
        }, 2L);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Entity entity = Bukkit.getEntity(entityId);
            if (entity == null || !NPCS_BY_ENTITY.containsKey(entityId)) {
                return;
            }
            hideNameplateForAll(npcName);
            hideNameplateForAll(entityName);
            entity.setPose(Pose.SWIMMING, true);
            if (entity instanceof LivingEntity living) {
                living.setSwimming(true);
            }
        }, 20L);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!NPCS_BY_ENTITY.containsKey(entityId)) {
                return;
            }
            hideNameplateForAll(npcName);
            hideNameplateForAll(entityName);
        }, 40L);
        Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            if (!NPCS_BY_ENTITY.containsKey(entityId)) {
                task.cancel();
                return;
            }
            hideNameplateForAll(npcName);
            hideNameplateForAll(entityName);
        }, 60L, 20L);
    }

    private static void invokeIfPresent(Object target, String methodName, Class<?>[] parameterTypes, Object... args) {
        try {
            target.getClass().getMethod(methodName, parameterTypes).invoke(target, args);
        } catch (ReflectiveOperationException ignored) {
        }
    }

    private static void destroyNpc(Object npc) {
        try {
            npc.getClass().getMethod("destroy").invoke(npc);
        } catch (ReflectiveOperationException ignored) {
        }
    }
}
