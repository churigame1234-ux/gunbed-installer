package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.Game;
import java.util.*;

/** Three-block forge/shop cubes, with five-block bed defence taking precedence. */
final class ProtectedVolumes implements Listener {
    ProtectedVolumes(GunbedCore p){Bukkit.getScheduler().runTask(p,()->Bukkit.getPluginManager().registerEvents(this,p));}
    static boolean editor(Player p){return p!=null&&p.isOp()&&p.getGameMode()==GameMode.CREATIVE;}
    static boolean cube(Location at,Location center,int radius){if(center==null||at.getWorld()!=center.getWorld())return false;return Math.abs(at.getBlockX()-center.getBlockX())<=radius&&Math.abs(at.getBlockY()-center.getBlockY())<=radius&&Math.abs(at.getBlockZ()-center.getBlockZ())<=radius;}
    static boolean inside(Location at,Location center){return cube(at,center,1);}
    boolean bedArea(Game g,Location at){return g!=null&&g.getAvailableTeams().stream().anyMatch(t->cube(at,t.getTargetBlock(),2));}
    boolean protectedAt(Game g,Location at){if(g==null||bedArea(g,at))return false;for(var s:g.getItemSpawners())if(inside(at,s.getLocation()))return true;for(var s:g.getGameStores())if(inside(at,s.getStoreLocation()))return true;return false;}
    boolean allow(Game g,Location at,Player actor){return editor(actor)||!protectedAt(g,at);}
    private Game arena(Location at){return BedwarsAPI.getInstance().getGames().stream().filter(g->g.isLocationInArena(at)).findFirst().orElse(null);}
    @EventHandler(priority=EventPriority.HIGHEST)public void place(BlockPlaceEvent e){Game g=arena(e.getBlock().getLocation());if(!allow(g,e.getBlock().getLocation(),e.getPlayer())){e.setCancelled(true);e.getPlayer().sendActionBar("§c생성기·상점 주변에는 블록을 설치할 수 없습니다.");}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void bucket(org.bukkit.event.player.PlayerBucketEmptyEvent e){var at=e.getBlockClicked().getRelative(e.getBlockFace()).getLocation();if(!allow(arena(at),at,e.getPlayer()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST)public void multi(BlockMultiPlaceEvent e){for(var b:e.getReplacedBlockStates())if(!allow(arena(b.getLocation()),b.getLocation(),e.getPlayer())){e.setCancelled(true);return;}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void grow(BlockGrowEvent e){if(protectedAt(arena(e.getBlock().getLocation()),e.getBlock().getLocation()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void spread(BlockSpreadEvent e){if(protectedAt(arena(e.getBlock().getLocation()),e.getBlock().getLocation()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void form(BlockFormEvent e){if(protectedAt(arena(e.getBlock().getLocation()),e.getBlock().getLocation()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void fertilize(BlockFertilizeEvent e){if(editor(e.getPlayer()))return;e.getBlocks().removeIf(b->protectedAt(arena(b.getLocation()),b.getLocation()));}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void tree(org.bukkit.event.world.StructureGrowEvent e){if(editor(e.getPlayer()))return;e.getBlocks().removeIf(b->protectedAt(arena(b.getLocation()),b.getLocation()));}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void portal(org.bukkit.event.world.PortalCreateEvent e){if(e.getEntity() instanceof Player p&&editor(p))return;if(e.getBlocks().stream().anyMatch(b->protectedAt(arena(b.getLocation()),b.getLocation())))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void flow(BlockFromToEvent e){if(protectedAt(arena(e.getToBlock().getLocation()),e.getToBlock().getLocation()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void entity(EntityChangeBlockEvent e){if(protectedAt(arena(e.getBlock().getLocation()),e.getBlock().getLocation())&&!e.getTo().isAir())e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void piston(BlockPistonExtendEvent e){for(Block b:e.getBlocks())if(protectedAt(arena(b.getLocation()),b.getRelative(e.getDirection()).getLocation())){e.setCancelled(true);return;}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void retract(BlockPistonRetractEvent e){for(Block b:e.getBlocks())if(protectedAt(arena(b.getLocation()),b.getRelative(e.getDirection()).getLocation())){e.setCancelled(true);return;}}
}
