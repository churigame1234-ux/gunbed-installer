package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.screamingsandals.bedwars.Main;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.game.*;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.game.GamePlayer;
import org.screamingsandals.bedwars.game.CurrentTeam;
import java.util.*;
import java.util.function.BooleanSupplier;

/** Offline bed owners retain a logical round seat, without fake players or entities. */
final class RoundPresence implements Listener,AutoCloseable {
    private record Seat(Game game,String team){}
    private static final class Roster {Map<UUID,String> teams=new HashMap<>();Set<UUID> eliminated=new HashSet<>();Set<String> drained=new HashSet<>();}
    // 0.2.44 uses List.isEmpty() for both logical team survival and last-player teardown.
    // Iteration/size contain only real connected profiles; the adapter extends that survival check.
    private static final class ReservedRoster<E> extends ArrayList<E> {
        final BooleanSupplier reserved;ReservedRoster(List<E> a,BooleanSupplier r){super(a);reserved=r;}
        @Override public boolean isEmpty(){return super.isEmpty()&&!reserved.getAsBoolean();}
    }
    private final GunbedCore plugin;
    private final Map<Game,Roster> rounds=new HashMap<>();
    private final Map<UUID,Seat> reservations=new HashMap<>();
    private final Set<UUID> departing=new HashSet<>(),joining=new HashSet<>();
    RoundPresence(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,1);}
    boolean reserved(Game game,String team){return game.getStatus()==GameStatus.RUNNING&&reservations.values().stream().anyMatch(s->s.game==game&&(team==null||s.team.equals(team))&&game.getTeamFromName(s.team)!=null&&bed(game,s.team));}
    private boolean bed(Game g,String team){return g.getRunningTeams().stream().filter(t->t.getName().equals(team)).anyMatch(RunningTeam::isTargetBlockExists);}
    Set<UUID> members(Game g,String team){Roster r=rounds.get(g);if(r==null)return Set.of();Set<UUID> out=new HashSet<>();r.teams.forEach((id,t)->{if(t.equals(team))out.add(id);});return out;}
    private void wrap(Game g){try{var field=g.getClass().getDeclaredField("players");field.setAccessible(true);List<GamePlayer> list=(List<GamePlayer>)field.get(g);if(!(list instanceof ReservedRoster))field.set(g,new ReservedRoster<>(list,()->reserved(g,null)));for(var team:g.getRunningTeams())if(team instanceof CurrentTeam t){var f=CurrentTeam.class.getField("players");f.setAccessible(true);List<GamePlayer> players=(List<GamePlayer>)f.get(t);if(!(players instanceof ReservedRoster))f.set(t,new ReservedRoster<>(players,()->reserved(g,t.getName())));}}catch(ReflectiveOperationException error){throw new IllegalStateException("The pinned BedWars roster adapter is unavailable",error);}}
    @EventHandler(priority=EventPriority.LOWEST)public void start(BedwarsGameStartedEvent e){Roster r=new Roster();for(Player p:e.getGame().getConnectedPlayers()){var t=e.getGame().getTeamOfPlayer(p);if(t!=null)r.teams.put(p.getUniqueId(),t.getName());}rounds.put(e.getGame(),r);wrap(e.getGame());}
    @EventHandler(priority=EventPriority.LOWEST)public void leave(BedwarsPlayerLeaveEvent e){Game g=e.getGame();Player p=e.getPlayer();Roster r=rounds.get(g);if(g.getStatus()!=GameStatus.RUNNING||r==null||r.eliminated.contains(p.getUniqueId())||e.getTeam()==null||departing.contains(p.getUniqueId()))return;departing.add(p.getUniqueId());r.teams.putIfAbsent(p.getUniqueId(),e.getTeam().getName());if(e.getTeam().isTargetBlockExists())reservations.put(p.getUniqueId(),new Seat(g,e.getTeam().getName()));try{if(!p.isDead()&&p.getGameMode()!=GameMode.SPECTATOR){p.setInvulnerable(false);p.setHealth(0);}if(!e.getTeam().isTargetBlockExists()){r.eliminated.add(p.getUniqueId());reservations.remove(p.getUniqueId());drain(g,r);}}finally{departing.remove(p.getUniqueId());}}
    @EventHandler(priority=EventPriority.MONITOR)public void death(PlayerDeathEvent e){Player p=e.getEntity();Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);Roster r=rounds.get(g);if(r==null)return;String team=r.teams.get(p.getUniqueId());if(team!=null&&!bed(g,team)){r.eliminated.add(p.getUniqueId());reservations.remove(p.getUniqueId());drain(g,r);}}
    private void drain(Game g,Roster r){for(String team:new HashSet<>(r.teams.values()))if(!r.drained.contains(team)&&r.teams.entrySet().stream().filter(e->e.getValue().equals(team)).allMatch(e->r.eliminated.contains(e.getKey()))){r.drained.add(team);if(plugin.containers!=null)plugin.containers.eliminated(g,team,members(g,team));}}
    private void tick(){for(var e:List.copyOf(reservations.entrySet())){Seat s=e.getValue();if(s.game.getStatus()!=GameStatus.RUNNING){reservations.remove(e.getKey());continue;}if(!bed(s.game,s.team)){reservations.remove(e.getKey());Roster r=rounds.get(s.game);if(r!=null){r.eliminated.add(e.getKey());drain(s.game,r);}}}}
    @EventHandler(priority=EventPriority.MONITOR)public void login(PlayerJoinEvent e){Bukkit.getScheduler().runTaskLater(plugin,()->{Player p=e.getPlayer();if(!p.isOnline())return;if(reservations.containsKey(p.getUniqueId())){resume(p);return;}var api=BedwarsAPI.getInstance();if(api.getGameOfPlayer(p)==null&&!(p.isOp()&&p.getGameMode()==GameMode.CREATIVE)&&api.getGames().stream().anyMatch(g->g.isLocationInArena(p.getLocation()))){if(p.isDead())p.spigot().respawn();p.setGameMode(GameMode.ADVENTURE);p.setFlying(false);p.setFallDistance(0);p.teleport(Bukkit.getWorld("world").getSpawnLocation());p.setVelocity(new org.bukkit.util.Vector());plugin.controls.toolbar(p);}},40);}
    @EventHandler(priority=EventPriority.MONITOR)public void bedDestroyed(BedwarsTargetBlockDestroyedEvent e){tick();}
    private void resume(Player p){Seat seat=reservations.get(p.getUniqueId());if(seat==null||!p.isOnline()||!bed(seat.game,seat.team)||seat.game.getStatus()!=GameStatus.RUNNING||!joining.add(p.getUniqueId()))return;if(p.isDead())p.spigot().respawn();seat.game.joinToGame(p);Bukkit.getScheduler().runTaskLater(plugin,()->{try{if(!p.isOnline()||BedwarsAPI.getInstance().getGameOfPlayer(p)!=seat.game||!bed(seat.game,seat.team))return;if(seat.game instanceof org.screamingsandals.bedwars.game.Game impl){impl.selectPlayerTeam(p,seat.game.getTeamFromName(seat.team),true,false,true);impl.makePlayerFromSpectator(Main.getPlayerGameProfile(p));reservations.remove(p.getUniqueId());p.sendMessage("§a침대가 살아 있어 이전 팀으로 복귀했습니다.");}}finally{joining.remove(p.getUniqueId());}},20);}
    @EventHandler(priority=EventPriority.LOWEST)public void join(BedwarsPlayerJoinEvent e){Seat s=reservations.get(e.getPlayer().getUniqueId());if(s!=null&&s.game!=e.getGame()){e.setCancelled(true);e.setCancelMessage("§e이전 경기의 침대가 살아 있습니다. 해당 경기로 복귀합니다.");Bukkit.getScheduler().runTask(plugin,()->resume(e.getPlayer()));}}
    @EventHandler(priority=EventPriority.LOWEST)public void end(BedwarsGameEndingEvent e){rounds.remove(e.getGame());reservations.entrySet().removeIf(x->x.getValue().game==e.getGame());}
    @Override public void close(){reservations.clear();rounds.clear();}
}
