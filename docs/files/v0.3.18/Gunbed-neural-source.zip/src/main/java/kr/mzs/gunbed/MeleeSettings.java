package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.attribute.*;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.GameStatus;
import java.nio.file.*;
import java.util.*;

/** Validated reach/area settings; CS energy weapons retain their original damage engine. */
final class MeleeSettings implements Listener,AutoCloseable {
    record Shape(double reach,double radius,double angle){}
    private final GunbedCore plugin;private final Path file;private final NamespacedKey modifier;
    private final Map<String,Double> defaults=new LinkedHashMap<>();private final Map<String,String[]> energy=new LinkedHashMap<>();
    private Map<String,Double> live=Map.of();private boolean sweeping;private final org.bukkit.scheduler.BukkitTask task;
    MeleeSettings(GunbedCore p){
        plugin=p;file=p.getDataFolder().toPath().resolve("melee.yml");modifier=new NamespacedKey(p,"melee_reach");
        for(String id:AddonMelee.names().keySet())add("weapons.lr."+id,4,4,120);
        if(p.visuals!=null)for(String id:p.visuals.titles())if(p.arsenal.meleeTitle(id)&&!id.equals("전기톱")){
            var h=p.visuals.cs.getHandle();String type=h.getString(id+".Shooting.Projectile_Type");String subtype=h.getString(id+".Shooting.Projectile_Subtype");
            if("energy".equalsIgnoreCase(type)&&subtype!=null){String[] fields=subtype.split("-");if(fields.length>=2){try{add("weapons.cs."+id,Double.parseDouble(fields[0]),Double.parseDouble(fields[1]),360);energy.put(id,fields);}catch(NumberFormatException ignored){}}}
            else if(h.getBoolean(id+".Item_Information.Melee_Mode"))add("weapons.cs."+id,3,0,120);
        }
        for(Material m:Material.values())if(m.name().endsWith("_SWORD")||m.name().endsWith("_AXE")||m==Material.MACE||m==Material.TRIDENT)add("items."+m.name().toLowerCase(Locale.ROOT),3,0,120);
        if(!reload(null))throw new IllegalStateException("Invalid melee.yml");Bukkit.getPluginManager().registerEvents(this,p);task=Bukkit.getScheduler().runTaskTimer(p,this::attributes,10,10);
    }
    private void add(String key,double reach,double radius,double angle){defaults.put(key+".reach",reach);defaults.put(key+".area-radius",radius);defaults.put(key+".arc-degrees",angle);}
    Shape shape(String id){String key=id.startsWith("items.")?id:DamageSettings.weapon(id);return new Shape(live.getOrDefault(key+".reach",3.2),live.getOrDefault(key+".area-radius",0d),live.getOrDefault(key+".arc-degrees",120d));}
    private String id(ItemStack item){if(item==null)return "";String addon=plugin.addonMelee.id(item);if(addon!=null)return "lr:"+addon;String cs=plugin.visuals==null?null:plugin.visuals.cs.getWeaponTitle(item);if(cs!=null&&defaults.containsKey("weapons.cs."+cs+".reach"))return "cs:"+cs;String ordinary="items."+item.getType().name().toLowerCase(Locale.ROOT);return defaults.containsKey(ordinary+".reach")?ordinary:"";}
    Map<String,Double> snapshot(){return live;}
    void restore(Map<String,Double> snapshot){live=snapshot;apply();}
    boolean reload(CommandSender sender){try{
        var yaml=new YamlConfiguration();yaml.options().parseComments(true);if(Files.exists(file))yaml.load(file.toFile());Map<String,Double> next=new LinkedHashMap<>(defaults);boolean added=false;
        for(String key:yaml.getKeys(true)){if(yaml.isConfigurationSection(key))continue;Object value=yaml.get(key);if(!defaults.containsKey(key)||!(value instanceof Number n)||!Double.isFinite(n.doubleValue()))throw new IllegalArgumentException("알 수 없는 항목 또는 숫자가 아닌 값: "+key);double d=n.doubleValue(),min=key.endsWith(".reach")?.5:key.endsWith(".arc-degrees")?1:0,max=key.endsWith(".reach")?16:key.endsWith(".arc-degrees")?360:8;if(d<min||d>max)throw new IllegalArgumentException(key+": "+min+"~"+max+" 범위");next.put(key,d);}
        for(var e:defaults.entrySet())if(!yaml.contains(e.getKey())){yaml.set(e.getKey(),e.getValue());added=true;}
        if(added||!Files.exists(file)){yaml.options().setHeader(List.of("Gunbed 근접 사거리·광역 범위 전용 설정. 대미지와 넉백은 damage.yml / knockback.yml에서 수정합니다.","reach: 전방 사거리(블록, 0.5~16). area-radius: 광역 판정 반경(0~8). 0은 단일 대상.","arc-degrees: 전방 부채꼴 전체 각도(1~360). TA 애드온(lr)은 기본 사거리 4 / 반경 4 / 각도 120.","CrackShot energy 근접은 기존 energy 엔진의 길이·반경을 그대로 사용합니다. arc-degrees는 해당 엔진에는 적용되지 않습니다.","CrackShot의 기존 대미지·쿨타임·효과는 유지합니다. 눈덩이 전기톱은 투사체 무기이므로 이 파일에서 제외합니다.","items는 상점 검·도끼 등 바닐라 직접 근접 공격. 기본 광역 반경 0으로 기존 단일 공격 유지.","아군·관전자 제외, TA/바닐라 광역은 벽 뒤 적을 맞히지 않습니다. 대미지는 대상별 기존 방어 처리를 거칩니다.","수정 후 OP /총리로드 또는 /초기화. 오타·잘못된 숫자는 세 설정 모두 이전 값을 유지합니다."));Files.createDirectories(file.getParent());Path temp=file.resolveSibling("melee.yml.tmp");Files.writeString(temp,yaml.saveToString());Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);}
        live=Map.copyOf(next);apply();return true;
    }catch(Exception e){plugin.getLogger().warning("melee.yml 적용 거부: "+e.getMessage());if(sender!=null)sender.sendMessage("§c근접 범위 설정 오류: "+e.getMessage());return false;}}
    private void apply(){for(var row:energy.entrySet()){Shape s=shape("cs:"+row.getKey());String[] fields=row.getValue().clone();fields[0]=s.reach==Math.rint(s.reach)?Long.toString((long)s.reach):Double.toString(s.reach);fields[1]=s.radius==Math.rint(s.radius)?Long.toString((long)s.radius):Double.toString(s.radius);com.shampaggon.crackshot.CSDirector.strings.put(row.getKey()+".Shooting.Projectile_Subtype",String.join("-",fields));}if(plugin.specs!=null)plugin.specs.invalidate();}
    List<LivingEntity> targets(Player source,String id){
        Shape shape=shape(id);Location eye=source.getEyeLocation();Vector forward=eye.getDirection();Set<UUID> seen=new HashSet<>();List<LivingEntity> result=new ArrayList<>();
        var g=BedwarsAPI.getInstance().getGameOfPlayer(source);if(g==null||g.getStatus()!=GameStatus.RUNNING||g.getTeamOfPlayer(source)==null)return result;
        double search=shape.reach+shape.radius+3;
        for(Entity raw:source.getNearbyEntities(search,search,search)){LivingEntity target=BattleTargets.living(raw);if(target==null||target==source||target.isDead()||!seen.add(target.getUniqueId())||!FriendlyProjectiles.hittable(source,target))continue;
            String team=BattleTargets.team(plugin,g,target);if(team!=null&&team.equals(g.getTeamOfPlayer(source).getName()))continue;if(target instanceof ArmorStand&&(plugin.turrets==null||plugin.turrets.team(target)==null))continue;
            var box=target.getBoundingBox();Vector nearest=new Vector(Math.clamp(eye.getX(),box.getMinX(),box.getMaxX()),Math.clamp(eye.getY(),box.getMinY(),box.getMaxY()),Math.clamp(eye.getZ(),box.getMinZ(),box.getMaxZ()));Vector delta=nearest.clone().subtract(eye.toVector());double along=delta.dot(forward);if(delta.lengthSquared()>shape.reach*shape.reach||along<-.1)continue;
            if(shape.radius==0){if(box.expand(.15).rayTrace(eye.toVector(),forward,shape.reach)==null)continue;}
            else if(delta.lengthSquared()>.001&&(Math.toDegrees(forward.angle(delta))>shape.angle/2||delta.clone().subtract(forward.clone().multiply(along)).length()>shape.radius))continue;
            Vector ray=box.getCenter().subtract(eye.toVector());if(ray.lengthSquared()>.001&&eye.getWorld().rayTraceBlocks(eye,ray.clone().normalize(),ray.length(),FluidCollisionMode.NEVER,true)!=null)continue;result.add(target);
        }
        result.sort(Comparator.comparingDouble(e->e.getLocation().distanceSquared(source.getLocation())));return shape.radius==0&&result.size()>1?result.subList(0,1):result;
    }
    void attack(Player p,String id,double damage){for(LivingEntity target:targets(p,id))BattleTargets.hurt(plugin,target,p,damage);}
    private void attributes(){for(Player p:Bukkit.getOnlinePlayers()){var attribute=p.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);if(attribute==null)continue;String id=id(p.getInventory().getItemInMainHand());var g=BedwarsAPI.getInstance().getGameOfPlayer(p);double desired=g!=null&&g.getStatus()==GameStatus.RUNNING&&p.getGameMode()==GameMode.SURVIVAL&&!id.isEmpty()&&!id.startsWith("lr:")&&!energy.containsKey(id.replace("cs:",""))?shape(id).reach:attribute.getBaseValue();double extra=desired-attribute.getBaseValue();var current=attribute.getModifier(modifier);if(current!=null&&Math.abs(current.getAmount()-extra)<.001)continue;attribute.removeModifier(modifier);if(Math.abs(extra)>.001)attribute.addTransientModifier(new AttributeModifier(modifier,extra,AttributeModifier.Operation.ADD_NUMBER));}}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void sweep(EntityDamageByEntityEvent e){if(sweeping||e.getCause()!=org.bukkit.event.entity.EntityDamageEvent.DamageCause.ENTITY_ATTACK||!(e.getDamager() instanceof Player p)||e.getFinalDamage()<=0||plugin.taWeapons.damageDefinition()!=null||plugin.throwables.damageKind()!=null)return;String id=id(p.getInventory().getItemInMainHand());if(!id.startsWith("items.")||shape(id).radius<=0)return;sweeping=true;try{for(LivingEntity extra:targets(p,id))if(extra!=e.getEntity())BattleTargets.hurt(plugin,extra,p,e.getDamage());}finally{sweeping=false;}}
    @Override public void close(){task.cancel();for(Player p:Bukkit.getOnlinePlayers()){var a=p.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);if(a!=null)a.removeModifier(modifier);}}
}
