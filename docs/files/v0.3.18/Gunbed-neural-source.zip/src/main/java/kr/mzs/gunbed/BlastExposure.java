package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.Vector;

/** Sample exposed parts of the victim, with impact origins outside the hit face. */
final class BlastExposure {
 private static final ThreadLocal<String> weapon=new ThreadLocal<>();
 static String weapon(){return weapon.get();}
 static boolean applying(){return weapon.get()!=null;}
 static void damage(org.bukkit.entity.Player owner,LivingEntity target,double amount,String title){weapon.set(title);try{target.damage(amount,owner);}finally{weapon.remove();}}

 static Location impact(Location at,Block block,BlockFace face){Location out=at.clone();if(block==null||face==null)return out;out.setX(Math.max(block.getX()+.001,Math.min(block.getX()+.999,out.getX())));out.setY(Math.max(block.getY()+.001,Math.min(block.getY()+.999,out.getY())));out.setZ(Math.max(block.getZ()+.001,Math.min(block.getZ()+.999,out.getZ())));Vector n=face.getDirection();if(n.getX()!=0)out.setX(block.getX()+(n.getX()>0?1.035:-.035));if(n.getY()!=0)out.setY(block.getY()+(n.getY()>0?1.035:-.035));if(n.getZ()!=0)out.setZ(block.getZ()+(n.getZ()>0?1.035:-.035));return out;}
 static double distance(Location from,LivingEntity victim,double radius){if(from.getWorld()!=victim.getWorld())return Double.POSITIVE_INFINITY;var b=victim.getBoundingBox();double[] xs={b.getMinX()+.04,b.getCenterX(),b.getMaxX()-.04},ys={b.getMinY()+.08,b.getCenterY(),b.getMaxY()-.08},zs={b.getMinZ()+.04,b.getCenterZ(),b.getMaxZ()-.04};double nearest=Double.POSITIVE_INFINITY;
  for(int x=0;x<3;x++)for(int y=0;y<3;y++)for(int z=0;z<3;z++){if(x!=1&&z!=1)continue;Vector delta=new Vector(xs[x]-from.getX(),ys[y]-from.getY(),zs[z]-from.getZ());double len=delta.length();if(len>radius||len>=nearest)continue;if(len<.001||from.getWorld().rayTraceBlocks(from,delta.clone().normalize(),len,FluidCollisionMode.NEVER,true)==null)nearest=len;}
  return nearest;
 }
}
