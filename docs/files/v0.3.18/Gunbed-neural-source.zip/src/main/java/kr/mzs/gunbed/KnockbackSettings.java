package kr.mzs.gunbed;

import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import java.nio.file.*;
import java.util.*;

/** Editable horizontal/vertical ground/air impulses, independent of damage.yml. */
final class KnockbackSettings {
    record Force(double ground,double air,double up,double airUp,double stun) {}
    private final GunbedCore plugin;private final Path file;
    private final Map<String,Double> defaults=new LinkedHashMap<>();private Map<String,Double> live=Map.of();
    KnockbackSettings(GunbedCore p){plugin=p;file=p.getDataFolder().toPath().resolve("knockback.yml");
        for(var row:p.damageProfiles.describe()){
            String id=row.get("id").toString(),group=row.get("class").toString();
            double[] v=switch(group){case "sniper"->new double[]{.9,1.1,.28,.18};case "shotgun"->new double[]{1,1.2,.32,.2};case "pistol"->new double[]{.22,.28,.08,.06};case "rpg"->new double[]{1.1,1.3,.35,.22};case "melee"->new double[]{.5,.65,.2,.15};default->new double[]{.16,.22,.055,.04};};
            if(id.equals("cs:망치"))v=new double[]{2,2.35,.55,.4};
            force(DamageSettings.weapon(id),v,id.equals("cs:망치")?.6:0);
        }
        force("items.knockback-stick",new double[]{1.8,2.1,.5,.35},0);
        force("turrets.burst",new double[]{.06,.09,.025,.025},0);
        force("turrets.slowness",new double[]{.2,.25,.12,.08},0);
        force("turrets.siege",new double[]{1.15,1.3,.55,.4},0);
        for(String kind:List.of("tnt","fireball")){defaults.put("explosions."+kind+".horizontal",1.3);defaults.put("explosions."+kind+".vertical",1.65);}
        if(!reload(null))throw new IllegalStateException("Invalid knockback.yml");
    }
    private void force(String key,double[] v,double stun){defaults.put(key+".ground",v[0]);defaults.put(key+".air",v[1]);defaults.put(key+".vertical",v[2]);defaults.put(key+".air-vertical",v[3]);defaults.put(key+".stun-seconds",stun);}
    Force force(String key){return new Force(value(key+".ground",.2),value(key+".air",.25),value(key+".vertical",.08),value(key+".air-vertical",.05),value(key+".stun-seconds",0));}
    double value(String key,double fallback){return live.getOrDefault(key,fallback);}
    boolean reload(CommandSender sender){try{
        YamlConfiguration yaml=new YamlConfiguration();yaml.options().parseComments(true);if(Files.exists(file))yaml.load(file.toFile());Map<String,Double> next=new LinkedHashMap<>(defaults);boolean added=false;
        for(String key:yaml.getKeys(true)){if(yaml.isConfigurationSection(key))continue;if(!defaults.containsKey(key))throw new IllegalArgumentException("알 수 없는 항목: "+key);Object raw=yaml.get(key);if(!(raw instanceof Number n)||!Double.isFinite(n.doubleValue())||n.doubleValue()<0||n.doubleValue()>(key.endsWith("stun-seconds")?10:5))throw new IllegalArgumentException(key+": 넉백 0~5 / 경직 시간 0~10 범위의 숫자를 입력하세요.");next.put(key,n.doubleValue());}
        for(var e:defaults.entrySet())if(!yaml.contains(e.getKey())){yaml.set(e.getKey(),e.getValue());added=true;}
        if(added||!Files.exists(file)){
            yaml.options().setHeader(List.of("Gunbed 넉백 설정 · 플레이어와 몹 공통 · 단위: 블록/틱 속도", "ground: 지상 수평 넉백 / air: 공중 수평 넉백", "vertical: 지상 위로 띄우는 속도 / air-vertical: 공중 위로 띄우는 속도", "stun-seconds: 이동·점프 경직 시간. 해머 기본 0.6초. 0이면 경직 없음.", "샷건의 같은 틱 여러 펠렛은 넉백을 중복 가산하지 않습니다.", "시즈·포탑 설치·무기 선택 잠금·리스폰 보호 중 넉백 면역은 유지됩니다.", "explosions: 구 MBedwars XZ 1.3 / Y 1.65를 기준으로 잡은 TNT·파이어볼 점프 세기", "weapons.cs: CrackShot 내부 무기 이름 / weapons.ta: TA 무기 ID / weapons.lr: 무료 근접 무기 ID", "수정 후 OP /총리로드로 경기 유지 즉시 적용 또는 /초기화로 적용. 잘못된 값은 기존 설정을 유지합니다."));
            for(var row:plugin.damageProfiles.describe()){String id=row.get("id").toString();String name=plugin.arsenal.weapons().stream().filter(w->w.id().equals(id)).map(w->w.title()).findFirst().orElse(id);yaml.setComments(DamageSettings.weapon(id),List.of(org.bukkit.ChatColor.stripColor(name)+" · "+row.get("class")));}
            Files.createDirectories(file.getParent());Path tmp=file.resolveSibling("knockback.yml.tmp");Files.writeString(tmp,yaml.saveToString());Files.move(tmp,file,StandardCopyOption.REPLACE_EXISTING);
        }
        live=Map.copyOf(next);if(sender!=null)sender.sendMessage("§a넉백 설정 적용: plugins/GunbedCore/knockback.yml");return true;
    }catch(Exception e){plugin.getLogger().warning("knockback.yml: "+e.getMessage());if(sender!=null)sender.sendMessage("§c넉백 설정 적용 실패 · 이전 값 유지: "+e.getMessage());return false;}}
}
