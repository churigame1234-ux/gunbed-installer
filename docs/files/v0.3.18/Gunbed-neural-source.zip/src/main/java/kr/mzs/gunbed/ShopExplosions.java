package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.game.*;
import java.util.*;

/** Shop explosives keep ray/exposure-based blast physics, independent of firearm wool HP. */
final class ShopExplosions implements Listener {
    static final NamespacedKey OWNER=new NamespacedKey("gunbedcore","blast_owner");
    private final GunbedCore plugin;
    private final Map<UUID,Integer> suppressed=new HashMap<>();
    ShopExplosions(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);}
    void fireball(Player p,Game game){var f=p.launchProjectile(LargeFireball.class);f.setShooter(p);f.setYield(2);f.setIsIncendiary(false);f.setVelocity(p.getEyeLocation().getDirection().multiply(.9));f.setDirection(p.getEyeLocation().getDirection().multiply(.08));f.getPersistentDataContainer().set(OWNER,PersistentDataType.STRING,p.getUniqueId().toString());BedwarsAPI.getInstance().registerEntityToGame(f,game);p.getWorld().playSound(p.getLocation(),Sound.ENTITY_GHAST_SHOOT,.8f,1);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void placed(BlockPlaceEvent e){if(e.getBlock().getType()!=Material.TNT)return;Player p=e.getPlayer();Game game=BedwarsAPI.getInstance().getGameOfPlayer(p);if(game==null||game.getStatus()!=GameStatus.RUNNING)return;var at=e.getBlock().getLocation();Bukkit.getScheduler().runTask(plugin,()->{if(at.getBlock().getType()!=Material.TNT||game.getStatus()!=GameStatus.RUNNING)return;at.getBlock().setType(Material.AIR,false);game.getRegion().removeBlockBuiltDuringGame(at);var tnt=at.getWorld().spawn(at.clone().add(.5,0,.5),TNTPrimed.class,t->{t.setFuseTicks(60);t.setYield(4);t.setSource(p);t.getPersistentDataContainer().set(OWNER,PersistentDataType.STRING,p.getUniqueId().toString());});BedwarsAPI.getInstance().registerEntityToGame(tnt,game);});}
    private Player owner(Entity e){if(e instanceof Projectile q&&q.getShooter() instanceof Player p)return p;String id=e.getPersistentDataContainer().get(OWNER,PersistentDataType.STRING);return id==null?null:Bukkit.getPlayer(UUID.fromString(id));}
    @EventHandler(priority=EventPriority.HIGHEST)public void turretBlast(EntityExplodeEvent e){if(!e.getEntity().getPersistentDataContainer().has(OWNER))return;Player p=owner(e.getEntity());if(p==null)return;Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);boolean tnt=e.getEntity() instanceof TNTPrimed;double radius=tnt?8:4,maximum=plugin.damages.value(tnt?"items.tnt.maximum":"items.fireball.maximum",tnt?4000:2000),nativeMax=tnt?57:29;BattleTargets.blastTurrets(plugin,p,g,e.getLocation(),radius,d->{double strength=Math.max(0,1-d/radius);return Math.min(maximum,((strength*strength+strength)/2*7*radius+1)/nativeMax*maximum);});}
    @EventHandler(priority=EventPriority.HIGHEST)public void damage(EntityDamageByEntityEvent e){if(!e.getDamager().getPersistentDataContainer().has(OWNER)||!(e.getEntity() instanceof Player target))return;Player source=owner(e.getDamager());if(source==null)return;Game g=BedwarsAPI.getInstance().getGameOfPlayer(source);RunningTeam own=g==null?null:g.getTeamOfPlayer(source),other=g==null?null:g.getTeamOfPlayer(target);if(g==null||own==null||other==null||target.getGameMode()==GameMode.SPECTATOR||source!=target&&own==other||plugin.inventories.protectedLife(target)){suppressed.put(target.getUniqueId(),Bukkit.getCurrentTick());e.setCancelled(true);return;}if(e.getCause()!=EntityDamageEvent.DamageCause.ENTITY_EXPLOSION&&e.getCause()!=EntityDamageEvent.DamageCause.BLOCK_EXPLOSION){e.setCancelled(true);return;}
        // Retain the engine's distance/exposure curve while scaling its full
        // blast endpoint to the BedWars health budget (8 / 4 of 20 HP).
        boolean tnt=e.getDamager() instanceof TNTPrimed;double nativeMax=tnt?57:29,scaledMax=plugin.damages.value(tnt?"items.tnt.maximum":"items.fireball.maximum",tnt?4000:2000);e.setCancelled(false);e.setDamage(Math.min(scaledMax,e.getDamage()/nativeMax*scaledMax));
    }
    @EventHandler(priority=EventPriority.HIGHEST)public void knockback(EntityKnockbackEvent e){if(suppressed.getOrDefault(e.getEntity().getUniqueId(),-1)>=Bukkit.getCurrentTick()){e.setCancelled(true);e.setFinalKnockback(new org.bukkit.util.Vector());}}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void boost(EntityDamageByEntityEvent e){
        if(!e.getDamager().getPersistentDataContainer().has(OWNER)||!(e.getEntity() instanceof LivingEntity target)||e.getFinalDamage()<=0||!(e.getDamager() instanceof TNTPrimed||e.getDamager() instanceof LargeFireball))return;
        boolean tnt=e.getDamager() instanceof TNTPrimed;Location at=e.getDamager().getLocation();double radius=tnt?8:4;
        double strength=Math.max(0,1-target.getBoundingBox().getCenter().distance(at.toVector())/radius);
        if(strength>0)plugin.impacts.blast(target,at,tnt?"tnt":"fireball",strength);
    }
}
