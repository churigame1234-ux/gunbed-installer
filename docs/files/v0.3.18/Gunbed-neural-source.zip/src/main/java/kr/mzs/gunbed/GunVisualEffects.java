package kr.mzs.gunbed;

import com.shampaggon.crackshot.events.WeaponShootEvent;
import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Projectile;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import java.io.File;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** Reads the user's original Plus presentation values without changing weapon files. */
final class GunVisualEffects implements Listener {
    record Trail(Particle particle,Particle.DustOptions dust,double spacing,double catchDistance) {}
    record Spec(boolean invisible,Trail trail,double upMin,double upMax,double sideMin,double sideMax) {}
    private final JavaPlugin plugin;
    private final Map<String,Spec> specs=new HashMap<>();
    private final Map<UUID,Integer> cameraTick=new HashMap<>();
    GunVisualEffects(JavaPlugin plugin) {
        this.plugin=plugin;
        File original=new File(plugin.getDataFolder().getParentFile(),"CrackShotPlus");
        Map<String,Trail> trails=new HashMap<>();
        File[] trailFiles=new File(original,"trails").listFiles((d,n)->n.endsWith(".yml"));
        if(trailFiles!=null)for(File file:trailFiles) {
            var yaml=YamlConfiguration.loadConfiguration(file);
            for(String id:yaml.getKeys(false)) {
                var section=yaml.getConfigurationSection(id);if(section==null)continue;
                String type=section.getString("Trail","");Particle particle;
                if(type.equals("CRIT"))particle=Particle.CRIT;
                else if(type.equals("REDSTONE"))particle=Particle.DUST;
                else continue;
                Particle.DustOptions dust=null;
                if(particle==Particle.DUST) {
                    String[] rgb=section.getString("Trail_Color","255-255-255").split("-");
                    if(rgb.length!=3)continue;
                    dust=new Particle.DustOptions(Color.fromRGB(Integer.parseInt(rgb[0]),Integer.parseInt(rgb[1]),Integer.parseInt(rgb[2])),1);
                }
                trails.put(id,new Trail(particle,dust,Math.max(.1,section.getDouble("Trail_Catch.Space_Between_Trails",1)),section.getDouble("Trail_Catch.Required_Distance_To_Catch",2)));
            }
        }
        File[] weapons=new File(original,"weapons").listFiles((d,n)->n.endsWith(".yml"));
        if(weapons!=null)for(File file:weapons) {
            var yaml=YamlConfiguration.loadConfiguration(file);
            for(String id:yaml.getKeys(false)) {
                var shoot=yaml.getConfigurationSection(id+".Shoot");if(shoot==null)continue;
                specs.put(id,new Spec(shoot.getBoolean("Invisible_Projectiles"),trails.get(shoot.getString("Trails.Default_Trail","")),
                    value(shoot,"Upwards","Minium"),value(shoot,"Upwards","Maxium"),value(shoot,"Sideways","Minium"),value(shoot,"Sideways","Maxium")));
            }
        }
        plugin.getServer().getPluginManager().registerEvents(this,plugin);
        plugin.getLogger().info("Original Plus trails/projectile visibility/camera values loaded for "+specs.size()+" weapon definitions.");
    }
    private double value(ConfigurationSection s,String axis,String bound){return s.getDouble("Camera_Recoil."+axis+"."+bound,0);}
    String describe(String title){Spec s=specs.get(title);return s==null?"상하 0° / 좌우 0°":String.format(java.util.Locale.ROOT,"상하 %.2f~%.2f° / 좌우 %.2f~%.2f°",s.upMin,s.upMax,s.sideMin,s.sideMax);}
    private double sample(double a,double b){return a==b?a:ThreadLocalRandom.current().nextDouble(Math.min(a,b),Math.max(a,b));}
    Map<String,Object> shotFields(WeaponShootEvent event) {
        Map<String,Object> fields=new HashMap<>();fields.put("event","shot");
        Spec spec=specs.get(event.getWeaponTitle());
        if(spec!=null && !Objects.equals(cameraTick.put(event.getPlayer().getUniqueId(),Bukkit.getCurrentTick()),Bukkit.getCurrentTick())) {
            fields.put("recoilUp",sample(spec.upMin,spec.upMax));
            fields.put("recoilSide",sample(spec.sideMin,spec.sideMax));
        }
        return fields;
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void shot(WeaponShootEvent event) {
        Spec spec=specs.get(event.getWeaponTitle());
        if(spec==null || !(event.getProjectile() instanceof Projectile projectile))return;
        if(spec.invisible)for(var viewer:Bukkit.getOnlinePlayers())viewer.hideEntity(plugin,projectile);
        if(spec.trail==null)return;
        new BukkitRunnable() {
            Location previous=projectile.getLocation();double travelled=0,next=spec.trail.catchDistance;int age=0;
            @Override public void run() {
                Location current=projectile.getLocation();
                if(current.getWorld()!=previous.getWorld()){cancel();return;}
                double length=current.distance(previous);
                if(length>0 && length<256) {
                    var direction=current.toVector().subtract(previous.toVector()).multiply(1/length);
                    double end=travelled+length;
                    for(int n=0;next<=end&&n<256;n++,next+=spec.trail.spacing) {
                        Location at=previous.clone().add(direction.clone().multiply(Math.max(0,next-travelled)));
                        if(spec.trail.dust!=null)at.getWorld().spawnParticle(spec.trail.particle,at,1,0,0,0,0,spec.trail.dust);
                        else at.getWorld().spawnParticle(spec.trail.particle,at,1,0,0,0,0);
                    }
                    travelled=end;
                }
                previous=current;
                if(!projectile.isValid()||projectile.isDead()||++age>200)cancel();
            }
        }.runTaskTimer(plugin,1,1);
    }
    @EventHandler public void quit(PlayerQuitEvent event){cameraTick.remove(event.getPlayer().getUniqueId());}
}
