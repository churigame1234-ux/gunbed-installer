package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.GameStatus;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
/** A team's purchased shopkeeper biome skin, with an unadorned default villager. */
final class ShopAppearance {
    ShopAppearance(GunbedCore plugin){Bukkit.getScheduler().runTaskTimer(plugin,()->{
        for(var game:BedwarsAPI.getInstance().getGames())if(game.getStatus()==GameStatus.RUNNING)for(var store:game.getGameStores()){
            LivingEntity entity=store.getEntity();if(entity==null||!entity.isValid())continue;
            String skin="plains";
            if(store.getTeam()!=null)for(Player player:game.getConnectedPlayers())if(store.getTeam().getName().equals(game.getTeamOfPlayer(player)==null?"":game.getTeamOfPlayer(player).getName())){
                String owned=plugin.profiles.get(player.getUniqueId()).getString("cosmetics.shopkeeper","plains");if(plugin.points.owns(player.getUniqueId(),"shopkeeper:"+owned)){skin=owned;break;}
            }
            if(entity instanceof Villager villager){villager.setProfession(Villager.Profession.NONE);villager.setVillagerType(switch(skin){case "desert"->Villager.Type.DESERT;case "taiga"->Villager.Type.TAIGA;case "snow"->Villager.Type.SNOW;case "jungle"->Villager.Type.JUNGLE;default->Villager.Type.PLAINS;});}
            entity.customName(Component.text(store.getShopFile()!=null&&store.getShopFile().contains("upgrade")?"팀 업그레이드":"아이템 상점",NamedTextColor.YELLOW));entity.setCustomNameVisible(true);
        }
    },10,20);}
}
