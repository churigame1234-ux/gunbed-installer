package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.game.*;
import org.screamingsandals.bedwars.api.events.*;
import java.util.*;

/** Visible bodies are separate NPCs; the real dead player spectates at their death position. */
final class MatchCorpses implements Listener,AutoCloseable {
    private static final class Body {UUID npc,owner;Game game;boolean terminal;double vy;}
    private final Map<UUID,Body> bodies=new HashMap<>();
    private final Map<UUID,Location> deaths=new HashMap<>();
    private final GunbedCore plugin;
    MatchCorpses(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,1);}
    @EventHandler(priority=EventPriority.LOWEST)public void death(PlayerDeathEvent e){Player p=e.getEntity();Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);var team=g==null?null:g.getTeamOfPlayer(p);if(team==null||g.getStatus()!=GameStatus.RUNNING)return;Location at=p.getLocation().clone();deaths.put(p.getUniqueId(),EnvironmentDeaths.cause(p).equals("공허")?team.getTeamSpawn().clone():at);boolean terminal=!team.isTargetBlockExists();Bukkit.getScheduler().runTask(plugin,()->{UUID npc=CorpseNpcService.spawn(plugin,p,at);if(npc==null){plugin.getLogger().warning("Could not create corpse for "+p.getName());return;}Body body=new Body();body.npc=npc;body.owner=p.getUniqueId();body.game=g;body.terminal=terminal;bodies.put(npc,body);});}
    @EventHandler(priority=EventPriority.HIGHEST)public void respawn(PlayerRespawnEvent e){Location at=deaths.get(e.getPlayer().getUniqueId());if(at==null)return;if(at.getY()<at.getWorld().getMinHeight()+8)at=at.clone().add(0,at.getWorld().getMinHeight()+8-at.getY(),0);final Location camera=at;e.setRespawnLocation(camera);Bukkit.getScheduler().runTaskLater(plugin,()->{Player p=e.getPlayer();if(deaths.containsKey(p.getUniqueId())&&p.isOnline()&&p.getGameMode()==GameMode.SPECTATOR){p.teleport(camera);p.setAllowFlight(true);p.setFlying(true);p.setFallDistance(0);}},2);}
    @EventHandler(priority=EventPriority.LOWEST)public void revived(BedwarsPlayerRespawnedIngameEvent e){UUID id=e.getPlayer().getUniqueId();deaths.remove(id);for(Body b:List.copyOf(bodies.values()))if(b.owner.equals(id)&&!b.terminal)remove(b);}
    private void tick(){for(Body b:List.copyOf(bodies.values())){Entity npc=Bukkit.getEntity(b.npc);if(npc==null||!npc.isValid()||b.game.getStatus()!=GameStatus.RUNNING){remove(b);continue;}npc.setVelocity(new org.bukkit.util.Vector());npc.setPose(Pose.SWIMMING,true);Location at=npc.getLocation();if(at.getY()<at.getWorld().getMinHeight()-4){remove(b);continue;}if(at.clone().subtract(0,.08,0).getBlock().isPassable()){b.vy=Math.min(2,b.vy+.08);var hit=at.getWorld().rayTraceBlocks(at,new org.bukkit.util.Vector(0,-1,0),b.vy,FluidCollisionMode.NEVER,true);if(hit==null)npc.teleport(at.subtract(0,b.vy,0));else {npc.teleport(hit.getHitPosition().toLocation(at.getWorld()).add(0,.02,0));b.vy=0;}}else b.vy=0;}}
    private void remove(Body b){CorpseNpcService.remove(b.npc);bodies.remove(b.npc);}
    @EventHandler public void end(BedwarsGameEndingEvent e){for(Body b:List.copyOf(bodies.values()))if(b.game==e.getGame())remove(b);for(Player p:e.getGame().getConnectedPlayers())deaths.remove(p.getUniqueId());}
    @EventHandler public void leave(BedwarsPlayerLeaveEvent e){deaths.remove(e.getPlayer().getUniqueId());}
    @Override public void close(){for(Body b:List.copyOf(bodies.values()))remove(b);deaths.clear();}
}
