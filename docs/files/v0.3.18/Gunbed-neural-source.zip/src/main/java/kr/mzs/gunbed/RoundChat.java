package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.screamingsandals.bedwars.api.events.*;
import java.util.*;

/** Frozen round rosters retain eliminated teammates until they leave the arena. */
final class RoundChat implements Listener {
    private record Membership(String arena,String team,boolean enabled){}
    private final Map<UUID,Membership> members=new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID,String> arenas=new java.util.concurrent.ConcurrentHashMap<>();
    private final Set<UUID> toggled=java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final GunbedCore plugin;
    RoundChat(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);}
    @EventHandler public void start(BedwarsGameStartedEvent e){for(Player p:e.getGame().getConnectedPlayers()){arenas.put(p.getUniqueId(),e.getGame().getName());var t=e.getGame().getTeamOfPlayer(p);if(t!=null)members.put(p.getUniqueId(),new Membership(e.getGame().getName(),t.getName(),t.countConnectedPlayers()>1));}}
    @EventHandler public void join(BedwarsPlayerJoinEvent e){arenas.put(e.getPlayer().getUniqueId(),e.getGame().getName());}
    org.screamingsandals.bedwars.api.Team originalTeam(Player p){Membership m=members.get(p.getUniqueId());if(m==null)return null;var g=org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getGameByName(m.arena);return g==null?null:g.getTeamFromName(m.team);}
    private void toggle(Player p){Membership m=members.get(p.getUniqueId());if(m==null||!m.enabled){p.sendMessage("§e팀 경기에서만 팀 채팅을 사용할 수 있습니다.");return;}boolean on=toggled.add(p.getUniqueId());if(!on)toggled.remove(p.getUniqueId());p.sendMessage(on?"§b팀 채팅으로 전환했습니다. /t 또는 t로 전체 채팅 전환":"§a전체 채팅으로 전환했습니다.");}
    private void send(Player p,String text){Membership m=members.get(p.getUniqueId());if(m==null||!m.enabled)return;var line=net.kyori.adventure.text.Component.text("[TEAM] ",net.kyori.adventure.text.format.NamedTextColor.AQUA).append(TeamPalette.name(p)).append(net.kyori.adventure.text.Component.text(" » "+text,net.kyori.adventure.text.format.NamedTextColor.WHITE));for(Player target:Bukkit.getOnlinePlayers())if(m.equals(members.get(target.getUniqueId()))){target.sendMessage(line);if(!target.equals(p))plugin.play(target,"onMessage");}}
    @EventHandler(priority=EventPriority.LOWEST)public void command(PlayerCommandPreprocessEvent e){String[] parts=e.getMessage().split("\\s+",2);if(!Set.of("/t","/tc","/teamchat","/ㅅ").contains(parts[0].toLowerCase(Locale.ROOT)))return;e.setCancelled(true);if(parts.length==1)toggle(e.getPlayer());else send(e.getPlayer(),parts[1]);}
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void chat(AsyncPlayerChatEvent e){if(Set.of("set","설정","vote","추천","error","에러").contains(e.getMessage().strip().toLowerCase(Locale.ROOT)))return;UUID id=e.getPlayer().getUniqueId();if(e.getMessage().equalsIgnoreCase("t")){e.setCancelled(true);Bukkit.getScheduler().runTask(plugin,()->toggle(e.getPlayer()));}else if(toggled.contains(id)){e.setCancelled(true);Membership epoch=members.get(id);Bukkit.getScheduler().runTask(plugin,()->{if(epoch!=null&&epoch.equals(members.get(id)))send(e.getPlayer(),e.getMessage());});}else{String arena=arenas.get(id);if(arena!=null){e.setCancelled(true);String text=e.getMessage();Bukkit.getScheduler().runTask(plugin,()->{if(!arena.equals(arenas.get(id)))return;var game=org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getGameByName(arena);if(game==null)return;var line=net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(plugin.levels.badge(id)).append(TeamPalette.name(e.getPlayer())).append(net.kyori.adventure.text.Component.text(" » "+text,net.kyori.adventure.text.format.NamedTextColor.WHITE));for(Player target:game.getConnectedPlayers()){target.sendMessage(line);if(!target.equals(e.getPlayer()))plugin.play(target,"onMessage");}});}}}
    @EventHandler public void leave(BedwarsPlayerLeaveEvent e){UUID id=e.getPlayer().getUniqueId();members.remove(id);arenas.remove(id);toggled.remove(id);}
    @EventHandler public void quit(PlayerQuitEvent e){UUID id=e.getPlayer().getUniqueId();members.remove(id);arenas.remove(id);toggled.remove(id);}
    @EventHandler public void end(BedwarsGameEndEvent e){String name=e.getGame().getName();arenas.entrySet().removeIf(x->x.getValue().equals(name));members.entrySet().removeIf(x->{boolean remove=x.getValue().arena.equals(name);if(remove)toggled.remove(x.getKey());return remove;});}
}
