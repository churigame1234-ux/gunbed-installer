package kr.mzs.gunbed;

import com.google.gson.*;
import com.shampaggon.crackshot.events.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Original TRG sounds follow the same normalized cycles as the imported animation. */
final class TrgAudio implements Listener {
    private final GunbedCore plugin;
    private final JsonObject data;
    private final Map<UUID,Long> actions=new HashMap<>();
    private final Map<UUID,String> seen=new HashMap<>();
    TrgAudio(GunbedCore plugin){this.plugin=plugin;try(var in=plugin.getResource("trg-audio.json")){data=JsonParser.parseReader(new InputStreamReader(Objects.requireNonNull(in),StandardCharsets.UTF_8)).getAsJsonObject();}catch(IOException e){throw new UncheckedIOException(e);}Bukkit.getPluginManager().registerEvents(this,plugin);}
    void held(Player player,String title){String last=seen.put(player.getUniqueId(),title==null?"":title);if(!Objects.equals(last,title==null?"":title)){cancel(player);if("TRG".equals(title))sequence(player,"draw",data.get("drawMs").getAsLong());}}
    void virtualReload(Player player,String title,long duration){if(title.equals("TRG"))sequence(player,"reload",duration);}
    private void cancel(Player player){actions.merge(player.getUniqueId(),1L,Long::sum);}
    private void sound(Player player,String id,float volume){player.getWorld().playSound(player.getLocation(),id,SoundCategory.PLAYERS,volume,1);}
    private void sequence(Player player,String name,long duration){
        long token=actions.merge(player.getUniqueId(),1L,Long::sum);
        for(var raw:data.getAsJsonArray(name)){var event=raw.getAsJsonObject();long delay=Math.max(0,Math.round(event.get("cycle").getAsDouble()*duration/50));String id=event.get("sound").getAsString();Bukkit.getScheduler().runTaskLater(plugin,()->{if(player.isOnline()&&!player.isDead()&&actions.getOrDefault(player.getUniqueId(),-1L)==token&&plugin.visuals!=null&&"TRG".equals(plugin.visuals.title(player)))sound(player,id,.8f);},delay);}
    }
    @EventHandler(priority=EventPriority.MONITOR)public void shoot(WeaponShootEvent event){if(!event.getWeaponTitle().equals("TRG"))return;Player p=event.getPlayer();cancel(p);sound(p,data.get("fire").getAsString(),3);sequence(p,"shoot",data.get("shootMs").getAsLong());}
    @EventHandler(priority=EventPriority.MONITOR)public void reload(WeaponReloadEvent event){if(!event.getWeaponTitle().equals("TRG"))return;sequence(event.getPlayer(),"reload",Math.max(50,(long)(event.getReloadDuration()*event.getReloadSpeed()*50)));}
    @EventHandler public void switched(PlayerItemHeldEvent event){cancel(event.getPlayer());seen.remove(event.getPlayer().getUniqueId());}
    @EventHandler public void died(PlayerDeathEvent event){cancel(event.getEntity());seen.remove(event.getEntity().getUniqueId());}
    @EventHandler public void quit(PlayerQuitEvent event){actions.remove(event.getPlayer().getUniqueId());seen.remove(event.getPlayer().getUniqueId());}
}
