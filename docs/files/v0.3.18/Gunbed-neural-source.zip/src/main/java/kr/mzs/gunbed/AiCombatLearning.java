package kr.mzs.gunbed;

import com.google.gson.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Map-independent combat imitation, separate from map-specific route and bed-defense memory. */
final class AiCombatLearning implements Listener,AutoCloseable {
    record Stat(long n,double sum){}
    record Motion(String name,double forward,double side,boolean sprint,boolean sneak,int ticks){}
    private record Observation(String key,String motion,double given,double taken,double max,int tick){}
    private static final class Trace {
        Location last;int tick,shotTick=-1000,burstStart,frames;String weapon="",team="";int loaded;boolean reload;
        double given,taken;boolean teacher;final Deque<Observation> pending=new ArrayDeque<>();final Map<String,Stat> learned=new HashMap<>();
    }
    private final GunbedCore plugin;private final AiTelemetry telemetry;
    private final Map<String,Stat> values=new HashMap<>();private final Map<Game,Map<String,Stat>> frozen=new HashMap<>();
    private final Map<Game,Map<UUID,Trace>> traces=new HashMap<>();private final Path model;
    private final org.bukkit.scheduler.BukkitTask sampler,writer;private volatile String pending;private long episodes,seedFrames;
    private static final String[] MOVES={"advance","advance_right","right","retreat_right","retreat","retreat_left","left","advance_left","hold"};
    AiCombatLearning(GunbedCore p,AiTelemetry log){
        plugin=p;telemetry=log;model=p.getDataFolder().toPath().resolve("ai-learning/combat-policy.yml");
        if(Files.exists(model)){var cfg=YamlConfiguration.loadConfiguration(model.toFile());episodes=cfg.getLong("episodes");seedFrames=cfg.getLong("seed-frames");var section=cfg.getConfigurationSection("values");if(section!=null)for(String key:section.getKeys(false)){long n=cfg.getLong("values."+key+".samples");double sum=cfg.getDouble("values."+key+".score");if(n>0&&Double.isFinite(sum)&&Math.abs(sum)<=n*3&&values.size()<30000)values.put(key,new Stat(n,sum));}}
        else try(var in=p.getResource("ai-combat-priors.json")){if(in!=null){var root=JsonParser.parseReader(new java.io.InputStreamReader(in,StandardCharsets.UTF_8)).getAsJsonObject();seedFrames=root.get("frames").getAsLong();for(var e:root.getAsJsonObject("values").entrySet()){var v=e.getValue().getAsJsonObject();values.put(code(e.getKey()),new Stat(v.get("samples").getAsLong(),v.get("score").getAsDouble()));}}}catch(Exception e){p.getLogger().warning("Combat prior unavailable: "+e.getMessage());}
        Bukkit.getPluginManager().registerEvents(this,p);sampler=Bukkit.getScheduler().runTaskTimer(p,this::sample,4,4);writer=Bukkit.getScheduler().runTaskTimerAsynchronously(p,this::flush,40,40);save();
    }
    private static String code(String key){return Base64.getUrlEncoder().withoutPadding().encodeToString(key.getBytes(StandardCharsets.UTF_8));}
    private Map<String,Stat> policy(Game g){return frozen.computeIfAbsent(g,k->Map.copyOf(values));}
    private Trace trace(Game g,Player p){Trace t=traces.computeIfAbsent(g,k->new HashMap<>()).computeIfAbsent(p.getUniqueId(),id->new Trace());t.teacher=p.getName().equalsIgnoreCase("GMdong");if(g.getTeamOfPlayer(p)!=null)t.team=g.getTeamOfPlayer(p).getName();return t;}
    private boolean human(Player p,Game g){return g!=null&&g.getStatus()==GameStatus.RUNNING&&!BotRuntime.bot(p)&&!p.isDead()&&(p.getGameMode()==GameMode.SURVIVAL||p.getGameMode()==GameMode.ADVENTURE)&&g.getTeamOfPlayer(p)!=null&&!plugin.inventories.locked(p);}
    private Player enemy(Player p,Game g){var team=g.getTeamOfPlayer(p);return g.getConnectedPlayers().stream().filter(q->q!=p&&!q.isDead()&&q.getGameMode()!=GameMode.SPECTATOR&&q.getWorld()==p.getWorld()&&g.getTeamOfPlayer(q)!=null&&!team.isPlayerInTeam(q)&&q.getLocation().distanceSquared(p.getLocation())<6400&&(!q.isInvisible()||q.getLocation().distanceSquared(p.getLocation())<16)).sorted(Comparator.comparingDouble(q->q.getLocation().distanceSquared(p.getLocation()))).limit(8).filter(p::hasLineOfSight).findFirst().orElse(null);}
    static String context(String family,double distance,double hp){return family+"/"+(distance<6?"close":distance<20?"near":distance<60?"far":"travel")+"/"+(hp<.33?"low":hp<.66?"hurt":"healthy");}
    static String motion(double dx,double dz,double fx,double fz,double seconds){
        if(seconds<=0||Math.hypot(dx,dz)/seconds<.25)return "hold";double forward=dx*fx+dz*fz,side=dx*(-fz)+dz*fx;
        if(Math.abs(forward)>Math.abs(side)*1.5)return forward>0?"advance":"retreat";
        if(Math.abs(side)>Math.abs(forward)*1.5)return side>0?"right":"left";
        return (forward>0?"advance":"retreat")+"_"+(side>0?"right":"left");
    }
    private void add(Map<String,Stat> map,String key,long n,double score){String id=code(key);Stat old=map.getOrDefault(id,new Stat(0,0));if(map.size()<30000||map.containsKey(id))map.put(id,new Stat(old.n+n,old.sum+score));}
    private void settle(Trace t,int tick,boolean all){while(!t.pending.isEmpty()&&(all||tick-t.pending.peekFirst().tick>=20)){Observation o=t.pending.removeFirst();double reward=Math.max(-2,Math.min(2,4*((t.given-o.given)-(t.taken-o.taken))/Math.max(1,o.max)));add(t.learned,"motion/"+o.key+"/"+o.motion,1,reward);}}
    private void sample(){int tick=Bukkit.getCurrentTick();for(Game g:BedwarsAPI.getInstance().getGames())if(g.getStatus()==GameStatus.RUNNING)for(Player p:g.getConnectedPlayers()){
        if(!human(p,g)||!p.getName().equalsIgnoreCase("GMdong")&&Math.floorMod(tick/4+p.getUniqueId().hashCode(),5)!=0)continue;Trace t=trace(g,p);settle(t,tick,false);
        Location at=p.getLocation();int dt=tick-t.tick;Vector delta=t.last==null?new Vector():at.toVector().subtract(t.last.toVector());boolean continuous=t.last!=null&&t.last.getWorld()==at.getWorld()&&dt>0&&dt<=24&&delta.lengthSquared()<=36;
        AiGuns.Gun gun=AiGuns.held(plugin,p);Player foe=enemy(p,g);double max=p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue(),distance=foe==null?999:foe.getLocation().distance(at);String context=context(gun.family(),distance,p.getHealth()/max);
        Vector forward=foe==null?p.getEyeLocation().getDirection().setY(0):foe.getLocation().toVector().subtract(at.toVector()).setY(0);if(forward.lengthSquared()>.0001)forward.normalize();else forward.setZ(1);
        String move=continuous?motion(delta.getX(),delta.getZ(),forward.getX(),forward.getZ(),dt/20.0):"hold";
        boolean engaged=foe!=null||tick-t.shotTick<=20;
        if(continuous&&engaged){t.pending.addLast(new Observation(context,move,t.given,t.taken,max,tick));t.frames++;add(t.learned,"jump-opportunity/"+gun.family(),1,0);if(!move.equals("hold")){add(t.learned,"sprint/"+gun.family(),1,p.isSprinting()?1:0);add(t.learned,"sneak/"+gun.family(),1,p.isSneaking()?1:0);}}
        if(continuous&&!t.weapon.equals(gun.id())&&engaged){String oldFamily=AiGuns.family(plugin,t.weapon);if(!oldFamily.equals("pistol")&&gun.family().equals("pistol")&&(t.loaded==0||t.reload))add(t.learned,"secondary/"+oldFamily,1,1);telemetry.record(p,"human-switch",Map.of("from",t.weapon,"to",gun.id(),"previousLoaded",t.loaded,"previousReload",t.reload));}
        if(foe!=null&&tick-t.shotTick<12){double horizontal=Math.sqrt(Math.pow(foe.getX()-p.getX(),2)+Math.pow(foe.getZ()-p.getZ(),2));double height=p.getEyeLocation().getY()-Math.tan(Math.toRadians(p.getPitch()))*horizontal-foe.getY();if(height>=.2&&height<=1.9)add(t.learned,"aim/"+gun.family(),1,height);}
        Map<String,Object> row=new LinkedHashMap<>();row.put("pos",List.of(at.getX(),at.getY(),at.getZ()));row.put("motion",move);row.put("context",context);row.put("weapon",gun.id());row.put("loaded",gun.loaded());row.put("reload",AiGuns.reloading(plugin,p));row.put("reloadProgress",AiGuns.progress(plugin,p));row.put("look",List.of(p.getYaw(),p.getPitch()));row.put("sprint",p.isSprinting());row.put("sneak",p.isSneaking());row.put("visibleTarget",foe==null?"":foe.getUniqueId().toString());telemetry.record(p,"human-frame",row);
        t.last=at;t.tick=tick;t.weapon=gun.id();t.loaded=gun.loaded();t.reload=AiGuns.reloading(plugin,p);
    }}
    void shot(Player p,String weapon){Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(!human(p,g))return;Trace t=trace(g,p);add(t.learned,"attempt/"+weapon,1,0);int now=Bukkit.getCurrentTick();if(now-t.shotTick>10){if(t.burstStart>0&&t.shotTick>=t.burstStart)add(t.learned,"burst/"+AiGuns.family(plugin,weapon),1,Math.min(2,(t.shotTick-t.burstStart+2)/20.0));t.burstStart=now;}t.shotTick=now;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void hit(EntityDamageByEntityEvent e){
        if(!(e.getEntity() instanceof LivingEntity victim))return;double amount=AiTelemetry.damageAmount(e,victim);if(amount<=0)return;Player source=AiTelemetry.attacker(e.getDamager());
        if(victim instanceof Player p){Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(human(p,g))trace(g,p).taken+=amount;}
        if(source!=null){Game g=BedwarsAPI.getInstance().getGameOfPlayer(source);if(human(source,g)){Trace t=trace(g,source);t.given+=amount;String id=AiGuns.damageId(plugin,source,e.getDamager());if(!id.isEmpty())add(t.learned,"weapon/"+id,1,Math.min(2,amount/1000));}}
    }
    private Stat find(Game g,String key){return policy(g).get(code(key));}
    private double mean(Game g,String key,double fallback){Stat s=find(g,key);return s==null||s.n<3?fallback:s.sum/s.n;}
    Motion choose(Game g,String family,double distance,double hp,long token){
        String exact=context(family,distance,hp);String[] contexts={exact,family+"/any/any","any/any/any"};double[] weights=new double[MOVES.length];
        for(String c:contexts){double total=0;for(int i=0;i<MOVES.length;i++){Stat s=find(g,"motion/"+c+"/"+MOVES[i]);weights[i]=s==null?0:Math.max(0,s.sum/s.n+.12)*Math.sqrt(Math.min(500,s.n));total+=weights[i];}if(total>0)break;}
        double total=Arrays.stream(weights).sum();if(total<=0){weights=new double[]{1,.5,1,.3,.3,.3,1,.5,.2};total=Arrays.stream(weights).sum();}
        SplittableRandom random=new SplittableRandom(token);double pick=random.nextDouble()*total;int index=0;for(;index<weights.length-1;index++){pick-=weights[index];if(pick<=0)break;}
        String name=MOVES[index];double forward=name.contains("advance")?1:name.contains("retreat")?-1:0,side=name.contains("right")?1:name.contains("left")?-1:0;
        return new Motion(name,forward,side,random.nextDouble()<Math.max(0,Math.min(.95,mean(g,"sprint/"+family,.15))),random.nextDouble()<Math.max(0,Math.min(.8,mean(g,"sneak/"+family,.05))),10+random.nextInt(9));
    }
    void action(Player p,String action){if(!action.equals("double-jump"))return;Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(!human(p,g))return;Trace t=trace(g,p);add(t.learned,"jump/"+AiGuns.held(plugin,p).family(),1,1);telemetry.record(p,"human-double-jump",Map.of("weapon",AiGuns.held(plugin,p).id()));}
    boolean jump(Game g,String family,long token){Stat events=find(g,"jump/"+family),opportunities=find(g,"jump-opportunity/"+family);double chance=events==null?0:Math.min(.2,events.n*4.0/Math.max(1,opportunities==null?100:opportunities.n));return new SplittableRandom(token).nextDouble()<chance;}
    double aimHeight(Game g,String family){return Math.max(.6,Math.min(1.6,mean(g,"aim/"+family,1.1)));}
    int burstTicks(Game g,String family){return (int)Math.max(6,Math.min(36,mean(g,"burst/"+family,.65)*20));}
    boolean secondaryEarly(Game g,String family){return mean(g,"secondary/"+family,0)>.5;}
    String preferredWeapon(Game g,List<String> legal){return legal.stream().filter(id->{Stat s=find(g,"weapon/"+id);return s!=null&&s.n>=3&&s.sum>0;}).max(Comparator.comparingDouble(id->{Stat s=find(g,"weapon/"+id);Stat shots=find(g,"attempt/"+id);return s.sum/Math.max(3,shots==null?s.n:shots.n);})).orElse("");}
    @EventHandler(priority=EventPriority.MONITOR)public void start(BedwarsGameStartedEvent e){frozen.put(e.getGame(),Map.copyOf(values));}
    @EventHandler(priority=EventPriority.MONITOR)public void ending(BedwarsGameEndingEvent e){var round=traces.remove(e.getGame());if(round==null||e.getWinningTeam()==null||!plugin.learning.adaptation.accepts(e.getGame(),e.getWinningTeam()))return;int accepted=0;for(var entry:round.entrySet()){Trace t=entry.getValue();settle(t,Bukkit.getCurrentTick(),true);if(t.frames<25)continue;boolean won=e.getWinningTeam().getName().equals(t.team);int weight=t.teacher?4:1;for(var row:t.learned.entrySet()){Stat old=values.getOrDefault(row.getKey(),new Stat(0,0)),v=row.getValue();String key=new String(Base64.getUrlDecoder().decode(row.getKey()),StandardCharsets.UTF_8);double bonus=key.startsWith("motion/")?(won?.1:-.04)*v.n:0;values.put(row.getKey(),new Stat(old.n+v.n*weight,old.sum+(v.sum+bonus)*weight));}accepted++;episodes++;}if(accepted>0)save();}
    @EventHandler public void end(BedwarsGameEndEvent e){traces.remove(e.getGame());frozen.remove(e.getGame());}
    Map<String,Object> status(Game g){return Map.of("episodes",episodes,"features",values.size(),"seedFrames",seedFrames,"frozenFeatures",g==null?0:policy(g).size(),"humanTraces",traces.values().stream().mapToInt(Map::size).sum());}
    private void save(){var cfg=new YamlConfiguration();cfg.set("schema",1);cfg.set("episodes",episodes);cfg.set("seed-frames",seedFrames);cfg.set("teacher-weight",4);cfg.set("scope","human combat on all maps; map routes remain separate");cfg.set("activation","next round snapshot");for(var e:values.entrySet()){cfg.set("values."+e.getKey()+".samples",e.getValue().n);cfg.set("values."+e.getKey()+".score",e.getValue().sum);}pending=cfg.saveToString();}
    private synchronized void flush(){String text=pending;if(text==null)return;try{Files.createDirectories(model.getParent());Path temporary=model.resolveSibling("combat-policy.yml.tmp");Files.writeString(temporary,text,StandardCharsets.UTF_8);Files.move(temporary,model,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);if(pending==text)pending=null;}catch(Exception e){plugin.getLogger().warning("Combat policy save will retry: "+e.getMessage());}}
    void persist() throws java.io.IOException {flush();if(pending!=null)throw new java.io.IOException("Combat policy is not durable");}
    @Override public void close(){sampler.cancel();writer.cancel();save();flush();traces.clear();frozen.clear();}
}
