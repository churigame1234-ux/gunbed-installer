package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.game.*;
import java.util.*;

/** Team-owned arena flights, bounded terrain edits and one shared player contact cooldown. */
final class SuddenDragons implements Listener {
    private static final class Flight {Game game;String team;Location center;int index,respawnAt;EnderDragon dragon;}
    private final List<Flight> flights=new ArrayList<>();private final Set<Game> games=new HashSet<>();
    private final Map<UUID,Integer> damaged=new HashMap<>();private boolean applying;
    private final GunbedCore plugin;
    SuddenDragons(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,1);DragonTestCommand.install(p);}
    void start(Game game){clear(game);games.add(game);reconcile(game);}
    private void reconcile(Game g){for(RunningTeam team:g.getRunningTeams()){if(!team.isAlive())continue;int desired=plugin.bedwars.shop.level(g,team,"dragon-buff")>0?2:1;long have=flights.stream().filter(f->f.game==g&&f.team.equals(team.getName())).count();for(int n=(int)have;n<desired;n++){Flight f=new Flight();f.game=g;f.team=team.getName();f.index=flights.size();double x=g.getRunningTeams().stream().mapToDouble(t->t.getTeamSpawn().getX()).average().orElse(0),z=g.getRunningTeams().stream().mapToDouble(t->t.getTeamSpawn().getZ()).average().orElse(0);f.center=new Location(g.getGameWorld(),x,team.getTeamSpawn().getY()+14,z);flights.add(f);spawn(f);}}}
    private void spawn(Flight f){double angle=f.index*2.4;Location at=f.center.clone().add(Math.cos(angle)*24,0,Math.sin(angle)*24);f.dragon=at.getWorld().spawn(at,EnderDragon.class,d->{d.setPersistent(false);d.setAI(true);d.setGravity(false);d.setPhase(EnderDragon.Phase.HOVER);d.getAttribute(Attribute.MAX_HEALTH).setBaseValue(500000);d.setHealth(d.getAttribute(Attribute.MAX_HEALTH).getValue());d.customName(TeamPalette.of(f.game,f.game.getTeamFromName(f.team)).text(TeamPalette.of(f.game,f.game.getTeamFromName(f.team)).name()+"팀 엔더드래곤"));});BedwarsAPI.getInstance().registerEntityToGame(f.dragon,f.game);}
    private void move(EnderDragon dragon,Location to){
        try{
            // Direct position edits must explicitly notify the entity tracker.
            // Otherwise existing viewers can retain the old spawn coordinates.
            // Keep AI enabled in HOVER so wings and multipart hitboxes still animate.
            dragon.setAI(true);dragon.setPhase(EnderDragon.Phase.HOVER);
            Object handle=dragon.getClass().getMethod("getHandle").invoke(dragon);
            handle.getClass().getMethod("setPos",double.class,double.class,double.class).invoke(handle,to.getX(),to.getY(),to.getZ());
            handle.getClass().getMethod("setYRot",float.class).invoke(handle,to.getYaw()+180f);
            handle.getClass().getField("needsSync").setBoolean(handle,true);
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Dragon movement synchronization failed",e);}
    }

    private boolean enemy(Flight f,Player p){var t=f.game.getTeamOfPlayer(p);return t!=null&&!t.getName().equals(f.team)&&!p.isDead()&&p.getGameMode()!=GameMode.SPECTATOR&&p.getWorld()==f.game.getGameWorld();}
    private void tick(){int tick=Bukkit.getCurrentTick(),budget=64;if(tick%20==0)for(Game g:List.copyOf(games))if(g.getStatus()==GameStatus.RUNNING)reconcile(g);
        for(var it=flights.iterator();it.hasNext();){Flight f=it.next();RunningTeam running=f.game.getRunningTeams().stream().filter(t->t.getName().equals(f.team)).findFirst().orElse(null);if(f.game.getStatus()!=GameStatus.RUNNING||running==null||!running.isAlive()){if(f.dragon!=null)f.dragon.remove();it.remove();continue;}
            if(f.dragon==null){if(tick>=f.respawnAt)spawn(f);continue;}
            if(!f.dragon.isValid()||f.dragon.isDead()||f.dragon.getHealth()<=0){f.dragon.remove();f.dragon=null;f.respawnAt=tick+3600;continue;}
            var targets=f.game.getConnectedPlayers().stream().filter(p->enemy(f,p)).toList();
            Location next=DragonFlightMotion.advance(f.dragon,f.center,f.index,targets,tick,f.game);
            move(f.dragon,next);
            Location at=f.dragon.getLocation();if((tick+f.index)%2==0&&budget>0){int edits=0;for(int dx=-3;dx<=3&&edits<8&&budget>0;dx++)for(int dy=-2;dy<=2&&edits<8&&budget>0;dy++)for(int dz=-3;dz<=3&&edits<8&&budget>0;dz++){var block=at.clone().add(dx,dy,dz).getBlock();if(block.getType().isAir()||Set.of(Material.BEDROCK,Material.BARRIER,Material.CHEST,Material.TRAPPED_CHEST,Material.ENDER_CHEST).contains(block.getType())||block.getType().name().endsWith("_BED")||!f.game.isLocationInArena(block.getLocation()))continue;LegacyActions.recordBlock(block);var data=block.getBlockData();block.setType(Material.AIR,false);if(edits==0)at.getWorld().spawnParticle(Particle.BLOCK,block.getLocation().add(.5,.5,.5),6,.3,.3,.3,0,data,true);edits++;budget--;}}
            if(tick%20==0){double amount=plugin.damages.value("sudden-death.dragon",2000);if(plugin.turrets!=null)plugin.turrets.dragonHit(f.game,f.team,at,5,amount);for(LivingEntity mob:BattleTargets.enemies(plugin,f.game,f.team,at,5))if(!(mob instanceof Player)&&!(mob instanceof EnderDragon)&&tick-damaged.getOrDefault(mob.getUniqueId(),-100)>=20){damaged.put(mob.getUniqueId(),tick);applying=true;try{mob.setNoDamageTicks(0);mob.damage(amount,f.dragon);}finally{applying=false;}}}
            for(Player p:targets)if(p.getLocation().distanceSquared(at)<25&&tick-damaged.getOrDefault(p.getUniqueId(),-100)>=20){damaged.put(p.getUniqueId(),tick);applying=true;try{p.damage(plugin.damages.value("sudden-death.dragon",2000),f.dragon);}finally{applying=false;}if(!p.isDead()&&!plugin.inventories.locked(p)&&!plugin.inventories.protectedLife(p)&&!plugin.weaponModes.anchored(p)&&!plugin.turrets.building(p)){Vector push=p.getLocation().toVector().subtract(at.toVector()).setY(.7);if(push.lengthSquared()>.01)p.setVelocity(push.normalize().multiply(1.2));}}
        }
        games.removeIf(g->g.getStatus()!=GameStatus.RUNNING);
    }
    String team(Entity entity){if(entity instanceof ComplexEntityPart part)entity=part.getParent();for(Flight f:flights)if(f.dragon==entity)return f.team;return null;}
    private boolean own(Entity entity){if(entity instanceof ComplexEntityPart part)entity=part.getParent();Entity candidate=entity;return flights.stream().anyMatch(f->f.dragon==candidate);}
    boolean damage(Entity entity,Player source,double amount){if(entity instanceof ComplexEntityPart part)entity=part.getParent();for(Flight f:flights)if(f.dragon==entity){if(source==null||BedwarsAPI.getInstance().getGameOfPlayer(source)!=f.game||amount<=0||!Double.isFinite(amount)||f.dragon.isDead())return true;double before=f.dragon.getHealth();f.dragon.setHealth(Math.max(0,before-amount));DragonHitFeedback.hit(plugin,f.game,f.team,f.dragon,source,Math.min(before,amount));return true;}return false;}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void shot(com.shampaggon.crackshot.events.WeaponDamageEntityEvent e){if(own(e.getVictim())&&DragonCrackShotImpact.spent(e.getDamager())){e.setCancelled(true);return;}if(damage(e.getVictim(),e.getPlayer(),e.getDamage())){DragonCrackShotImpact.mark(e.getDamager());e.setCancelled(true);}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void hurt(EntityDamageByEntityEvent e){Player p=e.getDamager() instanceof Player player?player:e.getDamager() instanceof Projectile q&&q.getShooter() instanceof Player player?player:null;if(own(e.getEntity())){e.setCancelled(true);if(!DragonCrackShotImpact.spent(e.getDamager()))damage(e.getEntity(),p,e.getDamage());}}
    @EventHandler(priority=EventPriority.HIGHEST)public void naturalDamage(EntityDamageByEntityEvent e){if(own(e.getDamager())){if(!applying)e.setCancelled(true);else e.setDamage(plugin.damages.value("sudden-death.dragon",2000));}}
    @EventHandler(priority=EventPriority.HIGHEST)public void naturalExplosion(EntityExplodeEvent e){if(own(e.getEntity()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST)public void naturalBlockChange(EntityChangeBlockEvent e){if(own(e.getEntity()))e.setCancelled(true);}
    @EventHandler public void loot(EntityDeathEvent e){if(own(e.getEntity())){e.getDrops().clear();e.setDroppedExp(0);}}
    void clear(Game game){games.remove(game);flights.removeIf(f->{if(f.game!=game)return false;if(f.dragon!=null)f.dragon.remove();return true;});}
}
