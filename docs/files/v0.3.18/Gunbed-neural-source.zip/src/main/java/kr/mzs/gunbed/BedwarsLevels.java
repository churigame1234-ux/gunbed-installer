package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.*;
import java.util.*;

/** Independent BedWars experience; one epoch reset, with the legacy source retained. */
final class BedwarsLevels implements Listener {
    private final GunbedCore plugin;
    private final Map<Game,Map<UUID,Integer>> seconds=new HashMap<>();
    private final Map<Game,Set<String>> firstKills=new HashMap<>();
    BedwarsLevels(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,20,20);}
    static int level(long xp){long laps=xp/487000,rest=xp%487000;int l=(int)Math.min(Integer.MAX_VALUE-100,laps*100);for(int n:new int[]{500,1000,2000,3500}){if(rest<n)return l;rest-=n;l++;}return l+(int)(rest/5000);}
    static long next(long xp){long r=xp%487000;for(int n:new int[]{500,1000,2000,3500}){if(r<n)return n-r;r-=n;}return 5000-r%5000;}
    long xp(UUID id){return plugin.profiles.get(id).getLong("bedwars-levels.xp",0);}
    int level(UUID id){return level(xp(id));}
    String badge(UUID id){int n=level(id);String[] colors={"§7","§f","§6","§b","§2","§3","§4","§d","§9","§5","§e"};return colors[Math.min(colors.length-1,n/100)]+"["+n+"✫] §r";}
    void add(UUID id,long value){plugin.profiles.set(id,"bedwars-levels.xp",Math.max(0,Math.addExact(xp(id),value)));}
    private void tick(){for(var e:seconds.entrySet())if(e.getKey().getStatus()==GameStatus.RUNNING)for(Player p:e.getKey().getConnectedPlayers()){if(e.getKey().getTeamOfPlayer(p)==null)continue;int s=e.getValue().merge(p.getUniqueId(),1,Integer::sum);if(s%60==0)add(p.getUniqueId(),15);}}
    void generatorPickup(Player p,Material type,int amount){if(type==Material.DIAMOND||type==Material.EMERALD)add(p.getUniqueId(),(long)amount*(type==Material.DIAMOND?2:3));}
    @EventHandler(priority=EventPriority.MONITOR)public void kill(BedwarsPlayerKilledEvent e){Player killer=e.getKiller()==null?plugin.combatPresentation.credit(e.getPlayer()):e.getKiller();if(killer==null||killer.equals(e.getPlayer()))return;if(plugin.combatPresentation.finalDeath(e.getPlayer()))add(killer.getUniqueId(),10);else if(firstKills.computeIfAbsent(e.getGame(),g->new HashSet<>()).add(killer.getUniqueId()+"/"+e.getPlayer().getUniqueId()))add(killer.getUniqueId(),5);}
    @EventHandler(priority=EventPriority.MONITOR)public void bed(BedwarsTargetBlockDestroyedEvent e){if(e.getPlayer()!=null)add(e.getPlayer().getUniqueId(),15);}
    @EventHandler public void start(BedwarsGameStartedEvent e){seconds.put(e.getGame(),new HashMap<>());firstKills.put(e.getGame(),new HashSet<>());}
    @EventHandler public void ending(BedwarsGameEndingEvent e){if(e.getWinningTeam()!=null)for(Player p:e.getWinningTeam().getConnectedPlayers())add(p.getUniqueId(),e.getGame().getAvailableTeams().stream().anyMatch(t->t.getMaxPlayers()>=3)?50:100);}
    @EventHandler public void end(BedwarsGameEndEvent e){seconds.remove(e.getGame());firstKills.remove(e.getGame());}
}
