package kr.mzs.gunbed;

import com.google.gson.Gson;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.events.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;

/** Bounded asynchronous gameplay diagnostics. Human demonstrations and bot outcomes stay distinct. */
final class AiTelemetry implements Listener,AutoCloseable {
    static final class Stats {long shots,hits,reloads,switches,blocked,deaths;double dealt,taken;int incoming=-10000,lastTick;String decision="",reason="",weapon="";}
    private final GunbedCore plugin;private final Gson gson=new Gson();
    private final Map<UUID,Stats> stats=new HashMap<>();private final Map<Object,String> rounds=new HashMap<>();
    private final ArrayBlockingQueue<String> queue=new ArrayBlockingQueue<>(8192);
    private final Path folder;private final org.bukkit.scheduler.BukkitTask writer;
    private LocalDate day;private long bytes,dropped;private String lastError="";
    AiTelemetry(GunbedCore p){plugin=p;folder=p.getDataFolder().toPath().resolve("ai-telemetry");Bukkit.getPluginManager().registerEvents(this,p);writer=Bukkit.getScheduler().runTaskTimerAsynchronously(p,this::flush,40,40);}
    Stats stats(Player p){return stats.computeIfAbsent(p.getUniqueId(),id->new Stats());}
    boolean pressured(Player p,int tick){return tick-stats(p).incoming<30;}
    void record(Player p,String event,Map<String,?> details){
        var game=BedwarsAPI.getInstance().getGameOfPlayer(p);if(game==null||!plugin.getConfig().getBoolean("ai.telemetry.enabled",true))return;
        Map<String,Object> row=new LinkedHashMap<>();row.put("time",System.currentTimeMillis());row.put("tick",Bukkit.getCurrentTick());row.put("round",rounds.computeIfAbsent(game,g->game.getName()+":"+System.currentTimeMillis()));row.put("map",AiLearning.map(game));row.put("player",p.getUniqueId().toString());row.put("name",p.getName());row.put("actor",BotRuntime.bot(p)?"bot":"human");row.put("teacher",p.getName().equalsIgnoreCase("GMdong"));row.put("event",event);row.putAll(details);if(!queue.offer(gson.toJson(row)))dropped++;
    }
    void decision(Player p,int tick,String action,String reason,Map<String,?> details){
        Stats s=stats(p);int interval=Math.max(4,plugin.getConfig().getInt("ai.telemetry.interval-ticks",10));boolean changed=!action.equals(s.decision)||!reason.equals(s.reason);
        if(!changed&&tick-s.lastTick<interval)return;s.decision=action;s.reason=reason;s.lastTick=tick;
        Map<String,Object> row=new LinkedHashMap<>(details);row.put("action",action);row.put("reason",reason);row.put("pos",List.of(p.getX(),p.getY(),p.getZ()));record(p,"decision",row);
    }
    void shot(Player p,String weapon){if(!BotRuntime.bot(p))return;Stats s=stats(p);s.shots++;s.weapon=weapon;record(p,"shot",Map.of("weapon",weapon,"shotEvent",s.shots));}
    void reload(Player p,String weapon){if(!BotRuntime.bot(p))return;stats(p).reloads++;record(p,"reload-start",Map.of("weapon",weapon));}
    void reloadEnd(Player p,String weapon,String outcome,int before,int after){if(BotRuntime.bot(p))record(p,"reload-end",Map.of("weapon",weapon,"outcome",outcome,"loadedBefore",before,"loadedAfter",after));}
    void switched(Player p,int old,int slot,String reason){stats(p).switches++;record(p,"weapon-switch",Map.of("from",old,"to",slot,"reason",reason));}
    void blocked(Player p,String reason,Location at){stats(p).blocked++;record(p,"path-blocked",Map.of("reason",reason,"cell",List.of(at.getBlockX(),at.getBlockY(),at.getBlockZ())));}
    static Player attacker(Entity e){return e instanceof Player p?p:e instanceof Projectile shot&&shot.getShooter() instanceof Player p?p:null;}
    static double damageAmount(EntityDamageByEntityEvent e,LivingEntity target){
        double absorbed=e.isApplicable(EntityDamageEvent.DamageModifier.ABSORPTION)?Math.min(target.getAbsorptionAmount(),Math.max(0,-e.getDamage(EntityDamageEvent.DamageModifier.ABSORPTION))):0;
        return Math.min(target.getHealth()+target.getAbsorptionAmount(),Math.max(0,e.getFinalDamage())+absorbed);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void hit(EntityDamageByEntityEvent e){
        if(!(e.getEntity() instanceof LivingEntity target))return;Player source=attacker(e.getDamager());
        double amount=damageAmount(e,target);if(amount<=0)return;
        if(target instanceof Player p&&BotRuntime.bot(p)){Stats s=stats(p);s.taken+=amount;s.incoming=Bukkit.getCurrentTick();record(p,"damaged",Map.of("damage",amount,"source",source==null?e.getDamager().getType().name():source.getName(),"remaining",Math.max(0,p.getHealth()-e.getFinalDamage())));}
        if(source!=null&&BotRuntime.bot(source)){Stats s=stats(source);s.hits++;s.dealt+=amount;record(source,"hit",Map.of("target",target.getUniqueId().toString(),"targetType",target.getType().name(),"weapon",AiGuns.damageId(plugin,source,e.getDamager()),"damage",amount,"hitEvent",s.hits));}
    }
    @EventHandler(priority=EventPriority.MONITOR)public void death(PlayerDeathEvent e){if(BotRuntime.bot(e.getEntity())){Stats s=stats(e.getEntity());s.deaths++;record(e.getEntity(),"death",Map.of("deaths",s.deaths,"cause",e.getEntity().getLastDamageCause()==null?"unknown":e.getEntity().getLastDamageCause().getCause().name()));}}
    @EventHandler(priority=EventPriority.MONITOR)public void start(BedwarsGameStartedEvent e){rounds.put(e.getGame(),e.getGame().getName()+":"+System.currentTimeMillis());for(Player p:e.getGame().getConnectedPlayers())if(BotRuntime.bot(p))stats.remove(p.getUniqueId());}
    @EventHandler(priority=EventPriority.MONITOR)public void ending(BedwarsGameEndingEvent e){for(Player p:e.getGame().getConnectedPlayers())if(BotRuntime.bot(p)){Stats s=stats(p);record(p,"round-summary",Map.of("shots",s.shots,"hitEvents",s.hits,"damage",s.dealt,"damageTaken",s.taken,"reloads",s.reloads,"switches",s.switches,"blocked",s.blocked,"deaths",s.deaths,"won",e.getWinningTeam()!=null&&e.getWinningTeam().isPlayerInTeam(p)));}}
    @EventHandler public void end(BedwarsGameEndEvent e){rounds.remove(e.getGame());for(Player p:e.getGame().getConnectedPlayers())if(BotRuntime.bot(p))stats.remove(p.getUniqueId());}
    private synchronized void flush(){try{
        Files.createDirectories(folder);LocalDate today=LocalDate.now();Path log=folder.resolve("combat-"+today+".jsonl");
        if(!today.equals(day)){day=today;bytes=Files.exists(log)?Files.size(log):0;try(var files=Files.list(folder)){for(Path f:files.filter(f->f.getFileName().toString().matches("combat-[0-9]{4}-[0-9]{2}-[0-9]{2}\\.jsonl")).toList())if(LocalDate.parse(f.getFileName().toString().substring(7,17)).isBefore(today.minusDays(30)))Files.delete(f);}}
        long cap=Math.max(8,plugin.getConfig().getLong("ai.telemetry.max-daily-mb",128))*1048576;List<String> batch=new ArrayList<>(4096);queue.drainTo(batch,4096);if(batch.isEmpty())return;
        String payload=String.join("\n",batch)+"\n";byte[] data=payload.getBytes(StandardCharsets.UTF_8);if(bytes+data.length>cap){dropped+=batch.size();return;}Files.write(log,data,StandardOpenOption.CREATE,StandardOpenOption.APPEND);bytes+=data.length;lastError="";
    }catch(Exception e){lastError=e.toString();plugin.getLogger().warning("AI telemetry write failed: "+e.getMessage());}}
    Map<String,Object> status(){return Map.of("queued",queue.size(),"dropped",dropped,"dailyBytes",bytes,"lastError",lastError);}
    @Override public void close(){writer.cancel();for(int n=0;n<3&&!queue.isEmpty();n++)flush();if(!queue.isEmpty()){dropped+=queue.size();queue.clear();}stats.clear();rounds.clear();}
}
