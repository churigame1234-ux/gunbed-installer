package kr.mzs.gunbed;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/** Read the real weapon state. Bots never synthesize ammunition or complete reloads themselves. */
final class AiGuns {
    record Gun(String id,String family,int loaded,int capacity,int reserve){boolean ready(){return loaded!=0&&!id.isEmpty();}}
    static String id(GunbedCore p,ItemStack item){String result=p.ammo.id(item);if(result.isEmpty()){String melee=p.addonMelee.id(item);return melee==null?"":"lr:"+melee;}return result;}
    static String damageId(GunbedCore plugin,Player source,org.bukkit.entity.Entity damager){if(plugin.throwables.damageKind()!=null)return "throwable:"+plugin.throwables.damageKind();if(plugin.turrets!=null&&plugin.turrets.damageOrigin()!=null)return "turret:"+plugin.turrets.damageOrigin().kind();var nativeGun=plugin.taWeapons.damageDefinition();if(nativeGun!=null)return "ta:"+nativeGun.id();if(damager instanceof org.bukkit.entity.Projectile projectile){String title=plugin.visuals.cs.getWeaponTitle(projectile);if(title!=null)return "cs:"+title;}return id(plugin,source.getInventory().getItemInMainHand());}
    static String family(GunbedCore p,String id){
        if(id.isEmpty())return "empty";if(id.startsWith("lr:"))return "melee";
        var w=p.arsenal.weapons().stream().filter(g->g.id().equals(id)).findFirst().orElse(null);
        if(w!=null&&w.role().equals("melee"))return "melee";if(w!=null&&w.role().equals("secondary"))return "pistol";
        return p.arsenal.category(id);
    }
    static Gun slot(GunbedCore p,Player who,int slot){
        ItemStack item=who.getInventory().getItem(slot);String id=id(p,item);int loaded=0,capacity=p.ammo.capacity(id);
        var ta=p.taWeapons.definition(item);if(ta!=null)loaded=p.taWeapons.loaded(item);
        else if(id.startsWith("cs:")){String title=p.visuals.cs.getWeaponTitle(item);if(title!=null)loaded=p.visuals.cs.getHandle().getAmmoBetweenBrackets(who,title,item);}
        if(family(p,id).equals("melee"))loaded=-1;
        return new Gun(id,family(p,id),loaded,capacity,id.isEmpty()?0:p.ammo.reserve(who,id));
    }
    static Gun held(GunbedCore p,Player who){return slot(p,who,who.getInventory().getHeldItemSlot());}
    static boolean reloading(GunbedCore p,Player who){return p.ammo.reloading(who)||p.taWeapons.reloading(who);}
    static double progress(GunbedCore p,Player who){return p.ammo.reloading(who)?p.ammo.reloadProgress(who):p.taWeapons.reloadProgress(who);}
    static void reload(GunbedCore p,Player who){if(p.taWeapons.held(who)!=null)p.taWeapons.reload(who);else {String title=p.visuals.title(who);if(title!=null)p.ammo.reload(who,title);}}
    static double reach(GunbedCore plugin,Player p,Gun gun){
        if(gun.family().equals("melee"))return plugin.meleeSettings.shape(gun.id()).reach();
        var definition=plugin.taWeapons.definition(p.getInventory().getItem(0));
        if(definition!=null&&gun.id().equals("ta:"+definition.id())){var b=definition.data().getAsJsonObject("bullet");double speed=b.has("speed")?b.get("speed").getAsDouble():200,life=b.has("life")?b.get("life").getAsDouble():1;return Math.max(4,Math.min(128,speed*life*.85));}
        if(gun.id().startsWith("cs:")){var h=plugin.visuals.cs.getHandle();String subtype=h.getString(gun.id().substring(3)+".Shooting.Projectile_Subtype");String type=h.getString(gun.id().substring(3)+".Shooting.Projectile_Type");if("energy".equalsIgnoreCase(type)&&subtype!=null)try{return Math.min(128,Double.parseDouble(subtype.split("-")[0]));}catch(NumberFormatException ignored){}}
        return 128;
    }
    static double range(Gun gun){return switch(gun.family){case "melee"->2.8;case "shotgun"->15;case "pistol"->24;case "sniper"->60;default->42;};}
}
