package kr.mzs.gunbed;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.*;

/** Capture before team removal, and fill in environmental deaths absent from the kill event. */
final class EnvironmentDeaths {
 private static final Map<UUID,Runnable> pending=new HashMap<>();
 static String cause(Player p){var e=p.getLastDamageCause();if(e!=null&&e.getCause()==EntityDamageEvent.DamageCause.FALL)return "낙하";if(e!=null&&e.getCause()==EntityDamageEvent.DamageCause.VOID)return "공허";if(e!=null&&Set.of("CUSTOM","SUICIDE","KILL").contains(e.getCause().name()))return "자살";return "";}
 static void capture(GunbedCore plugin,PlayerDeathEvent e){FeedV16.capture(plugin,e);}
 static void nativeFeed(Player victim){pending.remove(victim.getUniqueId());}
}
