package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.GameStatus;

/** Scaled health and regeneration must never turn the void into a survivable damage-over-time zone. */
final class MatchVoid implements Listener {
    private final GunbedCore plugin;
    MatchVoid(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,1);}
    static boolean below(Player p){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);return g!=null&&g.getStatus()==GameStatus.RUNNING&&g.getTeamOfPlayer(p)!=null&&(p.getGameMode()==GameMode.SURVIVAL||p.getGameMode()==GameMode.ADVENTURE)&&p.getY()<Math.min(g.getPos1().getY(),g.getPos2().getY())-1;}
    @EventHandler(priority=EventPriority.HIGHEST)public void damage(EntityDamageEvent e){if(e.getEntity() instanceof Player p&&e.getCause()==EntityDamageEvent.DamageCause.VOID&&below(p)){e.setCancelled(false);e.setDamage(Math.max(100000,p.getHealth()+p.getAbsorptionAmount()+10000));}}
    @SuppressWarnings("deprecation") private void tick(){for(Player p:Bukkit.getOnlinePlayers())if(!p.isDead()&&below(p)){
        p.clearActiveItem();if(plugin.healthRecovery!=null)plugin.healthRecovery.milk(p);p.setInvulnerable(false);p.setNoDamageTicks(0);
        var event=new EntityDamageEvent(p,EntityDamageEvent.DamageCause.VOID,p.getHealth()+10000);p.setLastDamageCause(event);p.setHealth(0);
    }}
}
