package kr.mzs.gunbed;

import java.lang.reflect.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.GameStatus;

/** The ninth hotbar slot is reserved only in the match weapon bank (A). */
final class FixedTracker implements Listener {
    static final int SLOT=8;
    private static final NamespacedKey KEY=new NamespacedKey("gunbedcore","enemy_tracker");
    private static final Set<GunbedCore> installed=Collections.newSetFromMap(new IdentityHashMap<>());
    private final GunbedCore plugin;
    private FixedTracker(GunbedCore p){plugin=p;}
    static void install(GunbedCore p){if(!installed.add(p))return;GunReloadCommand.install(p);CompassNavigation.disable(p);Bukkit.getPluginManager().registerEvents(new FixedTracker(p),p);}
    static boolean item(ItemStack i){return i!=null&&i.hasItemMeta()&&i.getItemMeta().getPersistentDataContainer().has(KEY);}
    static boolean active(Player p){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);return g!=null&&g.getStatus()==GameStatus.RUNNING&&g.getTeamOfPlayer(p)!=null&&p.getGameMode()!=GameMode.SPECTATOR;}
    private static ItemStack compass(){ItemStack i=new ItemStack(Material.COMPASS);var m=i.getItemMeta();m.setDisplayName("§a팀 추적기 §7(우클릭)");m.setLore(List.of("§7클릭: 팀색 양털로 추적할 팀 선택","§7모든 적 침대 파괴 후 · 에메랄드 2개","§7사망 시 추적 해제 · A모드 9번 슬롯 고정"));m.getPersistentDataContainer().set(KEY,PersistentDataType.BYTE,(byte)1);i.setItemMeta(m);return i;}
    private static boolean reserve(ItemStack[] items){
        ItemStack keep=item(items[SLOT])?items[SLOT]:compass();
        if(items[SLOT]!=null&&!items[SLOT].getType().isAir()&&!item(items[SLOT])){
            int free=-1;for(int n=9;n<36;n++)if(n!=MatchContainers.BUTTON_SLOT&&(items[n]==null||items[n].getType().isAir())){free=n;break;}
            if(free<0)for(int n=0;n<8;n++)if(items[n]==null||items[n].getType().isAir()){free=n;break;}
            if(free<0)return false;items[free]=items[SLOT];
        }
        for(int n=0;n<36;n++)if(n!=SLOT&&item(items[n]))items[n]=null;
        items[SLOT]=keep;return true;
    }
    @SuppressWarnings("unchecked") private static BattleInventory.State state(GunbedCore p,Player player){try{Field f=BattleInventory.class.getDeclaredField("states");f.setAccessible(true);return ((Map<UUID,BattleInventory.State>)f.get(p.inventories)).get(player.getUniqueId());}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}}
    static boolean ensure(GunbedCore p,Player player){
        if(!active(player))return false;var s=state(p,player);ItemStack[] shown=BattleInventory.copy(player.getInventory().getStorageContents());
        ItemStack[] hidden=s==null?null:BattleInventory.copy(s.a?s.utility:s.weapons);
        if(s==null||s.a){if(!reserve(shown))return false;if(hidden!=null)for(int n=0;n<36;n++)if(item(hidden[n]))hidden[n]=null;}
        else{if(!reserve(hidden))return false;for(int n=0;n<36;n++)if(item(shown[n]))shown[n]=null;}
        if(!Arrays.equals(shown,player.getInventory().getStorageContents()))player.getInventory().setStorageContents(shown);
        if(s!=null){if(s.a)s.utility=hidden;else s.weapons=hidden;}return true;
    }
    static void selected(GunbedCore p,Player player,ItemStack compass){var s=state(p,player);if(s==null||s.a)player.getInventory().setItem(SLOT,compass);else s.weapons[SLOT]=compass;}
    static void reset(GunbedCore p,Player player){selected(p,player,compass());}
    @EventHandler(priority=EventPriority.LOWEST)public void click(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p)||!active(p))return;if(item(e.getCurrentItem())||item(e.getCursor())||plugin.inventories.modeA(p)&&(e.getClickedInventory() instanceof PlayerInventory&&e.getSlot()==SLOT||e.getClick()==ClickType.NUMBER_KEY&&e.getHotbarButton()==SLOT))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST)public void drag(InventoryDragEvent e){if(!(e.getWhoClicked() instanceof Player p)||!active(p))return;if(item(e.getOldCursor())||plugin.inventories.modeA(p)&&e.getRawSlots().stream().anyMatch(n->e.getView().getInventory(n) instanceof PlayerInventory&&e.getView().convertSlot(n)==SLOT))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST)public void drop(PlayerDropItemEvent e){if(item(e.getItemDrop().getItemStack()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST)public void swap(PlayerSwapHandItemsEvent e){if(item(e.getOffHandItem())||item(e.getMainHandItem()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST)public void use(PlayerInteractEvent e){if(e.getHand()!=EquipmentSlot.HAND||!active(e.getPlayer())||!item(e.getItem()))return;e.setCancelled(true);if(e.getAction().isLeftClick())plugin.tracker.open(e.getPlayer());}
    @EventHandler public void join(PlayerJoinEvent e){Bukkit.getScheduler().runTask(plugin,()->CompassNavigation.clear(e.getPlayer()));}
    // A cached FAWE tool can survive a config reload; never allow it to teleport a compass holder.
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void teleport(PlayerTeleportEvent e){if(!e.getPlayer().isOp()||e.getPlayer().getInventory().getItemInMainHand().getType()!=Material.COMPASS)return;for(StackTraceElement f:Thread.currentThread().getStackTrace())if(f.getClassName().equals("com.sk89q.worldedit.command.tool.NavigationWand")){e.setCancelled(true);return;}}
}
