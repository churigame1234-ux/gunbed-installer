package kr.mzs.gunbed;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Gunbed utilities and the adapter for the current BedWars engine. */
public final class GunbedCore extends JavaPlugin implements Listener {
    private volatile Settings settings;
    BedwarsBridge bedwars;
    PlayerProfiles profiles;
    PointLedger points;
    Arsenal arsenal;
    CosmeticShop cosmetics;
    MatchBoard board;
    ArenaFlow flow;
    PlayerTags tags;
    ResourceWallet wallet;
    EnemyTracker tracker;
    CombatPresentation combatPresentation;
    GunVisualBridge visuals;
    TrgAudio trgAudio;
    GunbedProtocol protocol;
    TaczWeapons taWeapons;
    WeaponLab weaponLab;
    VirtualAmmo ammo;
    BattleInventory inventories;
    MatchMechanics mechanics;
    Throwables throwables;
    WeaponModes weaponModes;
    BedwarsLevels levels;
    WaitingRoom waiting;
    RoundChat roundChat;
    WardrobeShop wardrobe;
    ArenaRestoration restores;
    LobbyActivities activities;
    MatchTurrets turrets;
    PublicStatistics publicStats;
    CombatBalance balance;
    KnockbackSettings knockbacks;
    WeaponImpacts impacts;
    AddonMelee addonMelee;
    LobbyControls controls;
    MatchContainers containers;
    RoundRecovery recovery;
    MatchCorpses corpses;
    ProtectedVolumes volumes;
    WoolHealth wool;
    RoundPresence presence;
    ItemParity parity;
    DamageProfiles damageProfiles;
    FriendlyProjectiles friendlyProjectiles;
    WeaponSpecs specs;
    VirtualStacks stacks;
    HotbarMemory hotbar;
    MatchGrapple grapple;
    HealthRecovery healthRecovery;
    SummonCreatures summons;
    RoundFalls falls;
    ShopExplosions explosions;
    AiLearning learning;
    NeuralVision neural;
    AiChallengeRules aiRules;
    AiPractice practice;

    DamageSettings damages;
    MeleeSettings meleeSettings;
    private record SoundSpec(String sound, float volume, float pitch) { }
    private record Settings(boolean hunger, boolean leaves, boolean chat,
                            Set<String> excludedWorlds, Map<String, SoundSpec> sounds) { }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        readSettings();
        profiles=new PlayerProfiles(this);
        points=new PointLedger(this);
        new SharedRecommendations(this);
        getServer().getPluginManager().registerEvents(this, this);
        new ResourcePackMonitor(this);
        taWeapons=new TaczWeapons(this);
        if (getServer().getPluginManager().isPluginEnabled("CrackShot")){trgAudio=new TrgAudio(this);visuals=new GunVisualBridge(this);}
        addonMelee=new AddonMelee(this);
        protocol=new GunbedProtocol(this);
        weaponLab=new WeaponLab(this);
        ammo=new VirtualAmmo(this);
        inventories=new BattleInventory(this);
        weaponModes=new WeaponModes(this);
        if (getServer().getPluginManager().isPluginEnabled("BedWars")) {
            damageProfiles=new DamageProfiles(this);volumes=new ProtectedVolumes(this);wool=new WoolHealth(this);presence=new RoundPresence(this);parity=new ItemParity(this);friendlyProjectiles=new FriendlyProjectiles(this);
            specs=new WeaponSpecs(this);
            flow=new ArenaFlow(this);
            wallet=new ResourceWallet(this,profiles);
            tracker=new EnemyTracker(this);
            combatPresentation=new CombatPresentation(this);
            throwables=new Throwables(this);
            if(Bukkit.getPluginManager().isPluginEnabled("ComplexTurrets"))turrets=new MatchTurrets(this);
            bedwars = new BedwarsBridge(this);
            arsenal=new Arsenal(this);
            wardrobe=new WardrobeShop(this);
            cosmetics=new CosmeticShop(this);
            new ShopAppearance(this);
            controls=new LobbyControls(this);
            board=new MatchBoard(this);
            tags=new PlayerTags(this);
            mechanics=new MatchMechanics(this);
            balance=new CombatBalance(this);
            levels=new BedwarsLevels(this);
            new ScriptProfiles(this);
            restores=new ArenaRestoration(this);restores.recover();
            waiting=new WaitingRoom(this);
            roundChat=new RoundChat(this);
            activities=new LobbyActivities(this);publicStats=new PublicStatistics(this);
            new ArenaEditing(this);
            containers=new MatchContainers(this);recovery=new RoundRecovery(this);corpses=new MatchCorpses(this);new PlayerMenuRoutes(this);healthRecovery=new HealthRecovery(this);new ExplosiveRounds(this);new BedAlerts(this);
            stacks=new VirtualStacks(this);hotbar=new HotbarMemory(this);grapple=new MatchGrapple(this);summons=new SummonCreatures(this);falls=new RoundFalls(this);explosions=new ShopExplosions(this);knockbacks=new KnockbackSettings(this);impacts=new WeaponImpacts(this);damages=new DamageSettings(this);meleeSettings=new MeleeSettings(this);
        }
        if(getConfig().getBoolean("ai.enabled",false)){learning=new AiLearning(this);if(Bukkit.getPluginManager().isPluginEnabled("MZSBotCore")){practice=new AiPractice(this);aiRules=new AiChallengeRules(this);}if(getConfig().getBoolean("ai.neural.enabled",true))neural=new NeuralVision(this);}
        if(bedwars!=null){RenewalV16.install(this);new MatchVoid(this);}
        new DailyRestart(this);
        getLogger().info("Enabled Gunbed utilities, independent TA weapons, point ledger and BedWars adapters.");
    }

    @Override
    public void onDisable() {
        if(neural!=null)neural.close();if(practice!=null)practice.close();if(learning!=null)learning.close();
        if(hotbar!=null)for(Player p:Bukkit.getOnlinePlayers())hotbar.capture(p);
        if(grapple!=null)grapple.close();if(stacks!=null)stacks.close();
        if(meleeSettings!=null)meleeSettings.close();if(wool!=null)wool.close();if(presence!=null)presence.close();if(parity!=null)parity.close();if(friendlyProjectiles!=null)friendlyProjectiles.close();
        if(containers!=null)containers.close();if(corpses!=null)corpses.close();
        if(publicStats!=null)publicStats.close();
        if(turrets!=null)turrets.close();
        if(activities!=null)activities.close();
        if(weaponModes!=null)weaponModes.close();
        if(inventories!=null)inventories.close();
        if(throwables!=null)throwables.close();
        if (bedwars != null) bedwars.close();
        if(board!=null)board.close();
        if(flow!=null)flow.close();
        if(tags!=null)tags.close();
        if(combatPresentation!=null)combatPresentation.close();
        if(taWeapons!=null)taWeapons.close();
        if(weaponLab!=null)weaponLab.close();
        if(profiles!=null)profiles.close();
        if(points!=null)points.close();
    }

    private void readSettings() {
        Map<String, SoundSpec> sounds = new HashMap<>();
        for (String name : List.of("onMessage", "onMention", "onPrivateMessage")) {
            String path = "sounds." + name;
            try {
                String configured=getConfig().getString(path+".sound","BLOCK_NOTE_BLOCK_PLING");String sound=configured.contains(":")?configured:Sound.valueOf(configured).getKey().toString();
                sounds.put(name, new SoundSpec(sound,
                        (float) Math.max(0, getConfig().getDouble(path + ".volume", 1)),
                        (float) Math.clamp(getConfig().getDouble(path + ".pitch", 1), 0.5, 2)));
            } catch (IllegalArgumentException ex) {
                getLogger().warning("Unknown sound for " + name + "; this notification is disabled.");
            }
        }
        settings = new Settings(getConfig().getBoolean("prevent-hunger", true),
                getConfig().getBoolean("prevent-leaf-decay", true),
                getConfig().getBoolean("chat-sounds", true),
                Set.copyOf(getConfig().getStringList("excluded-worlds")), Map.copyOf(sounds));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent event) {
        Settings current = settings;
        if (current.hunger() && event.getEntity() instanceof Player player
                && !current.excludedWorlds().contains(player.getWorld().getName())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLeaves(LeavesDecayEvent event) {
        Settings current = settings;
        if (current.leaves() && !current.excludedWorlds().contains(event.getBlock().getWorld().getName())) {
            event.setCancelled(true);
        }
    }

    // Use the same recipients as the existing chat pipeline. All sound/world work runs on the server thread.
    @SuppressWarnings("deprecation")
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Settings current = settings;
        if (!current.chat()) return;
        UUID senderId = event.getPlayer().getUniqueId();
        String message = event.getMessage().toLowerCase(Locale.ROOT);
        List<UUID> recipients = event.getRecipients().stream().map(Player::getUniqueId)
                .filter(id -> !id.equals(senderId)).toList();
        Bukkit.getScheduler().runTask(this, () -> {
            for (UUID id : recipients) {
                Player player = Bukkit.getPlayer(id);
                if (player == null) continue;
                play(player, message.contains(player.getName().toLowerCase(Locale.ROOT))
                        ? "onMention" : "onMessage");
            }
        });
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPrivateCommand(PlayerCommandPreprocessEvent event) {
        if (!settings.chat()) return;
        String[] args = event.getMessage().trim().split("\\s+", 3);
        if (args.length != 3) return;
        String command = args[0].substring(1).toLowerCase(Locale.ROOT);
        if (command.startsWith("essentials:")) command = command.substring("essentials:".length());
        if (!Set.of("msg", "tell", "w", "whisper", "m", "t").contains(command)) return;
        Player receiver = Bukkit.getPlayerExact(args[1]);
        if (receiver != null && !receiver.equals(event.getPlayer()) && event.getPlayer().canSee(receiver)) {
            play(receiver, "onPrivateMessage");
        }
    }

    void play(Player player, String type) {
        Settings current = settings;
        if (current.excludedWorlds().contains(player.getWorld().getName())) return;
        SoundSpec spec = current.sounds().get(type);
        if (spec != null) player.playSound(player.getLocation(), spec.sound(), spec.volume(), spec.pitch());
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if(knockbacks!=null&&!knockbacks.reload(sender))return true;
            reloadConfig();
            readSettings();
            sender.sendMessage("GunbedCore 설정을 다시 읽었습니다.");
        } else if (args.length == 0 || (args.length == 1 && args[0].equalsIgnoreCase("status"))) {
            Settings current = settings;
            sender.sendMessage("GunbedCore " + getPluginMeta().getVersion()
                    + " | 배고픔 고정=" + current.hunger()
                    + " | 나뭇잎 보호=" + current.leaves()
                    + " | 채팅 소리=" + current.chat());
        } else return false;
        return true;
    }
}
