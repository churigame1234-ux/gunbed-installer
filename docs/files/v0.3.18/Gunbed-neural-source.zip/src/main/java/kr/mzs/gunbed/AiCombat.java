package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.Vector;
import java.util.*;

/** Explicit combat states consume human movement styles and actual ammunition/reload state. */
final class AiCombat {
    static final class Memory {
        final List<Location> wallPieces=new ArrayList<>();int wallWatchUntil;boolean trajectoryReachable=true;int nextAim;Location aimPoint;UUID target;Location lastSeen,previousEnemy,cover,peek,wallBase;Vector enemyVelocity=new Vector();boolean jumpWanted;int doubleJumpAt;int seenTick,previousTick,nextCover,nextMotion,burstUntil,restUntil,returnWeaponAt,nextJump,nextFlank,peekUntil,nextPeek,nextWall,wallUntil,wallBuildUntil;long choices;AiCombatLearning.Motion motion;double errorX,errorY;
        void clear(){aimPoint=null;nextAim=0;target=null;lastSeen=null;previousEnemy=null;cover=null;peek=null;motion=null;nextCover=0;seenTick=0;}
    }
    private final AiBrain brain;private final GunbedCore plugin;private final BotRuntime runtime;
    AiCombat(AiBrain brain,GunbedCore p,BotRuntime r){this.brain=brain;plugin=p;runtime=r;}
    private void release(Player p){plugin.taWeapons.input(p,false,false);plugin.addonMelee.input(p,false);if(plugin.visuals!=null)plugin.visuals.input(p,false,false,false);}
    private void select(AiBrain.State s,int slot,int tick,String reason){Player p=s.bot.getPlayer();if(slot==p.getInventory().getHeldItemSlot())return;int old=p.getInventory().getHeldItemSlot();release(p);brain.slot(p,slot);plugin.learning.telemetry.switched(p,old,slot,reason);s.combat.returnWeaponAt=tick+16;s.reason=reason;}
    boolean blockWall(AiBrain.State s,int tick){Player p=s.bot.getPlayer();Memory m=s.combat;
        if(!m.wallPieces.isEmpty()&&tick<m.wallWatchUntil&&m.wallBase!=null&&p.getLocation().distanceSquared(m.wallBase)<25){boolean holes=m.wallPieces.stream().anyMatch(at->at.getBlock().isPassable());if(holes&&wallBlock(s,tick))return true;if(holes&&tick<m.wallBuildUntil&&brain.wool(p)>0){release(p);runtime.stop(s.bot);s.action="block-cover";s.reason="complete-multi-block-cover";return true;}}
        Location incoming=brain.senses.incomingPoint(s);if(incoming==null||tick<m.nextWall||!plugin.learning.telemetry.pressured(p,tick)||brain.wool(p)==0||AiGuns.reloading(plugin,p)||plugin.turrets.building(p)||s.throwUntil>0||p.hasPotionEffect(org.bukkit.potion.PotionEffectType.INVISIBILITY))return false;
        Vector d=incoming.toVector().subtract(p.getLocation().toVector()).setY(0);double distance=d.length();if(distance<4)return false;m.nextWall=tick+60;d.normalize();Vector front=Math.abs(d.getX())>Math.abs(d.getZ())?new Vector(Math.signum(d.getX()),0,0):new Vector(0,0,Math.signum(d.getZ()));Vector side=new Vector(-front.getZ(),0,front.getX());m.wallBase=p.getLocation().clone().add(front.clone().multiply(1.8)).getBlock().getLocation();int width=distance>22&&brain.wool(p)>=9?3:distance>10&&brain.wool(p)>=6?2:1,height=width>1?3:2;m.wallPieces.clear();
        for(int y=0;y<height;y++)for(int x=-(width/2);x<width-width/2;x++)m.wallPieces.add(m.wallBase.clone().add(side.clone().multiply(x)).add(0,y,0));m.wallBuildUntil=tick+50;m.wallWatchUntil=tick+200;return wallBlock(s,tick);
    }
    private boolean wallBlock(AiBrain.State s,int tick){Player p=s.bot.getPlayer();Memory m=s.combat;for(Location at:m.wallPieces){var block=at.getBlock();if(!block.isPassable())continue;release(p);if(brain.strategy.place(s,block,null,tick)){s.action="block-cover";s.reason="build-or-repair-multi-block-wool-cover";m.cover=p.getLocation().clone();m.nextPeek=tick+20;plugin.learning.telemetry.record(p,"defensive-wool",Map.of("block",List.of(block.getX(),block.getY(),block.getZ()),"planned",m.wallPieces.size(),"repair",tick>m.wallBuildUntil));return true;}}
        boolean high=m.wallPieces.stream().anyMatch(at->at.getBlock().isPassable()&&at.getY()>p.getEyeLocation().getY());if(high&&p.isOnGround()&&brain.wool(p)>0){runtime.move(s.bot,0,0,true,false,false);m.wallBuildUntil=Math.max(m.wallBuildUntil,tick+20);s.action="block-cover";s.reason="jump-to-reach-visible-upper-shield-face";return true;}return false;}
    boolean breakCover(AiBrain.State s,int tick){Player p=s.bot.getPlayer();Memory m=s.combat;Location point=brain.senses.incomingPoint(s);if(point==null&&m.lastSeen!=null&&tick-m.seenTick<100)point=m.lastSeen;if(point==null||p.hasPotionEffect(org.bukkit.potion.PotionEffectType.INVISIBILITY)||s.throwUntil>0)return false;
        Vector delta=point.toVector().subtract(p.getEyeLocation().toVector());if(delta.lengthSquared()<1||delta.lengthSquared()>16384)return false;var hit=p.getWorld().rayTraceBlocks(p.getEyeLocation(),delta.clone().normalize(),Math.min(128,delta.length()),FluidCollisionMode.NEVER,true);
        if(hit!=null&&hit.getHitBlock()!=null&&tick<m.wallWatchUntil&&m.wallPieces.stream().anyMatch(at->at.getBlock().equals(hit.getHitBlock())))return false;
        if(hit==null||hit.getHitBlock()==null||!hit.getHitBlock().getType().name().endsWith("_WOOL")||!s.room.game.getRegion().isBlockAddedDuringGame(hit.getHitBlock().getLocation()))return false;
        if(tick>=m.wallUntil){m.wallUntil=tick+30;if(p.getLocation().distanceSquared(hit.getHitBlock().getLocation())<1024&&brain.strategy.count(p,Material.FIRE_CHARGE)>0&&brain.strategy.useProjectile(s,Material.FIRE_CHARGE,hit.getHitBlock().getLocation().add(.5,.5,.5),false,tick)){s.action="break-cover";s.reason="paid-fireball-against-observed-wool-cover";return true;}}
        plugin.inventories.mode(p,true);select(s,0,tick,"primary-break-wool-cover");AiGuns.Gun gun=AiGuns.held(plugin,p);if(!gun.ready()){release(p);AiGuns.reload(plugin,p);return AiGuns.reloading(plugin,p);}if(AiGuns.reloading(plugin,p))return false;
        runtime.stop(s.bot);runtime.look(s.bot,hit.getHitBlock().getLocation().add(.5,.5,.5));boolean fire=(tick/2)%2==0;plugin.taWeapons.input(p,fire,true);if(plugin.visuals!=null)plugin.visuals.input(p,fire,true,false);s.action="break-cover";s.reason="shoot-player-built-wool-on-last-observed-fire-line";return true;
    }
    void fight(AiBrain.State s,LivingEntity foe,int tick){
        Player p=s.bot.getPlayer();Memory m=s.combat;var g=s.room.game;
        if(!foe.getUniqueId().equals(m.target)){m.clear();m.target=foe.getUniqueId();m.nextMotion=0;}
        Location eye=foe.getEyeLocation();if(m.previousEnemy!=null&&tick>m.previousTick){Vector velocity=eye.toVector().subtract(m.previousEnemy.toVector()).multiply(1.0/(tick-m.previousTick));if(velocity.lengthSquared()<1)m.enemyVelocity=velocity;}
        m.previousEnemy=eye.clone();m.previousTick=tick;m.lastSeen=eye.clone();m.seenTick=tick;
        plugin.inventories.mode(p,true);double distance=p.getLocation().distance(foe.getLocation());double hp=p.getHealth()/p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();boolean pressure=plugin.learning.telemetry.pressured(p,tick);
        if(throwing(s,foe,tick))return;
        AiGuns.Gun primary=AiGuns.slot(plugin,p,0),secondary=AiGuns.slot(plugin,p,1);boolean loading=AiGuns.reloading(plugin,p);double progress=AiGuns.progress(plugin,p);
        if(loading){
            if(secondary.ready()&&p.getInventory().getHeldItemSlot()!=1&&((progress>=.7&&distance<25)||(progress<.15&&(pressure||distance<12)))){select(s,1,tick,progress>=.7?"reload-70-finish-and-secondary":"emergency-secondary");loading=false;}
        }else{
            int selected=0;
            if(preferMelee(s,foe,primary,distance))selected=2;
            else if(secondary.ready()&&(!primary.ready()||primary.family().equals("shotgun")&&distance>18||plugin.learning.combat.secondaryEarly(g,primary.family())&&primary.capacity()>0&&primary.loaded()<=Math.max(1,primary.capacity()/8)&&distance<10))selected=1;
            else if(p.getInventory().getHeldItemSlot()==1&&secondary.ready()&&tick<m.returnWeaponAt)selected=1;
            if(!primary.ready()&&!secondary.ready()&&distance>=2.6)selected=primary.reserve()!=0?0:secondary.reserve()!=0?1:2;
            if(!primary.ready()&&primary.reserve()!=0&&selected==1&&tick>=m.returnWeaponAt&&distance>16&&!pressure)selected=0;
            select(s,selected,tick,selected==1?"primary-unavailable-secondary":"weapon-for-distance");
            AiGuns.Gun current=AiGuns.held(plugin,p);if(!current.ready()&&current.reserve()!=0){AiGuns.reload(plugin,p);loading=AiGuns.reloading(plugin,p);}
        }
        AiGuns.Gun gun=AiGuns.held(plugin,p);
        boolean wantsReload=loading||gun.capacity()>1&&gun.loaded()>0&&gun.loaded()<Math.max(1,gun.capacity()/4)&&distance>18&&!pressure;
        if(wantsReload&&!loading){release(p);AiGuns.reload(plugin,p);loading=AiGuns.reloading(plugin,p);}
        boolean peeking=m.peek!=null&&tick<m.peekUntil&&!loading&&hp>.18;boolean seekCover=(loading||hp<.4||pressure&&hp<.75)&&!peeking;
        if(seekCover){
            release(p);if(tick>=m.nextCover){m.nextCover=tick+24;m.cover=AiTerrain.cover(g,p.getLocation(),eye,s.avoided.keySet());m.peek=null;}
            if(m.cover!=null){
                if(p.getLocation().distanceSquared(m.cover)>.8){s.action="cover";s.reason=loading?"reload-behind-cover":"under-fire-cover";brain.navigate(s,m.cover,tick,false,false);return;}
                runtime.stop(s.bot);smoothAim(s,foe,gun,distance,tick);s.action="reload";s.reason=loading?"protected-reload":"recover-behind-cover";
                if(!loading&&tick>=m.nextPeek){m.peek=AiTerrain.peek(g,m.cover,eye);m.peekUntil=tick+14;m.nextPeek=tick+32;if(m.peek!=null){s.action="peek";s.reason="short-exposure";brain.navigate(s,m.peek,tick,false,false);}}
                return;
            }
            // Without reachable cover, keep moving away from incoming fire while the real reload runs.
            if(loading){move(s,foe,gun,distance,hp,tick,true);s.action="reload";s.reason="reload-evasive-move";smoothAim(s,foe,gun,distance,tick);return;}
        }
        if(m.peek!=null&&tick<m.peekUntil){s.action="peek";s.reason="short-exposure";brain.navigate(s,m.peek,tick,false,false);}else if(m.peek!=null){m.peek=null;if(m.cover!=null&&(pressure||hp<.6)){s.action="cover";s.reason="return-after-peek";release(p);brain.navigate(s,m.cover,tick,false,false);return;}}
        double effective=AiGuns.reach(plugin,p,gun);double preferred=plugin.learning.adaptation.range(gun.family(),AiGuns.range(gun));
        if(!gun.family().equals("melee")&&(distance>effective||gun.family().equals("shotgun")&&distance>preferred+3)){
            release(p);Location at=AiTerrain.flank(g,p.getLocation(),eye,(s.index&1)==0?1:-1);if(at!=null){s.action="flank";s.reason="outside-weapon-range";brain.navigate(s,at,tick,false,false);return;}
        }
        smoothAim(s,foe,gun,distance,tick);
        if(tick>=m.restUntil&&tick>=m.burstUntil){var random=new SplittableRandom(p.getUniqueId().getLeastSignificantBits()+(++m.choices));m.burstUntil=tick+plugin.learning.combat.burstTicks(g,gun.family());m.restUntil=m.burstUntil+4+random.nextInt(5);m.errorX=random.nextDouble(-1,1);m.errorY=random.nextDouble(-.4,.4);}
        boolean aligned=m.trajectoryReachable&&p.getEyeLocation().getDirection().angle((m.aimPoint==null?eye:m.aimPoint).toVector().subtract(p.getEyeLocation().toVector()))<Math.toRadians(distance<4?40:8);
        boolean fire=aligned&&p.hasLineOfSight(foe)&&tick<m.burstUntil&&!AiGuns.reloading(plugin,p);
        var ta=plugin.taWeapons.held(p);if(ta!=null&&!plugin.taWeapons.mode(p).equals("auto")&&!plugin.taWeapons.mode(p).equals("burst"))fire&=(tick/2)%2==0;
        if(plugin.addonMelee.held(p)!=null)plugin.addonMelee.input(p,fire);plugin.taWeapons.input(p,fire,distance>15);if(plugin.visuals!=null)plugin.visuals.input(p,fire,distance>15,false);
        if(!peeking){s.action=gun.family().equals("melee")?"melee":p.getInventory().getHeldItemSlot()==1?"secondary":"fire";s.reason=fire?"aimed-visible-burst":"track-before-fire";if(distance>preferred&&distance<effective){runtime.stop(s.bot);}else move(s,foe,gun,distance,hp,tick,false);}
    }
    boolean preferMelee(AiBrain.State s,LivingEntity foe,AiGuns.Gun primary,double distance){
        Player p=s.bot.getPlayer();AiGuns.Gun melee=AiGuns.slot(plugin,p,2);if(!melee.ready()||!melee.family().equals("melee"))return false;
        double reach=plugin.meleeSettings.shape(melee.id()).reach();if(distance>Math.min(4,reach)-.25||!p.hasLineOfSight(foe))return false;
        double damage=plugin.damages.value(DamageSettings.weapon(melee.id())+".body",1500),gun=plugin.damages.value(DamageSettings.weapon(primary.id())+".body",600);
        // A loaded shotgun can be better at point blank range; an empty sniper is not.
        var definition=plugin.taWeapons.definition(p.getInventory().getItem(0));int pellets=definition==null?1:definition.data().getAsJsonObject("bullet").has("bullet_amount")?definition.data().getAsJsonObject("bullet").get("bullet_amount").getAsInt():1;
        return !primary.ready()||AiGuns.reloading(plugin,p)||primary.family().equals("sniper")||damage>=foe.getHealth()||damage>=gun*(primary.family().equals("shotgun")?Math.max(1,pellets)*.7:1.4)||distance<1.5;
    }
    boolean throwing(AiBrain.State s,LivingEntity foe,int tick){
        Player p=s.bot.getPlayer();
        if(s.throwUntil>0){release(p);brain.slot(p,3);runtime.stop(s.bot);runtime.look(s.bot,s.throwAim);plugin.throwables.input(p,tick<s.throwUntil&&s.throwStrength>.4,tick<s.throwUntil&&s.throwStrength<.9);s.action="throw";s.reason=tick<s.throwUntil?"pull-pin-for-observed-threat":"keep-throwable-until-release-animation-completes";if(tick>=s.throwUntil+9){s.throwUntil=0;s.nextThrow=tick+120;plugin.learning.telemetry.record(p,"throw-complete",Map.of("kind",s.throwKind));}return true;}
        if(foe==null||tick<s.nextThrow||p.hasPotionEffect(org.bukkit.potion.PotionEffectType.INVISIBILITY))return false;
        String kind=plugin.throwables.kind(p.getInventory().getItem(3));double distance=p.getLocation().distance(foe.getLocation());if(kind==null||!(foe instanceof Player)&&!kind.startsWith("labs_")||distance<5||distance>23||!p.hasLineOfSight(foe))return false;
        boolean opportunity=plugin.learning.telemetry.pressured(p,tick)||!AiGuns.slot(plugin,p,0).ready()||brain.senses.threatening(s,foe)||distance>10;
        if(!opportunity)return false;Location target=foe.getLocation().add(foe.getVelocity().clone().multiply(Math.min(8,distance/1.3)));Vector flat=target.toVector().subtract(p.getEyeLocation().toVector()).setY(0);if(flat.lengthSquared()<1)return false;flat.normalize();Vector best=null;double score=Double.MAX_VALUE;
        s.nextThrow=tick+40;long deadline=System.nanoTime()+3_000_000;double strength=1;trajectory:for(double power:new double[]{.35,.65,1})for(int degrees:new int[]{-10,0,10,20,30,40,50,60}){
            if(System.nanoTime()>deadline)break trajectory;
            double angle=Math.toRadians(degrees);Vector direction=flat.clone().multiply(Math.cos(angle)).setY(Math.sin(angle));Vector velocity=direction.clone().multiply(.45+power*1.15).add(new Vector(0,.12,0)).add(p.getVelocity());Location at=p.getEyeLocation().add(direction.clone().multiply(.3));int fuse=kind.equals("fire")?60:kind.equals("labs_gas")?50:kind.startsWith("labs_")?55:30;
            for(int step=1;step<=fuse;step++){var hit=at.getWorld().rayTraceBlocks(at,velocity.clone().normalize(),Math.max(.01,velocity.length()),FluidCollisionMode.NEVER,true);if(hit!=null&&hit.getHitBlockFace()!=null){Vector normal=hit.getHitBlockFace().getDirection();at=hit.getHitPosition().toLocation(p.getWorld()).add(normal.clone().multiply(.03));if((kind.equals("fire")&&normal.getY()>.5||kind.equals("labs_impact"))&&step>3)break;velocity.subtract(normal.multiply(2*velocity.dot(normal))).multiply(.45);}else at.add(velocity);velocity.multiply(.98).setY(velocity.getY()-.04);}
            double miss=at.distanceSquared(target);if(miss<score&&at.distanceSquared(p.getLocation())>16){score=miss;best=direction;strength=power;}
        }
        double radius=kind.equals("fire")?3:kind.equals("flash")?10:7;if(best==null||score>radius*radius)return false;
        s.throwAim=p.getEyeLocation().add(best.multiply(10));s.throwKind=kind;s.throwStrength=strength;s.throwUntil=tick+10;release(p);brain.slot(p,3);runtime.look(s.bot,s.throwAim);plugin.throwables.input(p,strength>.4,strength<.9);runtime.stop(s.bot);s.action="throw";s.reason="ballistic-throw-at-observed-threat";plugin.learning.telemetry.record(p,"throw-choice",Map.of("kind",kind,"distance",distance,"predictedMiss",Math.sqrt(score),"strength",strength));return true;
    }
    private void smoothAim(AiBrain.State s,LivingEntity foe,AiGuns.Gun gun,double distance,int tick){
        Memory m=s.combat;Location target=foe.getLocation().add(0,Math.min(foe.getHeight()*.9,plugin.learning.combat.aimHeight(s.room.game,gun.family())*foe.getHeight()/1.8),0);
        Player p=s.bot.getPlayer();if(tick>=m.nextAim||m.aimPoint==null){var model=AiBallistics.model(plugin,p,gun);var shot=AiBallistics.solve(model,target.toVector().subtract(p.getEyeLocation().toVector()),m.enemyVelocity);m.aimPoint=AiBallistics.aim(p.getEyeLocation(),shot);m.trajectoryReachable=shot.reachable()&&AiBallistics.clear(p.getEyeLocation(),model,shot);m.nextAim=tick+4;}target=m.aimPoint.clone();double error=Math.tan(Math.toRadians(AiPractice.Difficulty.HARD.error))*Math.min(20,distance);target.add(m.errorX*error,m.errorY*error,0);Location desired=p.getLocation().setDirection(target.toVector().subtract(p.getEyeLocation().toVector()));
        double dyaw=(desired.getYaw()-p.getYaw()+540)%360-180,limit=40;float yaw=(float)(p.getYaw()+Math.max(-limit,Math.min(limit,dyaw))),pitch=(float)(p.getPitch()+Math.max(-limit,Math.min(limit,desired.getPitch()-p.getPitch())));
        Location direction=p.getEyeLocation().clone();direction.setYaw(yaw);direction.setPitch(pitch);runtime.look(s.bot,p.getEyeLocation().add(direction.getDirection().multiply(10)));
    }
    private void move(AiBrain.State s,LivingEntity foe,AiGuns.Gun gun,double distance,double hp,int tick,boolean reload){
        Player p=s.bot.getPlayer();Memory m=s.combat;Vector forward=foe.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);if(forward.lengthSquared()<.001){runtime.stop(s.bot);return;}forward.normalize();
        if(tick>=m.nextMotion||m.motion==null){m.motion=plugin.learning.combat.choose(s.room.game,gun.family(),distance,hp,p.getUniqueId().getLeastSignificantBits()+(++m.choices));m.nextMotion=tick+m.motion.ticks();m.jumpWanted=plugin.learning.combat.jump(s.room.game,gun.family(),m.choices*31+p.getUniqueId().getLeastSignificantBits());}
        double advance=m.motion.forward(),side=m.motion.side();if(reload||hp<.25)advance=Math.min(-.5,advance);else if(gun.family().equals("melee")||distance>AiGuns.range(gun))advance=1;else if(distance<5&&!gun.family().equals("melee"))advance=Math.min(0,advance);
        Vector move=forward.clone().multiply(advance).add(new Vector(-forward.getZ(),0,forward.getX()).multiply(side));
        if(m.doubleJumpAt>0&&tick>=m.doubleJumpAt){m.doubleJumpAt=0;if(!p.isOnGround()&&p.getAllowFlight())Bukkit.getPluginManager().callEvent(new org.bukkit.event.player.PlayerToggleFlightEvent(p,true));}
        if(AiTerrain.safeStep(p.getLocation(),move)){boolean jump=m.jumpWanted&&!reload&&tick>=m.nextJump&&p.isOnGround()&&!m.motion.sneak();if(jump){m.jumpWanted=false;m.nextJump=tick+60;m.doubleJumpAt=tick+4;}runtime.move(s.bot,move.getX(),move.getZ(),jump,m.motion.sprint()&&!reload,m.motion.sneak());}
        else {Vector alternate=new Vector(-forward.getZ(),0,forward.getX()).multiply(side==0?1:-Math.signum(side));if(AiTerrain.safeStep(p.getLocation(),alternate))runtime.move(s.bot,alternate.getX(),alternate.getZ(),false,false,false);else {runtime.stop(s.bot);if(tick>=m.nextFlank){m.nextFlank=tick+24;Location around=AiTerrain.flank(s.room.game,p.getLocation(),m.lastSeen,((int)m.choices&1)==0?1:-1);if(around!=null){s.action="flank";s.reason="unsafe-strafe-detour";brain.navigate(s,around,tick,false,false);}}}}
    }
    boolean search(AiBrain.State s,int tick){Memory m=s.combat;Player p=s.bot.getPlayer();if(AiGuns.reloading(plugin,p)){release(p);s.action="reload";s.reason="finish-protected-reload";if(m.cover!=null&&p.getLocation().distanceSquared(m.cover)>.8)brain.navigate(s,m.cover,tick,false,false);else runtime.stop(s.bot);return true;}if(m.lastSeen==null||tick-m.seenTick>60)return false;release(p);
        if(m.peek!=null&&tick<m.peekUntil){s.action="peek";s.reason="move-to-peek-edge";brain.navigate(s,m.peek,tick,false,false);return true;}
        if(m.peek!=null){m.peek=null;if(m.cover!=null){s.action="cover";s.reason="return-after-peek";brain.navigate(s,m.cover,tick,false,false);return true;}}

        if(m.cover!=null){
            double distance=p.getLocation().distanceSquared(m.cover);double hp=p.getHealth()/p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
            if(distance>=1&&(hp<.4||plugin.learning.telemetry.pressured(p,tick))){s.action="cover";s.reason="reach-selected-cover";brain.navigate(s,m.cover,tick,false,false);return true;}
            if(distance<1){
                if(tick<m.nextPeek){runtime.stop(s.bot);s.action="cover";s.reason="wait-before-peek";return true;}
                m.nextPeek=tick+32;m.peek=AiTerrain.peek(s.room.game,m.cover,m.lastSeen);m.peekUntil=tick+14;
                if(m.peek!=null){s.action="peek";s.reason="check-last-visible-position";brain.navigate(s,m.peek,tick,false,false);return true;}
            }
        }
        Location around=AiTerrain.flank(s.room.game,p.getLocation(),m.lastSeen,(s.index&1)==0?1:-1);if(around==null)return false;s.action="search";s.reason="last-seen-not-hidden-player";brain.navigate(s,around,tick,false,false);return true;
    }
}
