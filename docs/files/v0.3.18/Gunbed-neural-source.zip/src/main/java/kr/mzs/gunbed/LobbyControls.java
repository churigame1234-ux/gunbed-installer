package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.GameStatus;
import java.io.*;
import java.util.*;

/** Fixed lobby controls and preferences, independent of translated item names. */
final class LobbyControls implements Listener {
    private record Menu(String kind) implements InventoryHolder{public Inventory getInventory(){throw new UnsupportedOperationException();}}
    private final GunbedCore plugin;
    private final NamespacedKey key;
    LobbyControls(GunbedCore plugin){this.plugin=plugin;key=new NamespacedKey(plugin,"lobby_control");Bukkit.getPluginManager().registerEvents(this,plugin);plugin.getCommand("즐겨찾기").setExecutor((s,c,l,a)->{if(s instanceof Player p)favorites(p);return true;});plugin.getCommand("gunbed설정").setExecutor((s,c,l,a)->{if(s instanceof Player p)settings(p);return true;});}
    private boolean idle(Player p){var game=BedwarsAPI.getInstance().getGameOfPlayer(p);return game==null||game.getStatus()==GameStatus.WAITING;}
    private ItemStack item(Material material,String title,String action){ItemStack item=new ItemStack(material);var meta=item.getItemMeta();meta.setDisplayName(title);if(action!=null)meta.getPersistentDataContainer().set(key,PersistentDataType.STRING,action);item.setItemMeta(meta);return item;}
    private String action(ItemStack item){return item==null||!item.hasItemMeta()?null:item.getItemMeta().getPersistentDataContainer().get(key,PersistentDataType.STRING);}
    void toolbar(Player p){if(!p.isOnline()||ParkourV16.active(plugin,p)||!idle(p)||plugin.weaponLab.testing(p)||p.getGameMode()==GameMode.CREATIVE||p.getGameMode()==GameMode.SPECTATOR)return;
        if(!plugin.profiles.get(p.getUniqueId()).getBoolean("lobby.initial-hotbar-saved",false)){plugin.profiles.set(p.getUniqueId(),"lobby.original-hotbar",Arrays.stream(Arrays.copyOf(p.getInventory().getStorageContents(),5)).map(i->i==null?null:i.clone()).toList());plugin.profiles.set(p.getUniqueId(),"lobby.initial-hotbar-saved",true);if(!plugin.profiles.saved())return;}
        ItemStack[] buttons={item(Material.LECTERN,"§a게임 참가","join"),item(Material.BOOK,"§e즐겨찾기","favorites"),item(Material.NETHER_STAR,"§d치장","shop"),item(Material.COMPARATOR,"§b설정","settings"),item(Material.COMPASS,"§f서버 이동","servers")};for(int i=0;i<5;i++)p.getInventory().setItem(i,buttons[i]);}
    void favorites(Player p){Inventory inv=Bukkit.createInventory(new Menu("favorites"),27,"즐겨찾기 설정");inv.setItem(10,item(Material.CHEST,"§e아이템 상점 즐겨찾기",null));inv.setItem(13,item(Material.DIAMOND,"§b팀 상점 즐겨찾기",null));inv.setItem(16,item(Material.BOOK,"§a무기 세트 즐겨찾기",null));p.openInventory(inv);}
    void play(Player p){Inventory inv=Bukkit.createInventory(new Menu("play"),27,"Gunbed · 플레이 선택");inv.setItem(11,item(plugin.practice==null?Material.BARRIER:Material.PLAYER_HEAD,"§bAI 유저와 플레이",null));inv.setItem(15,item(Material.IRON_SWORD,"§a플레이어와 플레이",null));p.openInventory(inv);}
    void settings(Player p){Inventory inv=Bukkit.createInventory(new Menu("settings"),27,"Gunbed 개인 설정");var profile=plugin.profiles.get(p.getUniqueId());inv.setItem(10,item(profile.getBoolean("settings.damage-numbers",true)?Material.LIME_DYE:Material.GRAY_DYE,"§e피해량 · 남은 체력 표시: "+(profile.getBoolean("settings.damage-numbers",true)?"켜짐":"꺼짐"),null));inv.setItem(12,item(profile.getBoolean("settings.hit-sound",true)?Material.NOTE_BLOCK:Material.GRAY_DYE,"§e피격 확인 소리: "+(profile.getBoolean("settings.hit-sound",true)?"켜짐":"꺼짐"),null));inv.setItem(14,item(Material.SPYGLASS,"§eHUD 크기: "+Math.round(profile.getDouble("settings.hud-scale",1)*100)+"%",null));inv.setItem(16,item(Material.BARRIER,"§c처치 효과 해제",null));p.openInventory(inv);}
    private void servers(Player p){Inventory inv=Bukkit.createInventory(new Menu("servers"),27,"서버 이동");inv.setItem(11,item(Material.ZOMBIE_HEAD,"§a좀비서버 · 로비",null));inv.setItem(15,item(Material.SPYGLASS,"§b추리게임",null));p.openInventory(inv);}
    private void connect(Player p,String name){try{var bytes=new ByteArrayOutputStream();var out=new DataOutputStream(bytes);out.writeUTF("Connect");out.writeUTF(name);p.sendPluginMessage(plugin,"BungeeCord",bytes.toByteArray());p.closeInventory();}catch(IOException e){throw new UncheckedIOException(e);}}
    @EventHandler(priority=EventPriority.HIGHEST)public void use(PlayerInteractEvent e){if(e.getHand()!=EquipmentSlot.HAND||!e.getAction().isRightClick()&&!e.getAction().isLeftClick())return;String action=action(e.getItem());if(action==null)return;e.setCancelled(true);Player p=e.getPlayer();if(!idle(p)||plugin.weaponLab.testing(p))return;switch(action){case "join"->play(p);case "favorites"->favorites(p);case "shop"->plugin.cosmetics.open(p);case "settings"->settings(p);case "servers"->servers(p);default->{}}}
    @EventHandler public void click(InventoryClickEvent e){if(action(e.getCurrentItem())!=null||action(e.getCursor())!=null)e.setCancelled(true);if(e.getHotbarButton()>=0&&action(e.getWhoClicked().getInventory().getItem(e.getHotbarButton()))!=null)e.setCancelled(true);if(!(e.getView().getTopInventory().getHolder() instanceof Menu menu))return;e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p)||e.getRawSlot()<0||e.getRawSlot()>=27)return;int slot=e.getRawSlot();switch(menu.kind){case "play"->{if(slot==15)plugin.bedwars.openArenas(p,0);if(slot==11){if(plugin.practice!=null)plugin.practice.maps(p);else p.sendMessage("§eAI 경기장 준비 중입니다.");}}case "favorites"->{if(slot==10)plugin.bedwars.shop.editFavorites(p,false);if(slot==13)plugin.bedwars.shop.editFavorites(p,true);if(slot==16)plugin.arsenal.favorites(p);}case "settings"->{if(slot==10||slot==12){String setting=slot==10?"settings.damage-numbers":"settings.hit-sound";plugin.profiles.set(p.getUniqueId(),setting,!plugin.profiles.get(p.getUniqueId()).getBoolean(setting,true));}if(slot==14){double current=plugin.profiles.get(p.getUniqueId()).getDouble("settings.hud-scale",1);plugin.profiles.set(p.getUniqueId(),"settings.hud-scale",current<.95?1:current<1.1?1.25:.85);}if(slot==16)plugin.profiles.set(p.getUniqueId(),"cosmetics.kill-effect","");settings(p);}case "servers"->{if(slot==11)connect(p,"lobby");if(slot==15)connect(p,"churi");}default->{}}}
    @EventHandler public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof Menu||action(e.getOldCursor())!=null)e.setCancelled(true);}
    @EventHandler public void drop(PlayerDropItemEvent e){if(action(e.getItemDrop().getItemStack())!=null)e.setCancelled(true);}
    @EventHandler public void swap(PlayerSwapHandItemsEvent e){if(action(e.getMainHandItem())!=null||action(e.getOffHandItem())!=null)e.setCancelled(true);}
    @EventHandler public void join(PlayerJoinEvent e){var permissions=e.getPlayer().addAttachment(plugin);permissions.setPermission("worldedit.navigation.jumpto.tool",false);permissions.setPermission("worldedit.navigation.thru.tool",false);Bukkit.getScheduler().runTaskLater(plugin,()->toolbar(e.getPlayer()),20);}
    @EventHandler public void leave(BedwarsPlayerLeaveEvent e){Bukkit.getScheduler().runTaskLater(plugin,()->toolbar(e.getPlayer()),2);}
    @EventHandler public void end(BedwarsGameEndEvent e){Bukkit.getScheduler().runTaskLater(plugin,()->{for(Player p:e.getGame().getConnectedPlayers())toolbar(p);},80);}
    @EventHandler public void mode(PlayerGameModeChangeEvent e){Bukkit.getScheduler().runTask(plugin,()->toolbar(e.getPlayer()));}
}
