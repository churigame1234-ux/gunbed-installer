package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.game.Game;
import java.util.*;

/** Small, bounded terrain queries. No hidden player positions or speculative teleportation. */
final class AiTerrain {
    static boolean floor(Location p){var feet=p.clone();feet.setY(Math.ceil(p.getY()-.05));var base=feet.getBlock();return base.isPassable()&&base.getRelative(0,1,0).isPassable()&&base.getRelative(0,-1,0).getType().isSolid();}
    static boolean visible(Location eye,Location point){if(eye.getWorld()!=point.getWorld())return false;Vector d=point.toVector().subtract(eye.toVector());return d.lengthSquared()<.001||eye.getWorld().rayTraceBlocks(eye,d.clone().normalize(),d.length(),FluidCollisionMode.NEVER,true)==null;}
    static boolean safeStep(Location from,Vector movement){if(movement.lengthSquared()<.0001)return true;Vector d=movement.clone().setY(0).normalize();for(double distance:new double[]{.35,.75}){Location next=from.clone().add(d.clone().multiply(distance));if(!floor(next))return false;}return true;}
    static Location cover(Game game,Location from,Location threat){return cover(game,from,threat,List.of());}
    static Location cover(Game game,Location from,Location threat,Collection<Location> avoided){
        List<Location> candidates=new ArrayList<>();int base=(int)Math.ceil(from.getY()-.05);
        for(int x=-5;x<=5;x++)for(int z=-5;z<=5;z++)for(int y=-1;y<=1;y++){if(x*x+z*z>25)continue;Location at=new Location(from.getWorld(),from.getBlockX()+x+.5,base+y,from.getBlockZ()+z+.5);if(game.isLocationInArena(at)&&floor(at)&&avoided.stream().noneMatch(a->a.getBlockX()==at.getBlockX()&&a.getBlockY()==at.getBlockY()&&a.getBlockZ()==at.getBlockZ()))candidates.add(at);}
        candidates.sort(Comparator.comparingDouble(at->at.distanceSquared(from)));int checked=0;
        for(Location at:candidates){if(++checked>64)break;if(visible(threat,at.clone().add(0,1.45,0))||visible(threat,at.clone().add(0,.8,0)))continue;return at;}
        return null;
    }
    static Location peek(Game game,Location cover,Location threat){
        List<Location> candidates=new ArrayList<>();for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++){if(x*x+z*z<1||x*x+z*z>5)continue;Location at=cover.clone().add(x,0,z);if(game.isLocationInArena(at)&&floor(at)&&visible(at.clone().add(0,1.5,0),threat))candidates.add(at);}
        return candidates.stream().min(Comparator.comparingDouble(a->a.distanceSquared(cover))).orElse(null);
    }
    static Location flank(Game game,Location from,Location threat,int side){Vector forward=threat.toVector().subtract(from.toVector()).setY(0);if(forward.lengthSquared()<.1)return null;forward.normalize();Vector right=new Vector(-forward.getZ(),0,forward.getX());
        for(double distance:new double[]{3,2,1}){Location at=from.clone().add(right.clone().multiply(distance*side)).add(forward.clone().multiply(1.5));at.setX(at.getBlockX()+.5);at.setZ(at.getBlockZ()+.5);at.setY(Math.ceil(from.getY()-.05));if(game.isLocationInArena(at)&&floor(at))return at;}return null;
    }
}
