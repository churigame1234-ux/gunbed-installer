package kr.mzs.gunbed;

import java.util.*;
import org.bukkit.entity.Player;

/** Both ordinary falls and double-jump landings charge only the distance beyond ten blocks. */
final class DoubleJumpFallGrace {
    private static final Map<UUID,Integer> ticks=new HashMap<>();
    private static final Map<UUID,Double> ground=new HashMap<>(),launch=new HashMap<>();
    static void ground(Player p){ground.put(p.getUniqueId(),p.getY());}
    static void launch(Player p){ticks.put(p.getUniqueId(),org.bukkit.Bukkit.getCurrentTick());launch.put(p.getUniqueId(),ground.getOrDefault(p.getUniqueId(),p.getY()));var core=org.bukkit.plugin.java.JavaPlugin.getPlugin(GunbedCore.class);if(core.protocol!=null)core.protocol.emit(p,Map.of("event","jumpLaunch","y",launch.get(p.getUniqueId())));}
    static double landing(Player p,double ordinary){if(launch.containsKey(p.getUniqueId())&&org.bukkit.Bukkit.getCurrentTick()-ticks.getOrDefault(p.getUniqueId(),-10)<4&&p.getVelocity().getY()>.1)return 0;Double at=launch.remove(p.getUniqueId());ticks.remove(p.getUniqueId());ground(p);double drop=at==null?ordinary:at-p.getY();return drop<=10?0:3+(drop-10);}
    static void clear(Player p){ground.remove(p.getUniqueId());launch.remove(p.getUniqueId());ticks.remove(p.getUniqueId());}
}
