package kr.mzs.gunbed;
import com.shampaggon.crackshot.events.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import java.util.*;

/** Arrow launchers use one impact and three discrete StarCraft-style damage zones. */
final class ExplosiveRounds implements Listener {
    private record Round(Player owner,String title){}
    private final Set<UUID> spent=new HashSet<>();
    private final Map<UUID,Round> rounds=new HashMap<>();
    private final GunbedCore plugin;
    private final Set<String> ids=Set.of("골데B","소드오프");
    private final ThreadLocal<Boolean> applying=ThreadLocal.withInitial(()->false);
    ExplosiveRounds(GunbedCore p){plugin=p;for(String id:ids)com.shampaggon.crackshot.CSDirector.bools.put(id+".Explosions.Enable",false);Bukkit.getPluginManager().registerEvents(this,p);}
    @EventHandler(priority=EventPriority.MONITOR)public void shot(WeaponShootEvent e){if(ids.contains(e.getWeaponTitle())&&e.getProjectile()!=null){if(e.getProjectile() instanceof Projectile q)LauncherEffects.track(plugin,q);UUID uuid=e.getProjectile().getUniqueId();rounds.put(uuid,new Round(e.getPlayer(),e.getWeaponTitle()));Bukkit.getScheduler().runTaskLater(plugin,()->rounds.remove(uuid),200);}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void direct(WeaponDamageEntityEvent e){if(ids.contains(e.getWeaponTitle())&&!applying.get())e.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void raw(EntityDamageByEntityEvent e){UUID id=e.getDamager().getUniqueId();Round r=rounds.remove(id);if(r!=null){e.setCancelled(true);spent.add(id);Location at=e.getEntity().getBoundingBox().getCenter().toLocation(e.getEntity().getWorld());if(e.getDamager() instanceof Projectile q)LauncherEffects.finish(q,at);Bukkit.getScheduler().runTask(plugin,()->{blast(r.owner,r.title,at);spent.remove(id);});e.getDamager().remove();}else if(spent.contains(id))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void impact(ProjectileHitEvent e){Round r=rounds.remove(e.getEntity().getUniqueId());if(r==null)return;UUID id=e.getEntity().getUniqueId();spent.add(id);Bukkit.getScheduler().runTask(plugin,()->spent.remove(id));Location at=BlastExposure.impact(e.getEntity().getLocation(),e.getHitBlock(),e.getHitBlockFace());if(e.getHitEntity()!=null)at=e.getHitEntity().getBoundingBox().getCenter().toLocation(at.getWorld());LauncherEffects.finish(e.getEntity(),at);blast(r.owner,r.title,at);e.getEntity().remove();}
    private void blast(Player p,String title,Location at){var game=BedwarsAPI.getInstance().getGameOfPlayer(p);if(game==null)return;var team=game.getTeamOfPlayer(p);if(team==null)return;double radius=title.equals("소드오프")?3:2;plugin.wool.blast(p,game,at,radius,d->plugin.damageProfiles.blast("cs:"+title,d<=radius/3?"center":d<=radius*2/3?"middle":"outer"));BattleTargets.blastTurrets(plugin,p,game,at,radius,d->plugin.damageProfiles.blast("cs:"+title,d<=radius/3?"center":d<=radius*2/3?"middle":"outer"));DragonCrackShotImpact.blast(plugin,p,game,title,at,radius);LauncherEffects.burst(plugin,p,at);at.getWorld().spawnParticle(Particle.EXPLOSION,at,1);at.getWorld().playSound(at,Sound.ENTITY_GENERIC_EXPLODE,.8f,1);for(Player target:game.getConnectedPlayers()){var other=game.getTeamOfPlayer(target);if(target==p||other==null||other==team||target.isDead()||target.getGameMode()==GameMode.SPECTATOR||target.getWorld()!=at.getWorld())continue;double distance=BlastExposure.distance(at,target,radius);if(distance>radius)continue;double value=plugin.damageProfiles.blast("cs:"+title,distance<=radius/3?"center":distance<=radius*2/3?"middle":"outer");applying.set(true);try{target.setNoDamageTicks(0);BlastExposure.damage(p,target,value,title);}finally{applying.remove();}}}
}
