package kr.mzs.gunbed;

import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.CompassMeta;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.RunningTeam;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.*;

/** Team Tracker rules adapted to Gunbed's wallet, palette and weapon bank. */
final class EnemyTracker implements Listener {
    private static final int PRICE=2, MENU_SIZE=36, CLOSE_SLOT=31;
    private record Menu(Game game,Map<Integer,String> teams) implements InventoryHolder {
        public Inventory getInventory(){throw new UnsupportedOperationException();}
    }
    private record Selection(Game game,String team){}
    private final GunbedCore plugin;
    private final Map<UUID,Selection> selections=new HashMap<>();
    // The purchase selects a team; the resolved player can change without another purchase.
    private final Map<UUID,UUID> targets=new HashMap<>();
    private final NamespacedKey key,teamKey;

    EnemyTracker(GunbedCore plugin){
        this.plugin=plugin;key=new NamespacedKey(plugin,"enemy_tracker");teamKey=new NamespacedKey(plugin,"tracker_team");
        FixedTracker.install(plugin);TrackerStatus.install(plugin);
        Bukkit.getPluginManager().registerEvents(this,plugin);
        Bukkit.getScheduler().runTaskTimer(plugin,this::tick,10,10);
    }
    private Game active(Player player){
        Game game=BedwarsAPI.getInstance().getGameOfPlayer(player);
        return game!=null&&game.getStatus()==GameStatus.RUNNING&&game.getTeamOfPlayer(player)!=null
                &&!player.isDead()&&player.getGameMode()!=GameMode.SPECTATOR?game:null;
    }
    private List<RunningTeam> enemies(Game game,Player player){
        var own=game.getTeamOfPlayer(player);
        return game.getRunningTeams().stream().filter(t->t.isAlive()&&!t.getName().equals(own.getName())).toList();
    }
    boolean available(Player player){Game game=active(player);return game!=null&&enemies(game,player).stream().noneMatch(RunningTeam::isTargetBlockExists);}
    RunningTeam selectedTeam(Player player){
        Selection selected=selections.get(player.getUniqueId());
        if(selected==null||active(player)!=selected.game)return null;
        return selected.game.getRunningTeams().stream().filter(t->t.getName().equals(selected.team)&&t.isAlive()).findFirst().orElse(null);
    }
    void open(Player player){
        Game game=active(player);if(game==null)return;
        List<RunningTeam> teams=enemies(game,player);Map<Integer,String> slots=new LinkedHashMap<>();
        for(int i=0;i<teams.size();i++)slots.put(10+i%7+i/7*9,teams.get(i).getName());
        Inventory inventory=Bukkit.createInventory(new Menu(game,Map.copyOf(slots)),MENU_SIZE,"적 팀 추적 구매");
        ItemStack filler=button(Material.BLACK_STAINED_GLASS_PANE," ");
        for(int slot=0;slot<MENU_SIZE;slot++)inventory.setItem(slot,filler);
        boolean unlocked=available(player);long money=plugin.wallet.amount(player,Material.EMERALD);
        for(var entry:slots.entrySet()){
            RunningTeam team=teams.stream().filter(t->t.getName().equals(entry.getValue())).findFirst().orElseThrow();
            var color=TeamPalette.of(game,team);ItemStack item=button(Material.valueOf(color.dye().name()+"_WOOL"),
                    (unlocked?"§a":"§c")+"추적: "+color.legacy()+color.name()+"팀");
            List<String> lore=new ArrayList<>(List.of("§7선택한 팀의 플레이어를 추적합니다.","§7가장 가까운 생존자를 자동으로 가리키며","§7본인이 죽을 때까지 유지됩니다.","","§7가격: §22 에메랄드",""));
            RunningTeam selected=selectedTeam(player);
            lore.add(!unlocked?"§c모든 적 침대가 파괴되면 구매할 수 있습니다.":selected!=null&&selected.getName().equals(team.getName())?"§c현재 추적 중인 팀입니다.":money<PRICE?"§c에메랄드가 부족합니다.":"§e클릭하여 구매하세요!");
            var meta=item.getItemMeta();meta.setLore(lore);meta.getPersistentDataContainer().set(teamKey,PersistentDataType.STRING,team.getName());item.setItemMeta(meta);
            inventory.setItem(entry.getKey(),item);
        }
        inventory.setItem(CLOSE_SLOT,button(Material.ARROW,"§c닫기"));player.openInventory(inventory);
    }
    private ItemStack button(Material material,String name){ItemStack item=new ItemStack(material);var meta=item.getItemMeta();meta.setDisplayName(name);item.setItemMeta(meta);return item;}
    private void reject(Player player,String message,Sound sound){player.closeInventory();player.sendMessage(message);player.playSound(player.getLocation(),sound,1,.5f);}
    @EventHandler public void click(InventoryClickEvent event){
        if(!(event.getView().getTopInventory().getHolder() instanceof Menu menu))return;
        event.setCancelled(true);if(!(event.getWhoClicked() instanceof Player player)||active(player)!=menu.game)return;
        if(event.getRawSlot()==CLOSE_SLOT){player.closeInventory();return;}
        String name=menu.teams.get(event.getRawSlot());if(name==null)return;
        RunningTeam team=enemies(menu.game,player).stream().filter(t->t.getName().equals(name)).findFirst().orElse(null);
        if(team==null){open(player);return;}
        if(!available(player)){reject(player,"§c모든 적 침대가 파괴된 뒤에 추적을 구매할 수 있습니다.",Sound.BLOCK_ANVIL_USE);return;}
        RunningTeam selected=selectedTeam(player);
        if(selected!=null&&selected.getName().equals(name)){reject(player,"§c이미 이 팀을 추적하고 있습니다.",Sound.BLOCK_ANVIL_USE);return;}
        if(!FixedTracker.ensure(plugin,player)){reject(player,"§c추적기를 지급할 인벤토리 공간이 필요합니다.",Sound.ENTITY_VILLAGER_NO);return;}
        if(!plugin.wallet.pay(player,List.of(new ItemStack(Material.EMERALD,PRICE)))){reject(player,"§c에메랄드 2개가 필요합니다.",Sound.ENTITY_VILLAGER_NO);return;}
        Selection purchase=new Selection(menu.game,name);selections.put(player.getUniqueId(),purchase);resolve(player,purchase);
        player.closeInventory();var color=TeamPalette.of(menu.game,team);
        player.sendMessage("§a"+color.legacy()+color.name()+"팀 §a추적을 구매했습니다.");
        player.playSound(player.getLocation(),Sound.ENTITY_PLAYER_LEVELUP,1,.5f);
        TrackerStatus.show(plugin,player,team,nearestTarget(player));
    }
    private Player nearestTarget(Player player){UUID id=targets.get(player.getUniqueId());return id==null?null:Bukkit.getPlayer(id);}
    private void resolve(Player player,Selection selected){
        Player nearest=selected.game.getConnectedPlayers().stream().filter(other->other!=player&&active(other)==selected.game
                &&selected.game.getTeamOfPlayer(other).getName().equals(selected.team)&&other.getWorld()==player.getWorld())
                .min(Comparator.<Player>comparingDouble(other->other.getLocation().distanceSquared(player.getLocation())).thenComparing(Player::getUniqueId)).orElse(null);
        if(nearest==null){targets.remove(player.getUniqueId());return;}
        targets.put(player.getUniqueId(),nearest.getUniqueId());
        ItemStack compass=button(Material.COMPASS,"§a팀 추적기 · "+TeamPalette.of(selected.game,selectedTeam(player)).name()+"팀");
        var meta=(CompassMeta)compass.getItemMeta();meta.getPersistentDataContainer().set(key,PersistentDataType.BYTE,(byte)1);
        meta.setLore(List.of("§7현재 대상: "+TeamPalette.display(nearest),"§7우클릭: 다른 팀 추적 구매 · 에메랄드 2개","§7사망 시 추적 해제"));
        meta.setLodestone(nearest.getLocation().getBlock().getLocation());meta.setLodestoneTracked(false);compass.setItemMeta(meta);
        FixedTracker.selected(plugin,player,compass);player.setCompassTarget(nearest.getLocation());
    }
    void clear(Player player){
        selections.remove(player.getUniqueId());targets.remove(player.getUniqueId());
        TrackerStatus.clear(plugin,player);if(active(player)!=null)FixedTracker.reset(plugin,player);
    }
    private void tick(){
        for(Player player:Bukkit.getOnlinePlayers())if(FixedTracker.active(player))FixedTracker.ensure(plugin,player);
        for(var entry:List.copyOf(selections.entrySet())){
            Player player=Bukkit.getPlayer(entry.getKey());if(player==null){selections.remove(entry.getKey());targets.remove(entry.getKey());continue;}
            if(active(player)!=entry.getValue().game||selectedTeam(player)==null){clear(player);continue;}
            resolve(player,entry.getValue());
        }
        TrackerStatus.tick(plugin,targets);
    }
    private boolean tracker(ItemStack item){return item!=null&&item.hasItemMeta()&&item.getItemMeta().getPersistentDataContainer().has(key);}
    @EventHandler(priority=EventPriority.HIGHEST)public void use(PlayerInteractEvent event){if(event.getHand()==EquipmentSlot.HAND&&event.getAction().isRightClick()&&tracker(event.getItem())){event.setCancelled(true);open(event.getPlayer());}}
    @EventHandler public void drag(InventoryDragEvent event){if(event.getView().getTopInventory().getHolder() instanceof Menu)event.setCancelled(true);}
    @EventHandler public void end(BedwarsGameEndingEvent event){for(var entry:List.copyOf(selections.entrySet()))if(entry.getValue().game==event.getGame()){Player player=Bukkit.getPlayer(entry.getKey());if(player!=null)clear(player);else{selections.remove(entry.getKey());targets.remove(entry.getKey());}}}
    @EventHandler public void leave(BedwarsPlayerLeaveEvent event){clear(event.getPlayer());}
    @EventHandler public void quit(PlayerQuitEvent event){clear(event.getPlayer());}
}
