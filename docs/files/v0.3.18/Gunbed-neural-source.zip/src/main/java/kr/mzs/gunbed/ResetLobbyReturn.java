package kr.mzs.gunbed;

import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.Main;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.game.GamePlayer;

/** A short, arena-aware fence against the engine's delayed makeSpectator callbacks. */
final class ResetLobbyReturn implements Listener {
    private static GunbedCore owner;
    private static final Map<UUID,Integer> until=new HashMap<>();
    private static final Map<UUID,GamePlayer> profiles=new HashMap<>();
    static void begin(GunbedCore plugin,Player player) {
        if(owner==null){owner=plugin;Bukkit.getPluginManager().registerEvents(new ResetLobbyReturn(),plugin);Bukkit.getScheduler().runTaskTimer(plugin,ResetLobbyReturn::tick,1,1);}
        until.put(player.getUniqueId(),Bukkit.getCurrentTick()+40);
        if(Main.isPlayerGameProfileRegistered(player))profiles.put(player.getUniqueId(),Main.getPlayerGameProfile(player));
    }
    static void finish(GunbedCore plugin,Player player) {
        if(!player.isOnline()||BedwarsAPI.getInstance().getGameOfPlayer(player)!=null)return;
        try {var restore=BattleInventory.class.getDeclaredMethod("restore",Player.class);restore.setAccessible(true);restore.invoke(plugin.inventories,player);}
        catch(ReflectiveOperationException e){throw new IllegalStateException("Reset inventory release failed",e);}
        try{var deaths=MatchCorpses.class.getDeclaredField("deaths");deaths.setAccessible(true);((Map<?,?>)deaths.get(plugin.corpses)).remove(player.getUniqueId());var bodies=MatchCorpses.class.getDeclaredField("bodies");bodies.setAccessible(true);for(Object body:List.copyOf(((Map<?,?>)bodies.get(plugin.corpses)).values())){var owner=body.getClass().getDeclaredField("owner");owner.setAccessible(true);if(player.getUniqueId().equals(owner.get(body))){var remove=MatchCorpses.class.getDeclaredMethod("remove",body.getClass());remove.setAccessible(true);remove.invoke(plugin.corpses,body);}}}catch(ReflectiveOperationException e){throw new IllegalStateException("Reset corpse release failed",e);}
        clearSpectator(player);if(player.isDead()){player.spigot().respawn();return;}
        player.setGameMode(GameMode.SURVIVAL);player.setFlying(false);player.setFallDistance(0);player.setInvulnerable(false);player.setVelocity(new org.bukkit.util.Vector());
        player.teleport(lobby());ready(player);plugin.controls.toolbar(player);plugin.protocol.refreshHeld(player);
    }
    private static void ready(Player player){try{Object handle=player.getClass().getMethod("getHandle").invoke(player);Object connection=handle.getClass().getField("connection").get(handle);var waiting=connection.getClass().getDeclaredField("waitingForRespawn");waiting.setAccessible(true);if(waiting.getBoolean(connection)&&!player.isDead()&&player.getHealth()>0){
        // BedWars converts death to a live spectator instead of a vanilla respawn.
        // Release only that stale death gate; ordinary chunk-loading stays intact.
        connection.getClass().getMethod("restartClientLoadTimerAfterRespawn").invoke(connection);var loaded=connection.getClass().getDeclaredMethod("markClientLoaded");loaded.setAccessible(true);loaded.invoke(connection);
    }}catch(ReflectiveOperationException e){throw new IllegalStateException("Reset client input release failed",e);}}
    static Location lobby(){var config=Main.getConfigurator().config;World world=Bukkit.getWorld(config.getString("mainlobby.world","world"));if(world==null)world=Bukkit.getWorlds().getFirst();String[] point=config.getString("mainlobby.location","").split(";");if(point.length>=3)try{return new Location(world,Double.parseDouble(point[0]),Double.parseDouble(point[1]),Double.parseDouble(point[2]),point.length>3?Float.parseFloat(point[3]):0,point.length>4?Float.parseFloat(point[4]):0);}catch(NumberFormatException ignored){}return world.getSpawnLocation();}
    private static void clearSpectator(Player player) {
        GamePlayer old=profiles.get(player.getUniqueId());if(old!=null){old.isSpectator=false;old.temporaryTransitionSpectatorLockMovement=false;}
        if(Main.isPlayerGameProfileRegistered(player)){GamePlayer current=Main.getPlayerGameProfile(player);if(current.getGame()==null){current.isSpectator=false;current.temporaryTransitionSpectatorLockMovement=false;}}
    }
    private static void tick(){for(UUID id:List.copyOf(until.keySet())) {
        Player p=Bukkit.getPlayer(id);
        if(p==null||Bukkit.getCurrentTick()>until.get(id)||BedwarsAPI.getInstance().getGameOfPlayer(p)!=null){until.remove(id);profiles.remove(id);continue;}
        clearSpectator(p);if(p.isDead()){p.spigot().respawn();continue;}
        if(p.getGameMode()==GameMode.SPECTATOR){p.setGameMode(GameMode.SURVIVAL);p.setFlying(false);p.setFallDistance(0);}
        if(p.getGameMode()==GameMode.SURVIVAL){if(p.isFlying())p.setFlying(false);ready(p);}
        var item=p.getInventory().getItem(0);
        if(item==null||!item.hasItemMeta()||!"join".equals(item.getItemMeta().getPersistentDataContainer().get(new NamespacedKey(owner,"lobby_control"),PersistentDataType.STRING)))owner.controls.toolbar(p);
    }}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void mode(PlayerGameModeChangeEvent e){if(e.getNewGameMode()==GameMode.SPECTATOR&&until.containsKey(e.getPlayer().getUniqueId())&&BedwarsAPI.getInstance().getGameOfPlayer(e.getPlayer())==null)e.setCancelled(true);}
    @EventHandler public void quit(PlayerQuitEvent e){until.remove(e.getPlayer().getUniqueId());profiles.remove(e.getPlayer().getUniqueId());}
}
