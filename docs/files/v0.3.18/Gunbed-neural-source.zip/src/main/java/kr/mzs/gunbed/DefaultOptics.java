package kr.mzs.gunbed;

import java.util.*;

/** Fixed non-thermal optics; no attachment purchases or per-player configuration. */
final class DefaultOptics {
    static String id(String gun){return switch(gun){case "svd"->"scope_pso_1";case "hm50b","mrad"->"scope_mk4ert";case "scar_mk20","hcar"->"scope_c79";case "m1866"->"scope_1866_4x";case "ak12","ak74m"->"sight_1p87";case "mcx_spear_lt","mk18","urgi","qr_24","hk_mp7a1","pkm"->"sight_apm4s";default->"";};}
    static String name(String gun){return switch(id(gun)){case "scope_pso_1"->"PSO-1";case "scope_mk4ert"->"Mark 4 ER/T";case "scope_c79"->"C79";case "scope_1866_4x"->"Winchester Sharpshooter";case "sight_1p87"->"1P87";case "sight_apm4s"->"APM4s";default->"기본 조준기";};}
}
