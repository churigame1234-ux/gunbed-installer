"""Read plugin identities from JAR metadata; prepare an isolated migration server."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import zipfile
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = Path(r"C:\Users\mydon\Desktop\마크서버\번지코드서버")
GUNBED = BASE / "gunbed"
REFERENCE = BASE / "zombie 1.21.11"
STAGE = ROOT / ".local" / "staging"
UPGRADES = {
    "Citizens", "EasyCommandBlocker", "Essentials", "EssentialsSpawn", "Images",
    "NBTAPI", "LuckPerms", "ProtocolLib", "SkBee", "Skript", "TAB",
    "ViaVersion", "ViaBackwards",
}
# No gunbed configurations or scripts refer to these two alternative item/gun engines.
# Core utilities are replaced by GunbedCore before deployment.
REPLACED = {"Block_Hunger", "NoGroundDecay", "ChatNotifySound", "ForceResourcePack"}
UNUSED = {"QualityArmory", "ItemsAdder"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def inspect(path: Path) -> dict:
    with zipfile.ZipFile(path) as jar:
        entry = "plugin.yml" if "plugin.yml" in jar.namelist() else "paper-plugin.yml"
        meta = yaml.safe_load(jar.read(entry).decode("utf-8-sig"))
        main = meta["main"].replace(".", "/") + ".class"
        major = int.from_bytes(jar.read(main)[6:8], "big") if main in jar.namelist() else None
    return {
        "file": path.name, "path": str(path), "name": meta["name"],
        "version": str(meta["version"]), "main": meta["main"],
        "api": str(meta.get("api-version", "legacy")),
        "depend": meta.get("depend", []), "softdepend": meta.get("softdepend", []),
        "provides": meta.get("provides", []), "java_class_major": major,
        "sha256": sha256(path),
    }


def inventory(server: Path) -> list[dict]:
    return [inspect(path) for path in sorted((server / "plugins").glob("*.jar"))]


def dump(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def copytree(source: Path, target: Path) -> None:
    if source.exists():
        shutil.copytree(source, target, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("session.lock", "*.lck", "*.lock"))


def prepare() -> None:
    if (STAGE / ".prepared").exists():
        raise SystemExit(f"Refusing to overwrite an existing stage: {STAGE}")
    old = inventory(GUNBED)
    reference = {p["name"]: p for p in inventory(REFERENCE)}
    STAGE.mkdir(parents=True, exist_ok=True)
    for name in ("server.properties", "bukkit.yml", "spigot.yml", "commands.yml", "eula.txt"):
        shutil.copy2(GUNBED / name, STAGE / name)
    shutil.copy2(REFERENCE / "server.jar", STAGE / "server.jar")
    for name in ("libraries", "versions", "cache"):
        copytree(REFERENCE / name, STAGE / name)
    for name in ("world", "world_nether", "world_the_end", "siege", "newwolrd", "config"):
        copytree(GUNBED / name, STAGE / name)
    plugin_dir = STAGE / "plugins"
    plugin_dir.mkdir(exist_ok=True)
    actions = []
    for plugin in old:
        name = plugin["name"]
        if name in REPLACED | UNUSED:
            actions.append({"name": name, "action": "replace-core" if name in REPLACED else "archive-unused", "old": plugin})
            continue
        replacement = reference[name] if name in UPGRADES else plugin
        if name == "WorldEdit":
            replacement = next(p for p in inventory(REFERENCE) if p["name"] == "FastAsyncWorldEdit")
        if name == "ComplexTurrets":
            replacement = inspect(next((REFERENCE / "임시 비활성화 플긴").glob("ComplexTurrets-3.25.2*.jar")))
        shutil.copy2(replacement["path"], plugin_dir / replacement["file"])
        actions.append({"name": name, "action": "upgrade" if replacement["sha256"] != plugin["sha256"] else "retain", "old": plugin, "new": replacement})
    for folder in (GUNBED / "plugins").iterdir():
        if not folder.is_dir() or folder.name.startswith(".") or folder.name in {"폐기한 플긴", "됨", "채팅로그", "ItemsAdder", "QualityArmory"}:
            continue
        if folder.name == "Skript":
            target = plugin_dir / folder.name
            target.mkdir(exist_ok=True)
            for item in folder.iterdir():
                if item.name == "backups":
                    continue
                if item.is_dir():
                    copytree(item, target / item.name)
                else:
                    shutil.copy2(item, target / item.name)
        else:
            copytree(folder, plugin_dir / folder.name)
    props = (STAGE / "server.properties").read_text(encoding="utf-8")
    values = {
        "server-ip": "127.0.0.1", "server-port": "25688", "online-mode": "true",
        "enable-query": "false", "enable-rcon": "false", "white-list": "true",
        "enforce-whitelist": "true", "view-distance": "3", "simulation-distance": "3",
        "resource-pack": "", "resource-pack-sha1": "", "require-resource-pack": "false",
        "enable-status": "true",
    }
    for key, value in values.items():
        if re.search(r"^" + re.escape(key) + "=", props, re.M):
            props = re.sub(r"^" + re.escape(key) + r"=.*$", key + "=" + value, props, flags=re.M)
        else:
            props += "\n" + key + "=" + value
    (STAGE / "server.properties").write_text(props, encoding="utf-8")
    # Disable copied server/proxy forwarding only inside this loopback test instance.
    spigot_path = STAGE / "spigot.yml"
    spigot_path.write_text(re.sub(r"bungeecord: true", "bungeecord: false", spigot_path.read_text(encoding="utf-8")), encoding="utf-8")
    # FileCleaner can remove team data on commands. Test its replacement separately.
    for plugin in inventory(STAGE):
        if plugin["name"] == "FileCleaner":
            source = Path(plugin["path"])
            source.rename(source.with_suffix(".jar.disabled"))
    reboot = plugin_dir / "Skript/scripts/[시스템]자동리붓.sk"
    reboot.rename(reboot.with_suffix(".sk.disabled"))
    dump(ROOT / "reports" / "migration-plan.json", actions)
    (STAGE / ".prepared").write_text("Prepared from gunbed and zombie 1.21.11; loopback only.\n", encoding="utf-8")
    print(json.dumps({"stage": str(STAGE), "plugins": len(inventory(STAGE)), "actions": {a: sum(p["action"] == a for p in actions) for a in {p["action"] for p in actions}}}, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["audit", "prepare"])
    args = parser.parse_args()
    if args.action == "audit":
        for folder in (GUNBED, REFERENCE):
            plugins = inventory(folder)
            dump(ROOT / "reports" / (folder.name + "-before.json"), plugins)
            print(f"{folder.name}: {len(plugins)} plugins")
    else:
        prepare()
