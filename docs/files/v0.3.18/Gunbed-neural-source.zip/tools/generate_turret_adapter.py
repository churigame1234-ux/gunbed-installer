"""Thin native triangle renderer, including the render-state bridge on newer games."""
def generate(package,version,identifier,legacy):
    buffer='MultiBufferSource' if legacy else 'SubmitNodeCollector'
    draw='vertices(surface.frame(),matrices.last(),buffers.getBuffer(type),light,surface.color());' if legacy else 'buffers.submitCustomGeometry(matrices,type,(pose,consumer)->vertices(surface.frame(),pose,consumer,light,surface.color()));'
    types='RenderType' if version in ('1.21.8','1.21.9','1.21.10') else 'RenderTypes'
    imports='net.minecraft.client.renderer.'+types if types=='RenderType' else 'net.minecraft.client.renderer.rendertype.RenderTypes'
    render=f'''package kr.mzs.gunbedvisual;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.renderer.{buffer};
import {imports};
import net.minecraft.resources.{identifier};
import org.joml.Vector3f;
import kr.mzs.gunbedvisual.model.GunMesh;
public final class GunbedWorldMeshes {{
 public static boolean draw(String kind,PoseStack matrices,{buffer} buffers,int light){{return draw(kind,matrices,buffers,light,0);}}
 public static boolean draw(String kind,PoseStack matrices,{buffer} buffers,int light,float pitch){{if(!HudState.INSTANCE.active()||kind==null||kind.isEmpty())return false;var mesh=TurretMesh.get(kind);if(mesh.isEmpty())return false;for(var surface:mesh){{matrices.pushPose();if(surface.frame().vertices().stream().mapToDouble(v->v.y()).average().orElse(0)>.48){{matrices.translate(0,.55,0);matrices.mulPose(new org.joml.Matrix4f().rotationX((float)Math.toRadians(pitch)));matrices.translate(0,-.55,0);}}var type={types}.entityCutout({identifier}.parse(surface.texture()));{draw}matrices.popPose();}}return true;}}
 private static void vertices(GunMesh.Frame frame,PoseStack.Pose pose,VertexConsumer consumer,int light,int color){{Vector3f p=new Vector3f(),n=new Vector3f();for(var v:frame.vertices()){{pose.pose().transformPosition(v.x(),v.y(),v.z(),p);pose.normal().transform(v.nx(),v.ny(),v.nz(),n).normalize();consumer.addVertex(p.x,p.y,p.z).setColor(color).setUv(v.u(),v.v()).setOverlay(net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY).setLight(light).setNormal(n.x,n.y,n.z);}}}}
}}
'''
    (package/'GunbedWorldMeshes.java').write_text(render,encoding='utf8')
    state='net.minecraft.client.renderer.entity.state.ItemDisplayEntityRenderState'
    # All mapped versions expose this nested render state. Explicit descriptors avoid bridge overloads.
    method='renderInner' if legacy else 'submitInner'
    desc=method+'(L'+state.replace('.','/')+';Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/'+buffer+';IF)V'
    (package/'mixin/GunbedTurretStateMixin.java').write_text(f'''package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.*;
@Mixin({state}.class)
public abstract class GunbedTurretStateMixin implements kr.mzs.gunbedvisual.TurretDisplayData {{@Unique private float gunbed$pitch;public float gunbed$pitch(){{return gunbed$pitch;}}public void gunbed$pitch(float pitch){{gunbed$pitch=pitch;}}@Unique private String gunbed$kind="";public String gunbed$kind(){{return gunbed$kind;}}public void gunbed$kind(String kind){{gunbed$kind=kind;}}}}
''',encoding='utf8')
    (package/'mixin/GunbedTurretMixin.java').write_text(f'''package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.world.entity.Display;
import {state};
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.{buffer};
@Mixin(net.minecraft.client.renderer.entity.DisplayRenderer.ItemDisplayRenderer.class)
public abstract class GunbedTurretMixin {{
 @Inject(method="extractRenderState(Lnet/minecraft/world/entity/Display$ItemDisplay;Lnet/minecraft/client/renderer/entity/state/ItemDisplayEntityRenderState;F)V",at=@At("TAIL"))
 private void gunbed$extract(Display.ItemDisplay entity,ItemDisplayEntityRenderState state,float partial,CallbackInfo ci){{var data=(kr.mzs.gunbedvisual.TurretDisplayData)(Object)state;var itemState=entity.itemRenderState();if(itemState==null){{data.gunbed$kind("");return;}}var model=itemState.itemStack().get(net.minecraft.core.component.DataComponents.ITEM_MODEL);String kind="";if(model!=null&&model.getNamespace().equals("gunbed")&&model.getPath().startsWith("turret/"))kind=model.getPath().substring(7);data.gunbed$kind(kind);data.gunbed$pitch(kr.mzs.gunbedvisual.HudState.INSTANCE.turretPitch(entity.getUUID()));}}
 @Inject(method="{desc}",at=@At("HEAD"),cancellable=true)
 private void gunbed$draw(ItemDisplayEntityRenderState state,PoseStack poses,{buffer} buffers,int light,float partial,CallbackInfo ci){{if(kr.mzs.gunbedvisual.GunbedWorldMeshes.draw(((kr.mzs.gunbedvisual.TurretDisplayData)(Object)state).gunbed$kind(),poses,buffers,light,((kr.mzs.gunbedvisual.TurretDisplayData)(Object)state).gunbed$pitch()))ci.cancel();}}
}}
''',encoding='utf8')

    (package/'mixin/GunbedVisibilityMixin.java').write_text("""package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(net.minecraft.world.entity.Entity.class)
public abstract class GunbedVisibilityMixin {
 @Inject(method="shouldRenderAtSqrDistance",at=@At("RETURN"),cancellable=true)
 private void gunbed$distance(double square,CallbackInfoReturnable<Boolean> ci){if(!((Object)this instanceof net.minecraft.world.entity.Display)&&kr.mzs.gunbedvisual.HudState.INSTANCE.active()&&square<16384&&!ci.getReturnValue())ci.setReturnValue(true);}
 @Inject(method="getTeamColor",at=@At("RETURN"),cancellable=true)
 private void gunbed$glow(CallbackInfoReturnable<Integer> ci){var state=kr.mzs.gunbedvisual.HudState.INSTANCE;if(!state.active())return;var entity=(net.minecraft.world.entity.Entity)(Object)this;Integer colour=state.glow(entity.getUUID());if(colour!=null)ci.setReturnValue(colour);}
}
""",encoding='utf8')
