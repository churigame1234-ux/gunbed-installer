"""Prepare an isolated renderer profile. Does not change a user's existing mods."""
import argparse,hashlib,json,os,re,shutil,uuid
from pathlib import Path
from server_audit import ROOT,dump
from native_pack_check import prepare_game,allowed

def prepare(destination:Path,name='GBNeuralView',observer=True,debug=False):
    template=json.loads((ROOT/'.local/visual-clients/1.21.8/launch.json').read_text(encoding='utf8'))
    game=destination/'game';mods=game/'mods';mods.mkdir(parents=True,exist_ok=True)
    source=Path(template['game_dir'])/'mods'
    for jar in source.glob('*.jar'):
        if not jar.name.startswith('GunbedVisuals-'):shutil.copy2(jar,mods/jar.name)
    built=ROOT/'client/build/1.21.8/libs/GunbedVisuals-1.21.8-0.3.18.jar';assert built.exists();shutil.copy2(built,mods/built.name)
    # This folder is exclusively managed for the dedicated renderer.
    for old in mods.glob('GunbedVisuals-*.jar'):
        if old.name!=built.name:
            retired=destination/'retired';retired.mkdir(exist_ok=True);shutil.move(str(old),str(retired/old.name))
    prepare_game(game,'127.0.0.1:{PORT}')
    options=game/'options.txt';text=options.read_text();text=text.replace('maxFps:30','maxFps:12').replace('renderDistance:2','renderDistance:6');options.write_text(text+'\nentityDistanceScaling:1.0\nfov:0.0\n',encoding='utf8')
    identity=uuid.UUID(bytes=hashlib.md5(('OfflinePlayer:'+name).encode()).digest(),version=3)
    native=game/'natives';native.mkdir(exist_ok=True)
    variables={'natives_directory':str(native),'launcher_name':'GunbedNeuralView','launcher_version':'1','classpath':template['classpath'],
               'auth_player_name':name,'version_name':'1.21.8','game_directory':str(game),'assets_root':template['assets'],'assets_index_name':template['asset_index'],
               'auth_uuid':identity.hex,'auth_access_token':'0','clientid':'','auth_xuid':'','user_type':'legacy','version_type':'release','resolution_width':'480','resolution_height':'270',
               'quickPlayPath':str(game/'quickplay.json'),'quickPlayMultiplayer':'127.0.0.1:{PORT}'}
    def expand(value):return re.sub(r'\$\{([^}]+)\}',lambda m:variables[m[1]],value)
    def args(group):
        result=[]
        for entry in template['manifest']['arguments'][group]:
            if isinstance(entry,dict):
                if not allowed(entry.get('rules',[])):continue
                entry=entry['value']
            result.extend(expand(x) for x in (entry if isinstance(entry,list) else [entry]))
        return result
    flags=['-Dgunbed.neuralObserverKey={OBSERVER_KEY}'] if observer else ['-Dgunbed.exercise=true','-Dgunbed.exerciseLoadout=true']
    if debug:flags.append('-Dgunbed.neuralDebug=true')
    command=[r'C:\Program Files\Java\jdk-21\bin\java.exe','-Xms128M','-Xmx1200M','-Dfile.encoding=UTF-8',*flags,*args('jvm'),template['manifest']['mainClass'],*args('game')]
    config=destination/'viewer.json';dump(config,{'name':name,'cwd':str(game),'command':command});return config

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--destination',type=Path,required=True);a=p.parse_args();print(prepare(a.destination.resolve()))
