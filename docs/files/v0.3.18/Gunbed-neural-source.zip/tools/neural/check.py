"""Isolated mathematical/contract checks. Toy pixels are never production training data."""
import base64,io,json,tempfile
from pathlib import Path
from PIL import Image
import torch
from service import Worker,pixel
from model import PixelPolicy,STATE,WIDTH,HEIGHT

def run():
    torch.manual_seed(21)
    checks=[]
    with tempfile.TemporaryDirectory(prefix='gunbed-neural-check-') as name:
        worker=Worker(Path(name),minimum_rounds=3,minimum_frames=24,max_epochs=15)
        image=Image.new('RGB',(160,90),(20,160,80));buffer=io.BytesIO();image.save(buffer,format='JPEG');raw=buffer.getvalue()
        row=dict(schema=1,actor='human',round='../../not-a-path',player='../../GMdong',seq=1,time=1000,teacher=True,map='Orchestra_8',image=base64.b64encode(raw).decode(),state=[0.]*STATE,buttons=[0]*12,aim=[0,0],slot=0,task='rush',testFixture=True)
        assert worker.frame(row)['accepted'];assert not worker.frame(row)['accepted'];assert not (Path(name).parent/'not-a-path').exists();checks.append('bounded image ingest, duplicate rejection and hashed paths')
        try:worker.frame({**row,'actor':'bot','seq':2});raise AssertionError('Bot demonstration accepted')
        except ValueError:pass
        assert worker.finish({'round':row['round'],'complete':True,'winners':[row['player']]})['queued'] is False
        assert worker.dataset()==([],[]);checks.append('AI frames and explicit test fixtures excluded from automatic human learning')
        assert not worker.predict({'round':'x','player':'b','version':''},pixel(raw),[0.]*STATE)['ready'];checks.append('no fabricated ready model before human video training')
        model=PixelPolicy();optimizer=torch.optim.Adam(model.parameters(),lr=.002)
        pixels=torch.rand(2,8,3,HEIGHT,WIDTH);state=torch.rand(2,8,STATE)
        targets={'buttons':torch.zeros(2,8,12),'aim':torch.zeros(2,8,2),'slot':torch.zeros(2,8,dtype=torch.long),'task':torch.zeros(2,8,dtype=torch.long),'value':torch.ones(2,8)}
        batch=(pixels,state,targets);before=float(worker.loss(model,batch).detach());weight=model.visual[0].weight.detach().clone()
        for _ in range(12):optimizer.zero_grad();loss=worker.loss(model,batch);loss.backward();optimizer.step()
        after=float(worker.loss(model,batch).detach());assert after<before;assert not torch.equal(weight,model.visual[0].weight);checks.append('actual convolution/GRU backpropagation updates visual weights and decreases toy loss')
        out,hidden=model(pixels[:,:1],state[:,:1]);out2,hidden2=model(pixels[:,1:2],state[:,1:2],hidden)
        assert hidden2.shape==(1,2,96) and out2['buttons'].shape==(2,1,12);checks.append('recurrent inference retains hidden state between frames')
        rows=[]
        for episode in ('a','b','c'):
            for seq in range(64):rows.append({'_episode':episode,'_stream':episode,'seq':seq,'time':seq*200})
        sequences=worker.sequences(rows);assert len(sequences)==9 and all(len({r['_episode'] for r in seq})==1 for seq in sequences);checks.append('temporal windows do not join different rounds or actors')
        # Exercise candidate training/checkpoint publication in this temporary directory only.
        toy=[]
        for episode in ('a','b','c'):
            for seq in range(64):toy.append({'_episode':episode,'_stream':episode,'seq':seq,'time':seq*200,'_path':next((Path(name)/'episodes').rglob('*.jpg')),'state':[0.]*STATE,'buttons':[int(seq%2==0)]+[0]*11,'aim':[0.,0.],'slot':0,'task':'rush','_value':1.})
        worker.train(['a','b','c'],toy)
        assert worker.model is not None and (Path(name)/'active.pt').exists(),worker.status()
        prediction=worker.predict({'round':'toy','player':'bot','version':worker.version},pixel(raw),[0.]*STATE)
        assert prediction['ready'] and len(prediction['buttons'])==12 and len(prediction['tasks'])==12
        checks.append('candidate training, held-out validation, atomic checkpoint loading and frozen-version pixel inference in an isolated toy directory')
        worker.close()
        return {'success':True,'checks':checks,'toyLossBefore':before,'toyLossAfter':after,'productionTraining':False,'note':'Synthetic contract tests only. No claim of live bot improvement.'}

if __name__=='__main__':
    report=run();dest=Path(__file__).resolve().parents[2]/'reports/neural-contract-check.json';dest.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False))
