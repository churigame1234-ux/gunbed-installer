"""Small pixel/recurrent imitation policy. No pretrained or synthetic gameplay claims."""
from __future__ import annotations
import torch
from torch import nn

SCHEMA = 1
WIDTH, HEIGHT, STATE = 96, 64, 24
BUTTONS = ['forward','back','left','right','jump','sprint','sneak','attack','use','reload','swap','drop']
TASKS = ['rush','defend','diamond','emerald','gather','shop','fight','retreat','bridge','heal','infiltrate','bank']

class PixelPolicy(nn.Module):
    def __init__(self):
        super().__init__()
        self.visual = nn.Sequential(nn.Conv2d(3,16,5,2),nn.ReLU(),nn.Conv2d(16,32,3,2),nn.ReLU(),
                                    nn.Conv2d(32,48,3,2),nn.ReLU(),nn.AdaptiveAvgPool2d((2,3)),nn.Flatten(),nn.Linear(288,96),nn.ReLU())
        self.memory = nn.GRU(96+STATE,96,batch_first=True)
        self.buttons=nn.Linear(96,len(BUTTONS));self.aim=nn.Linear(96,2)
        self.slot=nn.Linear(96,9);self.task=nn.Linear(96,len(TASKS));self.value=nn.Linear(96,1)
    def forward(self,pixels,state,hidden=None):
        b,t=pixels.shape[:2]
        vision=self.visual(pixels.reshape(b*t,3,HEIGHT,WIDTH)).reshape(b,t,96)
        memory,hidden=self.memory(torch.cat((vision,state),-1),hidden)
        return {'buttons':self.buttons(memory),'aim':torch.tanh(self.aim(memory)),
                'slot':self.slot(memory),'task':self.task(memory),'value':self.value(memory).squeeze(-1)},hidden

def load_model(path):
    data=torch.load(path,map_location='cpu',weights_only=True)
    if data.get('schema')!=SCHEMA:raise ValueError('Unsupported policy schema')
    model=PixelPolicy();model.load_state_dict(data['weights']);model.eval()
    return model,data
