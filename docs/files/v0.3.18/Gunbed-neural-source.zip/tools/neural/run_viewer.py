"""Dedicated first-person renderer, isolated from the user's launcher/profile.

The loopback bridge supplies the backend's ordinary Bungee forwarding envelope;
it never listens externally and is restricted to this one observer identity.
"""
from __future__ import annotations
import argparse,hashlib,json,os,socket,struct,subprocess,threading,time,uuid
from pathlib import Path

def varint(n):
    b=bytearray()
    while True:
        v=n&127;n>>=7;b.append(v|(128 if n else 0))
        if not n:return bytes(b)
def readvar(sock):
    n=0
    for shift in range(0,35,7):
        b=sock.recv(1)
        if not b:raise EOFError()
        n|=(b[0]&127)<<shift
        if b[0]<128:return n
    raise ValueError('VarInt overflow')
def take(sock,n):
    out=bytearray()
    while len(out)<n:
        b=sock.recv(n-len(out))
        if not b:raise EOFError()
        out.extend(b)
    return bytes(out)
def text(s):
    b=s.encode();return varint(len(b))+b
def relay(a,b):
    try:
        while True:
            data=a.recv(65536)
            if not data:break
            b.sendall(data)
    except OSError:pass
    finally:
        for s in (a,b):
            try:s.shutdown(socket.SHUT_RDWR)
            except OSError:pass
def forward(client,port,identity,forwarded=True):
    upstream=None
    try:
        size=readvar(client)
        if size>2048:raise ValueError('Invalid handshake')
        raw=take(client,size)
        class Cursor:
            pos=0
            def recv(self,n):b=raw[self.pos:self.pos+n];self.pos+=len(b);return b
        c=Cursor();packet=readvar(c);protocol=readvar(c);host=take(c,readvar(c));destination=take(c,2);state=readvar(c)
        if packet!=0 or state!=2:raise ValueError('Only observer login is allowed')
        address='localhost\0'+'127.0.0.1\0'+identity.hex+'\0[]' if forwarded else 'localhost'
        hello=varint(0)+varint(protocol)+text(address)+struct.pack('>H',port)+varint(state)
        upstream=socket.create_connection(('127.0.0.1',port),timeout=10);upstream.settimeout(None);client.settimeout(None)
        upstream.sendall(varint(len(hello))+hello)
        threading.Thread(target=relay,args=(client,upstream),daemon=True).start();relay(upstream,client)
    except (OSError,ValueError,EOFError):pass
    finally:
        client.close()
        if upstream:upstream.close()

def launch(config,key_file,port,listen,forwarded):
    from importlib.util import spec_from_file_location,module_from_spec
    root=Path(__file__).resolve().parents[2]
    # In production this file is copied under plugins/GunbedCore/neural, and the
    # fully expanded client command is supplied by the deployment helper.
    settings=json.loads(config.read_text(encoding='utf8'));name=settings.get('name','GBNeuralView')
    identity=uuid.UUID(bytes=hashlib.md5(('OfflinePlayer:'+name).encode()).digest(),version=3)
    listener=socket.socket();listener.bind(('127.0.0.1',listen));listener.listen(4);listener.settimeout(1)
    key=key_file.read_text(encoding='utf8').strip();args=[str(x).replace('{OBSERVER_KEY}',key).replace('{PORT}',str(listen)) for x in settings['command']]
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=subprocess.SW_HIDE
    folder=Path(settings['cwd']);folder.mkdir(parents=True,exist_ok=True)
    with (folder/'observer.log').open('a',encoding='utf8') as log:
        proc=subprocess.Popen(args,cwd=folder,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup)
        try:
            while proc.poll() is None:
                try:client,_=listener.accept();threading.Thread(target=forward,args=(client,port,identity,forwarded),daemon=True).start()
                except socket.timeout:continue
        finally:
            listener.close()
            if proc.poll() is None:proc.terminate()
            proc.wait(timeout=15)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',type=Path,required=True);parser.add_argument('--key-file',type=Path,required=True);parser.add_argument('--backend-port',type=int,default=25588);parser.add_argument('--listen-port',type=int,default=25690);parser.add_argument('--forwarded',choices=['true','false'],default='true')
    args=parser.parse_args();launch(args.config,args.key_file,args.backend_port,args.listen_port,args.forwarded=='true')
if __name__=='__main__':main()
