package kr.mzs.gunbedvisual;

import com.google.gson.*;
import java.util.*;

/** Server data only. Health, ammo, resources and kill credit are never guessed by the HUD. */
public final class HudState {
    public static final HudState INSTANCE=new HudState();
    public double health=20,maxHealth=20,absorption=0,scale=1;
    public long parkourMs=-1,parkourReceived,enemyUntil;public String enemyName="";public float enemyProgress;
    public long parkourTime(){return parkourMs<0?-1:parkourMs+(System.nanoTime()-parkourReceived)/1_000_000;}
    private long milkUntil;
    public long milkTime(){return Math.max(0,(milkUntil-System.nanoTime())/1_000_000);}
    public int mapViewDistance;
    public int armorTier=1,ammo=0,capacity=0,reserve=0;
    public boolean controlled,infinite,loadoutPending,loadoutPrevious;
    public long loadoutLife;
    public String buildKind="";private long buildStart,buildEnd;
    public boolean building(){return active()&&buildEnd>System.nanoTime();}
    public float buildProgress(){return Math.max(0,Math.min(1,(System.nanoTime()-buildStart)/(float)Math.max(1,buildEnd-buildStart)));}
    public String name="",mode="",model="";
    public record Gun(String name,int ammo,int capacity,int reserve){}
    public java.util.List<Gun> guns=java.util.List.of();
    public int kills,finals,beds;
    private long blindedAt,blindMillis;private float blindStrength;
    public float blindAlpha(){float t=(System.nanoTime()-blindedAt)/1_000_000f;if(blindMillis<=0||t>=blindMillis)return 0;return blindStrength*Math.min(1,(blindMillis-t)/Math.max(1,blindMillis*.55f));}
    public final long[] resources=new long[4];
    private final Map<UUID,Float> turretPitches=new HashMap<>();
    public float turretPitch(UUID id){return turretPitches.getOrDefault(id,0f);}
    private final Map<UUID,Integer> glows=new HashMap<>();
    public Integer glow(UUID id){return glows.get(id);}
    private long received;
    public record Feed(String kind,String killer,List<String> assists,String victim,String weapon,String icon,int killerColor,int victimColor,Map<String,Integer> assistColors,boolean headshot,long expiry){}
    private final Deque<Feed> feeds=new ArrayDeque<>();
    public void packet(String json){JsonObject data=JsonParser.parseString(json).getAsJsonObject();if(!data.has("event"))return;String event=data.get("event").getAsString();
        if(event.equals("enemyHealth")){enemyName=data.get("name").getAsString();enemyProgress=data.get("progress").getAsFloat();enemyUntil=System.nanoTime()+4_000_000_000L;}
        if(event.equals("turretAim")){if(turretPitches.size()>1024)turretPitches.clear();turretPitches.put(UUID.fromString(data.get("uuid").getAsString()),data.get("pitch").getAsFloat());}
        if(event.equals("entityGlow")){if(glows.size()>2048)glows.clear();glows.put(UUID.fromString(data.get("uuid").getAsString()),data.get("color").getAsInt());}
        if(event.equals("turretBuild")){buildStart=System.nanoTime();buildEnd=data.get("active").getAsBoolean()?buildStart+data.get("durationMs").getAsLong()*1_000_000L:0;if(data.has("kind"))buildKind=data.get("kind").getAsString();}
        if(event.equals("flash")){blindedAt=System.nanoTime();blindMillis=Math.max(0,Math.min(6000,data.get("durationMs").getAsLong()));blindStrength=Math.max(0,Math.min(1,data.get("strength").getAsFloat()));}
        if(event.equals("hud")){milkUntil=System.nanoTime()+(data.has("milkRemainingMs")?data.get("milkRemainingMs").getAsLong():0)*1_000_000L;mapViewDistance=data.has("mapViewDistance")?data.get("mapViewDistance").getAsInt():0;if(data.has("matchStats")){var stats=data.getAsJsonObject("matchStats");kills=stats.has("kills")?stats.get("kills").getAsInt():0;finals=stats.has("finals")?stats.get("finals").getAsInt():0;beds=stats.has("beds")?stats.get("beds").getAsInt():0;}if(data.has("inventoryGuns")){var all=new java.util.ArrayList<Gun>();for(var value:data.getAsJsonArray("inventoryGuns")){var gun=value.getAsJsonObject();all.add(new Gun(gun.get("name").getAsString(),gun.get("ammo").getAsInt(),gun.get("capacity").getAsInt(),gun.get("reserve").getAsInt()));}guns=java.util.List.copyOf(all);}loadoutPrevious=data.has("loadoutPrevious")&&data.get("loadoutPrevious").getAsBoolean();if(data.has("loadoutPending"))loadoutPending=data.get("loadoutPending").getAsBoolean();if(data.has("loadoutLife"))loadoutLife=data.get("loadoutLife").getAsLong();if(data.has("parkourMs")){parkourMs=data.get("parkourMs").getAsLong();parkourReceived=System.nanoTime();}if(data.has("absorption"))absorption=data.get("absorption").getAsDouble();received=System.nanoTime();health=data.get("health").getAsDouble();maxHealth=Math.max(1,data.get("maxHealth").getAsDouble());armorTier=data.get("armorTier").getAsInt();String[] keys={"iron_ingot","gold_ingot","diamond","emerald"};JsonObject counts=data.getAsJsonObject("resources");for(int i=0;i<4;i++)resources[i]=counts!=null&&counts.has(keys[i])?counts.get(keys[i]).getAsLong():0;if(data.has("settings"))scale=Math.max(.75,Math.min(1.5,data.getAsJsonObject("settings").get("scale").getAsDouble()));}
        if(event.equals("held")){controlled=data.has("controlled")&&data.get("controlled").getAsBoolean();name=data.has("name")?data.get("name").getAsString():"";mode=data.has("mode")?data.get("mode").getAsString():"";model=data.has("model")?data.get("model").getAsString():"";ammo=data.has("ammo")?data.get("ammo").getAsInt():0;capacity=data.has("capacity")?data.get("capacity").getAsInt():0;reserve=data.has("reserve")?data.get("reserve").getAsInt():0;infinite=data.has("infiniteReserve")&&data.get("infiniteReserve").getAsBoolean();}
        if(event.equals("feed")){List<String> assists=new ArrayList<>();if(data.has("assists"))for(JsonElement a:data.getAsJsonArray("assists"))assists.add(a.getAsString());feeds.addFirst(new Feed(data.get("kind").getAsString(),data.get("killer").getAsString(),assists,data.get("victim").getAsString(),data.has("weapon")?data.get("weapon").getAsString():"",data.has("icon")?data.get("icon").getAsString():"minecraft:iron_sword",data.has("killerColor")?data.get("killerColor").getAsInt():0xE9EFF6,data.has("victimColor")?data.get("victimColor").getAsInt():0xE9EFF6,colors(data),data.has("headshot")&&data.get("headshot").getAsBoolean(),System.nanoTime()+7_000_000_000L));while(feeds.size()>5)feeds.removeLast();}
    }
    public List<Feed> feeds(){long now=System.nanoTime();feeds.removeIf(f->f.expiry<now);return List.copyOf(feeds);}
    public boolean active(){return received>0&&System.nanoTime()-received<5_000_000_000L;}
    private static Map<String,Integer> colors(JsonObject data){Map<String,Integer> result=new HashMap<>();if(data.has("assistColors"))for(var e:data.getAsJsonObject("assistColors").entrySet())result.put(e.getKey(),e.getValue().getAsInt());return result;}
    public void clear(){milkUntil=0;mapViewDistance=0;turretPitches.clear();parkourMs=-1;enemyUntil=0;glows.clear();buildEnd=0;received=0;blindMillis=0;guns=java.util.List.of();loadoutPending=false;loadoutPrevious=false;controlled=false;feeds.clear();}
    public static String count(long amount){return amount>=1_000_000?String.format(Locale.ROOT,"%.1fM",amount/1e6):amount>=10000?String.format(Locale.ROOT,"%.1fK",amount/1e3):Long.toString(amount);}
}
