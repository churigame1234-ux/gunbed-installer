"""Render the converted 3D mesh to a transparent inventory sprite (no painted pixels)."""
import hashlib,json,math,shutil
from pathlib import Path
from PIL import Image
from import_trg_source import transform
from server_audit import ROOT,STAGE,dump
resources=ROOT/'client/src/main/resources';mesh=json.loads((resources/'assets/gunbed/models/trg21/classic_mesh.json').read_text(encoding='utf-8'))['gunbed:source_mesh']
frame=mesh['clips']['idle1']['frames'][0];points=[transform(frame[v[8]],v[:3]) for v in mesh['vertices']]
used=sorted({i for part in mesh['parts'] if part['texture']!='$skin' for i in part['indices']})
xs=[-p[0] for p in points];ys=[-p[2] for p in points];lo_x,hi_x=min(xs[i] for i in used),max(xs[i] for i in used);lo_y,hi_y=min(ys[i] for i in used),max(ys[i] for i in used);scale=min(480/(hi_x-lo_x),400/(hi_y-lo_y));cx=(lo_x+hi_x)/2;cy=(lo_y+hi_y)/2
screen=[((x-cx)*scale+256,(y-cy)*scale+256,p[1]) for x,y,p in zip(xs,ys,points)]
image=Image.new('RGBA',(512,512));pixels=image.load();depth=[math.inf]*(512*512);textures={}
for part in mesh['parts']:
    if part['texture']=='$skin':continue
    texture_id=part['texture'];namespace,path=texture_id.split(':',1);path=resources/'assets'/namespace/path
    if texture_id not in textures:textures[texture_id]=Image.open(path).convert('RGBA')
    texture=textures[texture_id];tex=texture.load();indices=part['indices']
    for i in range(0,len(indices),3):
        ids=indices[i:i+3];a,b,c=[screen[j] for j in ids];uv=[mesh['vertices'][j][6:8] for j in ids]
        denominator=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
        if abs(denominator)<1e-8:continue
        for y in range(max(0,int(min(a[1],b[1],c[1]))),min(512,int(max(a[1],b[1],c[1]))+1)):
            for x in range(max(0,int(min(a[0],b[0],c[0]))),min(512,int(max(a[0],b[0],c[0]))+1)):
                w0=((b[1]-c[1])*(x+.5-c[0])+(c[0]-b[0])*(y+.5-c[1]))/denominator;w1=((c[1]-a[1])*(x+.5-c[0])+(a[0]-c[0])*(y+.5-c[1]))/denominator;w2=1-w0-w1
                if min(w0,w1,w2)<-.00001:continue
                z=w0*a[2]+w1*b[2]+w2*c[2];at=y*512+x
                if z>=depth[at]:continue
                u=sum(w*p[0] for w,p in zip((w0,w1,w2),uv));v=sum(w*p[1] for w,p in zip((w0,w1,w2),uv));color=tex[min(texture.width-1,max(0,int(u*texture.width))),min(texture.height-1,max(0,int(v*texture.height)))];pixels[x,y]=color;depth[at]=z
target=resources/'assets/gunbed/textures/item/trg21.png';target.parent.mkdir(parents=True,exist_ok=True);image.save(target)
dump(resources/'assets/gunbed/models/item/trg21.json',{'parent':'minecraft:item/generated','textures':{'layer0':'gunbed:item/trg21'}})
slug=hashlib.sha256(b'TRG').hexdigest()[:16];dump(resources/f'assets/gunbed/items/cs/{slug}.json',{'model':{'type':'minecraft:model','model':'gunbed:item/trg21'}})
ia=STAGE/'plugins/ItemsAdder/contents/gunbed_fps/resourcepack'
for relative in ('assets/gunbed/textures/item/trg21.png','assets/gunbed/models/item/trg21.json',f'assets/gunbed/items/cs/{slug}.json'):
    p=ia/relative;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(resources/relative,p)
print({'sprite':str(target),'size':[512,512],'rendered_from_original_mesh':True})
