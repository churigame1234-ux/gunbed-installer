import json,shutil,subprocess
from pathlib import Path
import imageio_ffmpeg
from server_audit import ROOT,STAGE,dump
from import_trg_source import read_model

source=ROOT/'.local/trg-source/extracted/sound/weapons/trg';assets=ROOT/'client/src/main/resources/assets/gunbed'
ia=STAGE/'plugins/ItemsAdder/contents/gunbed_fps/resourcepack/assets/gunbed'
names={'trg_fire':'fire','trg_clipout':'magout','trg_clipin':'magin','trg_boltback':'boltback','trg_boltpull':'boltpull','trg_select':'select'}
sounds=json.loads((assets/'sounds.json').read_text(encoding='utf-8')) if (assets/'sounds.json').exists() else {}
for original,name in names.items():
    dest=assets/'sounds/trg21'/(name+'.ogg');dest.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-loglevel','error','-i',str(source/(original+'.wav')),'-ac','1','-ar','44100','-c:a','libvorbis','-q:a','5',str(dest)],check=True)
    target=ia/'sounds/trg21'/dest.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,target)
    sounds['trg21.'+name]={'sounds':[{'name':'gunbed:trg21/'+name,'stream':False}]}
dump(assets/'sounds.json',sounds)
current=json.loads((ia/'sounds.json').read_text(encoding='utf-8')) if (ia/'sounds.json').exists() else {}
current.update(sounds);dump(ia/'sounds.json',current)
mapping={'Weapon_TRG_Magout':'magout','Weapon_TRG_Magin':'magin','Weapon_TRG_boltback':'boltback','Weapon_TRG_boltpull':'boltpull','Weapon_TRG_Select':'select'}
data={'fire':'gunbed:trg21.fire','drawMs':1033,'shootMs':1367}
for name,events in read_model('v_snip_awp')['sequences'].items():data[name]=[{'cycle':e['cycle'],'sound':'gunbed:trg21.'+mapping[e['sound']]} for e in events]
dump(ROOT/'src/main/resources/trg-audio.json',data);dump(ROOT/'reports/trg-audio.json',{'success':True,'clips':len(names),'reload_events':data['reload'],'source_wav_preserved':True});print({'audio_files':len(names),'reload_events':len(data['reload'])})
