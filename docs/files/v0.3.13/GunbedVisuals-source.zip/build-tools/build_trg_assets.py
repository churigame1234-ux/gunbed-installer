"""Convert original model triangles/UVs and author a classic-skin UV variant.

Texture decoding is lossless; the DTX pixels are not painted or synthesized.
"""
import copy,io,json,math,re,struct,zipfile
from pathlib import Path
from PIL import Image
from server_audit import ROOT,dump,sha256
from import_trg_source import read_model,transform

RES=ROOT/'client/src/main/resources';OUT=RES/'assets/gunbed';SOURCE=ROOT/'.local/trg-source/extracted'
def dds(raw,w,h,fourcc):
    header=bytearray(128);header[:4]=b'DDS ';struct.pack_into('<7I',header,4,124,0x81007,h,w,len(raw),0,1);struct.pack_into('<II4s',header,76,32,4,fourcc);struct.pack_into('<I',header,108,0x1000)
    return Image.open(io.BytesIO(header+raw)).convert('RGBA')
def vtf(path):
    b=path.read_bytes();assert b[:4]==b'VTF\0';w,h=struct.unpack_from('<HH',b,16);fmt=struct.unpack_from('<i',b,52)[0]
    if fmt==12:return Image.frombytes('RGBA',(w,h),b[-w*h*4:],'raw','BGRA')
    if fmt in (13,14,15):
        length=max(1,(w+3)//4)*max(1,(h+3)//4)*(8 if fmt==13 else 16);return dds(b[-length:],w,h,{13:b'DXT1',14:b'DXT3',15:b'DXT5'}[fmt])
    raise ValueError(('Unsupported VTF',path,fmt))
def dtx(b):
    _,version,w,h,mips,sections,flags,user=struct.unpack_from('<IiHHHHII',b);assert version==-5
    if b[26]==3:return Image.frombytes('RGBA',(w,h),b[164:164+w*h*4],'raw','BGRA')
    if b[26]==6:return dds(b[164:164+w*h],w,h,b'DXT5')
    raise ValueError(('Unsupported DTX',b[26]))
def save_image(image,path):path.parent.mkdir(parents=True,exist_ok=True);image.save(path)
def classic_uv(point,normal,bone,material,original):
    # Mapping is on the new mesh, so the supplied classic texture stays byte-preserved.
    x,y,z=point
    def rect(region,a,lo,hi,b,blo,bhi):
        u,v,w,h=region;return [(u+w*max(0,min(1,(a-lo)/(hi-lo))))/1024,(v+h*max(0,min(1,(b-blo)/(bhi-blo))))/512]
    if material=='lens':return [(384+original[0]*114)/1024,(252+original[1]*118)/512]
    if bone==1:return rect((533,245,137,73),z,-3.2,3.2,-y,-5,0)
    if bone==2:return rect((480,319,541,59),z,-8,8,-y,-10,-5)
    if y>8.8:return rect((3,35,374,250),z,-16,7,math.atan2(y-10.3,x),-math.pi,math.pi)
    if z < -18:return rect((3,306,373,97),z,-34,-18,math.atan2(y-7.2,x),-math.pi,math.pi)
    if z > 4:return rect((359,416,655,63),z,4,20,-y,-9,1)
    if y < 3:return rect((854,188,166,92),z,-3,6,-y,-4,1)
    return rect((480,379,463,37),z,-18,4,-y,-9,-2)

def build():
    parsed=read_model('v_snip_awp');gun=[g for g in parsed['groups'] if g['model']=='gun.smd'];used=sorted({i for g in gun for i in g['indices']});remap={v:i for i,v in enumerate(used)}
    original=[];classic=[]
    for i in used:
        v=parsed['vertices'][i];assert len(v['weights'])==1 and abs(v['weights'][0][1]-1)<.00001
        bone=v['weights'][0][0];p=transform(parsed['bindInverse'][bone],v['p']);n=transform(parsed['bindInverse'][bone],v['n'],0)
        # Retain material seams; classic UVs below are authored per triangle as needed.
        original.append([*p,*n,*v['uv'],bone])
    clips={name:{'fps':a['fps'],'frames':[[[round(v,7) for v in matrix] for matrix in frame] for frame in a['frames']]} for name,a in parsed['animations'].items()}
    aliases={'':'idle1','static_idle':'idle1','draw':'draw','shoot':'shoot','bolt':'shoot','reload_tactical':'reload','reload_empty':'reload'}
    data={'vertices':original,'parts':[],'clips':clips,'aliases':aliases,'leftArm':8,'rightArm':27,'muzzle':4}
    for g in gun:
        material=g['texture'];vmt=(SOURCE/'materials/models/weapons/v_models/trg'/f'{material}.vmt').read_text(encoding='utf-8');base=re.search(r'"\$baseTexture"\s+"([^"]+)"',vmt,re.I)[1].replace('\\','/');stem=Path(base).name
        target=OUT/'textures/trg21'/f'{stem}.png'
        if not target.exists():save_image(vtf(SOURCE/'materials'/(base+'.vtf')),target)
        data['parts'].append({'texture':f'gunbed:textures/trg21/{stem}.png','indices':[remap[i] for i in g['indices']]})
    mesh=OUT/'models/trg21/source_mesh.json';dump(mesh,{'gunbed:source_mesh':data})
    classic_data=copy.deepcopy(data);classic_data['vertices']=[];classic_data['parts']=[]
    for g in gun:
        indices=[]
        for original_index in g['indices']:
            vertex=original[remap[original_index]];body_p=transform(parsed['bindInverse'][0],parsed['vertices'][original_index]['p']);body_n=transform(parsed['bindInverse'][0],parsed['vertices'][original_index]['n'],0)
            uv=classic_uv(body_p,body_n,vertex[8],g['texture'],vertex[6:8]);indices.append(len(classic_data['vertices']));classic_data['vertices'].append(vertex[:6]+uv+[vertex[8]])
        classic_data['parts'].append({'texture':'gunbed:textures/trg21/classic.png','indices':indices})
    dump(OUT/'models/trg21/classic_mesh.json',{'gunbed:source_mesh':classic_data})
    with zipfile.ZipFile(Path.home()/'Downloads/옛날 구 스킨.zip') as archive:save_image(dtx(archive.read('trg21.dtx')),OUT/'textures/trg21/classic.png')
    animations={name:{'animation_length':(len(parsed['animations'][source]['frames'])-1)/parsed['animations'][source]['fps'],'loop':name=='static_idle','bones':{}} for name,source in aliases.items() if name}
    dump(OUT/'models/trg21/animations.json',{'animations':animations})
    path=RES/'assets/tacz/gunbed_catalog.json';catalog=json.loads(path.read_text(encoding='utf-8'))
    for id,mesh_file,texture in [('gunbed_trg21','classic_mesh.json','classic'),('gunbed_trg21_infinity','source_mesh.json','trginfid')]:
        definition=copy.deepcopy(catalog['guns']['ai_awp']);definition.update(id=id,name='TRG-21',model=f'assets/gunbed/models/trg21/{mesh_file}',texture=f'gunbed:textures/trg21/{texture}.png',animation='assets/gunbed/models/trg21/animations.json',soundAliases={},actions={'shoot':1367,'draw':1033});definition.pop('defaultAnimation',None);catalog['guns'][id]=definition
    dump(path,catalog)
    report={'success':True,'source':'https://blog.jeongtae.com/css-서든어택-trg21인피니티d-스킨-완성-배포/','weapon_vertices':len(used),'triangles':sum(len(g['indices'])//3 for g in gun),'source_bones':len(parsed['bones']),'clips':list(parsed['animations']),'classic_texture_size':[1024,512],'classic_pixels_unmodified':True,'original_hands_mesh_excluded':True,'models':['gunbed_trg21','gunbed_trg21_infinity']}
    dump(ROOT/'reports/trg-model-import.json',report);print(json.dumps(report,ensure_ascii=True))
if __name__=='__main__':build()
