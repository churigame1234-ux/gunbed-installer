"""New local TTS recordings and radio filtering; no Counter-Strike samples."""
import json,subprocess,shutil
from server_audit import ROOT,STAGE,dump,sha256
RES=ROOT/'client/src/main/resources/assets/gunbed'
ffmpeg=STAGE/'plugins/ItemsAdder/storage/cache/ffmpeg/windows/ffmpeg.exe'
result=[]
for source,id in [('fire','fire_in_the_hole'),('flash','flashbang')]:
 target=RES/f'sounds/radio/{id}.ogg';target.parent.mkdir(parents=True,exist_ok=True)
 subprocess.run([str(ffmpeg),'-y','-i',str(ROOT/f'.local/radio-voice/{source}.wav'),'-af','asetrate=20947,aresample=22050,highpass=f=260,lowpass=f=3400,acompressor=threshold=0.15:ratio=3,acrusher=bits=13:mix=0.04,alimiter=limit=0.8,volume=1.25','-c:a','libvorbis','-q:a','5',str(target)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 result.append({'id':id,'sha256':sha256(target),'source':'New Piper Joe CC0 neural speech; subtle low male radio treatment'})
file=RES/'sounds.json';sounds=json.loads(file.read_text(encoding='utf8')) if file.exists() else {}
for entry in result:sounds['radio.'+entry['id']]={'sounds':[{'name':'gunbed:radio/'+entry['id'],'volume':.7,'attenuation_distance':32}]}
dump(file,sounds);destination=STAGE/'plugins/ItemsAdder/contents/gunbed_fps/resourcepack/assets/gunbed';shutil.copytree(RES/'sounds/radio',destination/'sounds/radio',dirs_exist_ok=True);existing=json.loads((destination/'sounds.json').read_text(encoding='utf8')) if (destination/'sounds.json').exists() else {};existing.update({k:v for k,v in sounds.items() if k.startswith('radio.')});dump(destination/'sounds.json',existing);dump(ROOT/'reports/radio-audio.json',{'success':True,'sounds':result,'copied_game_voice':False})
print('Created 2 independent radio callouts.')
