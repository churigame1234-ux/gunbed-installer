"""Author additive mechanical parts; keep the original model/animation/texture files intact."""
import copy,json,math
from pathlib import Path
from PIL import Image
from server_audit import ROOT,dump,sha256

RES=ROOT/'client/src/main/resources'
catalog_path=RES/'assets/tacz/gunbed_catalog.json'
catalog=json.loads(catalog_path.read_text(encoding='utf-8'))
SPECS=[('gold','deagle_golden','Deagle_golden'),('vss','mk14','mk14_default'),('double','db_long','Db'),('g36','g36k','g36k'),('bastion','m249','m249_default')]

def patch_uv(texture,gold=False):
    im=Image.open(RES/('assets/'+texture.replace(':','/',1))).convert('RGBA');best=(float('-inf'),0,0)
    for y in range(0,im.height-2,2):
        for x in range(0,im.width-2,2):
            colors=[im.getpixel((x+dx,y+dy)) for dx in range(2) for dy in range(2)]
            if min(c[3] for c in colors)<250:continue
            r,g,b=(sum(c[i] for c in colors)/4 for i in range(3));score=(r-b)+(g-b)*.7-abs(r-190)*.15 if gold else -abs((r+g+b)/3-75)-abs(r-g)-abs(g-b)
            if score>best[0]:best=(score,x,y)
    return [best[1],best[2]]

def cube(origin,size,uv,rotation=None,pivot=None):
    value={'origin':origin,'size':size,'uv':{face:{'uv':uv,'uv_size':[2,2]} for face in ['north','south','east','west','up','down']}}
    if rotation:value.update(rotation=rotation,pivot=pivot or origin)
    return value

def vector(value,default):
    if isinstance(value,list):return value
    if isinstance(value,dict):return vector(value.get('vector',next(iter(value.values()),default)),default)
    return default

results=[]
for family,source,parent in SPECS:
    original=catalog['guns'][source]
    base_geo=json.loads((RES/original['model']).read_text(encoding='utf-8'))
    base_anim=json.loads((RES/original['animation']).read_text(encoding='utf-8'))
    uv=patch_uv(original['texture'],family=='gold')
    for b in (False,True):
        id='gunbed_'+family+('_siege' if b else '_mobile') if family in ('g36','bastion') else 'gunbed_'+family+('_b' if b else '_a')
        geo=copy.deepcopy(base_geo);model=geo['minecraft:geometry'][0];model['description']['identifier']='geometry.'+id
        assert parent in {bone['name'] for bone in model['bones']}
        parts=[]
        if family=='gold':
            parts=[cube([-.85,4.4,1.5],[1.7,.4,3.5],uv)]
            if b:
                parts+=[cube([-1.1,4.4,-3],[2.2,1.8,5.5],uv),cube([-1.4,4.3,-2.6],[.35,2,4.8],uv),cube([1.05,4.3,-2.6],[.35,2,4.8],uv)]
                for z in (-2,-.6,.8):parts.append(cube([-1.25,4.25,z],[2.5,2.1,.25],uv))
        elif family=='vss':
            parts=[cube([-.8,7.4,-17.5],[1.6,1.6,4],uv)]
            if b:
                parts += [cube([-1.2,7,-14],[.4,2.5,10],uv),cube([.8,7,-14],[.4,2.5,10],uv),cube([-.9,1.5,2],[1.8,.35,4],uv)]
                for z in (-16,-12,-8):parts.append(cube([-1,7,z],[2,2.3,.35],uv))
        elif family=='double':
            parts=[cube([.65 if b else -1.1,9.15,1.5],[.45,.5,2.2],uv)]
            if b:
                for x in (-.78,.32):
                    parts += [cube([x,8.6,-20],[.8,.3,2],uv),cube([x,9.55,-20],[.8,.3,2],uv)]
        else:
            parts=[cube([-1.1,5.9,-5],[2.2,.4,5],uv)]
            if b:
                for sign in (-1,1):
                    parts += [cube([sign*.9-.2,1.6,-5.5],[.4,5,.6],uv,[0,0,sign*32],[sign*.9,6.2,-5.2]),cube([sign*2-.7,1.1,-6.5],[1.4,.4,2],uv)]
                parts += [cube([-1.5,5.2,-1],[3,1.3,3.5],uv),cube([-1.25,8.7,-9],[2.5,.55,6],uv)]
        overlay={'part':{'name':'mode_lever','parent':parent,'pivot':[0,7,1],'cubes':parts}}
        overlay_path='assets/gunbed/modes/'+id+'.json';target=RES/overlay_path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(overlay,separators=(',',':')),encoding='utf-8')
        catalog['guns'][id]={'id':id,'base':source,'mode_overlay':overlay_path}
        results.append({'model':id,'base_asset':source,'mechanical_cubes':len(parts),'overlay_sha256':sha256(target)})
        for folder in ('geo_models','animations'):
            obsolete=RES/('assets/gunbed/'+folder+'/'+id+'.json')
            if obsolete.exists():
                import shutil
                backup=ROOT/'.local/modes-private-derived'/folder/obsolete.name;backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(obsolete,backup);obsolete.unlink()
catalog_path.write_text(json.dumps(catalog,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
dump(ROOT/'reports/weapon-mode-assets.json',{'success':True,'variants':results,'human_hand_mesh_added':False})
print(json.dumps({'models':len(results),'catalog_models':len(catalog['guns'])}))
