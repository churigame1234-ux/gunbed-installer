"""Retarget the supplied blocky turret meshes to compact Minecraft item geometry."""
import base64,io,json,math,struct,zipfile
from pathlib import Path
import numpy as np
from PIL import Image
from server_audit import ROOT,dump,sha256
OUT=ROOT/'client/src/main/resources/assets/gunbed'
SPECS={'burst':'minecraft-sentry-gun.zip','siege':'missile-turret.zip','healing':'회복포탑 shock-cannon-turret.zip','slowness':'portal-alternative-turret-minecraft.zip'}
def matrix(node):
 if 'matrix' in node:return np.array(node['matrix']).reshape((4,4)).T
 x,y,z,w=node.get('rotation',[0,0,0,1]);r=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w),0],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w),0],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y),0],[0,0,0,1.]])
 r[:3,:3]@=np.diag(node.get('scale',[1,1,1]));r[:3,3]=node.get('translation',[0,0,0]);return r
reports=[]
for kind,filename in SPECS.items():
 source=Path.home()/'Downloads'/filename;parts=[];textures={}
 with zipfile.ZipFile(source) as z:
  if kind=='slowness':
   inner=zipfile.ZipFile(io.BytesIO(z.read(next(n for n in z.namelist() if n.endswith('.zip')))));obj=inner.read(next(n for n in inner.namelist() if n.endswith('.obj'))).decode();verts=[];uvs=[];material='turret';group=[]
   for line in obj.splitlines():
    a=line.split()
    if not a:continue
    if a[0]=='v':verts.append([float(x) for x in a[1:4]])
    elif a[0]=='vt':uvs.append([float(x) for x in a[1:3]])
    elif a[0]=='usemtl':material=a[1]
    elif a[0]=='f':
     idx=[int(v.split('/')[0])-1 for v in a[1:]];parts.append((np.array([verts[i] for i in idx]),material))
   colors=[]
   for n in inner.namelist():
    if n.endswith('.png'):
     im=Image.open(io.BytesIO(inner.read(n))).convert('RGBA');colors.append((Path(n).stem,np.array(im.resize((1,1)))[0,0]))
   fallback=colors[0][1] if colors else [180,180,180,255]
   # Existing model's material names correspond to its packaged textures.
   for m in {p[1] for p in parts}:textures[m]=next((c for name,c in colors if name.lower() in m.lower()),fallback)
  else:
   d=json.loads(z.read(next(n for n in z.namelist() if n.endswith('.gltf'))));buffers=[base64.b64decode(b['uri'].split(',',1)[1]) for b in d['buffers']]
   def accessor(index):
    a=d['accessors'][index];v=d['bufferViews'][a['bufferView']];count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];fmt={5126:'f',5125:'I',5123:'H',5121:'B'}[a['componentType']];size=struct.calcsize('<'+fmt)*count;stride=v.get('byteStride',size);start=v.get('byteOffset',0)+a.get('byteOffset',0);return np.array([struct.unpack_from('<'+fmt*count,buffers[v['buffer']],start+i*stride) for i in range(a['count'])])
   for i,m in enumerate(d['materials']):
    pbr=m.get('pbrMetallicRoughness',{});ti=pbr.get('baseColorTexture',{}).get('index');color=pbr.get('baseColorFactor',[.55,.55,.55,1])
    if ti is not None:
     im=d['images'][d['textures'][ti]['source']];img=Image.open(io.BytesIO(base64.b64decode(im['uri'].split(',',1)[1]))).convert('RGBA');color=np.array(img.resize((1,1)))[0,0]/255
    textures[str(i)]=np.array(color)*255
   def visit(index,parent):
    node=d['nodes'][index];transform=parent@matrix(node)
    if 'mesh' in node:
     for primitive in d['meshes'][node['mesh']]['primitives']:
      pos=accessor(primitive['attributes']['POSITION']);pos=(transform@np.c_[pos,np.ones(len(pos))].T).T[:,:3];parts.append((pos,str(primitive.get('material',0))))
    for child in node.get('children',[]):visit(child,transform)
   for node in d['scenes'][d.get('scene',0)]['nodes']:visit(node,np.eye(4))
 allpoints=np.concatenate([p for p,m in parts]);low=allpoints.min(0);high=allpoints.max(0);scale=20/max(high-low);center=(low+high)/2
 keys=list(textures);atlas=Image.new('RGBA',(2**max(0,(len(keys)-1).bit_length())*16,16));
 for n,k in enumerate(keys):atlas.paste(tuple(int(max(0,min(255,x))) for x in textures[k]),(n*16,0,n*16+16,16))
 atlas_path=OUT/f'textures/item/turret/{kind}.png';atlas_path.parent.mkdir(parents=True,exist_ok=True);atlas.save(atlas_path)
 elements=[]
 for points,material in parts:
  a=(points.min(0)-center)*scale+8;b=(points.max(0)-center)*scale+8
  # Axis-aligned block silhouettes preserve the supplied shapes at Minecraft scale.
  for i in range(3):
   if b[i]-a[i]<.02:b[i]=a[i]+.02
  a=np.clip(a,-16,32);b=np.clip(b,-16,32);u=(keys.index(material)*16+8)/atlas.width*16
  elements.append({'from':a.round(4).tolist(),'to':b.round(4).tolist(),'faces':{face:{'texture':'#0','uv':[u-.01,0,u+.01,16]} for face in ['north','south','east','west','up','down']}})
 if len(elements)>500:
  voxels={};grid=1.0
  for points,material in parts:
   q=(points-center)*scale+8
   for n in range(1,len(q)-1):
    aa,bb,cc=q[0],q[n],q[n+1];steps=max(1,min(48,int(max(np.linalg.norm(bb-aa),np.linalg.norm(cc-aa))*2)))
    for u in range(steps+1):
     for v in range(steps+1-u):
      point=aa+(bb-aa)*u/steps+(cc-aa)*v/steps;cell=tuple(int(k) for k in np.floor(point/grid));voxels[cell]=material
  elements=[]
  while voxels:
   (x,y,z),material=voxels.popitem();end=x+1
   while voxels.get((end,y,z))==material:del voxels[(end,y,z)];end+=1
   u=(keys.index(material)*16+8)/atlas.width*16
   elements.append({'from':[x,y,z],'to':[end,y+1,z+1],'faces':{face:{'texture':'#0','uv':[u-.01,0,u+.01,16]} for face in ['north','south','east','west','up','down']}})
 model={'textures':{'0':f'gunbed:item/turret/{kind}','particle':f'gunbed:item/turret/{kind}'},'elements':elements,'display':{'gui':{'rotation':[20,225,0],'scale':[.65,.65,.65]},'ground':{'translation':[0,4,0],'scale':[1,1,1]},'fixed':{'translation':[0,1,0],'scale':[1,1,1]}}}
 dump(OUT/f'models/turret/{kind}.json',model);dump(OUT/f'items/turret/{kind}.json',{'model':{'type':'minecraft:model','model':f'gunbed:turret/{kind}'}});reports.append({'kind':kind,'source':str(source),'sha256':sha256(source),'parts':len(elements),'conversion':'block silhouette retarget, source colours sampled per part'})
dump(ROOT/'reports/turret-models.json',{'success':True,'models':reports});print('Imported four supplied turret silhouettes:',[(r['kind'],r['parts']) for r in reports])

