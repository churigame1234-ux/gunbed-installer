"""Apply churi's eight team colours to the effective server-pack colour families."""
import io,json,zipfile
import numpy as np
from PIL import Image
from server_audit import ROOT,STAGE,dump,sha256
TARGET=STAGE/'plugins/ItemsAdder/contents/gunbed_fps/resourcepack'
PALETTE={'red':0xF40404,'light_blue':0x0C48CC,'lime':0x2CB494,'pink':0x88409C,'cyan':0xF88C14,'gray':0x703014,'white':0xCCE0D0,'yellow':0xFCFC38}
vanilla=zipfile.ZipFile(ROOT/'.local/pack-clients/1.21.8/client.jar') if (ROOT/'.local/pack-clients/1.21.8/client.jar').exists() else zipfile.ZipFile(__import__('pathlib').Path.home()/'AppData/Roaming/.minecraft/versions/1.21.8/1.21.8.jar')
sources={n:vanilla.read(n) for n in vanilla.namelist() if n.startswith('assets/minecraft/textures/') and ('/white_' in n or '/entity/bed/white.png' in n or '/entity/shulker/shulker_white.png' in n) and n.endswith('.png')}
for pack in ('gunbed_legacy','gunbed_fps'):
 for file in (STAGE/f'plugins/ItemsAdder/contents/{pack}/resourcepack/assets/minecraft/textures').rglob('white_*.png'):
  key=file.relative_to(STAGE/f'plugins/ItemsAdder/contents/{pack}/resourcepack').as_posix()
  # Use the original white pattern, not a previously recoloured generated white.
  if pack=='gunbed_legacy':sources[key]=file.read_bytes()
changed=[]
for name,raw in sources.items():
 if name.endswith('white_tulip.png'):continue
 if not any(folder in name for folder in ('/block/','/blocks/','/entity/bed/','/entity/shulker/','/entity/banner/')):continue
 image=np.array(Image.open(io.BytesIO(raw)).convert('RGBA'));rgb=image[:,:,:3].astype(float)
 # Preserve wooden bed frames and other deliberately coloured non-cloth pixels.
 cloth=(rgb.max(2)-rgb.min(2)<40)&(rgb.max(2)>20)
 lum=(rgb@np.array([.2126,.7152,.0722]))/255
 for colour,value in PALETTE.items():
  target=np.array([(value>>16)&255,(value>>8)&255,value&255],dtype=float);out=image.copy()
  dyed=np.clip(target[None,None,:]*lum[:,:,None],0,255).astype('uint8');out[:,:,:3]=np.where(cloth[:,:,None],dyed,image[:,:,:3])
  relative=name.replace('/white_','/'+colour+'_').replace('/white.png','/'+colour+'.png').replace('/shulker_white.png','/shulker_'+colour+'.png');dest=TARGET/relative;dest.parent.mkdir(parents=True,exist_ok=True);Image.fromarray(out).save(dest)
  changed.append({'file':relative,'sha256':sha256(dest)})
  if '/textures/blocks/' in relative:
   alias=TARGET/relative.replace('/textures/blocks/','/textures/block/');alias.parent.mkdir(parents=True,exist_ok=True);alias.write_bytes(dest.read_bytes())
dump(ROOT/'reports/team-palette-0.3.8.json',{'success':True,'palette':PALETTE,'files':changed,'global_client_overrides':False})
print(json.dumps({'recoloured':len(changed),'families':len(sources)}))
