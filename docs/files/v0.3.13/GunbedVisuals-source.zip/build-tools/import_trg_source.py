"""Read the supplied Source v48 model data; never execute downloaded programs.

Binary layout reference: ValveSoftware/source-sdk-2013 public studio.h/optimize.h.
The importer is independent code and preserves the model's UVs and animation poses.
"""
from pathlib import Path
import collections,json,math,struct
from server_audit import ROOT,dump,sha256

SOURCE=ROOT/'.local/trg-source/extracted'
def unpack(data,fmt,at):return struct.unpack_from('<'+fmt,data,at)
def cstring(data,at):return data[at:data.index(0,at)].decode('ascii',errors='replace')
def identity():return [1.,0,0,0,0,1.,0,0,0,0,1.,0,0,0,0,1.]
def multiply(a,b):return [sum(a[r*4+k]*b[k*4+c] for k in range(4)) for r in range(4) for c in range(4)]
def inverse_rigid(a):
    out=identity()
    for r in range(3):
        for c in range(3):out[r*4+c]=a[c*4+r]
        out[r*4+3]=-sum(out[r*4+c]*a[c*4+3] for c in range(3))
    return out
def transform(a,p,w=1):return [sum(a[r*4+c]*p[c] for c in range(3))+a[r*4+3]*w for r in range(3)]
def matrix(pos,q):
    x,y,z,w=q;n=math.sqrt(sum(v*v for v in q));x,y,z,w=[v/n for v in q]
    return [1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w),pos[0],2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w),pos[1],2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y),pos[2],0,0,0,1]
def quaternion(e):
    x,y,z=[a*.5 for a in e];cx,cy,cz=map(math.cos,(x,y,z));sx,sy,sz=map(math.sin,(x,y,z))
    return [sx*cy*cz-cx*sy*sz,cx*sy*cz+sx*cy*sz,cx*cy*sz-sx*sy*cz,cx*cy*cz+sx*sy*sz]
def q48(b,at):
    x,y,z=unpack(b,'3H',at);a=(x-32768)/32768;c=(y-32768)/32768;d=((z&32767)-16384)/16384
    w=math.sqrt(max(0,1-a*a-c*c-d*d));return [a,c,d,-w if z&32768 else w]
def q64(b,at):
    packed=unpack(b,'Q',at)[0];q=[(((packed>>(i*21))&2097151)-1048576)/1048576.5 for i in range(3)]
    w=math.sqrt(max(0,1-sum(v*v for v in q)));return q+[-w if packed>>63 else w]
def anim_value(b,at,frame):
    for _ in range(10000):
        valid,total=unpack(b,'2B',at)
        assert total>0 and valid<=total,(at,valid,total)
        if frame<total:return unpack(b,'h',at+2*(1+min(frame,valid-1)))[0] if valid else 0
        frame-=total;at+=2*(valid+1)
    raise ValueError('Invalid animation run')

def read_model(prefix):
    mdl=(SOURCE/'models/weapons'/f'{prefix}.mdl').read_bytes();vvd=(SOURCE/'models/weapons'/f'{prefix}.vvd').read_bytes();vtx=(SOURCE/'models/weapons'/f'{prefix}.dx90.vtx').read_bytes()
    assert mdl[:4]==b'IDST' and unpack(mdl,'i',4)[0]==48
    assert unpack(mdl,'i',8)[0]==unpack(vvd,'i',8)[0]==unpack(vtx,'i',16)[0]
    bones=[];nb,bo=unpack(mdl,'2i',156)
    for i in range(nb):
        at=bo+i*216;name,parent=unpack(mdl,'2i',at)
        bones.append(dict(name=cstring(mdl,at+name),parent=parent,pos=list(unpack(mdl,'3f',at+32)),quat=list(unpack(mdl,'4f',at+44)),rot=list(unpack(mdl,'3f',at+60)),pos_scale=list(unpack(mdl,'3f',at+72)),rot_scale=list(unpack(mdl,'3f',at+84))))
    def worlds(local):
        out=[]
        for i,bone in enumerate(bones):out.append(multiply(out[bone['parent']],local[i]) if bone['parent']>=0 else local[i])
        return out
    bind=worlds([matrix(b['pos'],b['quat']) for b in bones]);inverses=[inverse_rigid(m) for m in bind]
    textures=[];nt,to=unpack(mdl,'2i',204)
    for i in range(nt):
        at=to+i*64;textures.append(cstring(mdl,at+unpack(mdl,'i',at)[0]))
    nv=unpack(vvd,'i',16)[0];nfix,fixat,vat,tat=unpack(vvd,'4i',48);raw_vertices=[]
    for i in range(nv):
        at=vat+i*48;weights=unpack(vvd,'3f',at);ids=unpack(vvd,'3B',at+12);n=unpack(vvd,'B',at+15)[0]
        raw_vertices.append(dict(p=list(unpack(vvd,'3f',at+16)),n=list(unpack(vvd,'3f',at+28)),uv=list(unpack(vvd,'2f',at+40)),weights=[[ids[k],weights[k]] for k in range(n) if weights[k]>.000001]))
    vertices=[]
    if nfix:
        for i in range(nfix):
            lod,start,count=unpack(vvd,'3i',fixat+i*12)
            if lod>=0:vertices.extend(raw_vertices[start:start+count])
    else:vertices=raw_vertices
    assert len(vertices)==nv
    groups=[];nbp,bpat=unpack(mdl,'2i',232);vbcount,vbat=unpack(vtx,'2i',28);assert nbp==vbcount
    for bi in range(nbp):
        bp=bpat+bi*16;_,nmodels,_,model_rel=unpack(mdl,'4i',bp);vbp=vbat+bi*8;vnmodels,vmodel_rel=unpack(vtx,'2i',vbp);assert nmodels==vnmodels
        for mi in range(nmodels):
            model=bp+model_rel+mi*148;modelname=cstring(mdl,model);nm,mesh_rel,nverts,vert_bytes=unpack(mdl,'4i',model+72);model_vertex=vert_bytes//48
            vm=vbp+vmodel_rel+mi*8;nlod,lod_rel=unpack(vtx,'2i',vm);lod=vm+lod_rel;vnm,vm_rel=unpack(vtx,'2i',lod);assert nm==vnm
            for mesh_i in range(nm):
                mesh=model+mesh_rel+mesh_i*116;material,_,meshverts,meshvertex=unpack(mdl,'4i',mesh);vmesh=lod+vm_rel+mesh_i*9;nsg,sg_rel=unpack(vtx,'2i',vmesh);indices=[]
                for sgi in range(nsg):
                    sg=vmesh+sg_rel+sgi*25;sgnv,sgvo,sgni,sgio,nstrip,strip_rel=unpack(vtx,'6i',sg)
                    local_to_vvd=[unpack(vtx,'H',sg+sgvo+vi*9+4)[0]+model_vertex+meshvertex for vi in range(sgnv)]
                    local_indices=list(unpack(vtx,f'{sgni}H',sg+sgio))
                    for si in range(nstrip):
                        strip=sg+strip_rel+si*27;count,start=unpack(vtx,'2i',strip);flags=unpack(vtx,'B',strip+18)[0];seq=local_indices[start:start+count]
                        if flags&1:triangles=[seq[k:k+3] for k in range(0,len(seq),3)]
                        elif flags&2:triangles=[([seq[k+1],seq[k],seq[k+2]] if k%2 else seq[k:k+3]) for k in range(len(seq)-2)]
                        else:raise ValueError(('Unknown strip',flags))
                        for tri in triangles:
                            if len(set(tri))==3:indices.extend(local_to_vvd[k] for k in tri)
                assert all(0<=v<len(vertices) for v in indices)
                groups.append(dict(model=modelname,texture=textures[material],indices=indices))
    animations={};na,ao=unpack(mdl,'2i',180)
    for ai in range(na):
        at=ao+ai*100;name=cstring(mdl,at+unpack(mdl,'i',at+4)[0]).lstrip('@');fps,flags,nframes=unpack(mdl,'f2i',at+8);block,relative=unpack(mdl,'2i',at+52);section,section_frames=unpack(mdl,'2i',at+80)
        assert block==0 and section==0,(name,block,section);records={};cursor=at+relative
        while relative:
            bone,flag,nextoff=unpack(mdl,'BBh',cursor);assert bone<len(bones);records[bone]=(cursor+4,flag)
            if not nextoff:break
            cursor+=nextoff
        frames=[]
        for frame in range(nframes):
            local=[]
            for i,bone in enumerate(bones):
                pos=list(bone['pos']);q=list(bone['quat'])
                if i in records:
                    pos_at,flag=records[i];data_at=pos_at
                    if flag&2:q=q48(mdl,pos_at);data_at+=6
                    if flag&32:q=q64(mdl,pos_at);data_at+=8
                    if flag&1:pos=list(unpack(mdl,'3e',data_at))
                    if flag&8:
                        offsets=unpack(mdl,'3H',pos_at);e=[bone['rot'][k]+(anim_value(mdl,pos_at+offsets[k],frame)*bone['rot_scale'][k] if offsets[k] else 0) for k in range(3)];q=quaternion(e)
                    if flag&4:
                        p=pos_at+(6 if flag&8 else 0);offsets=unpack(mdl,'3H',p);pos=[bone['pos'][k]+(anim_value(mdl,p+offsets[k],frame)*bone['pos_scale'][k] if offsets[k] else 0) for k in range(3)]
                    assert not flag&16,'Delta animation needs explicit handling'
                local.append(matrix(pos,q))
            frames.append(worlds(local))
        animations[name]=dict(fps=fps,frames=frames)
    sequences={};ns,so=unpack(mdl,'2i',188)
    for si in range(ns):
        at=so+si*212;name=cstring(mdl,at+unpack(mdl,'i',at+4)[0]);ne,relative=unpack(mdl,'2i',at+24);events=[]
        for i in range(ne):
            event_at=at+relative+i*80;cycle,event_id,event_type=unpack(mdl,'fii',event_at);option=mdl[event_at+12:event_at+76].split(b'\0')[0].decode('ascii')
            if event_id==5004:events.append(dict(cycle=cycle,sound=option))
        sequences[name]=events
    return dict(bones=[dict(name=b['name'],parent=b['parent']) for b in bones],bind=bind,bindInverse=inverses,vertices=vertices,groups=groups,animations=animations,sequences=sequences)

if __name__=='__main__':
    model=read_model('v_snip_awp');out=ROOT/'.local/trg-source/parsed.json';dump(out,model)
    print(json.dumps({'vertices':len(model['vertices']),'groups':[{**g,'indices':len(g['indices'])} for g in model['groups']],'clips':{n:len(a['frames']) for n,a in model['animations'].items()}},ensure_ascii=True))
