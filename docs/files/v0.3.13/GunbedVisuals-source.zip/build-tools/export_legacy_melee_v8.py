"""Keep the original CrackShot item geometry/UVs while supplying native skin-hand animations."""
from pathlib import Path
import json,math,shutil
import numpy as np,yaml
from server_audit import ROOT,STAGE,dump
ASSETS=STAGE/'plugins/ItemsAdder/contents/gunbed_fps/resourcepack/assets';RES=ROOT/'client/src/main/resources/assets'
NAMES={'망치':'blaze_rod','나타나이프':'golden_sword','광선검':'wooden_sword','광선검무료':'iron_axe'}
catalog=RES/'tacz/gunbed_catalog.json';data=json.loads(catalog.read_text(encoding='utf8'));models={}
inverse=np.linalg.inv(np.array([[0,-1,0],[0,0,1],[-1,0,0]])/24)
for title,file in NAMES.items():
 source=json.loads((ASSETS/f'gunbed/models/cs/imported/minecraft/item/{file}.json').read_text(encoding='utf8'));points=[];parts={}
 tex=source['textures'];copied=set()
 def texture(value):
  while value.startswith('#'):value=tex[value[1:]]
  if value in copied:return value.split(':')[0]+':textures/'+value.split(':',1)[1]+'.png'
  copied.add(value);namespace,path=value.split(':',1);dest=RES/namespace/'textures'/(path+'.png');dest.parent.mkdir(parents=True,exist_ok=True);origin=ASSETS/namespace/'textures'/(path+'.png');origin=origin if origin.exists() else STAGE/'plugins/ItemsAdder/contents/gunbed_legacy/resourcepack/assets'/namespace/'textures'/(path+'.png');shutil.copy2(origin,dest)
  return namespace+':textures/'+path+'.png'
 corners={'north':[0,1,2,3],'south':[5,4,7,6],'west':[4,0,3,7],'east':[1,5,6,2],'up':[3,2,6,7],'down':[4,5,1,0]}
 for element in source['elements']:
  x0,y0,z0=element['from'];x1,y1,z1=element['to'];v=np.array([[x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0],[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]],dtype=float)
  if 'rotation'in element:
   r=element['rotation'];angle=math.radians(r['angle']);c,s=math.cos(angle),math.sin(angle);axis=r['axis'];m=np.array([[1,0,0],[0,c,-s],[0,s,c]]) if axis=='x' else np.array([[c,0,s],[0,1,0],[-s,0,c]]) if axis=='y' else np.array([[c,-s,0],[s,c,0],[0,0,1]]);o=np.array(r['origin']);v=(m@(v-o).T).T+o
  for face,spec in element.get('faces',{}).items():
   if face not in corners:continue
   positions=v[corners[face]];uv=spec.get('uv',[0,0,16,16]);u0,v0,u1,v1=uv;coords=[[u0,v1],[u1,v1],[u1,v0],[u0,v0]];shift=spec.get('rotation',0)//90;coords=coords[shift:]+coords[:shift];normal=np.cross(positions[1]-positions[0],positions[2]-positions[0]);length=np.linalg.norm(normal)
   if length<1e-8:continue
   normal/=length;indices=[]
   for p,coord in zip(positions,coords):indices.append(len(points));points.append([*p,*normal,coord[0]/16,coord[1]/16,0])
   parts.setdefault(texture(spec['texture']),[]).extend([indices[0],indices[1],indices[2],indices[0],indices[2],indices[3]])
 xyz=np.array([v[:3] for v in points]);lo=xyz.min(0);hi=xyz.max(0);scale=.95/max(hi-lo);center=(lo+hi)/2
 for v in points:
  # Upright blade/hammer, grip near the lower third; no gun texture is ever used for the skin arm.
  position=(np.array(v[:3])-np.array([center[0],lo[1]+(hi[1]-lo[1])*.22,center[2]]))*scale+np.array([.28,-.22,-.76]);v[:3]=(inverse@position).tolist();v[3:6]=(inverse@np.array(v[3:6])).tolist()
 identity=np.eye(4).reshape(-1).tolist();slug='gunbed_legacy_'+file;models[title]=slug
 mesh={'gunbed:source_mesh':{'viewOffset':[0,0,0],'vertices':points,'parts':[{'texture':k,'indices':v} for k,v in parts.items()],'clips':{'idle1':{'fps':1,'frames':[[identity],[identity]]}},'aliases':{'static_idle':'idle1','draw':'idle1','attack_left':'idle1'},'leftArm':0,'rightArm':0,'muzzle':0,'proceduralArms':False,'nativeArms':False}}
 dump(RES/f'gunbed/models/melee/{slug}.json',mesh);anim=RES/f'gunbed/animations/melee/{slug}.json';dump(anim,{'animations':{}})
 data['guns'][slug]={'id':slug,'name':title,'type':'melee','model':f'assets/gunbed/models/melee/{slug}.json','animation':f'assets/gunbed/animations/melee/{slug}.json','texture':next(iter(parts)),'display':{'sounds':{}},'soundAliases':{}}
for p in [STAGE/'plugins/GunbedCore/visuals.yml',ROOT/'src/main/resources/visuals.yml']:
 config=yaml.safe_load(p.read_text(encoding='utf8'));config['models'].update(models);p.write_text(yaml.safe_dump(config,allow_unicode=True,sort_keys=False),encoding='utf8')
dump(catalog,data);print('Retained original models and UVs for',list(NAMES))
