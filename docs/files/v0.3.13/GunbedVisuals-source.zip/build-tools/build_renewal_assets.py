"""Import the owner's QA throwable art and churi team textures into private model IDs."""
import copy,json,zipfile,shutil
from pathlib import Path
from PIL import Image
from server_audit import ROOT,BASE,STAGE,dump,sha256
RES=ROOT/'client/src/main/resources'
QA=Path.home()/'Documents/마인크래프트 좀비서버 리뉴얼/MZSResourceCompat/build/test-packs/mzs-compat-1_21_9-plus.zip'
catalog_path=RES/'assets/tacz/gunbed_catalog.json';catalog=json.loads(catalog_path.read_text(encoding='utf8'))
with zipfile.ZipFile(QA) as z:
 for kind,original in [('he','grenade'),('fire','incendarygrenade'),('flash','flashbang')]:
  model=json.loads(z.read(f'assets/qualityarmory/models/misc/{original}.json'))
  cubes=[]
  # All three QA throwable meshes use the same RGB atlas; preserve each face's UV.
  for e in model['elements']:
   origin=[e['from'][0]-8,e['from'][1],e['from'][2]-8];size=[b-a for a,b in zip(e['from'],e['to'])]
   uv={}
   for face,spec in e['faces'].items():
    u,v,uu,vv=spec.get('uv',[0,0,16,16]);uv[face]={'uv':[u,v],'uv_size':[uu-u,vv-v]}
   cube={'origin':origin,'size':size,'uv':uv}
   if e.get('rotation'):
    rotation=e['rotation'];axis='xyz'.index(rotation['axis']);angles=[0,0,0];angles[axis]=rotation['angle'];cube['rotation']=angles;cube['pivot']=[rotation['origin'][0]-8,rotation['origin'][1],rotation['origin'][2]-8]
   cubes.append(cube)
  atlas_name=next(v for k,v in model['textures'].items() if k!='particle').lstrip('_');namespace,texture=atlas_name.split(':',1)
  png=z.read(f'assets/{namespace}/textures/{texture}.png');target=RES/f'assets/gunbed/textures/throwable/{kind}.png';target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(png)
  # RGB sheets encode one colour per 1/16th; use original image pixel dimensions.
  width,height=Image.open(target).size
  for c in cubes:
   for uv in c['uv'].values():uv['uv']=[uv['uv'][0]*width/16,uv['uv'][1]*height/16];uv['uv_size']=[uv['uv_size'][0]*width/16,uv['uv_size'][1]*height/16]
  bones=[{'name':'root','pivot':[0,24,0]}, {'name':'body','parent':'root','pivot':[0,0,0],'cubes':cubes}, {'name':'righthand_pos','parent':'root','pivot':[-5,11,8]}, {'name':'lefthand_pos','parent':'root','pivot':[6,10,7]}, {'name':'idle_view','pivot':[3.5,8.8,16]}]
  geometry={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.qa_'+kind,'texture_width':width,'texture_height':height},'bones':bones}]}
  animation={'animations':{'static_idle':{'animation_length':1,'loop':True,'bones':{}},'draw':{'animation_length':.6,'bones':{'root':{'rotation':{'0':[25,0,-10],'.6':[0,0,0]}}}},'pull_pin':{'animation_length':.4,'bones':{'lefthand_pos':{'position':{'0':[0,0,0],'.15':[-8,3,-3],'.4':[-5,4,0]}}}},'throw':{'animation_length':.5,'bones':{'root':{'rotation':{'0':[0,0,0],'.2':[-70,0,-15],'.35':[45,0,0],'.5':[60,0,0]}},'lefthand_pos':{'position':{'0':[-5,4,0],'.2':[0,-20,0]}}}}}}
  dump(RES/f'assets/gunbed/models/throwable/{kind}.json',geometry);dump(RES/f'assets/gunbed/models/throwable/{kind}.animation.json',animation)
  catalog['guns']['qa_'+kind]={'id':'qa_'+kind,'name':original,'type':'throwable','model':f'assets/gunbed/models/throwable/{kind}.json','animation':f'assets/gunbed/models/throwable/{kind}.animation.json','texture':f'gunbed:textures/throwable/{kind}.png','soundAliases':{},'display':{'sounds':{}},'actions':{'draw':600,'pull_pin':400,'throw':500}}
  # Inventory/ground/third-person models use the untouched original element topology.
  for k,v in model['textures'].items():model['textures'][k]=f'gunbed:item/throwable/{kind}'
  item_texture=RES/f'assets/gunbed/textures/item/throwable/{kind}.png';item_texture.parent.mkdir(parents=True,exist_ok=True);item_texture.write_bytes(png)
  dump(RES/f'assets/gunbed/models/throwable/{kind}_item.json',model)
  dump(RES/f'assets/gunbed/items/throwable/{kind}.json',{'model':{'type':'minecraft:model','model':f'gunbed:throwable/{kind}_item'}})
dump(catalog_path,catalog)
churi=BASE/'churi/plugins/ItemsAdder/contents/detective_team_armor/resourcepack/detective_team_armor/textures/armor/team'
for layer,name in [('humanoid','layer_1'),('humanoid_leggings','layer_2')]:
 dest=RES/f'assets/gunbed/textures/entity/equipment/{layer}/churi_cloth.png';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(churi/(name+'.png'),dest)
dump(RES/'assets/gunbed/equipment/churi_cloth.json',{'layers':{layer:[{'texture':'gunbed:churi_cloth','dyeable':{'color_when_undyed':16777215}}] for layer in ['humanoid','humanoid_leggings']}})
# Copy only the team colour block assets, not churi's item selectors or GUI.
source=BASE/'churi/plugins/ItemsAdder/contents/my_server_pack/resourcepack/assets/minecraft/textures/block'
count=0
for path in source.glob('*.png'):
 if any(path.name.startswith(c+'_') for c in ['red','light_blue','lime','pink','cyan','gray','white','yellow']):
  dest=STAGE/'plugins/ItemsAdder/contents/gunbed_fps/resourcepack/assets/minecraft/textures/block'/path.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest);count+=1
dump(ROOT/'reports/renewal-assets.json',{'success':True,'qa_models':3,'qa_source':str(QA),'armor_sources':[str(churi/'layer_1.png'),str(churi/'layer_2.png')],'block_textures':count,'client_model_count':len(catalog['guns'])})
print('QA throwables imported, private dyed armor model and',count,'team block textures.')
