"""Preserve the supplied triangles, normals and UVs for the native display renderer."""
import base64,io,json,struct,zipfile
from pathlib import Path
import numpy as np
from server_audit import ROOT,dump,sha256
OUT=ROOT/'client/src/main/resources/assets/gunbed'
SPECS={'burst':'minecraft-sentry-gun.zip','siege':'missile-turret.zip','healing':'회복포탑 shock-cannon-turret.zip','slowness':'portal-alternative-turret-minecraft.zip'}
TINTS={'burst':[.85,.88,.94,1],'slowness':[1,.76,.22,1],'healing':[.35,.92,1,1],'siege':[.2,1,.55,1]}
def matrix(node):
 if 'matrix'in node:return np.array(node['matrix']).reshape((4,4)).T
 x,y,z,w=node.get('rotation',[0,0,0,1]);r=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w),0],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w),0],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y),0],[0,0,0,1.]])
 r[:3,:3]@=np.diag(node.get('scale',[1,1,1]));r[:3,3]=node.get('translation',[0,0,0]);return r
report=[]
for kind,name in SPECS.items():
 source=Path.home()/'Downloads'/name;parts=[];texture_count=0
 with zipfile.ZipFile(source) as archive:
  if kind=='slowness':
   inner=zipfile.ZipFile(io.BytesIO(archive.read(next(n for n in archive.namelist() if n.endswith('.zip')))));obj=inner.read(next(n for n in inner.namelist() if n.endswith('.obj'))).decode();vertices=[];uv=[];normals=[];material='default';groups={};materials={}
   for n in inner.namelist():
    if n.lower().endswith('.mtl'):
     current='default'
     for line in inner.read(n).decode().splitlines():
      row=line.split(maxsplit=1)
      if len(row)<2:continue
      if row[0]=='newmtl':current=row[1]
      if row[0]=='map_Kd':materials[current]=row[1].replace('\\','/').split('/')[-1]
   def index(v,size):return int(v)-1 if int(v)>0 else size+int(v)
   for line in obj.splitlines():
    row=line.split()
    if not row:continue
    if row[0]=='v':vertices.append([float(x) for x in row[1:4]])
    elif row[0]=='vt':uv.append([float(row[1]),1-float(row[2])])
    elif row[0]=='vn':normals.append([float(x) for x in row[1:4]])
    elif row[0]=='usemtl':material=' '.join(row[1:])
    elif row[0]=='f':
     face=[a.split('/') for a in row[1:]]
     for i in range(1,len(face)-1):
      tri=[face[0],face[i],face[i+1]];ps=np.array([vertices[index(a[0],len(vertices))] for a in tri]);normal=np.cross(ps[1]-ps[0],ps[2]-ps[0]);normal/=max(np.linalg.norm(normal),1e-9);points=[]
      for a,p in zip(tri,ps):points.append([*p,*(uv[index(a[1],len(uv))] if len(a)>1 and a[1] else [0,0]),*(normals[index(a[2],len(normals))] if len(a)>2 and a[2] else normal)])
      groups.setdefault(material,[]).extend([points[0],points[1],points[2],points[2]])
   pngs=[n for n in inner.namelist() if n.lower().endswith('.png')]
   for i,(m,points) in enumerate(groups.items()):
    filename=materials.get(m,'');selected=next((n for n in pngs if Path(n).name==filename),pngs[0]);texture=f'gunbed:textures/turret/native/{kind}_{i}.png';dest=OUT/f'textures/turret/native/{kind}_{i}.png';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(inner.read(selected));parts.append({'texture':texture,'color':TINTS[kind],'vertices':points});texture_count+=1
  else:
   gltf_name=next(n for n in archive.namelist() if n.endswith('.gltf'));gltf=json.loads(archive.read(gltf_name));prefix=str(Path(gltf_name).parent).replace('\\','/')
   def uri(u):return base64.b64decode(u.split(',',1)[1]) if u.startswith('data:') else archive.read((prefix+'/' if prefix!='.' else '')+u)
   buffers=[uri(b['uri']) for b in gltf['buffers']]
   def accessor(i):
    a=gltf['accessors'][i];v=gltf['bufferViews'][a['bufferView']];count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];fmt={5126:'f',5125:'I',5123:'H',5121:'B'}[a['componentType']];size=struct.calcsize('<'+fmt)*count;stride=v.get('byteStride',size);start=v.get('byteOffset',0)+a.get('byteOffset',0);return np.array([struct.unpack_from('<'+fmt*count,buffers[v['buffer']],start+k*stride) for k in range(a['count'])])
   def visit(i,parent):
    global texture_count
    node=gltf['nodes'][i];transform=parent@matrix(node)
    if 'mesh'in node:
     for primitive in gltf['meshes'][node['mesh']]['primitives']:
      assert primitive.get('mode',4)==4,'Only triangular source meshes expected'
      attributes=primitive['attributes'];pos=accessor(attributes['POSITION']);pos=(transform@np.c_[pos,np.ones(len(pos))].T).T[:,:3];uv=accessor(attributes['TEXCOORD_0']) if 'TEXCOORD_0'in attributes else np.zeros((len(pos),2));normal=accessor(attributes['NORMAL']) if 'NORMAL'in attributes else np.tile([0,1,0],(len(pos),1));normal=(np.linalg.inv(transform[:3,:3]).T@normal.T).T;normal/=np.maximum(np.linalg.norm(normal,axis=1)[:,None],1e-9);indices=accessor(primitive['indices']).astype(int).ravel() if 'indices'in primitive else np.arange(len(pos));material=gltf['materials'][primitive.get('material',0)].get('pbrMetallicRoughness',{});image=gltf['images'][gltf['textures'][material['baseColorTexture']['index']]['source']] if 'baseColorTexture'in material else None;data=(uri(image['uri']) if 'uri'in image else buffers[gltf['bufferViews'][image['bufferView']]['buffer']][gltf['bufferViews'][image['bufferView']].get('byteOffset',0):][:gltf['bufferViews'][image['bufferView']]['byteLength']]) if image is not None else base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4////fwAJ+wP9KobjigAAAABJRU5ErkJggg==');n=len(parts);texture=f'gunbed:textures/turret/native/{kind}_{n}.png';dest=OUT/f'textures/turret/native/{kind}_{n}.png';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);factor=np.array(material.get('baseColorFactor',[1,1,1,1]))*TINTS[kind];factor[3]=1;points=[]
      for t in range(0,len(indices),3):
       ids=indices[t:t+3]
       for k in [ids[0],ids[1],ids[2],ids[2]]:points.append([*pos[k],*uv[k],*normal[k]])
      parts.append({'texture':texture,'color':factor.tolist(),'vertices':points});texture_count+=1
    for child in node.get('children',[]):visit(child,transform)
   for i in gltf['scenes'][gltf.get('scene',0)]['nodes']:visit(i,np.eye(4))
 allpoints=np.array([row[:3] for p in parts for row in p['vertices']]);low=allpoints.min(0);high=allpoints.max(0);center=(low+high)/2;center[1]=low[1];scale=1.5/max(high-low)
 for part in parts:
  for row in part['vertices']:row[:3]=((np.array(row[:3])-center)*scale).tolist()
  part['vertices']=[[round(float(x),6) for x in row] for row in part['vertices']]
 dump(OUT/f'models/turret/native/{kind}.json',{'parts':parts})
 report.append({'kind':kind,'source':str(source),'source_sha256':sha256(source),'triangles':len(allpoints)//4,'surfaces':len(parts),'uv_and_topology_preserved':True})
dump(ROOT/'reports/native-turret-meshes.json',{'success':True,'models':report});print(report)
