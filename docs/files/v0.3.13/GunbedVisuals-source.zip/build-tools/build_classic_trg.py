"""Port the supplied MiniSudden classic TRG mesh, retaining original UVs.

The standalone game calls the models mk23/mk23sd; they are TRG-shaped rifles.
Skeletal poses are retimed against the user-specified review, not extracted
from the video. The server's existing 7.5-second reload remains authoritative.
"""
import copy,json,math,re
from pathlib import Path
from PIL import Image
from server_audit import ROOT,dump,sha256
from import_trg_source import read_model,transform,multiply,identity

SOURCE=Path(r'C:\Users\mydon\Desktop\유용하다\미니게임\Sudden Attack mod 2\data\model\weapon')
RES=ROOT/'client/src/main/resources';OUT=RES/'assets/gunbed'

def read_x(path):
    text=path.read_text(encoding='utf-8-sig');start=re.search(r'\bMesh\s+\w*\s*\{',text).end()
    values=[float(x) for x in re.findall(r'-?\d+\.?\d*(?:[eE][-+]?\d+)?',text[start:].split('MeshNormals')[0])]
    n=int(values[0]);positions=[values[1+i*3:4+i*3] for i in range(n)];at=1+n*3;faces=[]
    for _ in range(int(values[at])):
        k=int(values[at+1]);faces.append([int(i) for i in values[at+2:at+2+k]]);at+=k+1
    values=[float(x) for x in re.findall(r'-?\d+\.?\d*(?:[eE][-+]?\d+)?',text.split('MeshTextureCoords')[1].split('}')[0])]
    assert int(values[0])==n
    return positions,faces,[values[1+i*2:3+i*2] for i in range(n)]

def normalize(p):
    size=math.sqrt(sum(x*x for x in p));return [x/size for x in p] if size>1e-12 else [0,1,0]

def build():
    source=SOURCE/'mk23sd.x';positions,faces,uvs=read_x(source);parsed=read_model('v_snip_awp')
    # MiniSudden uses metres and a Y-up body; the imported rig uses Source units
    # with its local Y pointing down. Align receiver/grip, not outer silencer tips.
    points=[[(p[0]-.007)*29-1.5,-p[1]*29+1,p[2]*23.25+1] for p in positions]
    normals=[[0.,0.,0.] for p in points];triangles=[]
    for face in faces:
        for k in range(1,len(face)-1):
            a,b,c=face[0],face[k],face[k+1];triangles.extend((a,b,c));u=[points[b][i]-points[a][i] for i in range(3)];v=[points[c][i]-points[a][i] for i in range(3)]
            normal=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
            for i in (a,b,c):normals[i]=[x+y for x,y in zip(normals[i],normal)]
    normals=list(map(normalize,normals))
    # A disconnected component belongs wholly to its moving part; this avoids
    # stretching a magazine/bolt face when seams duplicate its vertices.
    parents=list(range(len(points)))
    def find(a):
        while parents[a]!=a:parents[a]=parents[parents[a]];a=parents[a]
        return a
    for f in faces:
        for i in f[1:]:parents[find(i)]=find(f[0])
    groups={}
    for i in range(len(points)):groups.setdefault(find(i),[]).append(i)
    bones=[0]*len(points)
    for ids in groups.values():
        lo=[min(positions[i][k] for i in ids) for k in range(3)];hi=[max(positions[i][k] for i in ids) for k in range(3)]
        bone=1 if lo[2]>=-.24 and hi[2]<=-.07 and lo[1]<-.08 and hi[1]<-.03 else 2 if hi[0]<-.001 and lo[1]>.025 and hi[1]<.08 and lo[2]>-.061 and hi[2]<.051 else 0
        for i in ids:bones[i]=bone
    vertices=[]
    for p,n,uv,bone in zip(points,normals,uvs,bones):
        world=transform(parsed['bind'][0],p);normal=transform(parsed['bind'][0],n,0)
        vertices.append(transform(parsed['bindInverse'][bone],world)+transform(parsed['bindInverse'][bone],normal,0)+uv+[bone])
    clips={name:{'fps':clip['fps'],'frames':copy.deepcopy(clip['frames'])} for name,clip in parsed['animations'].items()}
    # Observed order in the 38.9–42.0s review segment: mag down, mag in,
    # right hand to bolt, bolt closed. Retime the donor rig to those landmarks.
    target=[0,.10,.45,.75,.89,1];donor=[0,.15315315,.2882883,.7297297,.8018018,1]
    frames=clips['reload']['frames'];retimed=[]
    for frame in range(len(frames)):
        t=frame/(len(frames)-1);segment=next((i for i in range(5) if t<=target[i+1]),4);fraction=(t-target[segment])/(target[segment+1]-target[segment]);at=(donor[segment]+fraction*(donor[segment+1]-donor[segment]))*(len(frames)-1);lo=min(int(at),len(frames)-1);hi=min(lo+1,len(frames)-1);blend=at-lo
        retimed.append([[a+(b-a)*blend for a,b in zip(x,y)] for x,y in zip(frames[lo],frames[hi])])
    clips['reload']['frames']=retimed
    # Additional poses inferred from the visible rifle angle in the review.
    # These are authored corrections, not recovered original game animation.
    pose_keys=[(0,0,0),(.10,-3,.10),(.25,-4,.30),(.45,-3,.25),(.60,3,.20),(.75,9,.15),(.86,7,.10),(.94,2,.04),(1,0,0)]
    for index,frame in enumerate(clips['reload']['frames']):
        t=index/(len(retimed)-1);segment=next((k for k in range(len(pose_keys)-1) if t<=pose_keys[k+1][0]),len(pose_keys)-2);a,b=pose_keys[segment:segment+2];blend=(t-a[0])/(b[0]-a[0]);blend=blend*blend*(3-2*blend)
        angle=math.radians(a[1]+(b[1]-a[1])*blend);rise=a[2]+(b[2]-a[2])*blend;c,s=math.cos(angle),math.sin(angle);rotation=[1,0,0,0,0,c,-s,0,0,s,c,0,0,0,0,1]
        pivot=[frame[0][k] for k in (3,7,11)];turned=transform(rotation,pivot);rotation[3]=pivot[0]-turned[0];rotation[7]=pivot[1]-turned[1];rotation[11]=pivot[2]-turned[2]+rise
        for bone in range(len(frame)):frame[bone]=multiply(rotation,frame[bone])
    # A muzzle attachment at the actual end of this model, not Infinity D's barrel.
    muzzle=identity();muzzle[3]=(0.06-.007)*29-1.5;muzzle[7]=-.064*29+1;muzzle[11]=min(p[2] for p in positions)*23.25+1
    for clip in clips.values():
        for frame in clip['frames']:frame.append(multiply(frame[0],muzzle))
    mesh={'vertices':vertices,'parts':[{'texture':'gunbed:textures/trg21/minisudden_classic.png','indices':triangles}],
          'clips':clips,'aliases':{'':'idle1','static_idle':'idle1','draw':'draw','shoot':'shoot','bolt':'shoot','reload_tactical':'reload','reload_empty':'reload'},
          'leftArm':8,'rightArm':27,'muzzle':43,'proceduralArms':False,'nativeArms':True,'viewOffset':[0,-.03,-.35]}
    dump(OUT/'models/trg21/classic_mesh.json',{'gunbed:source_mesh':mesh})
    Image.open(SOURCE/'mk23.bmp').convert('RGBA').save(OUT/'textures/trg21/minisudden_classic.png')
    catalog_path=RES/'assets/tacz/gunbed_catalog.json';catalog=json.loads(catalog_path.read_text(encoding='utf-8'));catalog['guns']['gunbed_trg21']['actions']={'shoot':1167,'draw':850};dump(catalog_path,catalog)
    audio_path=ROOT/'src/main/resources/trg-audio.json';audio=json.loads(audio_path.read_text(encoding='utf-8'));audio['shootMs']=1167
    for event,cycle in zip(audio['reload'],target[1:-1]):event['cycle']=cycle
    dump(audio_path,audio)
    report={'success':True,'source_model':str(source),'source_model_sha256':sha256(source),'model_vertices':len(points),'model_triangles':len(triangles)//3,'model_uv_preserved':True,'moving_mag_vertices':bones.count(1),'moving_bolt_vertices':bones.count(2),'hand_style':'native Minecraft player arms, no articulated human fingers','articulated_hand_vertices':0,'reference_pose_keys':pose_keys,'reload_landmarks':target[1:-1],'reference':'https://www.youtube.com/watch?v=UzyyS6ncmMU','reference_title':'Sudden Attack TRG-21 Silencer Review','silenced_fire_audio_imported':False,'existing_normal_fire_audio_preserved':True,'animation_note':'Video-inferred pose corrections and retimed donor rig; not original Sudden Attack animation data','reload_duration_ms':7500}
    dump(ROOT/'reports/trg-classic-import.json',report);print(json.dumps(report,ensure_ascii=True))

if __name__=='__main__':build()
