"""Add the requested melee art, distinct M79 and mode-correct inventory icons."""
import copy,json,shutil,hashlib
from pathlib import Path
from PIL import Image,ImageDraw
import json5,yaml
from server_audit import ROOT,STAGE,dump,sha256
RES=ROOT/'client/src/main/resources';TARGET=STAGE/'plugins/ItemsAdder/contents/gunbed_fps/resourcepack'
LR=ROOT/'.local/lrtactical-reference/src/main/resources/assets/lrtactical'
catalog_file=RES/'assets/tacz/gunbed_catalog.json';catalog=json.loads(catalog_file.read_text(encoding='utf8'))
for folder in ('geo_models','animations','textures','tacz_sounds'):
 if (LR/folder).exists():shutil.copytree(LR/folder,RES/'assets/lrtactical'/folder,dirs_exist_ok=True)
for id,name in [('dagger','단검'),('karambit','카람빗'),('baseball_bat','야구방망이')]:
 display=json5.loads((LR/f'display/melee/{id}.json').read_text(encoding='utf8'))
 animation=LR/('animations/'+display['animation'].split(':')[1]+'.animation.json');clips=json.loads(animation.read_text(encoding='utf8'))
 clips['animations']['attack_left']=copy.deepcopy(clips['animations']['melee_1'])
 dest=RES/f'assets/gunbed/animations/lr_{id}.json';dump(dest,clips)
 catalog['guns']['lr_'+id]={'id':'lr_'+id,'name':name,'type':'melee','model':'assets/lrtactical/geo_models/'+display['model'].split(':')[1]+'.json','animation':dest.relative_to(RES).as_posix(),'texture':'lrtactical:textures/'+display['texture'].split(':')[1]+'.png','display':{'sounds':{}},'soundAliases':{}}
 png=(LR/('textures/'+display['slot_texture'].split(':')[1]+'.png')).read_bytes()
 texture=RES/f'assets/gunbed/textures/item/melee/{id}.png';texture.parent.mkdir(parents=True,exist_ok=True);texture.write_bytes(png)
 dump(RES/f'assets/gunbed/models/item/melee/{id}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'gunbed:item/melee/{id}'}})
 dump(RES/f'assets/gunbed/items/melee/{id}.json',{'model':{'type':'minecraft:model','model':f'gunbed:item/melee/{id}'}})
# Retarget the addon pin/throw timing to the original QA body. Minecraft hands remain native skin.
reference=json.loads((LR/'animations/throwable/m67_grenade.animation.json').read_text(encoding='utf8'))['animations']
dump(RES/'assets/gunbed/reference/lr_throw_motion.json',{'source':'LesRaisins Tactical Equipements','clips':{k:reference[k] for k in ('unlock_safe','throw')}})
# M79: one large break-action barrel and wood furniture, not the two-barrel shotgun.
texture=Image.new('RGBA',(32,16),(0,0,0,255));draw=ImageDraw.Draw(texture)
for x,color in [(0,(55,59,63,255)),(8,(106,67,43,255)),(16,(23,26,29,255)),(24,(145,100,59,255))]:draw.rectangle((x,0,x+7,15),fill=color)
for y in (2,6,11,14):draw.line((8,y,15,y),fill=(77,47,32,255))
path=RES/'assets/gunbed/textures/m79.png';path.parent.mkdir(parents=True,exist_ok=True);texture.save(path)
def cube(o,s,u):return {'origin':o,'size':s,'uv':{f:{'uv':[u,0],'uv_size':[7,15]} for f in ('north','south','east','west','up','down')}}
bones=[{'name':'root','pivot':[0,0,0]},{'name':'stock','parent':'root','pivot':[0,4,3],'cubes':[cube([-1.6,2,3],[3.2,3,10],8),cube([-1.8,1.5,11],[3.6,4,3],8),cube([-1.1,-1,2],[2.2,4,3],8)]},{'name':'barrel','parent':'root','pivot':[0,5,3],'cubes':[cube([-1.7,4,-16],[3.4,3.4,19],0),cube([-1.1,4.6,-16.2],[2.2,2.2,.15],16),cube([-1.9,2.8,-6],[3.8,1.5,7],8),cube([-.3,7.4,-15],[.6,1,.8],0),cube([-2,3.5,1],[4,4,3],0)]},{'name':'idle_view','pivot':[0,0,0]},{'name':'righthand_pos','parent':'root','pivot':[-4,0,7]},{'name':'lefthand_pos','parent':'root','pivot':[3,2,-5]}]
geo={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.gunbed_m79','texture_width':32,'texture_height':16},'bones':bones}]}
anim={'animations':{'static_idle':{'loop':True,'animation_length':1,'bones':{}},'reload_tactical':{'animation_length':2.7,'bones':{'barrel':{'rotation':{'0':[0,0,0],'.5':[35,0,0],'1.9':[35,0,0],'2.3':[0,0,0]}},'lefthand_pos':{'position':{'0':[0,0,0],'.6':[0,-5,-2],'1.5':[0,1,3],'2.7':[0,0,0]}}}},'shoot':{'animation_length':.25,'bones':{'root':{'position':{'0':[0,0,0],'.08':[0,0,2],'.25':[0,0,0]}}}},'draw':{'animation_length':.6,'bones':{'root':{'rotation':{'0':[30,0,-15],'.6':[0,0,0]}}}}}}
anim['animations']['reload_empty']=copy.deepcopy(anim['animations']['reload_tactical']);dump(RES/'assets/gunbed/models/m79.json',geo);dump(RES/'assets/gunbed/animations/m79.json',anim)
catalog['guns']['gunbed_m79']={'id':'gunbed_m79','name':'M79','type':'shotgun','model':'assets/gunbed/models/m79.json','animation':'assets/gunbed/animations/m79.json','texture':'gunbed:textures/m79.png','display':{'sounds':{}},'soundAliases':{}}
dump(catalog_file,catalog)
for file in (STAGE/'plugins/GunbedCore/visuals.yml',ROOT/'src/main/resources/visuals.yml'):
 data=yaml.safe_load(file.read_text(encoding='utf8'));data['models']['소드오프']='gunbed_m79';file.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf8')
# B variants must select their own gun family rather than an unrelated legacy item override.
for title,id in [('더블배럴','db_long'),('더블배럴B','db_long'),('골데B','deagle_golden'),('VSS-B','mk14')]:
 slug=hashlib.sha256(title.encode()).hexdigest()[:16];dump(TARGET/f'assets/gunbed/items/cs/{slug}.json',{'model':{'type':'minecraft:model','model':f'gunbed:item/ta/{id}'}})
# Dedicated simple M79 icon, independently drawn, for all screen scales.
im=Image.new('RGBA',(128,64));d=ImageDraw.Draw(im);d.rounded_rectangle((27,24,111,35),3,fill='#41474C');d.rectangle((108,25,115,34),fill='#1E2328');d.polygon([(8,34),(34,29),(50,35),(38,45),(10,50)],fill='#845B3C');d.rectangle((42,34,66,41),fill='#A27145');d.line((32,23,109,23),fill='#818B94',width=2)
dest=TARGET/'assets/gunbed/textures/item/m79.png';dest.parent.mkdir(parents=True,exist_ok=True);im.save(dest);dump(TARGET/'assets/gunbed/models/item/m79.json',{'parent':'minecraft:item/generated','textures':{'layer0':'gunbed:item/m79'}})
slug=hashlib.sha256('소드오프'.encode()).hexdigest()[:16];dump(TARGET/f'assets/gunbed/items/cs/{slug}.json',{'model':{'type':'minecraft:model','model':'gunbed:item/m79'}})
shop=STAGE/'plugins/GunbedCore/shop.yml';data=yaml.safe_load(shop.read_text(encoding='utf8'));items=data['pages']['Weapon']['items'];items[:]=[x for x in items if not x.get('addon-melee')]
shop.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf8')
dump(ROOT/'reports/combat-assets.json',{'success':True,'melee_armory':[{'id':i,'model_sha256':sha256(RES/catalog['guns']['lr_'+i]['model'])} for i in ('dagger','karambit','baseball_bat')],'m79':'independent single barrel break-action','double_b_icon':'db_long','addon_source':'https://github.com/LesRaisins-Studios/LesRaisins-Tactical-Equipements','addon_motion_reference':True})
print('Imported 3 melee models; separate M79; repaired mode icons; 3 free armory entries.')
