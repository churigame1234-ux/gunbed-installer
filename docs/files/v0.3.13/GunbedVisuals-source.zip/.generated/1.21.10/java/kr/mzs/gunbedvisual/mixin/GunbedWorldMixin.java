package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(net.minecraft.client.multiplayer.ClientPacketListener.class)
public abstract class GunbedWorldMixin {
    @Inject(method="handleRespawn",at=@At("HEAD"))
    private void gunbedWorld(net.minecraft.network.protocol.game.ClientboundRespawnPacket packet,CallbackInfo ci){kr.mzs.gunbedvisual.PackOwnership.transition();kr.mzs.gunbedvisual.VisualState.INSTANCE.clear();kr.mzs.gunbedvisual.HudState.INSTANCE.clear();}
}
