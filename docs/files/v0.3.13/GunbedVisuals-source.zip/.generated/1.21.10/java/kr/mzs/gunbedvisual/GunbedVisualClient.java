package kr.mzs.gunbedvisual;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import java.nio.charset.StandardCharsets;
import org.slf4j.LoggerFactory;
public final class GunbedVisualClient implements ClientModInitializer {
    public static final org.slf4j.Logger LOG=LoggerFactory.getLogger("GunbedVisuals");
    private int tick=0;
    private int exerciseTick=0;
    private boolean previousAim=false;
    private boolean rightWasDown=false;
    private int zoomStage=0;
    private int lastSlot=-1;
    private int savedRenderDistance=-1;
    private void restoreDistance(net.minecraft.client.Minecraft client){if(savedRenderDistance>=0){client.options.renderDistance().set(savedRenderDistance);savedRenderDistance=-1;}}
    private int previousZoom=-1;
    private String lastWeapon="";
    private long exercisedLife=-1;
    private int loadoutExerciseTick,loadoutExercises;
    public record Wire(byte[] bytes) implements CustomPacketPayload {
        public static final Type<Wire> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("gunbed","visuals"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Wire> CODEC=StreamCodec.of(
            (buffer,packet)->buffer.writeBytes(packet.bytes), buffer->{
                if(buffer.readableBytes()>30000)throw new IllegalArgumentException("Oversized visual payload");
                byte[] bytes=new byte[buffer.readableBytes()];buffer.readBytes(bytes);return new Wire(bytes);
            });
        @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
    }
    @Override public void onInitializeClient() {
        GunbedHud.register();
        var reloadKey=net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(new net.minecraft.client.KeyMapping("key.gunbed.reload",com.mojang.blaze3d.platform.InputConstants.Type.KEYSYM,org.lwjgl.glfw.GLFW.GLFW_KEY_R,net.minecraft.client.KeyMapping.Category.GAMEPLAY));
        PayloadTypeRegistry.playS2C().register(Wire.TYPE,Wire.CODEC);
        PayloadTypeRegistry.playC2S().register(Wire.TYPE,Wire.CODEC);
        ClientPlayNetworking.registerGlobalReceiver(Wire.TYPE,(payload,context)->context.client().execute(()->{
            try {
                String json=new String(payload.bytes,StandardCharsets.UTF_8);
                if(dataWeaponChanged(json)){zoomStage=0;rightWasDown=false;}
                VisualState.INSTANCE.packet(json);
                HudState.INSTANCE.packet(json);
                var data=com.google.gson.JsonParser.parseString(json).getAsJsonObject();
                if(data.has("packId")&&data.has("packUrl"))PackOwnership.confirm(data.get("packId").getAsString(),data.get("packUrl").getAsString());
                var player=context.client().player;
                if(data.has("event")&&data.get("event").getAsString().equals("openSite")&&HudState.INSTANCE.active()){String url=data.get("url").getAsString();if(url.startsWith("https://churigame1234-ux.github.io/gunbed-installer/stats/"))net.minecraft.client.gui.screens.ConfirmLinkScreen.confirmLinkNow(net.minecraft.client.Minecraft.getInstance().screen,java.net.URI.create(url),false);}
                if(Boolean.getBoolean("gunbed.review")&&data.has("event")&&data.get("event").getAsString().equals("reviewInventory"))net.minecraft.client.KeyMapping.click(net.minecraft.client.Minecraft.getInstance().options.keyInventory.getDefaultKey());
                if(player!=null && data.has("recoilUp"))player.setXRot(net.minecraft.util.Mth.clamp(player.getXRot()-data.get("recoilUp").getAsFloat(),-90,90));
                if(player!=null && data.has("recoilSide"))player.setYRot(player.getYRot()+data.get("recoilSide").getAsFloat());
                if(Boolean.getBoolean("gunbed.exercise"))LOG.info("Display state {}",json);
            }
            catch(RuntimeException error){LOG.error("Invalid display state; keeping vanilla rendering",error);VisualState.INSTANCE.clear();}
        }));
        ClientPlayConnectionEvents.DISCONNECT.register((handler,client)->{VisualState.INSTANCE.clear();HudState.INSTANCE.clear();PackOwnership.clear();restoreDistance(client);});
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            if(client.player==null){restoreDistance(client);return;}
            int requested=HudState.INSTANCE.active()?HudState.INSTANCE.mapViewDistance:0;if(requested>0){if(savedRenderDistance<0)savedRenderDistance=client.options.renderDistance().get();if(client.options.renderDistance().get()<requested)client.options.renderDistance().set(requested);}else restoreDistance(client);
            var expiredPack=PackOwnership.tick();if(expiredPack!=null){client.getDownloadedPackSource().popPack(expiredPack);LOG.info("Released Gunbed pack after backend transition: {} (HUD active={})",expiredPack,HudState.INSTANCE.active());if(Boolean.getBoolean("gunbed.switchTest"))switchReturnAt=tick+80;}
            if(switchReturnAt>0&&tick>=switchReturnAt){switchReturnAt=0;client.player.connection.sendCommand("server gunbed");LOG.info("Requested return to Gunbed after backend transition test");}
            if(Boolean.getBoolean("gunbed.exerciseLoadout")&&client.screen==null&&HudState.INSTANCE.loadoutPending&&exercisedLife!=HudState.INSTANCE.loadoutLife){if(++loadoutExerciseTick>=20){int choice=HudState.INSTANCE.loadoutPrevious&&Boolean.getBoolean("gunbed.exerciseRepeat")?4:(loadoutExercises++%3)+1;net.minecraft.client.KeyMapping.click(client.options.keyHotbarSlots[choice-1].getDefaultKey());exercisedLife=HudState.INSTANCE.loadoutLife;loadoutExerciseTick=0;LOG.info("Exercised physical loadout key {} life {}",choice,exercisedLife);}}
            boolean active=GunbedRender.controlled(client.player);
            if(GunbedRender.active(client.player))for(String sound:VisualState.INSTANCE.sounds())client.getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(net.minecraft.sounds.SoundEvent.createVariableRangeEvent(ResourceLocation.parse(sound)),1.0f));
            boolean down=client.screen==null && active && client.options.keyUse.isDown();
            if(!active||lastSlot!=client.player.getInventory().getSelectedSlot()){zoomStage=0;rightWasDown=false;}lastSlot=client.player.getInventory().getSelectedSlot();
            if(down&&!rightWasDown&&VisualState.INSTANCE.canAim())zoomStage=(zoomStage+1)%3;rightWasDown=down;
            boolean aiming=VisualState.INSTANCE.canAim()?zoomStage>0:down;
            boolean firing=client.screen==null && !HudState.INSTANCE.loadoutPending && active && client.options.keyAttack.isDown();
            if((aiming!=previousAim || firing!=previousFire || zoomStage!=previousZoom || tick%(firing?1:4)==0&&active) && ClientPlayNetworking.canSend(Wire.TYPE)) {
                input(firing,aiming,zoomStage,down);previousAim=aiming;previousFire=firing;previousRight=down;previousZoom=zoomStage;
            }
            while(reloadKey.consumeClick())if(client.screen==null && active){zoomStage=0;requestReload(client);}
            if(Boolean.getBoolean("gunbed.exercise") && active) {
                exerciseTick++;
                if(exerciseTick==30){client.options.keyAttack.setDown(true);net.minecraft.client.KeyMapping.click(client.options.keyAttack.getDefaultKey());}
                if(exerciseTick==38)client.options.keyAttack.setDown(false);
                if(exerciseTick==60)net.minecraft.client.KeyMapping.click(reloadKey.getDefaultKey());
                if(exerciseTick==120){client.options.keyUse.setDown(true);net.minecraft.client.KeyMapping.click(client.options.keyUse.getDefaultKey());}
                if(exerciseTick==135)client.options.keyUse.setDown(false);
                if(exerciseTick==150){client.options.keyUse.setDown(true);net.minecraft.client.KeyMapping.click(client.options.keyUse.getDefaultKey());}
                if(exerciseTick==165)client.options.keyUse.setDown(false);
                if(exerciseTick==180){client.options.keyUse.setDown(true);net.minecraft.client.KeyMapping.click(client.options.keyUse.getDefaultKey());}
                if(exerciseTick==195)client.options.keyUse.setDown(false);
            }
            if(++tick%40==0&&ClientPlayNetworking.canSend(Wire.TYPE)) {
                String hello="{\"v\":1,\"event\":\"hello\",\"mc\":\"1.21.10\",\"client\":\"0.3.13\"}";
                ClientPlayNetworking.send(new Wire(hello.getBytes(StandardCharsets.UTF_8)));
            }
            if(Boolean.getBoolean("gunbed.capture") && tick>=40 && tick<=1800 && tick%(Boolean.getBoolean("gunbed.captureFast")?2:20)==0) {
                net.minecraft.client.Screenshot.grab(client.gameDirectory,"gunbed-"+tick+".png",client.getMainRenderTarget(),1,message->{});
            }
        });
        LOG.info("Gunbed display-only client 1.21.10 ready; no modded item/entity registries");
    }
    private boolean dataWeaponChanged(String json){var data=com.google.gson.JsonParser.parseString(json).getAsJsonObject();if(!data.has("weapon"))return false;String next=data.get("weapon").getAsString();if(next.equals(lastWeapon))return false;lastWeapon=next;return true;}
    private static void requestReload(net.minecraft.client.Minecraft client) {
        if(ClientPlayNetworking.canSend(Wire.TYPE))ClientPlayNetworking.send(new Wire("{\"v\":1,\"event\":\"reload_request\"}".getBytes(StandardCharsets.UTF_8)));
    }
    private boolean previousFire=false;
    private boolean previousRight=false;
    private int switchReturnAt;
    public static void chooseLoadout(int choice){var state=HudState.INSTANCE;if(!state.loadoutPending||choice<1||choice>(state.loadoutPrevious?4:3)||!ClientPlayNetworking.canSend(Wire.TYPE))return;ClientPlayNetworking.send(new Wire(("{\"v\":1,\"event\":\"loadout_choice\",\"choice\":"+choice+",\"life\":"+state.loadoutLife+"}").getBytes(StandardCharsets.UTF_8)));state.loadoutPending=false;}

    private static void input(boolean fire,boolean aim,int zoomStage,boolean right){ClientPlayNetworking.send(new Wire(("{\"v\":1,\"event\":\"input\",\"fire\":"+fire+",\"aim\":"+aim+",\"right\":"+right+",\"zoomStage\":"+zoomStage+"}").getBytes(StandardCharsets.UTF_8)));}
}
