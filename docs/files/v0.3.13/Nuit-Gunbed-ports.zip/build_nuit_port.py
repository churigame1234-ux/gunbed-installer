"""Compile the MIT upstream sky renderer for the two intermediate Minecraft APIs."""
import json,shutil,subprocess,sys
from server_audit import ROOT,dump,sha256

version=sys.argv[1];assert version in ('1.21.9','1.21.10')
source=ROOT/'.local/vendor/Nuit-1.21.8';target=ROOT/'.local/ports'/('Nuit-'+version)
target.mkdir(parents=True,exist_ok=True)
for module in ('common','fabric'):
    for folder in ('java','resources'):
        shutil.copytree(source/module/'src/main'/folder,target/'src/main'/folder,dirs_exist_ok=True)
config=target/'src/main/java/me/flashyreese/mods/nuit/config/NuitConfig.java'
config.write_text(config.read_text(encoding='utf-8').replace('"category.nuit"','KeyMapping.Category.GAMEPLAY'),encoding='utf-8')
java=target/'src/main/java/me/flashyreese/mods/nuit'
for relative in ('fabric/NuitClientFabric.java','resource/SkyboxResourceListener.java'):
    path=java/relative;text=path.read_text(encoding='utf-8')
    text=text.replace('PreparationBarrier preparationBarrier, ResourceManager resourceManager, Executor executor, Executor executor2','SharedState sharedState, Executor executor, PreparationBarrier preparationBarrier, Executor executor2')
    text=text.replace('reload(preparationBarrier, resourceManager, executor, executor2)','reload(sharedState, executor, preparationBarrier, executor2)').replace('this.readFiles(resourceManager), executor2','this.readFiles(sharedState.resourceManager()), executor2')
    path.write_text(text,encoding='utf-8')
path=java/'skybox/vanilla/EndSkybox.java';path.write_text(path.read_text(encoding='utf-8').replace('SkyRenderer.END_SKY_LOCATION','net.minecraft.resources.ResourceLocation.withDefaultNamespace("textures/environment/end_sky.png")'),encoding='utf-8')
path=java/'skybox/decorations/DecorationBox.java';path.write_text(path.read_text(encoding='utf-8').replace('RenderType.celestial(', 'me.flashyreese.mods.nuit.util.GunbedCelestial.type('),encoding='utf-8')
path=java/'mixin/MixinLevelRenderer.java';text=path.read_text(encoding='utf-8').replace('Camera camera, float tickDelta, GpuBufferSlice fogParameters','Camera camera, GpuBufferSlice fogParameters').replace('this.nuit$tickDelta = tickDelta;','this.nuit$tickDelta = Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(false);').replace('{"method_62215", "lambda$addSkyPass$13"}','"method_62215"');path.write_text(text,encoding='utf-8')
(java/'util/GunbedCelestial.java').write_text('''package me.flashyreese.mods.nuit.util;
import net.minecraft.client.renderer.*;
import net.minecraft.resources.ResourceLocation;
import java.util.*;
/** Compatibility for the celestial RenderType removed in Minecraft 1.21.9. */
public final class GunbedCelestial {
 private static final Map<ResourceLocation,RenderType> TYPES=new HashMap<>();
 public static RenderType type(ResourceLocation texture){return TYPES.computeIfAbsent(texture,t->RenderType.create("nuit_celestial",1536,RenderPipelines.CELESTIAL,RenderType.CompositeState.builder().setTextureState(new RenderStateShard.TextureStateShard(t,false)).createCompositeState(false)));}
}
''',encoding='utf-8')
metadata=target/'src/main/resources/fabric.mod.json';data=json.loads(metadata.read_text(encoding='utf-8'));data['version']='1.0.0-beta.1+gunbed.'+version;data['name']='Nuit (Gunbed compatibility build)';data['depends']['minecraft']=version;data['depends']['fabricloader']='>=0.19.5';metadata.write_text(json.dumps(data,indent=2),encoding='utf-8')
fabric=(ROOT/'client/.generated'/version/'fabric-version.txt').read_text().strip()
(target/'settings.gradle').write_text("pluginManagement { repositories { maven { url='https://maven.fabricmc.net/' }; gradlePluginPortal() } }\nrootProject.name='nuit-port'\n",encoding='utf-8')
(target/'build.gradle').write_text('''plugins { id 'net.fabricmc.fabric-loom-remap' version '1.17.21' }
repositories { mavenCentral(); maven { url='https://maven.fabricmc.net/' } }
version='1.0.0-beta.1+gunbed.MC'
base { archivesName='nuit-fabric-MC' }
java { toolchain { languageVersion=JavaLanguageVersion.of(21) } }
dependencies { minecraft 'com.mojang:minecraft:MC'; mappings loom.officialMojangMappings(); modImplementation 'net.fabricmc:fabric-loader:0.19.5'; modImplementation 'net.fabricmc.fabric-api:fabric-api:FABRIC' }
loom { accessWidenerPath=file('src/main/resources/nuit.accesswidener') }
tasks.withType(JavaCompile).configureEach { options.encoding='UTF-8' }
tasks.jar { from('LICENSE') }
'''.replace('MC',version).replace('FABRIC',fabric),encoding='utf-8')
shutil.copy2(source/'LICENSE',target/'LICENSE')
subprocess.run([str(ROOT/'client/gradlew.bat'),'-p',str(target),'build','--console=plain'],check=True,cwd=ROOT)
jar=next(p for p in (target/'build/libs').glob('*.jar') if '-dev' not in p.name and '-sources' not in p.name)
dump(ROOT/'reports'/f'nuit-port-{version}.json',{'success':True,'jar':str(jar),'sha256':sha256(jar),'source':str(target),'upstream':'https://github.com/FlashyReese/nuit/tree/1.21.8/dev','upstream_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'license':'MIT','native_validation_pending':True})
print({'built':version,'jar':str(jar)},flush=True)
