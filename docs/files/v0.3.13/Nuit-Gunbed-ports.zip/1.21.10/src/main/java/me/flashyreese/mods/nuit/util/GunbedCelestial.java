package me.flashyreese.mods.nuit.util;
import net.minecraft.client.renderer.*;
import net.minecraft.resources.ResourceLocation;
import java.util.*;
/** Compatibility for the celestial RenderType removed in Minecraft 1.21.9. */
public final class GunbedCelestial {
 private static final Map<ResourceLocation,RenderType> TYPES=new HashMap<>();
 public static RenderType type(ResourceLocation texture){return TYPES.computeIfAbsent(texture,t->RenderType.create("nuit_celestial",1536,RenderPipelines.CELESTIAL,RenderType.CompositeState.builder().setTextureState(new RenderStateShard.TextureStateShard(t,false)).createCompositeState(false)));}
}
