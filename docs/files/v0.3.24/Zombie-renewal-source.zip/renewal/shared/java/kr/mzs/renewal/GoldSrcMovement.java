package kr.mzs.renewal;

/** Shared prediction math. Distances are blocks, velocity is blocks/tick; collision stays with Minecraft. */
public final class GoldSrcMovement {
    public static final double TICK_SECONDS=.05;
    public static final double UNITS_TO_BLOCKS=5.612/250;
    public static final double RUN_SPEED=250*UNITS_TO_BLOCKS*TICK_SECONDS;
    public static final double AIR_DIRECTION_CAP=30*UNITS_TO_BLOCKS*TICK_SECONDS;
    public static final double GRAVITY=800*UNITS_TO_BLOCKS*TICK_SECONDS*TICK_SECONDS;
    /** 2026-11-26: jump clears a 2-block wall (measured peak ~2.2 blocks) under CS gravity. */
    public static final double JUMP_HEIGHT=1.95;
    public static final double JUMP_SPEED=Math.sqrt(2*GRAVITY*JUMP_HEIGHT)+GRAVITY/2;
    /** Vanilla-like ground response (share of the old velocity kept per tick) and air steering (turn share per tick). */
    public static final double GROUND_KEEP=.45,AIR_STEER=.12;
    public static final double LADDER_SPEED=200*UNITS_TO_BLOCKS*TICK_SECONDS;
    public static final double LADDER_PUSH=270*UNITS_TO_BLOCKS*TICK_SECONDS;
    public record Velocity(double x,double y,double z) {
        public Velocity {if(!Double.isFinite(x)||!Double.isFinite(y)||!Double.isFinite(z))throw new IllegalArgumentException("Non-finite velocity");}
        public double horizontalSpeed(){return Math.hypot(x,z);}
    }
    public record Input(double forward,double side,boolean walk,boolean crouch,boolean jumpPressed) {
        public Input {if(!Double.isFinite(forward)||!Double.isFinite(side)||Math.abs(forward)>1||Math.abs(side)>1)throw new IllegalArgumentException("Invalid input");}
    }
    public record Ladder(double outwardX,double outwardZ) {
        public Ladder {if(!Double.isFinite(outwardX)||!Double.isFinite(outwardZ)||Math.abs(Math.hypot(outwardX,outwardZ)-1)>.001)throw new IllegalArgumentException("Ladder normal must be a horizontal unit vector");}
    }
    public record Step(Velocity movement,Velocity next,boolean jumped,boolean ladderJump){}
    private GoldSrcMovement(){}

    public static Step step(Velocity velocity,Input input,boolean grounded,Ladder ladder,
                            double yawDegrees,double pitchDegrees,double groundSpeedMultiplier) {
        if(!Double.isFinite(yawDegrees)||!Double.isFinite(pitchDegrees)||!Double.isFinite(groundSpeedMultiplier)
                ||groundSpeedMultiplier<=0)throw new IllegalArgumentException("Invalid movement parameters");
        double yaw=Math.toRadians(yawDegrees),pitch=Math.toRadians(pitchDegrees);
        double forwardX=-Math.sin(yaw),forwardZ=Math.cos(yaw),rightX=-Math.cos(yaw),rightZ=-Math.sin(yaw);
        if(ladder!=null){
            if(input.jumpPressed){Velocity push=new Velocity(ladder.outwardX*LADDER_PUSH,0,ladder.outwardZ*LADDER_PUSH);return new Step(push,push,false,true);}
            double speed=LADDER_SPEED*(input.crouch?1.0/3:1);
            double x=(forwardX*Math.cos(pitch)*input.forward+rightX*input.side)*speed;
            double y=-Math.sin(pitch)*input.forward*speed;
            double z=(forwardZ*Math.cos(pitch)*input.forward+rightZ*input.side)*speed;
            double into=x*ladder.outwardX+z*ladder.outwardZ;
            Velocity climb=new Velocity(x-ladder.outwardX*into,y-into,z-ladder.outwardZ*into);
            return new Step(climb,climb,false,false);
        }
        double x=velocity.x,z=velocity.z,y=velocity.y;
        boolean jumped=grounded&&input.jumpPressed;
        if(jumped){grounded=false;y=JUMP_SPEED;}
        double wishX=forwardX*input.forward+rightX*input.side,wishZ=forwardZ*input.forward+rightZ*input.side;
        double magnitude=Math.hypot(wishX,wishZ);
        if(magnitude>.00001){wishX/=magnitude;wishZ/=magnitude;}
        double wishSpeed=RUN_SPEED*groundSpeedMultiplier*(input.crouch?1.0/3:input.walk?.77:1);
        if(grounded){
            // Vanilla-like ground control: velocity follows the input within 2-3 ticks (and stops as fast).
            double targetX=magnitude>.00001?wishX*wishSpeed:0,targetZ=magnitude>.00001?wishZ*wishSpeed:0;
            x=x*GROUND_KEEP+targetX*(1-GROUND_KEEP);z=z*GROUND_KEEP+targetZ*(1-GROUND_KEEP);
            y=0;
        }else if(magnitude>.00001){
            // CS air acceleration: strafing while turning gains speed (30u cap per direction, no total cap).
            double directionCap=Math.min(AIR_DIRECTION_CAP,wishSpeed);
            double available=directionCap-(x*wishX+z*wishZ);
            if(available>0){double acceleration=Math.min(available,10*wishSpeed*TICK_SECONDS);x+=wishX*acceleration;z+=wishZ*acceleration;}
            // Vanilla-like steering: holding a direction also turns the current velocity toward it, keeping the speed.
            double speed=Math.hypot(x,z);
            if(speed>.00001){
                double dirX=x/speed*(1-AIR_STEER)+wishX*AIR_STEER,dirZ=z/speed*(1-AIR_STEER)+wishZ*AIR_STEER,len=Math.hypot(dirX,dirZ);
                if(len>.00001){x=dirX/len*speed;z=dirZ/len*speed;}
            }
        }
        if(!grounded)y-=GRAVITY/2;
        Velocity movement=new Velocity(x,y,z);
        Velocity next=new Velocity(x,grounded?0:y-GRAVITY/2,z);
        return new Step(movement,next,jumped,false);
    }
    /** Gunbed's extra jump adds horizontal impulse; it never replaces existing bhop momentum. */
    public static Velocity doubleJump(Velocity before,double yawDegrees){
        double yaw=Math.toRadians(yawDegrees);
        return new Velocity(before.x-Math.sin(yaw)*.65,.65,before.z+Math.cos(yaw)*.65);
    }
}
