package kr.mzs.gunbedvisual;
import com.google.gson.*;
import java.util.*;
public final class ZombieScene {
    public record Member(UUID id,int entityId,String name,String role,double x,double y,double z,float yaw,boolean respawning){}
    public static final Map<UUID,Member> members=new LinkedHashMap<>();
    public static boolean escape,spectator,clientReady;
    public static int remaining,kills,infections,round,total,stage;
    public static String phase="";
    public static long appearanceSeed;
    public static void clear(){members.clear();remaining=kills=infections=round=total=stage=0;phase="";}
    public static void packet(JsonObject data){
        String event=data.has("event")?data.get("event").getAsString():"";
        if(event.equals("zombieRoster")){
            members.clear();escape=data.get("mode").getAsString().equals("escape");spectator=data.get("spectator").getAsBoolean();
            for(JsonElement element:data.getAsJsonArray("players")){var p=element.getAsJsonObject();UUID id=UUID.fromString(p.get("uuid").getAsString());members.put(id,new Member(id,p.get("entityId").getAsInt(),p.get("name").getAsString(),p.get("role").getAsString(),p.get("x").getAsDouble(),p.get("y").getAsDouble(),p.get("z").getAsDouble(),p.get("yaw").getAsFloat(),p.get("respawning").getAsBoolean()));}
        }else if(event.equals("zombieStatus")){
            remaining=data.get("remaining").getAsInt();kills=data.get("kills").getAsInt();infections=data.get("infections").getAsInt();round=data.get("round").getAsInt();total=data.get("total").getAsInt();stage=data.get("stage").getAsInt();phase=data.get("phase").getAsString();if(data.has("appearanceSeed"))appearanceSeed=data.get("appearanceSeed").getAsLong();
        }else if(event.equals("hud")){clientReady=data.has("zombieClientReady")&&data.get("zombieClientReady").getAsBoolean();if(data.has("zombieMatch")&&!data.get("zombieMatch").getAsBoolean())clear();}
    }
    public static String clock(){return phase.equals("warmup")?"숙주 대기":escape?"좀비 탈출":String.format(Locale.ROOT,"%d:%02d",remaining/60,remaining%60);}
    public static boolean zombie(UUID id){var p=members.get(id);return p!=null&&(p.role.equals("zombie")||p.role.equals("host"));}
    public static boolean host(UUID id){var p=members.get(id);return p!=null&&p.role.equals("host");}
    public static boolean ally(UUID a,UUID b){return members.containsKey(a)&&members.containsKey(b)&&zombie(a)==zombie(b);}
}
