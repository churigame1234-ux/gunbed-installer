"""Zombie HUD and scene state. Generates only the copied combined client adapters."""
import json
from prepare_client_controls import CLIENT,VERSIONS

SCENE=r'''package kr.mzs.gunbedvisual;
import com.google.gson.*;
import java.util.*;
public final class ZombieScene {
    public record Member(UUID id,int entityId,String name,String role,double x,double y,double z,float yaw,boolean respawning){}
    public static final Map<UUID,Member> members=new LinkedHashMap<>();
    public static boolean escape,spectator,clientReady;
    public static int remaining,kills,infections,round,total,stage;
    public static String phase="";
    public static long appearanceSeed;
    public static void clear(){members.clear();remaining=kills=infections=round=total=stage=0;phase="";}
    public static void packet(JsonObject data){
        String event=data.has("event")?data.get("event").getAsString():"";
        if(event.equals("zombieRoster")){
            members.clear();escape=data.get("mode").getAsString().equals("escape");spectator=data.get("spectator").getAsBoolean();
            for(JsonElement element:data.getAsJsonArray("players")){var p=element.getAsJsonObject();UUID id=UUID.fromString(p.get("uuid").getAsString());members.put(id,new Member(id,p.get("entityId").getAsInt(),p.get("name").getAsString(),p.get("role").getAsString(),p.get("x").getAsDouble(),p.get("y").getAsDouble(),p.get("z").getAsDouble(),p.get("yaw").getAsFloat(),p.get("respawning").getAsBoolean()));}
        }else if(event.equals("zombieStatus")){
            remaining=data.get("remaining").getAsInt();kills=data.get("kills").getAsInt();infections=data.get("infections").getAsInt();round=data.get("round").getAsInt();total=data.get("total").getAsInt();stage=data.get("stage").getAsInt();phase=data.get("phase").getAsString();if(data.has("appearanceSeed"))appearanceSeed=data.get("appearanceSeed").getAsLong();
        }else if(event.equals("hud")){clientReady=data.has("zombieClientReady")&&data.get("zombieClientReady").getAsBoolean();if(data.has("zombieMatch")&&!data.get("zombieMatch").getAsBoolean())clear();}
    }
    public static String clock(){return phase.equals("warmup")?"숙주 대기":escape?"좀비 탈출":String.format(Locale.ROOT,"%d:%02d",remaining/60,remaining%60);}
    public static boolean zombie(UUID id){var p=members.get(id);return p!=null&&(p.role.equals("zombie")||p.role.equals("host"));}
    public static boolean host(UUID id){var p=members.get(id);return p!=null&&p.role.equals("host");}
    public static boolean ally(UUID a,UUID b){return members.containsKey(a)&&members.containsKey(b)&&zombie(a)==zombie(b);}
}
'''

for version in VERSIONS:
    package=CLIENT/'.generated'/version/'java/kr/mzs/gunbedvisual'
    (package/'ZombieScene.java').write_text(SCENE,encoding='utf-8')
    network=package/'GunbedVisualClient.java';s=network.read_text(encoding='utf-8')
    if 'ZombieScene.packet(data)' not in s:s=s.replace('ZombieMovement.packet(data);','ZombieMovement.packet(data);ZombieScene.packet(data);')
    s=s.replace('ZombieMovement.clear();','ZombieMovement.clear();ZombieScene.clear();') if 'ZombieScene.clear();' not in s else s
    network.write_text(s,encoding='utf-8')
    file=package/'GunbedHud.java';s=file.read_text(encoding='utf-8')
    if 'ZombieScene.clock()' in s:continue
    s=s.replace('if(state.tracking())','if(!ZombieControls.active()&&state.tracking())')
    s=s.replace('for(int i=0;i<4;i++){int x=8+i*54','if(!ZombieControls.active())for(int i=0;i<4;i++){int x=8+i*54')
    draw='text' if version.startswith('26.') else 'drawString'
    s=s.replace('        int y=9;',f'''        if(ZombieMovement.active()){{String line=ZombieScene.clock()+" · "+ZombieScene.round+"/"+ZombieScene.total+"라운드";g.{draw}(font,line,(w-font.width(line))/2,31,0xFFE3EDF5);g.{draw}(font,"처치 "+ZombieScene.kills+"  감염 "+ZombieScene.infections,9,h-34,0xFFA5E987);}}
        int y=9;''')
    s=s.replace('"무기 · 자원 · 이번 경기"','(ZombieControls.active()?"장비 · 이번 라운드":"무기 · 자원 · 이번 경기")')
    first=f'g.{draw}(font,"철 "+state.resources[0]'
    start=s.index(first);end=s.index('g.pose().popMatrix()',start) if 'g.pose().popMatrix()' in s[start:] else s.index('g.pose().popPose()',start)
    original=s[start:end]
    s=s[:start]+f'if(ZombieControls.active()){{g.{draw}(font,"처치 "+ZombieScene.kills+"   감염 "+ZombieScene.infections,0,row,0xFFA5E987);}}else{{'+original+'}'+s[end:]
    file.write_text(s,encoding='utf-8')
print('Prepared zombie round HUD without resource panels, tracking or BedWars statistics.')
