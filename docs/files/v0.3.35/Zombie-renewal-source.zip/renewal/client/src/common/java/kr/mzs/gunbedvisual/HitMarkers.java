package kr.mzs.gunbedvisual;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * 2026-11-27 (rev13): a zombie this player hit in the last 3 s gets four red corner brackets around it on screen
 * (instead of the red body tint). Only while it is in direct line of sight, so it never shows through walls.
 * Returns rectangles {x1, y1, x2, y2, argb} in GUI coordinates; the version adapter fills them.
 */
public final class HitMarkers {
    /** vertical FOV the world was last rendered with (recorded by the FOV mixin) */
    public static volatile float fov = 70f;

    private HitMarkers() {}

    public static List<int[]> rects(int width, int height) {
        List<int[]> out = new ArrayList<>();
        Minecraft client = Minecraft.getInstance();
        Player self = client.player;
        if (self == null || client.level == null) return out;
        HudState state = HudState.INSTANCE;
        if (!state.anyHitMarker()) return out;
        Vec3 eye = self.getEyePosition(1f);
        double yaw = Math.toRadians(self.getViewYRot(1f)), pitch = Math.toRadians(self.getViewXRot(1f));
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        // right = forward x up(0,1,0), up = right x forward
        double rx = -fz, ry = 0, rz = fx;
        double rl = Math.sqrt(rx * rx + rz * rz);
        if (rl < 1e-6) return out;
        rx /= rl; rz /= rl;
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
        double focal = (height / 2.0) / Math.tan(Math.toRadians(Math.max(1f, fov)) / 2.0);
        for (Player other : client.level.players()) {
            if (other == self || !state.hitTinted(other.getUUID()) || !self.hasLineOfSight(other)) continue;
            AABB box = other.getBoundingBox();
            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            boolean behind = false;
            for (int i = 0; i < 8; i++) {
                double px = ((i & 1) == 0 ? box.minX : box.maxX) - eye.x;
                double py = ((i & 2) == 0 ? box.minY : box.maxY) - eye.y;
                double pz = ((i & 4) == 0 ? box.minZ : box.maxZ) - eye.z;
                double z = px * fx + py * fy + pz * fz;
                if (z < 0.1) { behind = true; break; }
                double sx = width / 2.0 + (px * rx + py * ry + pz * rz) / z * focal;
                double sy = height / 2.0 - (px * ux + py * uy + pz * uz) / z * focal;
                minX = Math.min(minX, sx); maxX = Math.max(maxX, sx); minY = Math.min(minY, sy); maxY = Math.max(maxY, sy);
            }
            if (behind) continue;
            int pad = 3;
            int x1 = (int) Math.floor(minX) - pad, y1 = (int) Math.floor(minY) - pad;
            int x2 = (int) Math.ceil(maxX) + pad, y2 = (int) Math.ceil(maxY) + pad;
            if (x2 < 0 || y2 < 0 || x1 > width || y1 > height || x2 - x1 > width * 2) continue;
            int len = Math.max(4, (int) (Math.min(x2 - x1, y2 - y1) * 0.28));
            int t = Math.max(1, Math.min(2, (x2 - x1) / 18 + 1));
            int color = state.hitMarkerColor(other.getUUID());
            // top-left, top-right, bottom-left, bottom-right: one horizontal and one vertical bar each
            out.add(new int[]{x1, y1, x1 + len, y1 + t, color}); out.add(new int[]{x1, y1, x1 + t, y1 + len, color});
            out.add(new int[]{x2 - len, y1, x2, y1 + t, color}); out.add(new int[]{x2 - t, y1, x2, y1 + len, color});
            out.add(new int[]{x1, y2 - t, x1 + len, y2, color}); out.add(new int[]{x1, y2 - len, x1 + t, y2, color});
            out.add(new int[]{x2 - len, y2 - t, x2, y2, color}); out.add(new int[]{x2 - t, y2 - len, x2, y2, color});
        }
        return out;
    }
}
