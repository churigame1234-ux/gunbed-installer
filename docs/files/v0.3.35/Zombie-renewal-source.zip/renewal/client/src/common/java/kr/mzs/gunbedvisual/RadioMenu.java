package kr.mzs.gunbedvisual;

/**
 * 2026-11-27: CS 1.6 style radio menus. C (commands) / V (reports) open a 4-line list at the left middle of the
 * screen; while it is open the hotbar number keys pick a line instead of a slot. Pressing the same key again
 * closes it, the other key switches lists, and it closes by itself after 10 s or when a screen opens.
 */
public final class RadioMenu {
    public static boolean keysFixed;
    private static final String[][] LINES = {
            {"1. 알겠다.", "2. 가자!", "3. 엄호하라!", "4. 지원이 필요하다."},
            {"1. 구역 확보 완료.", "2. 적을 발견했다.", "3. 팀, 후퇴하라!", "4. 안된다"}};
    private static final String[] NONE = new String[0];
    private static String menu;
    private static long openedAt;

    private RadioMenu() {}

    public static void toggle(String which) {
        if (which.equals(menu)) { menu = null; return; }
        menu = which;
        openedAt = System.currentTimeMillis();
    }

    public static boolean open() {
        if (menu != null && System.currentTimeMillis() - openedAt > 10_000L) menu = null;
        return menu != null;
    }

    public static void close() { menu = null; }

    /** @return the packet to send, or null when no menu is open. Choosing closes the menu. */
    public static String choose(int slot) {
        if (!open() || slot < 1 || slot > 4) return null;
        String which = menu;
        menu = null;
        return "{\"v\":1,\"event\":\"radio\",\"menu\":\"" + which + "\",\"slot\":" + slot + "}";
    }

    public static String[] lines() { return open() ? LINES[menu.equals("v") ? 1 : 0] : NONE; }
}
