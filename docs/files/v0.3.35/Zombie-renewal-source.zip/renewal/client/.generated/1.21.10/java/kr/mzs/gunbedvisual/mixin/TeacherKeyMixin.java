package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.KeyboardHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(KeyboardHandler.class)
public abstract class TeacherKeyMixin {
 @Inject(method="keyPress",at=@At("TAIL"))private void teacher$key(CallbackInfo ci){kr.mzs.gunbedvisual.TeacherInput.poll();}
}
