package kr.mzs.gunbedvisual;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import kr.mzs.gunbedvisual.model.GunMesh;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import java.util.*;

/** Articulated forearms, palms and curled fingers using the infected skin, never a flat hand image. */
public final class ZombieHands {
    public static boolean active(AbstractClientPlayer player){return ZombieMovement.active()&&player==Minecraft.getInstance().player&&ZombieScene.zombie(player.getUUID())&&!player.getMainHandItem().isEmpty()&&(player.getInventory().getSelectedSlot()==0||player.getInventory().getSelectedSlot()==1);}
    public static GunMesh.Frame frame(AbstractClientPlayer player){
        var p=player;
        List<GunMesh.Vertex> skin=new ArrayList<>(),metal=new ArrayList<>();boolean bomb=player.getInventory().getSelectedSlot()==1;
        float seconds=ZombieVisuals.swingSeconds(p.getId());
        boolean secondary=ZombieVisuals.secondary(p.getId());
        for(int side:new int[]{-1,1}){
            float[] k=bomb?new float[7]:pose(side,secondary,seconds);float strike=k[6];
            // Wrist sits in the lower half of the view; the forearm runs from it toward the lower screen corner so it is
            // visible at idle too (CS view-model layout), everything at 3/4 size.
            Matrix4f root=new Matrix4f().translation(side*.33f+k[0],-.17f+k[1],-.78f+k[2])
                .rotateY(side*.42f+k[5]).rotateZ(side*.15f+k[3]).rotateX(.85f+k[4]).scale(.75f);
            // long enough to leave the bottom of the screen (the gun view-model pass draws this mesh scaled down)
            // UVs sample the arm's side/back faces of the skin (the old 32,48 / 40,16 cells are blank in a 64x64 skin,
            // which is why the forearm was invisible and only hands showed)
            box(skin,root,-.085f,-.07f,0,.17f,.14f,1.4f,side<0?32:40,side<0?52:20);
            Matrix4f elbow=new Matrix4f(root).translate(0,-.01f,1.36f).rotateX(.25f).rotateY(side*-.12f);
            box(skin,elbow,-.1f,-.085f,0,.2f,.17f,3.2f,side<0?44:52,side<0?52:20);
            Matrix4f hand=new Matrix4f(root).rotateX(-.8f);
            box(skin,hand,-.1f,-.05f,-.2f,.2f,.11f,.22f,side<0?36:44,side<0?52:20);
            for(int finger=0;finger<4;finger++){
                Matrix4f digit=new Matrix4f(hand).translate(-.075f+finger*.05f,.01f,-.19f).rotateY((finger-1.5f)*-.14f);
                box(skin,digit,-.021f,-.03f,-.12f,.042f,.06f,.13f,44,20);
                digit.translate(0,-.004f,-.11f).rotateX(.9f+.35f*strike);
                box(skin,digit,-.019f,-.026f,-.08f,.038f,.052f,.09f,44,20);
                digit.translate(0,0,-.075f).rotateX(.55f);
                box(skin,digit,-.012f,-.016f,-.055f,.024f,.032f,.06f,44,16);
            }
            Matrix4f thumb=new Matrix4f(hand).translate(-side*.095f,-.015f,-.13f).rotateY(side*.9f).rotateX(.7f);
            box(skin,thumb,-.03f,-.026f,-.12f,.06f,.06f,.13f,44,20);
        }
        if(bomb){Matrix4f root=new Matrix4f().translation(.24f,-.32f,-.86f).rotateZ(-.2f);
            box(skin,root,-.12f,-.12f,-.12f,.24f,.24f,.24f,8,8);
            box(metal,root,-.06f,.12f,-.05f,.12f,.07f,.1f,0,0);
            for(int i=0;i<8;i++){double angle=i*Math.PI/4;Matrix4f ring=new Matrix4f(root).translate(.04f+(float)Math.cos(angle)*.065f,.22f+(float)Math.sin(angle)*.065f,0);box(metal,ring,-.018f,-.018f,-.015f,.036f,.036f,.03f,0,0);}
        }
        var surfaces=new LinkedHashMap<String,List<GunMesh.Vertex>>();surfaces.put(ZombieVisuals.texture(p.getId()).toString(),skin);if(!metal.isEmpty())surfaces.put("minecraft:textures/block/iron_block.png",metal);
        return new GunMesh.Frame(skin,null,null,null,surfaces);
    }
    // 2026-11-26: keyframes traced from the CS zombie-hand reference video (v_knife_zombi slash / stab).
    // Each row: time(s), dx, dy, dz, rollZ, pitchX, yawY, finger curl (0..1). Offsets are added to the idle pose.
    private static final float[][] LEFT_SLASH={{0,0,0,0,0,0,0,0},{.18f,-.02f,.3f,-.05f,.3f,.7f,0,.2f},{.32f,.35f,.05f,-.15f,-.6f,-.4f,-.8f,1},{.45f,.85f,.25f,-.05f,-1f,-.1f,-1.3f,1},{.6f,.9f,.5f,.1f,-.9f,.3f,-1.4f,.4f},{.85f,0,0,0,0,0,0,0}};
    private static final float[][] RIGHT_STAB={{0,0,0,0,0,0,0,0},{.45f,.05f,.24f,0,-.4f,.75f,0,.3f},{.62f,-.4f,-.05f,-.25f,.7f,-.6f,.9f,1},{.8f,-.55f,-.25f,-.1f,.5f,-.3f,1.1f,.8f},{1.2f,0,0,0,0,0,0,0}};
    private static final float[][] LEFT_ASSIST={{0,0,0,0,0,0,0,0},{.45f,0,.05f,0,0,.2f,0,.2f},{.62f,.3f,-.05f,-.2f,-.3f,-.4f,-.7f,1},{.8f,.4f,-.2f,-.1f,-.2f,-.2f,-.8f,.7f},{1.2f,0,0,0,0,0,0,0}};
    private static float[] pose(int side,boolean secondary,float t){
        float[][] keys=secondary?(side>0?RIGHT_STAB:LEFT_ASSIST):(side<0?LEFT_SLASH:null);
        float[] out=new float[7];if(keys==null||t<=0||t>=keys[keys.length-1][0])return out;
        for(int i=1;i<keys.length;i++)if(t<=keys[i][0]){float span=keys[i][0]-keys[i-1][0],u=(t-keys[i-1][0])/span;u=u*u*(3-2*u);
            for(int j=0;j<7;j++)out[j]=keys[i-1][j+1]+(keys[i][j+1]-keys[i-1][j+1])*u;break;}
        return out;
    }
    private static void box(List<GunMesh.Vertex> out,Matrix4f matrix,float x,float y,float z,float w,float h,float d,int u,int v){
        float[][] corners={{x,y,z},{x+w,y,z},{x+w,y+h,z},{x,y+h,z},{x,y,z+d},{x+w,y,z+d},{x+w,y+h,z+d},{x,y+h,z+d}};
        int[][] faces={{0,3,2,1},{4,5,6,7},{0,1,5,4},{3,7,6,2},{0,4,7,3},{1,2,6,5}};float[][] normals={{0,0,-1},{0,0,1},{0,-1,0},{0,1,0},{-1,0,0},{1,0,0}};
        float size=4;for(int f=0;f<6;f++){Vector3f normal=matrix.transformDirection(new Vector3f(normals[f])).normalize();float[][] uv={{u,v},{u,v+size},{u+size,v+size},{u+size,v}};
            for(int i=0;i<4;i++){float[] p=corners[faces[f][i]];Vector3f point=matrix.transformPosition(new Vector3f(p));out.add(new GunMesh.Vertex(point.x,point.y,point.z,uv[i][0]/64,uv[i][1]/64,normal.x,normal.y,normal.z));}
        }
    }
}
