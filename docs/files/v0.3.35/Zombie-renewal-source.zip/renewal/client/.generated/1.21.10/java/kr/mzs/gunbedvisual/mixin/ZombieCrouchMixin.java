package kr.mzs.gunbedvisual.mixin;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(LivingEntity.class)
public abstract class ZombieCrouchMixin {
    @Inject(method="getDimensions",at=@At("RETURN"),cancellable=true)
    private void zombie$compact(Pose pose,CallbackInfoReturnable<EntityDimensions> cir){
        if((Object)this instanceof Player&&kr.mzs.gunbedvisual.ZombieMovement.active()&&pose==Pose.CROUCHING)
            cir.setReturnValue(EntityDimensions.scalable(.6f,1f).withEyeHeight(.85f));
    }
}
