package kr.mzs.gunbedvisual.mixin;
import kr.mzs.gunbedvisual.*;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.player.AbstractClientPlayer;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(PlayerRenderer.class)
public abstract class ZombieAvatarMixin {
    @Inject(method="getTextureLocation(Lnet/minecraft/client/renderer/entity/state/PlayerRenderState;)Lnet/minecraft/resources/ResourceLocation;",at=@At("HEAD"),cancellable=true)
    private void zombie$texture(PlayerRenderState state,CallbackInfoReturnable<ResourceLocation> ci){if(ZombieVisuals.infected(state.id))ci.setReturnValue(ZombieVisuals.texture(state.id));}
    @Inject(method="extractRenderState(Lnet/minecraft/client/player/AbstractClientPlayer;Lnet/minecraft/client/renderer/entity/state/PlayerRenderState;F)V",at=@At("TAIL"))
    private void zombie$state(AbstractClientPlayer entity,PlayerRenderState state,float partial,CallbackInfo ci){
        if(ZombieVisuals.infected(state.id)&&!ZombieVisuals.ownCorpse(state.id)){
            state.showHat=false;state.showJacket=false;state.showLeftPants=false;state.showRightPants=false;state.showLeftSleeve=false;state.showRightSleeve=false;state.showCape=false;
            state.parrotOnLeftShoulder=null;state.parrotOnRightShoulder=null;
        }
        if(ZombieVisuals.corpse(state.id)){state.deathTime=0;state.walkAnimationSpeed=0;state.pose=net.minecraft.world.entity.Pose.STANDING;state.xRot=0;state.yRot=0;state.isSpectator=false;}
        kr.mzs.gunbedvisual.ZombieNameplates.apply(entity,state,partial,state.id);
        if(ZombieVisuals.fade(state.id)){state.isInvisible=true;state.isInvisibleToPlayer=false;}
    }
    @Inject(method="setupRotations(Lnet/minecraft/client/renderer/entity/state/PlayerRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;FF)V",at=@At("TAIL"))
    private void zombie$fall(PlayerRenderState state,PoseStack pose,float bodyRot,float scale,CallbackInfo ci){
        if(!ZombieVisuals.corpse(state.id))return;
        float progress=ZombieVisuals.deathProgress(state.id);int fall=ZombieVisuals.deathPose(state.id);
        pose.translate(0,.08*progress,0);
        pose.mulPose((fall==1?Axis.ZP:Axis.XP).rotationDegrees((fall==2?-90:90)*progress));
    }
}
