package kr.mzs.gunbedvisual;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityAttachment;
public final class ZombieNameplates {
    /** Kept for the HUD hook; names are now drawn by the vanilla nametag renderer (see apply). */
    public static void render(GuiGraphicsExtractor graphics){for(int[] r:HitMarkers.rects(graphics.guiWidth(),graphics.guiHeight()))graphics.fill(r[0],r[1],r[2],r[3],r[4]);}
    public static void apply(Entity entity,EntityRenderState state,float partial,int id){
        if(!ZombieMovement.active())return;
        if(ZombieVisuals.corpse(id)){state.nameTag=null;return;}
        var client=Minecraft.getInstance();var p=client.player;var m=ZombieScene.members.get(entity.getUUID());
        boolean show=p!=null&&m!=null&&entity!=p&&!m.respawning()&&!client.options.hideGui
            &&(ZombieScene.spectator||ZombieScene.ally(p.getUUID(),m.id())&&p.distanceToSqr(entity)<=2500);
        if(!show){state.nameTag=null;return;}
        int color=switch(m.role()){case "host"->0xAA0000;case "zombie"->0xFF5555;default->0x5555FF;};
        state.nameTag=Component.literal(m.name()).withColor(color);
        if(state.nameTagAttachment==null)state.nameTagAttachment=entity.getAttachments().getNullable(EntityAttachment.NAME_TAG,0,entity.getYRot(partial));
    }
}
