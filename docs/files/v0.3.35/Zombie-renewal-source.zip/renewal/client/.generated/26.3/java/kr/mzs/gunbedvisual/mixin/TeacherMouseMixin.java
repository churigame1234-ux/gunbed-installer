package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MouseHandler.class)
public abstract class TeacherMouseMixin {
 @Inject(method="onMove",at=@At("HEAD"))private void teacher$move(long window,double x,double y,double dx,double dy,CallbackInfo ci){kr.mzs.gunbedvisual.TeacherInput.relativeMove(dx,dy);}
 @Inject(method="onButton",at=@At("TAIL"))private void teacher$button(CallbackInfo ci){kr.mzs.gunbedvisual.TeacherInput.poll();}
}
