package kr.mzs.gunbedvisual;
import com.google.gson.*;
import net.minecraft.client.Minecraft;
import com.mojang.blaze3d.platform.InputConstants;
import java.util.*;

/** Only runs when this backend authorizes this player as an in-match teacher. */
public final class TeacherInput {
    private static boolean enabled,positioned;private static long epoch,seq,start,lastFrame;private static double x,y;private static int physical=-1,buttons=-1,dropped;
    private static final ArrayList<double[]> events=new ArrayList<>();
    private static final int[] KEYS={InputConstants.KEY_W,InputConstants.KEY_S,InputConstants.KEY_A,InputConstants.KEY_D,InputConstants.KEY_SPACE,InputConstants.KEY_LSHIFT,InputConstants.KEY_LCONTROL,InputConstants.KEY_R,InputConstants.KEY_Q,InputConstants.KEY_G,InputConstants.KEY_F,InputConstants.KEY_1,InputConstants.KEY_2,InputConstants.KEY_3,InputConstants.KEY_4,InputConstants.KEY_5,InputConstants.KEY_6,InputConstants.KEY_7,InputConstants.KEY_8,InputConstants.KEY_9};
    private TeacherInput(){}
    public static void packet(JsonObject data){if(!data.has("event")||!data.get("event").getAsString().equals("hud"))return;boolean next=data.has("teacherRecording")&&data.get("teacherRecording").getAsBoolean();if(next!=enabled){clear();enabled=next;epoch=System.nanoTime();start=lastFrame=System.nanoTime();}}
    public static void clear(){enabled=false;positioned=false;events.clear();seq=0;physical=buttons=-1;lastFrame=start=0;}
    private static boolean recording(){var c=Minecraft.getInstance();return enabled&&c.player!=null&&c.gui.screen()==null&&c.mouseHandler.isMouseGrabbed()&&c.getWindow().isFocused();}
    private static void add(int type,double a,double b,double flags){if(!recording())return;if(events.size()>=128){dropped++;return;}events.add(new double[]{type,(System.nanoTime()-start)/1000.0,Math.rint(a*1000)/1000,Math.rint(b*1000)/1000,flags});}
    public static void relativeMove(double dx,double dy){add(0,dx,dy,0);poll();}
    public static void move(double nx,double ny){if(!recording()){positioned=false;return;}if(positioned){double dx=nx-x,dy=ny-y;if(Math.abs(dx)<1000&&Math.abs(dy)<1000&&(dx!=0||dy!=0))add(0,dx,dy,0);}x=nx;y=ny;positioned=true;poll();}
    public static void wheel(double horizontal,double vertical){add(2,horizontal,vertical,0);}
    public static void poll(){if(!recording())return;var c=Minecraft.getInstance();int raw=0;for(int i=0;i<KEYS.length;i++)if(InputConstants.isKeyDown(KEYS[i]))raw|=1<<i;
        int mouse=(c.mouseHandler.isLeftPressed()?1:0)|(c.mouseHandler.isRightPressed()?2:0)|(c.mouseHandler.isMiddlePressed()?4:0);
        int state=logical(c);if(raw!=physical){add(3,state,raw,0);physical=raw;}if(mouse!=buttons){add(1,mouse,state,0);buttons=mouse;}
    }
    private static int logical(Minecraft c){boolean[] down={c.options.keyUp.isDown(),c.options.keyDown.isDown(),c.options.keyLeft.isDown(),c.options.keyRight.isDown(),c.options.keyJump.isDown(),c.options.keySprint.isDown(),c.options.keyShift.isDown(),c.options.keyAttack.isDown(),c.options.keyUse.isDown(),InputConstants.isKeyDown(InputConstants.KEY_R),c.options.keySwapOffhand.isDown(),c.options.keyDrop.isDown()};int mask=0;for(int i=0;i<down.length;i++)if(down[i])mask|=1<<i;return mask;}
    public static void tick(Minecraft c){if(!recording()){positioned=false;events.clear();start=lastFrame=System.nanoTime();return;}poll();long now=System.nanoTime();JsonObject row=new JsonObject();row.addProperty("v",1);row.addProperty("event","teacherInput");row.addProperty("epoch",epoch);row.addProperty("seq",++seq);row.addProperty("clientTime",System.currentTimeMillis());row.addProperty("dtMs",(now-lastFrame)/1000000d);row.addProperty("yaw",c.player.getYRot());row.addProperty("pitch",c.player.getXRot());row.addProperty("ground",c.player.onGround());row.addProperty("buttons",logical(c));row.addProperty("physical",physical);row.addProperty("slot",c.player.getInventory().getSelectedSlot());row.addProperty("sensitivity",c.options.sensitivity().get());row.addProperty("dropped",dropped);
        JsonArray raw=new JsonArray();for(double[] e:events){JsonArray event=new JsonArray();for(double value:e)event.add(value);raw.add(event);}row.add("events",raw);events.clear();String json=row.toString();if(json.getBytes(java.nio.charset.StandardCharsets.UTF_8).length<=8192)GunbedVisualClient.sendJson(json);else dropped++;start=lastFrame=now;
    }
}
