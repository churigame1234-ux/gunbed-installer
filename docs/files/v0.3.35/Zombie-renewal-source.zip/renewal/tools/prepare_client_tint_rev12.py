"""2026-11-27 client rev 12: the attacker-only hit mark becomes a red tint (vanilla hurt overlay) instead of a red outline.

GunbedHitTintMixin (src/common) sets LivingEntityRenderState.hasRedOverlay for entities in HudState.hitTinted.
The yellow radio outline (timedGlow) is unchanged. Hello zombie:11. Run after prepare_client_radio_rev11.py. Idempotent.
"""
import json, re
from prepare_client_controls import CLIENT, VERSIONS

for version in VERSIONS:
    resources = CLIENT / '.generated' / version / 'resources'
    mixins = resources / 'gunbed.mixins.json'
    data = json.loads(mixins.read_text(encoding='utf-8'))
    if 'GunbedHitTintMixin' not in data['client']:
        data['client'].append('GunbedHitTintMixin')
        mixins.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    client = CLIENT / '.generated' / version / 'java/kr/mzs/gunbedvisual/GunbedVisualClient.java'
    text = client.read_text(encoding='utf-8')
    text = re.sub(r'\\"zombie\\":(?:[2-9]|10)(?=\D)', r'\\"zombie\\":11', text)
    assert '\\"zombie\\":11' in text, version
    client.write_text(text, encoding='utf-8')
    print('rev12 hit tint', version)