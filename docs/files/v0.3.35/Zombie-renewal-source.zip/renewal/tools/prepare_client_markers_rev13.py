"""2026-11-27 client rev 13: red corner brackets (HitMarkers) around a zombie this player hit, instead of the body tint.

ZombieNameplates.render (called first by GunbedHud.render every frame) fills HitMarkers.rects; the FOV mixin records the
world FOV for the projection. Run after prepare_client_tint_rev12.py. Idempotent.
"""
from prepare_client_controls import CLIENT, VERSIONS

for version in VERSIONS:
    package = CLIENT / '.generated' / version / 'java/kr/mzs/gunbedvisual'
    plates = package / 'ZombieNameplates.java'
    text = plates.read_text(encoding='utf-8')
    for graphics in ('GuiGraphics', 'GuiGraphicsExtractor'):
        old = f'public static void render({graphics} graphics){{}}'
        new = (f'public static void render({graphics} graphics){{for(int[] r:HitMarkers.rects(graphics.guiWidth(),graphics.guiHeight()))'
               'graphics.fill(r[0],r[1],r[2],r[3],r[4]);}')
        text = text.replace(old, new)
    assert 'HitMarkers.rects' in text, version
    plates.write_text(text, encoding='utf-8')

    fov = package / 'mixin/GunbedFovMixin.java'
    text = fov.read_text(encoding='utf-8')
    if 'HitMarkers.fov' not in text:
        old = 'ci.setReturnValue(kr.mzs.gunbedvisual.VisualState.INSTANCE.zoomFov(ci.getReturnValue()));}'
        assert old in text, version
        record = 'if(useFov)kr.mzs.gunbedvisual.HitMarkers.fov=ci.getReturnValue();' if 'boolean useFov' in text else 'kr.mzs.gunbedvisual.HitMarkers.fov=ci.getReturnValue();'
        text = text.replace(old, 'ci.setReturnValue(kr.mzs.gunbedvisual.VisualState.INSTANCE.zoomFov(ci.getReturnValue()));' + record + '}')
    fov.write_text(text, encoding='utf-8')
    hud = package / 'GunbedHud.java'
    text = hud.read_text(encoding='utf-8')
    for call in ('original.render(graphics,delta)', 'original.extractRenderState(graphics,delta)'):
        text = text.replace('{if(!HudState.INSTANCE.active())' + call + ';}',
                            '{if(!HudState.INSTANCE.active()||id==VanillaHudElements.OVERLAY_MESSAGE&&HudState.INSTANCE.zombieServer)' + call + ';}')
    assert 'OVERLAY_MESSAGE&&HudState.INSTANCE.zombieServer' in text, version
    hud.write_text(text, encoding='utf-8')
    print('rev13 hit markers', version)