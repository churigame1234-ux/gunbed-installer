"""2026-11-26 client rev 4 (nametags): vanilla in-world nametags instead of the flat screen overlay.

- Players in a zombie match get the normal Minecraft nametag (distance scaling, faint through walls),
  coloured by role; shown to allies within 50 blocks and to spectators, never for oneself.
- The client-side corpse (a RemotePlayer named "Zombie") never shows a nametag (was the white name on death).
Run after prepare_client_names.py. Idempotent.
"""
from prepare_client_controls import CLIENT, VERSIONS

SOURCE = r'''package kr.mzs.gunbedvisual;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GUI;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityAttachment;
public final class ZombieNameplates {
    /** Kept for the HUD hook; names are now drawn by the vanilla nametag renderer (see apply). */
    public static void render(GUI graphics){}
    public static void apply(Entity entity,EntityRenderState state,float partial,int id){
        if(!ZombieMovement.active())return;
        if(ZombieVisuals.corpse(id)){state.nameTag=null;return;}
        var client=Minecraft.getInstance();var p=client.player;var m=ZombieScene.members.get(entity.getUUID());
        boolean show=p!=null&&m!=null&&entity!=p&&!m.respawning()&&!client.options.hideGui
            &&(ZombieScene.spectator||ZombieScene.ally(p.getUUID(),m.id())&&p.distanceToSqr(entity)<=2500);
        if(!show){state.nameTag=null;return;}
        int color=switch(m.role()){case "host"->0xAA0000;case "zombie"->0xFF5555;default->0x5555FF;};
        state.nameTag=Component.literal(m.name()).withColor(color);
        if(state.nameTagAttachment==null)state.nameTagAttachment=entity.getAttachments().getNullable(EntityAttachment.NAME_TAG,0,entity.getYRot(partial));
    }
}
'''

for version in VERSIONS:
    package = CLIENT / '.generated' / version / 'java/kr/mzs/gunbedvisual'
    gui = 'GuiGraphicsExtractor' if version.startswith('26.') else 'GuiGraphics'
    source = SOURCE.replace('GUI', gui)
    if version in ('26.2', '26.3'): source = source.replace('&&!client.options.hideGui', '')
    (package / 'ZombieNameplates.java').write_text(source, encoding='utf-8')
    old_hook = 'kr.mzs.gunbedvisual.ZombieNameplates.apply(entity,state,partial);'
    m = package / 'mixin/ZombieAvatarMixin.java'; mt = m.read_text(encoding='utf-8')
    if old_hook in mt: m.write_text(mt.replace(old_hook, 'kr.mzs.gunbedvisual.ZombieNameplates.apply(entity,state,partial,state.id);'), encoding='utf-8')
    mixin = package / 'mixin/ZombieAvatarMixin.java'
    text = mixin.read_text(encoding='utf-8')
    hook = 'kr.mzs.gunbedvisual.ZombieNameplates.apply(entity,state,partial,state.id);'
    if hook not in text:
        anchor = '        if(ZombieVisuals.fade(state.id))'
        assert text.count(anchor) == 1, version
        text = text.replace(anchor, '        ' + hook + '\n' + anchor)
        mixin.write_text(text, encoding='utf-8')
    print('rev4', version)
