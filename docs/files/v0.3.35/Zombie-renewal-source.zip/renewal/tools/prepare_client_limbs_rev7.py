"""2026-11-26 client rev 7: Tissou zombie skins use the vanilla zombie layout (left arm/leg mirrored from the right),
so on the player model the left limbs rendered transparent. Build a fixed copy of each skin once, like Minecraft's
legacy-skin conversion, and use it for infected players and the first-person zombie hands. Idempotent."""
from prepare_client_controls import CLIENT, VERSIONS

METHOD = r'''
    // rev7: fill empty left-limb areas (player model) with mirrored copies of the right limbs (zombie model layout).
    private static final Map<ID,ID> fixedSkins=new HashMap<>();
    private static ID fixLimbs(ID source){
        ID done=fixedSkins.get(source);if(done!=null)return done;
        ID result=source;
        try(var in=Minecraft.getInstance().getResourceManager().open(source)){
            var image=com.mojang.blaze3d.platform.NativeImage.read(in);
            if(image.getWidth()==64&&image.getHeight()==64&&transparent(image,32,48,16,16)&&transparent(image,16,48,16,16)){
                int[][] copies={{4,16,16,32,4,4},{8,16,16,32,4,4},{0,20,24,32,4,12},{4,20,16,32,4,12},{8,20,8,32,4,12},{12,20,16,32,4,12},
                                {44,16,-8,32,4,4},{48,16,-8,32,4,4},{40,20,0,32,4,12},{44,20,-8,32,4,12},{48,20,-16,32,4,12},{52,20,-8,32,4,12}};
                for(int[] c:copies)for(int y=0;y<c[5];y++)for(int x=0;x<c[4];x++)image.setPixel(c[0]+c[2]+c[4]-1-x,c[1]+c[3]+y,image.getPixel(c[0]+x,c[1]+y));
                result=ID.fromNamespaceAndPath("mzs_tissou_fixed",source.getPath());
                final ID label=result;
                Minecraft.getInstance().getTextureManager().register(result,new net.minecraft.client.renderer.texture.DynamicTexture(()->label.toString(),image));
            }else image.close();
        }catch(Exception ignored){}
        fixedSkins.put(source,result);return result;
    }
    private static boolean transparent(com.mojang.blaze3d.platform.NativeImage image,int x0,int y0,int w,int h){
        for(int y=y0;y<y0+h;y++)for(int x=x0;x<x0+w;x++)if((image.getPixel(x,y)>>>24)!=0)return false;return true;
    }
'''
OLD_RETURN = 'return textures.get(Math.floorMod(source.hashCode()+(int)(ZombieScene.appearanceSeed^(ZombieScene.appearanceSeed>>>32)),textures.size()));'
NEW_RETURN = 'return fixLimbs(textures.get(Math.floorMod(source.hashCode()+(int)(ZombieScene.appearanceSeed^(ZombieScene.appearanceSeed>>>32)),textures.size())));'

for version in VERSIONS:
    visuals = CLIENT / '.generated' / version / 'java/kr/mzs/gunbedvisual/ZombieVisuals.java'
    text = visuals.read_text(encoding='utf-8')
    ident = 'ResourceLocation' if 'import net.minecraft.resources.ResourceLocation;' in text else 'Identifier'
    if 'fixLimbs(' not in text:
        assert text.count(OLD_RETURN) == 1, version
        text = text.replace(OLD_RETURN, NEW_RETURN)
        anchor = '    public static boolean ownCorpse(int id){'
        assert text.count(anchor) == 1, version
        text = text.replace(anchor, METHOD.replace('ID', ident) + anchor)
        visuals.write_text(text, encoding='utf-8')
    print('rev7', version, ident)
