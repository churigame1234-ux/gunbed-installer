"""2026-11-26 client rev 6 (zombie attack motion): ZombieVisuals.swingSeconds for the keyframed hands
in prepare_client_hands.py. Run prepare_client_hands.py after this. Idempotent."""
from prepare_client_controls import CLIENT, VERSIONS

ANCHOR = '    public static float swing(int id){'
ADD = '    public static float swingSeconds(int id){long at=swings.getOrDefault(id,0L);return at==0?99:(System.nanoTime()-at)/1e9f;}\n'
for version in VERSIONS:
    visuals = CLIENT / '.generated' / version / 'java/kr/mzs/gunbedvisual/ZombieVisuals.java'
    text = visuals.read_text(encoding='utf-8')
    if 'swingSeconds' not in text:
        assert text.count(ANCHOR) == 1, version
        text = text.replace(ANCHOR, ADD + ANCHOR)
        visuals.write_text(text, encoding='utf-8')
    print('rev6', version)
