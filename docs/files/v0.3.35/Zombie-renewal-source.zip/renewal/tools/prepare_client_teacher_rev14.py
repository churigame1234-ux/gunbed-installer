from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
VERSIONS=('1.21.8','1.21.9','1.21.10','1.21.11','26.1','26.1.1','26.1.2','26.2','26.3')
SOURCE=r'''package kr.mzs.gunbedvisual;
import com.google.gson.*;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import java.util.*;

/** Only runs when this backend authorizes this player as an in-match teacher. */
public final class TeacherInput {
    private static boolean enabled,positioned;private static long epoch,seq,start,lastFrame;private static double x,y;private static int physical=-1,buttons=-1,dropped;
    private static final ArrayList<double[]> events=new ArrayList<>();
    private static final int[] KEYS={GLFW.GLFW_KEY_W,GLFW.GLFW_KEY_S,GLFW.GLFW_KEY_A,GLFW.GLFW_KEY_D,GLFW.GLFW_KEY_SPACE,GLFW.GLFW_KEY_LEFT_SHIFT,GLFW.GLFW_KEY_LEFT_CONTROL,GLFW.GLFW_KEY_R,GLFW.GLFW_KEY_Q,GLFW.GLFW_KEY_G,GLFW.GLFW_KEY_F,GLFW.GLFW_KEY_1,GLFW.GLFW_KEY_2,GLFW.GLFW_KEY_3,GLFW.GLFW_KEY_4,GLFW.GLFW_KEY_5,GLFW.GLFW_KEY_6,GLFW.GLFW_KEY_7,GLFW.GLFW_KEY_8,GLFW.GLFW_KEY_9};
    private TeacherInput(){}
    public static void packet(JsonObject data){if(!data.has("event")||!data.get("event").getAsString().equals("hud"))return;boolean next=data.has("teacherRecording")&&data.get("teacherRecording").getAsBoolean();if(next!=enabled){clear();enabled=next;epoch=System.nanoTime();start=lastFrame=System.nanoTime();}}
    public static void clear(){enabled=false;positioned=false;events.clear();seq=0;physical=buttons=-1;lastFrame=start=0;}
    private static boolean recording(){var c=Minecraft.getInstance();return enabled&&c.player!=null&&SCREEN==null&&c.mouseHandler.isMouseGrabbed()&&GLFW.glfwGetWindowAttrib(c.getWindow().getWindow(),GLFW.GLFW_FOCUSED)==GLFW.GLFW_TRUE;}
    private static void add(int type,double a,double b,double flags){if(!recording())return;if(events.size()>=128){dropped++;return;}events.add(new double[]{type,(System.nanoTime()-start)/1000.0,Math.rint(a*1000)/1000,Math.rint(b*1000)/1000,flags});}
    public static void move(double nx,double ny){if(!recording()){positioned=false;return;}if(positioned){double dx=nx-x,dy=ny-y;if(Math.abs(dx)<1000&&Math.abs(dy)<1000&&(dx!=0||dy!=0))add(0,dx,dy,0);}x=nx;y=ny;positioned=true;poll();}
    public static void wheel(double horizontal,double vertical){add(2,horizontal,vertical,0);}
    public static void poll(){if(!recording())return;var c=Minecraft.getInstance();long window=c.getWindow().getWindow();int raw=0;for(int i=0;i<KEYS.length;i++)if(GLFW.glfwGetKey(window,KEYS[i])==GLFW.GLFW_PRESS)raw|=1<<i;
        int mouse=0;for(int i=0;i<3;i++)if(GLFW.glfwGetMouseButton(window,i)==GLFW.GLFW_PRESS)mouse|=1<<i;
        int state=logical(c);if(raw!=physical){add(3,state,raw,0);physical=raw;}if(mouse!=buttons){add(1,mouse,state,0);buttons=mouse;}
    }
    private static int logical(Minecraft c){boolean[] down={c.options.keyUp.isDown(),c.options.keyDown.isDown(),c.options.keyLeft.isDown(),c.options.keyRight.isDown(),c.options.keyJump.isDown(),c.options.keySprint.isDown(),c.options.keyShift.isDown(),c.options.keyAttack.isDown(),c.options.keyUse.isDown(),GLFW.glfwGetKey(c.getWindow().getWindow(),GLFW.GLFW_KEY_R)==GLFW.GLFW_PRESS,c.options.keySwapOffhand.isDown(),c.options.keyDrop.isDown()};int mask=0;for(int i=0;i<down.length;i++)if(down[i])mask|=1<<i;return mask;}
    public static void tick(Minecraft c){if(!recording()){positioned=false;events.clear();start=lastFrame=System.nanoTime();return;}poll();long now=System.nanoTime();JsonObject row=new JsonObject();row.addProperty("v",1);row.addProperty("event","teacherInput");row.addProperty("epoch",epoch);row.addProperty("seq",++seq);row.addProperty("clientTime",System.currentTimeMillis());row.addProperty("dtMs",(now-lastFrame)/1000000d);row.addProperty("yaw",c.player.getYRot());row.addProperty("pitch",c.player.getXRot());row.addProperty("ground",c.player.onGround());row.addProperty("buttons",logical(c));row.addProperty("physical",physical);row.addProperty("slot",c.player.getInventory().getSelectedSlot());row.addProperty("sensitivity",c.options.sensitivity().get());row.addProperty("dropped",dropped);
        JsonArray raw=new JsonArray();for(double[] e:events){JsonArray event=new JsonArray();for(double value:e)event.add(value);raw.add(event);}row.add("events",raw);events.clear();String json=row.toString();if(json.getBytes(java.nio.charset.StandardCharsets.UTF_8).length<=8192)GunbedVisualClient.sendJson(json);else dropped++;start=lastFrame=now;
    }
}
'''
MOUSE=r'''package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MouseHandler.class)
public abstract class TeacherMouseMixin {
 @Inject(method="onMove",at=@At("HEAD"))private void teacher$move(long window,double x,double y,CallbackInfo ci){kr.mzs.gunbedvisual.TeacherInput.move(x,y);}
 @Inject(method="onPress",at=@At("TAIL"))private void teacher$button(CallbackInfo ci){kr.mzs.gunbedvisual.TeacherInput.poll();}
}
'''
KEY=r'''package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.KeyboardHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(KeyboardHandler.class)
public abstract class TeacherKeyMixin {
 @Inject(method="keyPress",at=@At("TAIL"))private void teacher$key(CallbackInfo ci){kr.mzs.gunbedvisual.TeacherInput.poll();}
}
'''
for version in VERSIONS:
    base=ROOT/'client/.generated'/version;java=base/'java/kr/mzs/gunbedvisual'
    screen='c.gui.screen()' if version in ('26.2','26.3') else 'c.screen'
    source=SOURCE.replace('SCREEN',screen)
    source=source.replace('int mouse=0;for(int i=0;i<3;i++)if(GLFW.glfwGetMouseButton(window,i)==GLFW.GLFW_PRESS)mouse|=1<<i;','int mouse=(c.mouseHandler.isLeftPressed()?1:0)|(c.mouseHandler.isRightPressed()?2:0)|(c.mouseHandler.isMiddlePressed()?4:0);')
    if version!='1.21.8':source=source.replace('getWindow().getWindow()','getWindow().handle()')
    if version=='26.3':
        import re
        source=source.replace('import org.lwjgl.glfw.GLFW;','import com.mojang.blaze3d.platform.InputConstants;')
        source=source.replace('GLFW.glfwGetWindowAttrib(c.getWindow().handle(),GLFW.GLFW_FOCUSED)==GLFW.GLFW_TRUE','c.getWindow().isFocused()')
        source=source.replace('long window=c.getWindow().handle();','')
        source=source.replace('GLFW.glfwGetKey(window,KEYS[i])==GLFW.GLFW_PRESS','InputConstants.isKeyDown(KEYS[i])')
        source=source.replace('GLFW.glfwGetKey(c.getWindow().handle(),GLFW.GLFW_KEY_R)==GLFW.GLFW_PRESS','InputConstants.isKeyDown(InputConstants.KEY_R)')
        source=source.replace('GLFW.GLFW_KEY_LEFT_SHIFT','InputConstants.KEY_LSHIFT').replace('GLFW.GLFW_KEY_LEFT_CONTROL','InputConstants.KEY_LCONTROL')
        source=re.sub(r'GLFW\.GLFW_KEY_([A-Z0-9]+)',r'InputConstants.KEY_\1',source)
        source=source.replace('    public static void move(double nx,double ny)', '    public static void relativeMove(double dx,double dy){add(0,dx,dy,0);poll();}\n    public static void move(double nx,double ny)')
    (java/'TeacherInput.java').write_text(source,encoding='utf-8')
    mouse=MOUSE if version=='1.21.8' else MOUSE.replace('method="onPress"','method="onButton"')
    if version=='26.3':mouse=mouse.replace('long window,double x,double y,CallbackInfo ci){kr.mzs.gunbedvisual.TeacherInput.move(x,y);}','long window,double x,double y,double dx,double dy,CallbackInfo ci){kr.mzs.gunbedvisual.TeacherInput.relativeMove(dx,dy);}')
    for name,source in [('TeacherMouseMixin',mouse),('TeacherKeyMixin',KEY)]: (java/'mixin'/f'{name}.java').write_text(source,encoding='utf-8')
    p=java/'mixin/ZombieWheelMixin.java';s=p.read_text(encoding='utf-8');needle='var client=Minecraft.getInstance();'
    if 'TeacherInput.wheel' not in s:s=s.replace(needle,'kr.mzs.gunbedvisual.TeacherInput.wheel(x,y);'+needle,1)
    p.write_text(s,encoding='utf-8')
    p=java/'GunbedVisualClient.java';s=p.read_text(encoding='utf-8')
    if 'TeacherInput.packet' not in s:s=s.replace('GunbedNeuralClient.packet(data);','GunbedNeuralClient.packet(data);TeacherInput.packet(data);',1)
    if 'TeacherInput.tick' not in s:s=s.replace('GunbedNeuralClient.tick(client);','GunbedNeuralClient.tick(client);TeacherInput.tick(client);',1)
    if 'TeacherInput.clear();' not in s:s=s.replace('ZombieControls.clear();ZombieMovement.clear();','TeacherInput.clear();ZombieControls.clear();ZombieMovement.clear();')
    if '\\"teacher\\"' not in s:s=s.replace('\\"zombie\\":11','\\"teacher\\":1,\\"zombie\\":11')
    p.write_text(s,encoding='utf-8')
    p=base/'resources/gunbed.mixins.json';data=json.loads(p.read_text(encoding='utf-8'))
    for name in ['TeacherMouseMixin','TeacherKeyMixin']:
        if name not in data['client']:data['client'].append(name)
    p.write_text(json.dumps(data,indent=2),encoding='utf-8')
print('prepared teacher input for',len(VERSIONS),'versions')
