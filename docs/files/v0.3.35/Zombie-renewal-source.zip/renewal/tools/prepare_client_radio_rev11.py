"""2026-11-27 client rev 11: CS-style radio (C / V menus + voices), team/radio glow colours, round timer colour,
vanilla hotbar save/load removed, hello zombie:10.

Voices: renewal/client/voice-src (user-made variants) -> assets/mzs_voice/sounds + sounds.json in every version.
Run after prepare_client_hitglow_rev10.py. Idempotent.
"""
import json
import re
import shutil
from prepare_client_controls import CLIENT, VERSIONS

VOICE = CLIENT / 'voice-src'
# sound key -> source files (several files = Minecraft picks one at random per playback)
SOUNDS = {
    'human': {
        'affirm': ['ct_affirm 알겠다_1.ogg', 'roger 알겠다_2.ogg'],
        'go': ['com_go 가자!.ogg'], 'coverme': ['ct_coverme 엄호하라!.ogg'], 'backup': ['ct_backup 지원이 필요하다..ogg'],
        'clear': ['clear 구역 확보 완료..ogg'], 'spotted': ['Enemy Spotted 적을 발견했다..ogg'],
        'fallback': ['fallback 팀, 후퇴하라!.ogg'], 'negative': ['negative 안된다.ogg'],
        'start1': ['letsgo locknload 게임시작할때 나오는음성.ogg'], 'start2': ['locknload 게임시작할때 나오는음성.ogg'],
        'start3': ['moveout 게임시작할때 나오는음성.ogg'], 'fire_in_the_hole': ['파이어인더홀 수류탄던지는음성.ogg'],
    },
    'zombie': {
        'affirm': ['ct_affirm 알겠다.ogg', 'roger 알겠다.ogg'],
        'go': ['com_go 가자!.ogg'], 'coverme': ['ct_coverme 엄호하라!.ogg'], 'backup': ['ct_backup 지원이 필요하다..ogg'],
        'clear': ['clear 구역 확보 완료..ogg'], 'spotted': ['Enemy Spotted 적을 발견했다..ogg'],
        'fallback': ['fallback 팀, 후퇴하라!.ogg'], 'negative': ['negative 안된다.ogg'],
    },
}
FOLDER = {'human': 'Human_Young', 'zombie': 'Zombie_Deep'}


def write_sounds(resources):
    root = resources / 'assets/mzs_voice'
    definitions = {}
    for side, table in SOUNDS.items():
        for key, files in table.items():
            names = []
            for i, name in enumerate(files):
                target = root / 'sounds' / side / f'{key}{i + 1 if len(files) > 1 else ""}.ogg'
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(VOICE / FOLDER[side] / name, target)
                names.append(f'mzs_voice:{side}/{target.stem}')
            definitions[f'{side}.{key}'] = {'sounds': names}
    (root / 'sounds.json').write_text(json.dumps(definitions, ensure_ascii=False, indent=1), encoding='utf-8')


def insert_after_line(text, marker, addition):
    start = text.index(marker)
    end = text.index('\n', start) + 1
    return text[:end] + addition + text[end:]


for version in VERSIONS:
    base = CLIENT / '.generated' / version
    package = base / 'java/kr/mzs/gunbedvisual'

    # 1. glow colour comes from the timed-glow map (red hit / yellow radio)
    mixin = package / 'mixin/GunbedVisibilityMixin.java'
    text = mixin.read_text(encoding='utf-8')
    text = text.replace('ci.setReturnValue(kr.mzs.gunbedvisual.HudState.HIT_GLOW_COLOR);return;',
                        'ci.setReturnValue(state.glow(((net.minecraft.world.entity.Entity)(Object)this).getUUID()));return;')
    assert 'HIT_GLOW_COLOR);return;' not in text, version
    mixin.write_text(text, encoding='utf-8')

    # 2. keys, tick handling, packet helper, handshake
    client = package / 'GunbedVisualClient.java'
    text = client.read_text(encoding='utf-8')
    reload_line = re.search(r'\n([ \t]*var reloadKey=[^\n]*)\n', text).group(1).strip()
    if 'radioCKey' not in text:
        c_line = reload_line.replace('var reloadKey=', 'var radioCKey=').replace('"key.gunbed.reload"', '"key.gunbed.radio_c"')
        c_line = re.sub(r'(GLFW_KEY_|InputConstants\.KEY_)R\b', r'\1C', c_line)
        v_line = c_line.replace('radioCKey', 'radioVKey').replace('radio_c', 'radio_v')
        v_line = re.sub(r'(GLFW_KEY_|InputConstants\.KEY_)C\b', r'\1V', v_line)
        assert c_line != reload_line and 'KEY_C' in c_line and 'KEY_V' in v_line, version
        text = insert_after_line(text, reload_line, '        ' + c_line + '\n        ' + v_line + '\n')
        loop = re.search(r'\n([ \t]*while\(reloadKey\.consumeClick\(\)\)if\((client[^&]*?==null) && active\)[^\n]*)\n', text)
        screen_null = loop.group(2).strip()
        tick = (
            '        // 2026-11-27 radio: C commands / V reports (zombie matches only); vanilla hotbar save/load is removed\n'
            f'        if(!({screen_null}))kr.mzs.gunbedvisual.RadioMenu.close();\n'
            f'        while(radioCKey.consumeClick())if({screen_null}&&ZombieMovement.active())kr.mzs.gunbedvisual.RadioMenu.toggle("c");\n'
            f'        while(radioVKey.consumeClick())if({screen_null}&&ZombieMovement.active())kr.mzs.gunbedvisual.RadioMenu.toggle("v");\n'
            '        if(!ZombieMovement.active())kr.mzs.gunbedvisual.RadioMenu.close();\n'
            '        if(!kr.mzs.gunbedvisual.RadioMenu.keysFixed){kr.mzs.gunbedvisual.RadioMenu.keysFixed=true;var radioOptions=client.options;boolean radioChanged=false;'
            'for(var vanilla:new net.minecraft.client.KeyMapping[]{radioOptions.keySaveHotbarActivator,radioOptions.keyLoadHotbarActivator})if(!vanilla.isUnbound()){vanilla.setKey(com.mojang.blaze3d.platform.InputConstants.UNKNOWN);radioChanged=true;}'
            'if(radioChanged){net.minecraft.client.KeyMapping.resetMapping();radioOptions.save();}}\n')
        text = insert_after_line(text, loop.group(1).strip(), tick)
    if 'public static void sendJson(' not in text:
        text = text.replace('    private static void input(boolean fire,',
                            '    public static void sendJson(String json){ClientPlayNetworking.send(new Wire(json.getBytes(StandardCharsets.UTF_8)));}\n'
                            '    private static void input(boolean fire,', 1)
    assert 'public static void sendJson(' in text, version
    text = re.sub(r'\\"zombie\\":[2-9](?=\D)', r'\\"zombie\\":10', text)
    assert '\\"zombie\\":10' in text, version
    client.write_text(text, encoding='utf-8')

    # 3. hotbar keys pick a radio line while a menu is open
    input_mixin = package / 'mixin/GunbedInputMixin.java'
    text = input_mixin.read_text(encoding='utf-8')
    if 'gunbed$radio' not in text:
        hook = ('    @Inject(method="handleKeybinds",at=@At("HEAD"))\n'
                '    private void gunbed$radio(CallbackInfo ci){var options=Minecraft.getInstance().options;'
                'while(options.keySaveHotbarActivator.consumeClick()){}while(options.keyLoadHotbarActivator.consumeClick()){}'
                'if(!kr.mzs.gunbedvisual.RadioMenu.open())return;'
                'for(int i=0;i<9;i++)while(options.keyHotbarSlots[i].consumeClick())if(i<4){String json=kr.mzs.gunbedvisual.RadioMenu.choose(i+1);'
                'if(json!=null)kr.mzs.gunbedvisual.GunbedVisualClient.sendJson(json);}}\n')
        text = text.replace('    @Inject(method="handleKeybinds",at=@At("HEAD"),cancellable=true)', hook + '    @Inject(method="handleKeybinds",at=@At("HEAD"),cancellable=true)', 1)
    assert 'gunbed$radio' in text, version
    input_mixin.write_text(text, encoding='utf-8')

    # 4. HUD: coloured round timer + radio menu (white text, black outline) at the left middle
    hud = package / 'GunbedHud.java'
    text = hud.read_text(encoding='utf-8')
    draw = 'g.drawString(' if 'g.drawString(font,line,w-8-font.width(line),h-14,0xFFE3EDF5);' in text else 'g.text('
    old = f'{draw}font,line,w-8-font.width(line),h-14,0xFFE3EDF5);'
    if old in text:
        new = ('{String time=ZombieScene.clock();int lx=w-8-font.width(line);'
               f'{draw}font,time,lx,h-14,ZombieScene.clockColor());{draw}font,line.substring(time.length()),lx+font.width(time),h-14,0xFFE3EDF5);}}')
        text = text.replace(old, new, 1)
        radio = ('if(ZombieMovement.active()){int ry=h/2-26;for(String radioLine:kr.mzs.gunbedvisual.RadioMenu.lines()){'
                 f'for(int[] o:new int[][]{{{{-1,0}},{{1,0}},{{0,-1}},{{0,1}}}}){draw}font,radioLine,9+o[0],ry+o[1],0xFF000000);'
                 f'{draw}font,radioLine,9,ry,0xFFFFFFFF);ry+=12;}}}}')
        marker = re.search(r'\n([ \t]*if\(ZombieMovement\.active\(\)\)\{String line=[^\n]*)\n', text).group(1).strip()
        text = insert_after_line(text, marker, '        ' + radio + '\n')
    assert 'ZombieScene.clockColor()' in text and 'RadioMenu.lines()' in text, version
    hud.write_text(text, encoding='utf-8')

    # 5. round length from the server -> timer colour (green > 2/3, orange > 1/3, red)
    scene = package / 'ZombieScene.java'
    text = scene.read_text(encoding='utf-8')
    if 'clockColor()' not in text:
        text = text.replace('public static int remaining,kills,infections,round,total,stage;',
                            'public static int remaining,kills,infections,round,total,stage,limit;', 1)
        text = text.replace('remaining=data.get("remaining").getAsInt();',
                            'remaining=data.get("remaining").getAsInt();limit=data.has("limit")?data.get("limit").getAsInt():0;', 1)
        text = text.replace('    public static String clock(){',
                            '    public static int clockColor(){if(phase.equals("warmup")||escape||limit<=0)return 0xFFE3EDF5;double left=remaining/(double)limit;'
                            'return left>2/3.0?0xFF55FF55:left>1/3.0?0xFFFFAA00:0xFFFF5555;}\n    public static String clock(){', 1)
    assert 'clockColor()' in text and ',limit;' in text, version
    scene.write_text(text, encoding='utf-8')

    # 6. key names and voices
    lang_dir = base / 'resources/assets/gunbed/lang'
    for lang, names in (('ko_kr', ('무전 (명령)', '무전 (보고)')), ('en_us', ('Radio (commands)', 'Radio (reports)'))):
        file = lang_dir / f'{lang}.json'
        data = json.loads(file.read_text(encoding='utf-8')) if file.exists() else {}
        data['key.gunbed.radio_c'], data['key.gunbed.radio_v'] = names
        file.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    write_sounds(base / 'resources')

    # 7. mixin glow source for future rev10 runs stays consistent
    print('rev11 radio', version)
