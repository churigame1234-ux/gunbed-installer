"""2026-11-26 client rev 5 (HUD): no armor icon on the zombie server (HP shifts left),
time/round moved from the top centre to the bottom-right corner. Run after rev3. Idempotent."""
from prepare_client_controls import CLIENT, VERSIONS

PAIRS = [
    ('g.fill(8,h-17,116,h-1,0x990C1118);', 'int ox=ZombieControls.active()?-34:0;g.fill(8,h-17,116+ox,h-1,0x990C1118);'),
    ('var armor=switch(state.armorTier)', 'if(!ZombieControls.active()){var armor=switch(state.armorTier)'),
    (',27,h-13,0xFF8EC5EE);', ',27,h-13,0xFF8EC5EE);}'),
    (',45,h-15,color);', ',45+ox,h-15,color);'),
    ('Math.max(82,49+font.width(', 'Math.max(82+ox,49+ox+font.width('),
    ('g.fill(43,h-4,110,h-2,0xFF27313B);g.fill(43,h-4,43+(int)(67*', 'g.fill(43+ox,h-4,110+ox,h-2,0xFF27313B);g.fill(43+ox,h-4,43+ox+(int)(67*'),
    ('(w-font.width(line))/2,31,0xFFE3EDF5)', 'w-8-font.width(line),h-14,0xFFE3EDF5)'),
]

for version in VERSIONS:
    hud = CLIENT / '.generated' / version / 'java/kr/mzs/gunbedvisual/GunbedHud.java'
    text = hud.read_text(encoding='utf-8')
    if 'int ox=ZombieControls.active()' not in text:
        for old, new in PAIRS:
            assert text.count(old) == 1, (version, old, text.count(old))
            text = text.replace(old, new)
        hud.write_text(text, encoding='utf-8')
    print('rev5', version)
