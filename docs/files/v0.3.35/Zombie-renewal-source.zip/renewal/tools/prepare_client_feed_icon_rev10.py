"""2026-11-27 client rev 10 (part): kill-feed infection icon = three bloody claw scratches (gunbed:feed_infection).

Writes the item definition, model and a generated 32x32 texture into every version's resources. Idempotent.
"""
import json
import math
from PIL import Image, ImageDraw
from prepare_client_controls import CLIENT, VERSIONS


def texture():
    size = 32
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # three parallel diagonal slashes, thick in the middle and tapering at both ends (claw marks)
    for i, offset in enumerate((-6, 0, 6)):
        x0, y0, x1, y1 = 9 + offset, 4, 22 + offset, 28
        steps = 40
        for s in range(steps + 1):
            t = s / steps
            x = x0 + (x1 - x0) * t
            y = y0 + (y1 - y0) * t
            w = 0.5 + 1.5 * math.sin(math.pi * t)
            d.ellipse((x - w - .7, y - w - .7, x + w + .7, y + w + .7), fill=(70, 0, 0, 255))
        for s in range(steps + 1):
            t = s / steps
            x = x0 + (x1 - x0) * t
            y = y0 + (y1 - y0) * t
            w = 0.2 + 1.1 * math.sin(math.pi * t)
            d.ellipse((x - w, y - w, x + w, y + w), fill=(205, 20, 20, 255))
        # a few drips under the middle of each scratch
        mx, my = x0 + (x1 - x0) * .55, y0 + (y1 - y0) * .55
        d.line((mx, my, mx, min(31, my + 3 + i)), fill=(150, 0, 0, 255), width=1)
    return img


for version in VERSIONS:
    assets = CLIENT / '.generated' / version / 'resources/assets/gunbed'
    (assets / 'items').mkdir(parents=True, exist_ok=True)
    (assets / 'models/item').mkdir(parents=True, exist_ok=True)
    (assets / 'textures/item').mkdir(parents=True, exist_ok=True)
    (assets / 'items/feed_infection.json').write_text(json.dumps(
        {'model': {'type': 'minecraft:model', 'model': 'gunbed:item/feed_infection'}}), encoding='utf-8')
    (assets / 'models/item/feed_infection.json').write_text(json.dumps(
        {'parent': 'minecraft:item/generated', 'textures': {'layer0': 'gunbed:item/feed_infection'}}), encoding='utf-8')
    texture().save(assets / 'textures/item/feed_infection.png')
    # the kill feed draws gunbed:textures/feed/<icon>.png (missing -> skeleton skull fallback), not the item model
    (assets / 'textures/feed').mkdir(parents=True, exist_ok=True)
    texture().save(assets / 'textures/feed/feed_infection.png')
    print('rev10 feed icon', version)
