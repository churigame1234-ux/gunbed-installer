"""2026-11-26 client rev 3: zombie HUD shows the real HP (humans keep the /100 Gunbed display); hello zombie:3.

Run after prepare_client_movement.py and prepare_client_dropkey_rev2.py. Idempotent.
"""
import re
from prepare_client_controls import CLIENT, VERSIONS

OLD_NUM = 'Integer.toString((int)Math.ceil(state.health/(state.maxHealth<1000?state.maxHealth/100:100)))'
NEW_NUM = 'ZombieMovement.hpText(state.health,state.maxHealth)'
OLD_LABEL = '"HP",82,h-15,'
NEW_LABEL = '"HP",Math.max(82,49+font.width(ZombieMovement.hpText(state.health,state.maxHealth))),h-15,'

for version in VERSIONS:
    package = CLIENT / '.generated' / version / 'java/kr/mzs/gunbedvisual'
    hud = package / 'GunbedHud.java'
    text = hud.read_text(encoding='utf-8')
    if NEW_NUM not in text:
        assert text.count(OLD_NUM) == 1, (version, text.count(OLD_NUM))
        assert text.count(OLD_LABEL) == 1, (version, text.count(OLD_LABEL))
        text = text.replace(OLD_NUM, NEW_NUM).replace(OLD_LABEL, NEW_LABEL)
        hud.write_text(text, encoding='utf-8')
    client = package / 'GunbedVisualClient.java'
    text = client.read_text(encoding='utf-8').replace('\\"zombie\\":2', '\\"zombie\\":5').replace('\\"zombie\\":3', '\\"zombie\\":5').replace('\\"zombie\\":4', '\\"zombie\\":5')
    assert re.search(r'\\"zombie\\":[5-9]', text), version
    client.write_text(text, encoding='utf-8')
    print('rev3', version)
