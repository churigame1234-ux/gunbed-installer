"""Compact crouch dimensions and continuous duck/stand-up bunnyhop, zombie match only."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
VERSIONS=('1.21.8','1.21.9','1.21.10','1.21.11','26.1','26.1.1','26.1.2','26.2','26.3')
MIXIN='''package kr.mzs.gunbedvisual.mixin;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(LivingEntity.class)
public abstract class ZombieCrouchMixin {
    @Inject(method="getDimensions",at=@At("RETURN"),cancellable=true)
    private void zombie$compact(Pose pose,CallbackInfoReturnable<EntityDimensions> cir){
        if((Object)this instanceof Player&&kr.mzs.gunbedvisual.ZombieMovement.active()&&pose==Pose.CROUCHING)
            cir.setReturnValue(EntityDimensions.scalable(.6f,1f).withEyeHeight(.85f));
    }
}
'''
def patch(s):
    if 'duckWindow' in s:
        return s.replace('if(result.jumped()||head)p.setOnGround(false);','if(result.jumped()||head)p.setOnGround(false);').replace('boolean crouch=p.input.keyPresses.shift();','boolean crouch=p.input.keyPresses.shift()||(p.getBbHeight()<1.1f&&!client.level.noCollision(p,p.getBoundingBox().expandTowards(0,.8,0)));')
    s=s.replace('private static int jumpBuffer;', 'private static long duckWindow;\n    private static int jumpBuffer;')
    s=s.replace('boolean jump=jumpBuffer>0&&ground;if(jumpBuffer>0)jumpBuffer--;if(jump)jumpBuffer=0;', 'boolean jump=false;')
    s=s.replace('boolean crouch=p.input.keyPresses.shift();', '''boolean crouch=p.input.keyPresses.shift();
        if(crouch)duckWindow=System.nanoTime()+150_000_000L;
        boolean duckHop=crouch||System.nanoTime()<duckWindow;
        if(crouch&&p.getPose()!=net.minecraft.world.entity.Pose.CROUCHING)p.setPose(net.minecraft.world.entity.Pose.CROUCHING);
        if(p.getPose()==net.minecraft.world.entity.Pose.CROUCHING&&Math.abs(p.getBbHeight()-1f)>.01)p.refreshDimensions();''')
    s=s.replace('double stun=Math.max', 'jump=jumpBuffer>0&&ground;if(jumpBuffer>0)jumpBuffer--;if(jump)jumpBuffer=0;\n        double stun=Math.max')
    s=s.replace('if(result.jumped()){if(stun>0){', 'if(result.jumped()){if(stun>0&&!duckHop){')
    s=s.replace('p.setDeltaMovement(move);p.move(MoverType.SELF,move);', 'if(result.jumped()||head)p.setOnGround(false);\n        p.setDeltaMovement(move);p.move(MoverType.SELF,move);')
    s=s.replace('if(head)p.setOnGround(true);', 'if(p.verticalCollision&&move.y>0)nextY=Math.min(0,nextY);\n        if(head)p.setOnGround(true);')
    s=s.replace('boolean crouch=p.input.keyPresses.shift();','boolean crouch=p.input.keyPresses.shift()||(p.getBbHeight()<1.1f&&!client.level.noCollision(p,p.getBoundingBox().expandTowards(0,.8,0)));')
    return s
def main():
    for version in VERSIONS:
        root=ROOT/'client/.generated'/version;package=root/'java/kr/mzs/gunbedvisual'
        p=package/'ZombieMovement.java';p.write_text(patch(p.read_text(encoding='utf-8')),encoding='utf-8')
        (package/'mixin/ZombieCrouchMixin.java').write_text(MIXIN,encoding='utf-8')
        p=package/'GunbedVisualClient.java';s=p.read_text(encoding='utf-8');s=s.replace(r'\"zombie\":11',r'\"zombie\":15');p.write_text(s,encoding='utf-8')
        p=root/'resources/gunbed.mixins.json';d=json.loads(p.read_text(encoding='utf-8'));d['client']=list(dict.fromkeys(d['client']+['ZombieCrouchMixin']));p.write_text(json.dumps(d,indent=2),encoding='utf-8')
    print('Prepared compact crouch and duck bunnyhop for nine adapters')
if __name__=='__main__':main()
