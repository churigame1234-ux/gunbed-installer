Gunbed Installer 0.3.14 / client mods 0.3.13
Unzip and run GunbedInstaller.exe, then select your Minecraft version.
Supported: 1.21.8, 1.21.9, 1.21.10, 1.21.11, 26.1, 26.1.1, 26.1.2, 26.2, 26.3
Other mods, settings and worlds are preserved.
https://churigame1234-ux.github.io/gunbed-installer/
