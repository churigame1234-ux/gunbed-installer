Gunbed Installer 0.3.16 / adapters 0.3.16 / shared assets 0.3.16
WAT guns, DeltaForce melees, 42Labs throwables, persistent spectator feed and tracker HUD.
Run installer, select version and your existing game folder. Other mods, settings and worlds are preserved.
57 firearms, 11 melee presets and 3 throwable presets added.
