package kr.mzs.gunbedvisual;

import com.google.gson.*;
import kr.mzs.gunbedvisual.model.GunMesh;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Display-only protocol. No client-supplied damage, ammunition or reload completion. */
public final class VisualState {
    public static final VisualState INSTANCE=new VisualState();
    private final Map<String,GunMesh> meshes=new HashMap<>();
    private String model="",weapon="",action="draw",engine="";
    private String material="",itemPrefix="";
    private long started=System.nanoTime(),durationMillis=850,lastPacket=0;
    private boolean aiming=false,nativeScope=false;
    private boolean controlled=false,allowAim=true;
    private float aim=0;
    private int zoomStage=0;
    private boolean optic=false;
    private long lastFrame=System.nanoTime();
    private int selectedSlot=-1;
    private boolean demo=false;
    private boolean firstFrame=true;
    private long flashUntil;
    private float flashAngle;
    private long modeStarted,modeDuration;
    private String modeAction="";
    private record Phase(String clip,long at,long duration){}
    private List<Phase> phases=List.of();
    private double lastSoundMillis=-1;
    private VisualState() {}
    public void packet(String json) {
        if(json.length()>30000)throw new IllegalArgumentException("Oversized gunbed visual packet");
        JsonObject data=JsonParser.parseString(json).getAsJsonObject();
        if(!data.has("v")||data.get("v").getAsInt()!=1) return;
        lastPacket=System.nanoTime();
        if(data.has("controlled"))controlled=data.get("controlled").getAsBoolean();
        else if(data.has("enabled"))controlled=data.get("enabled").getAsBoolean();
        if(data.has("enabled")&&!data.get("enabled").getAsBoolean()){model="";if(!controlled){clear();return;}}
        if(data.has("weapon") && !data.get("weapon").getAsString().equals(weapon)) {
            weapon=data.get("weapon").getAsString();if(!modeActive())trigger("draw",850);aiming=false;
        }
        if(data.has("model")) {
            String next=data.get("model").getAsString();
            if(!next.matches("[a-z0-9_]{1,64}"))throw new IllegalArgumentException("Invalid gun model");
            if(!next.equals(model)){model=next;if(!modeActive())trigger("draw",850);firstFrame=true;}
        }
        if(data.has("slot")) {
            int slot=data.get("slot").getAsInt();
            if(slot!=selectedSlot){trigger("draw",850);aiming=false;}
            selectedSlot=slot;
        }
        if(data.has("material"))material=data.get("material").getAsString();
        if(data.has("itemPrefix"))itemPrefix=data.get("itemPrefix").getAsString();
        if(data.has("aim"))aiming=data.get("aim").getAsBoolean();
        if(data.has("zoomStage"))zoomStage=data.get("zoomStage").getAsInt();
        if(data.has("optic"))optic=data.get("optic").getAsBoolean();
        if(data.has("canAim"))allowAim=data.get("canAim").getAsBoolean();else if(data.has("engine")&&data.get("engine").getAsString().equals("ta"))allowAim=true;
        if(data.has("engine"))engine=data.get("engine").getAsString();if(data.has("nativeScope"))nativeScope=data.get("nativeScope").getAsBoolean();
        if(data.has("event")) {
            String event=data.get("event").getAsString();
            if(event.equals("meleeSwing"))trigger("attack_left",data.get("durationMs").getAsLong());
            if(event.equals("throwAction")){trigger(data.get("phase").getAsString().equals("pin")?"pull_pin":"throw",data.get("durationMs").getAsLong());}
            if(event.equals("modeSwitch")){modeStarted=System.nanoTime();modeDuration=Math.max(100,Math.min(10000,data.get("durationMs").getAsLong()));modeAction=data.get("phase").getAsString();trigger(modeAction.equals("switch")?"mode_switch":modeAction,modeDuration);aiming=false;aim=0;zoomStage=0;}
            if(event.equals("reload")){trigger(data.has("empty")&&data.get("empty").getAsBoolean()?"reload_empty":"reload_tactical",Math.max(50,data.get("durationMs").getAsLong()));if(data.has("phases")){List<Phase> sequence=new ArrayList<>();for(JsonElement element:data.getAsJsonArray("phases")){JsonObject phase=element.getAsJsonObject();sequence.add(new Phase(phase.get("clip").getAsString(),phase.get("atMs").getAsLong(),Math.max(1,phase.get("durationMs").getAsLong())));}phases=sequence;}}
            if(event.equals("shot")){trigger("shoot",160);long bolt=data.has("boltMs")?data.get("boltMs").getAsLong():0;if(bolt>0){phases=List.of(new Phase("shoot",0,100),new Phase("bolt",100,bolt));durationMillis=100+bolt;}flashUntil=System.nanoTime()+70_000_000L;flashAngle=(float)(Math.random()*Math.PI*2);}
        }
    }
    public void demo(String id,int slot) {
        if(id==null||id.isBlank())return;
        if(!demo){demo=true;model=id;selectedSlot=slot;lastPacket=System.nanoTime();started=System.nanoTime();action="";firstFrame=true;}
        double cycle=(System.nanoTime()-lastPacket)/1e9 % 7;
        action=cycle<1?"draw":cycle<2?"":cycle<4.25?"reload_tactical":"";
        durationMillis=action.equals("reload_tactical")?2250:850;
        started=lastPacket+(long)((Math.floor((System.nanoTime()-lastPacket)/7e9)*7+(action.equals("reload_tactical")?2:0))*1e9);
    }
    private void trigger(String clip,long duration){var d=model.isEmpty()?null:definition(model);if(d!=null&&d.has("actions")&&d.getAsJsonObject("actions").has(clip))duration=d.getAsJsonObject("actions").get(clip).getAsLong();action=clip;durationMillis=duration;started=System.nanoTime();phases=List.of();lastSoundMillis=-1;}
    public void clear(){model="";weapon="";material="";itemPrefix="";controlled=false;allowAim=true;aiming=false;aim=0;zoomStage=0;optic=false;lastFrame=System.nanoTime();selectedSlot=-1;action="";demo=false;engine="";flashUntil=0;modeStarted=0;modeDuration=0;modeAction="";phases=List.of();lastSoundMillis=-1;}
    public boolean active(int slot) {
        if(!demo && (lastPacket==0 || System.nanoTime()-lastPacket>5_000_000_000L))clear();
        return !model.isEmpty()&&selectedSlot==slot;
    }
    public boolean matches(int slot,String material,String name) {
        return (controls(slot,material,name)||engine.equals("throwable")&&action.equals("throw")&&System.nanoTime()-started<durationMillis*1_000_000L&&selectedSlot==slot&&material.equals("minecraft:air"))&&!model.isEmpty();
    }
    public boolean controls(int slot,String material,String name) {active(slot);return (demo||controlled)&&selectedSlot==slot&&(demo||!this.material.isEmpty()&&this.material.equals(material)&&!itemPrefix.isEmpty()&&name.strip().startsWith(itemPrefix));}
    private JsonObject catalog;
    private JsonObject defaultOptics;
    private final Map<String,GunMesh> opticMeshes=new HashMap<>();
    private JsonObject defaultOptic(){if(defaultOptics==null)defaultOptics=read("assets/gunbed/default_optics.json");return defaultOptics.getAsJsonObject(model);}
    private final Map<String,JsonObject> definitions=new HashMap<>();
    private JsonObject definition(String id){if(catalog==null)catalog=read("assets/tacz/gunbed_catalog.json").getAsJsonObject("guns");return definitions.computeIfAbsent(id,key->ModeAssets.definition(catalog,key));}
    public String texture(){JsonObject d=definition(model);return d==null?"tacz:textures/gun/uv/"+model+".png":d.get("texture").getAsString();}
    private JsonObject flashDefinition(){JsonObject d=definition(model);return d==null?null:d.getAsJsonObject("display").getAsJsonObject("muzzle_flash");}
    public boolean flashActive(){return !engine.equals("ta")&&System.nanoTime()<flashUntil&&flashDefinition()!=null;}
    public String flashTexture(){String id=flashDefinition().get("texture").getAsString();String[] parts=id.split(":",2);return parts[0]+":textures/"+parts[1]+".png";}
    public GunMesh.Frame flashFrame(GunMesh.Frame gun){JsonObject d=flashDefinition();return GunMesh.flash(gun.muzzle(),d.has("scale")?d.get("scale").getAsFloat():1,flashAngle);}
    public boolean firstFrame(){boolean result=firstFrame;firstFrame=false;return result;}
    public String model(){return model;}
    public boolean optic(){return allowAim&&optic&&zoomStage>0&&aim>.8f;}
    public boolean canAim(){return controlled&&allowAim&&!model.isEmpty();}
    public float zoomFov(float original){if(!allowAim||!controlled||model.isEmpty()||aim<=0)return original;JsonObject preset=defaultOptic();double zoom=preset==null?optic?(zoomStage==2?8:4):(zoomStage==2?2.5:1.6):zoomStage==2?preset.get("zoom").getAsDouble():Math.max(1.25,preset.get("zoom").getAsDouble()*.6);double target=Math.toDegrees(2*Math.atan(Math.tan(Math.toRadians(original)/2)/zoom));return (float)(original+(target-original)*aim);}
    public GunMesh.Frame frame() {
        GunMesh mesh=meshes.computeIfAbsent(model,this::load);
        double elapsed=(System.nanoTime()-started)/1e6;
        Phase phase=phaseAt(elapsed);String clip=phase==null?null:resolvedClip(mesh,phase.clip);
        double clipTime=clip==null?0:(elapsed-phase.at)/phase.duration*mesh.duration(clip);
        long now=System.nanoTime();float step=Math.min(.25f,(now-lastFrame)/120_000_000f);lastFrame=now;aim+=Math.max(-step,Math.min(step,(aiming&&allowAim?1:0)-aim));
        boolean simpleDraw=model.equals("gunbed_trg21")&&"draw".equals(action)&&elapsed<durationMillis;
        GunMesh.Frame frame=mesh.frame(engine.equals("throwable")||simpleDraw?"static_idle":clip,engine.equals("throwable")||simpleDraw?0:clipTime,aim);
        JsonObject preset=defaultOptic();if(preset!=null){GunMesh attachment=opticMeshes.computeIfAbsent(preset.get("id").getAsString(),id->{JsonObject animations=new JsonObject();animations.add("animations",new JsonObject());return new GunMesh(read(preset.get("model").getAsString()),animations,true);});frame=mesh.attach(frame,clip,clipTime,aim,attachment.frame(null,0,0),texture(),preset.get("texture").getAsString());}
        if(simpleDraw){float t=(float)Math.min(1,elapsed/420);float smooth=t*t*(3-2*t);return ModePose.transform(frame,new org.joml.Matrix4f().translation(0,-.42f*(1-smooth),0));}
        if(model.startsWith("gunbed_legacy_"))frame=LegacyMeleePose.apply(frame);
        if(engine.equals("cs")&&action.equals("attack_left")&&elapsed<durationMillis&&(weapon.equals("망치")||weapon.equals("나타나이프"))){GunMesh ref=meshes.computeIfAbsent(weapon.equals("망치")?"lr_baseball_bat":"lr_dagger",this::load);return LegacyMeleePose.retarget(frame,ref.frame("attack_left",Math.min(1,elapsed/Math.max(1,durationMillis))*ref.duration("attack_left"),0),ref.frame(null,0,0));}
        if(engine.equals("cs")&&action.equals("attack_left")&&elapsed<durationMillis){float t=(float)Math.min(1,elapsed/durationMillis),swing=(float)Math.sin(t*Math.PI);boolean hammer=weapon.equals("망치"),saber=weapon.contains("광선검");return ModePose.transform(frame,new org.joml.Matrix4f().translation(.12f*swing,-.08f*swing,-(saber?.15f:.28f)*swing).rotateZ((saber?1.7f:hammer?.15f:1.0f)*swing).rotateX((hammer?-1.1f:-.3f)*swing));}
        if(model.equals("gunbed_m79"))return M79Pose.apply(frame);
        if(engine.equals("throwable"))return ThrowablePose.apply(frame,elapsed<durationMillis?action:"",(float)(elapsed/Math.max(1,durationMillis)));
        if(!modeActive())return frame;
        float progress=Math.min(1,(System.nanoTime()-modeStarted)/(modeDuration*1_000_000f)),wave=(float)Math.sin(Math.PI*progress);
        org.joml.Matrix4f transform=new org.joml.Matrix4f().translate(.06f*wave,-.13f*wave,.10f*wave).rotateZ(-.22f*wave).rotateY((modeAction.equals("switch")?.3f:.12f)*wave);
        return ModePose.transform(frame,transform);
    }
    private boolean modeActive(){return modeStarted>0&&System.nanoTime()-modeStarted<modeDuration*1_000_000L;}
    private Phase phaseAt(double elapsed){if(elapsed>=durationMillis)return null;if(phases.isEmpty())return new Phase(action,0,durationMillis);for(Phase phase:phases)if(elapsed>=phase.at&&elapsed<phase.at+phase.duration)return phase;return null;}
    private String resolvedClip(GunMesh mesh,String requested){if(mesh.hasClip(requested))return requested;return requested.startsWith("reload")&&mesh.hasClip("reload_loop")?"reload_loop":null;}
    public List<String> sounds(){
        if(model.isEmpty())return List.of();
        GunMesh mesh=meshes.computeIfAbsent(model,this::load);
        double elapsed=(System.nanoTime()-started)/1e6,from=Math.max(lastSoundMillis,elapsed-250);lastSoundMillis=elapsed;
        Set<String> result=new LinkedHashSet<>();
        List<Phase> sequence=phases.isEmpty()?List.of(new Phase(action,0,durationMillis)):phases;
        JsonObject definition=definition(model),aliases=definition.getAsJsonObject("soundAliases"),sounds=definition.getAsJsonObject("display").getAsJsonObject("sounds");
        if(aliases==null)return List.of();
        for(Phase phase:sequence){
            if(elapsed<phase.at||from>=phase.at+phase.duration)continue;
            String clip=resolvedClip(mesh,phase.clip);if(clip==null||phase.clip.equals("shoot"))continue;
            String complete=sounds!=null&&sounds.has(phase.clip)?sounds.get(phase.clip).getAsString():"";
            if(aliases.has(complete)){if(from<phase.at)result.add(aliases.get(complete).getAsString());continue;}
            double scale=mesh.duration(clip)/phase.duration,lo=(from-phase.at)*scale,hi=Math.min(phase.duration,elapsed-phase.at)*scale;
            for(String effect:mesh.sounds(clip,lo,hi))if(aliases.has(effect))result.add(aliases.get(effect).getAsString());
        }
        return List.copyOf(result);
    }
    private GunMesh load(String id){
        JsonObject d=definition(id);
        if(d==null)return new GunMesh(read("assets/tacz/geo_models/gun/"+id+"_geo.json"),read("assets/tacz/animations/"+id+".animation.json"));
        var loaded=ModeAssets.load(d,this::read);return new GunMesh(loaded.geometry(),loaded.animation());
    }
    private JsonObject read(String path) {
        try(InputStream input=VisualState.class.getClassLoader().getResourceAsStream(path)){
            if(input==null)throw new IllegalArgumentException("Missing original TaCZ asset: "+path);
            return JsonParser.parseReader(new InputStreamReader(input,StandardCharsets.UTF_8)).getAsJsonObject();
        }catch(IOException e){throw new UncheckedIOException(e);}
    }
}
