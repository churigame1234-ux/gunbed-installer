package kr.mzs.profile;
import java.sql.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.bukkit.*;
import org.bukkit.event.*;
import org.bukkit.plugin.*;

/** Count the signed receiver event, even while the voter is on another backend. */
final class NuVoteV16 implements Listener {
 static boolean install(MZSProfilePlugin plugin){try{
  Plugin receiver=Arrays.stream(Bukkit.getPluginManager().getPlugins()).filter(p->p.getName().equalsIgnoreCase("Votifier")||p.getName().equalsIgnoreCase("NuVotifier")).findFirst().orElse(null);
  if(receiver==null)return false;
  Class<?> raw=Class.forName("com.vexsoftware.votifier.model.VotifierEvent",true,receiver.getClass().getClassLoader());
  for(var listener:HandlerList.getRegisteredListeners(plugin))if(listener.getListener().getClass()==NuVoteV16.class)return true;
  var listener=new NuVoteV16();
  Bukkit.getPluginManager().registerEvent(raw.asSubclass(Event.class),listener,EventPriority.MONITOR,(l,event)->{
   try {Object vote=raw.getMethod("getVote").invoke(event);String name=(String)vote.getClass().getMethod("getUsername").invoke(vote),service=(String)vote.getClass().getMethod("getServiceName").invoke(vote),stamp=(String)vote.getClass().getMethod("getTimeStamp").invoke(vote);
    Runnable task=()->count(plugin,name,service,stamp);if(Bukkit.isPrimaryThread())task.run();else Bukkit.getScheduler().runTask(plugin,task);
   }catch(Exception e){throw new EventException(e);}
  },plugin,true);
  plugin.getLogger().info("Direct NuVotifier common vote hook installed; receipt deduplication enabled.");return true;
 }catch(ClassNotFoundException missing){return false;}}
 static void count(MZSProfilePlugin plugin,String name,String service,String stamp){if(name==null||!name.matches("[A-Za-z0-9_]{1,16}"))return;try{
  var df=MZSProfilePlugin.class.getDeclaredField("database");df.setAccessible(true);Object database=df.get(plugin);var cf=database.getClass().getDeclaredField("connection");cf.setAccessible(true);Connection db=(Connection)cf.get(database);
  String normalizedStamp=stamp==null||stamp.isBlank()?Long.toString(System.currentTimeMillis()/300000):stamp.trim();String receipt=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest((Objects.toString(service,"")+"\n"+name.toLowerCase(Locale.ROOT)+"\n"+normalizedStamp).getBytes(StandardCharsets.UTF_8)));
  synchronized(database){try(var sql=db.createStatement()){sql.execute("CREATE TABLE IF NOT EXISTS gunbed_vote_receipts_v16(receipt TEXT PRIMARY KEY,username TEXT NOT NULL,at INTEGER NOT NULL)");}boolean auto=db.getAutoCommit();if(!auto)throw new IllegalStateException("Vote database already in transaction");db.setAutoCommit(false);try{
   int inserted;try(var q=db.prepareStatement("INSERT OR IGNORE INTO gunbed_vote_receipts_v16 VALUES(?,?,?)")){q.setString(1,receipt);q.setString(2,name);q.setLong(3,System.currentTimeMillis());inserted=q.executeUpdate();}
   if(inserted==1)plugin.recordVote(name);db.commit();if(inserted==1)plugin.getLogger().info("Common recommendation recorded: "+name);
  }catch(Throwable failure){db.rollback();throw failure;}finally{db.setAutoCommit(true);}}
 }catch(Exception failure){plugin.getLogger().log(java.util.logging.Level.SEVERE,"Common vote transaction failed and rolled back",failure);}}
}
