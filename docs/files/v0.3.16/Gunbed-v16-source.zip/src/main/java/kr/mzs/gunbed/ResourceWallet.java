package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.GameStatus;
import java.util.*;

/** Main-thread atomic match currencies. Explicit withdrawals remain physical and tradable. */
final class ResourceWallet implements Listener {
    static final List<Material> TYPES=List.of(Material.IRON_INGOT,Material.GOLD_INGOT,Material.DIAMOND,Material.EMERALD);
    private final GunbedCore plugin;
    private final PlayerProfiles profiles;
    private final NamespacedKey withdrawal;
    private record Menu() implements InventoryHolder {public Inventory getInventory(){throw new UnsupportedOperationException();}}
    ResourceWallet(GunbedCore plugin,PlayerProfiles profiles){this.plugin=plugin;this.profiles=profiles;withdrawal=new NamespacedKey(plugin,"withdrawn_resource");Bukkit.getPluginManager().registerEvents(this,plugin);
        plugin.getCommand("자원창고").setExecutor((s,c,l,a)->{if(s instanceof Player p)open(p);return true;});
        Bukkit.getScheduler().runTaskTimer(plugin,()->{for(Player p:Bukkit.getOnlinePlayers())if(active(p))depositInventory(p);},10,10);
    }
    private boolean inMatch(Player p){var game=BedwarsAPI.getInstance().getGameOfPlayer(p);return game!=null&&game.getStatus()==GameStatus.RUNNING&&game.getTeamOfPlayer(p)!=null;}
    private boolean active(Player p){return inMatch(p)&&p.getGameMode()!=GameMode.SPECTATOR&&!plugin.inventories.locked(p);}
    void set(Player p,Material type,long value){if(value<0)throw new IllegalArgumentException();profiles.set(p.getUniqueId(),"resources."+type.name(),value);}
    long amount(Player p,Material type){return profiles.get(p.getUniqueId()).getLong("resources."+type.name(),0);}
    void add(Player p,Material type,long value){if(value<0)throw new IllegalArgumentException("Invalid resource amount");profiles.set(p.getUniqueId(),"resources."+type.name(),Math.addExact(amount(p,type),value));}
    private Map<Material,Long> prices(List<ItemStack> prices){Map<Material,Long> totals=new EnumMap<>(Material.class);for(ItemStack price:prices){if(!TYPES.contains(price.getType())||price.getAmount()<1)throw new IllegalArgumentException("Unknown currency or invalid price");totals.merge(price.getType(),(long)price.getAmount(),Math::addExact);}return totals;}
    long total(Player p,Material type){long count=amount(p,type);for(ItemStack item:plugin.inventories.utility(p))if(item!=null&&item.getType()==type)count+=plugin.stacks.count(item);return count;}
    boolean pay(Player p,List<ItemStack> prices){Map<Material,Long> totals=prices(prices);for(var e:totals.entrySet())if(total(p,e.getKey())<e.getValue())return false;
        // Validation precedes mutation; the caller commits its simulated non-currency inventory immediately afterwards.
        ItemStack[] bank=plugin.inventories.utility(p);for(int slot=0;slot<36;slot++){ItemStack item=bank[slot];if(item!=null&&TYPES.contains(item.getType())){add(p,item.getType(),plugin.stacks.count(item));bank[slot]=null;}}plugin.inventories.utility(p,bank);
        for(var e:totals.entrySet())profiles.set(p.getUniqueId(),"resources."+e.getKey().name(),amount(p,e.getKey())-e.getValue());return true;}
    boolean affordable(Player p,List<ItemStack> prices){return prices(prices).entrySet().stream().allMatch(e->total(p,e.getKey())>=e.getValue());}
    Inventory purchaseInventory(Player p){Inventory simulation=Bukkit.createInventory(null,36);simulation.setStorageContents(Arrays.stream(plugin.inventories.utility(p)).map(i->i==null||TYPES.contains(i.getType())?null:i.clone()).toArray(ItemStack[]::new));simulation.setItem(MatchContainers.BUTTON_SLOT,plugin.containers.button());return simulation;}
    void depositInventory(Player p){ItemStack[] bank=plugin.inventories.utility(p);boolean changed=false;for(int slot=0;slot<36;slot++){ItemStack item=bank[slot];if(item==null||!TYPES.contains(item.getType())||item.hasItemMeta()&&item.getItemMeta().getPersistentDataContainer().has(withdrawal))continue;add(p,item.getType(),plugin.stacks.count(item));bank[slot]=null;changed=true;}if(changed)plugin.inventories.utility(p,bank);}
    Map<String,Long> snapshot(Player p){Map<String,Long> map=new LinkedHashMap<>();for(Material type:TYPES)map.put(type.name().toLowerCase(Locale.ROOT),total(p,type));return map;}
    void clear(Player p){for(Material type:TYPES)profiles.set(p.getUniqueId(),"resources."+type.name(),0);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void pickup(EntityPickupItemEvent e){if(!(e.getEntity() instanceof Player p)||!active(p)||!TYPES.contains(e.getItem().getItemStack().getType())||!e.getItem().isValid())return;var pending=new NamespacedKey(plugin,"pickup_pending");if(e.getItem().getPersistentDataContainer().has(pending)){e.setCancelled(true);return;}e.getItem().getPersistentDataContainer().set(pending,PersistentDataType.BYTE,(byte)1);e.getItem().setPickupDelay(32767);ItemStack item=e.getItem().getItemStack();add(p,item.getType(),plugin.stacks.count(item));e.setCancelled(true);p.playPickupItemAnimation(e.getItem(),item.getAmount());if(plugin.levels!=null&&e.getItem().getPersistentDataContainer().has(new NamespacedKey(plugin,"generator_pile")))plugin.levels.generatorPickup(p,item.getType(),item.getAmount());Bukkit.getScheduler().runTaskLater(plugin,()->e.getItem().remove(),4);p.playSound(p.getLocation(),Sound.ENTITY_ITEM_PICKUP,.3f,1.3f);}
    void open(Player p){Inventory inv=Bukkit.createInventory(new Menu(),27,"자원창고 · 클릭하여 전체 입출금");for(int i=0;i<TYPES.size();i++){Material type=TYPES.get(i);ItemStack item=new ItemStack(type);var meta=item.getItemMeta();meta.setDisplayName("§e"+switch(type){case IRON_INGOT->"철";case GOLD_INGOT->"금";case DIAMOND->"다이아몬드";default->"에메랄드";}+" §f"+amount(p,type));meta.setLore(List.of("§7자원이 있으면 가능한 만큼 전부 꺼내기","§7인벤에 같은 자원이 있으면 전부 입금","§c사망 시 잃음 · 상자에 보관해야 안전"));item.setItemMeta(meta);inv.setItem(10+i*2,item);}p.openInventory(inv);}
    @EventHandler public void click(InventoryClickEvent e){if(!(e.getView().getTopInventory().getHolder() instanceof Menu))return;e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p)||e.getRawSlot()<0||e.getRawSlot()>=27||e.getCurrentItem()==null)return;Material type=e.getCurrentItem().getType();if(!TYPES.contains(type))return;
        ItemStack[] bank=plugin.inventories.utility(p);long physical=0;for(int n=0;n<36;n++)if(bank[n]!=null&&bank[n].getType()==type){physical+=plugin.stacks.count(bank[n]);bank[n]=null;}
        if(physical>0){add(p,type,physical);plugin.inventories.utility(p,bank);}else{Inventory sim=Bukkit.createInventory(null,36);bank[MatchContainers.BUTTON_SLOT]=plugin.containers.button();sim.setStorageContents(bank);long remaining=amount(p,type),moved=0;if(remaining>0){long n=Math.min(VirtualStacks.LIMIT,remaining);ItemStack item=new ItemStack(type);var meta=item.getItemMeta();meta.getPersistentDataContainer().set(withdrawal,PersistentDataType.BYTE,(byte)1);item.setItemMeta(meta);item=plugin.stacks.sized(item,n);if(plugin.stacks.add(sim,item))moved=n;}set(p,type,amount(p,type)-moved);plugin.inventories.utility(p,sim.getStorageContents());}open(p);
    }
    @EventHandler public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof Menu)e.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST)public void start(BedwarsGameStartedEvent e){for(Player p:e.getGame().getConnectedPlayers())clear(p);}
    // BedWars removes a final victim from their team at HIGHEST. Settle before
    // that removal, while the player's arena and physical drops still exist.
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void death(PlayerDeathEvent e){Player victim=e.getEntity();if(!inMatch(victim))return;UUID killer=plugin.combatPresentation==null?(victim.getKiller()==null?null:victim.getKiller().getUniqueId()):plugin.combatPresentation.creditId(victim);
        for(Material type:TYPES){long quantity=amount(victim,type);for(Iterator<ItemStack> it=e.getDrops().iterator();it.hasNext();){ItemStack item=it.next();if(item.getType()==type){quantity+=plugin.stacks.count(item);it.remove();}}profiles.set(victim.getUniqueId(),"resources."+type.name(),0);
            if(killer!=null&&!killer.equals(victim.getUniqueId())){long existing=profiles.get(killer).getLong("resources."+type.name(),0);profiles.set(killer,"resources."+type.name(),Math.addExact(existing,quantity));}
            else while(quantity>0){long count=Math.min(VirtualStacks.LIMIT,quantity);e.getDrops().add(plugin.stacks.sized(new ItemStack(type),count));quantity-=count;}}}
    @EventHandler public void leave(BedwarsPlayerLeaveEvent e){clear(e.getPlayer());}
    @EventHandler public void end(BedwarsGameEndEvent e){for(Player p:e.getGame().getConnectedPlayers())clear(p);}
}
