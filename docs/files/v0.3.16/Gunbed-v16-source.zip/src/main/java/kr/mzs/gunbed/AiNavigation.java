package kr.mzs.gunbed;
import org.bukkit.*;
import org.screamingsandals.bedwars.api.game.Game;
import java.util.*;

/** Bounded ground A*: planned bridge cells still require actual block placement. */
final class AiNavigation {
    record Cell(int x,int y,int z){Location at(World w){return new Location(w,x+.5,y,z+.5);}Cell offset(int x,int y,int z){return new Cell(this.x+x,this.y+y,this.z+z);}}
    private record Node(Cell cell,double g,double f){}
    static List<Location> path(Game game,Location from,Location target,boolean bridge,AiLearning learning,org.bukkit.entity.Player bot){
        World world=from.getWorld();Cell start=new Cell(from.getBlockX(),(int)Math.ceil(from.getY()-.05),from.getBlockZ());
        PriorityQueue<Node> open=new PriorityQueue<>(Comparator.comparingDouble(Node::f));Map<Cell,Cell> parent=new HashMap<>();Map<Cell,Double> score=new HashMap<>();open.add(new Node(start,0,0));score.put(start,0.0);Cell best=start;double distance=metric(start,target);int budget=3000;
        while(!open.isEmpty()&&budget-->0){Node node=open.poll();Cell c=node.cell;if(node.g>score.getOrDefault(c,Double.MAX_VALUE))continue;double remaining=metric(c,target);if(remaining<distance){best=c;distance=remaining;}if(remaining<2.1)break;
            for(int[] delta:new int[][]{{1,0},{-1,0},{0,1},{0,-1}})for(int dy:new int[]{0,1,-1}){
                Cell next=c.offset(delta[0],dy,delta[1]);if(next.y<39||next.y>65||!world.isChunkLoaded(next.x>>4,next.z>>4)||!game.isLocationInArena(next.at(world)))continue;
                var feet=world.getBlockAt(next.x,next.y,next.z);if(!feet.isPassable()||!feet.getRelative(0,1,0).isPassable())continue;boolean ground=world.getBlockAt(next.x,next.y-1,next.z).getType().isSolid();
                if(!ground&&(!bridge||next.y!=47||dy!=0))continue;if(dy>0&&!world.getBlockAt(c.x,c.y+2,c.z).isPassable())continue;
                double cost=node.g+(ground?1:3.5)+(dy==0?0:.25)-(learning==null?0:learning.routeScore(game,bot,next.at(world)));if(cost>=score.getOrDefault(next,Double.MAX_VALUE))continue;
                score.put(next,cost);parent.put(next,c);open.add(new Node(next,cost,cost+metric(next,target)));break;
            }
        }
        LinkedList<Location> result=new LinkedList<>();for(Cell c=best;!c.equals(start);c=parent.get(c)){if(c==null)return List.of();result.addFirst(c.at(world));}return result;
    }
    private static double metric(Cell c,Location at){return Math.abs(c.x+.5-at.getX())+Math.abs(c.z+.5-at.getZ())+Math.abs(c.y-at.getY())*.5;}
}
