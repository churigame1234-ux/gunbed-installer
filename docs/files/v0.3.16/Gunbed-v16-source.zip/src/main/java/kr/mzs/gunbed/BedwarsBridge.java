package kr.mzs.gunbed;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.Game;
import org.screamingsandals.bedwars.api.game.GameStatus;
import org.screamingsandals.bedwars.api.RunningTeam;
import org.screamingsandals.bedwars.api.events.*;
import org.bukkit.inventory.meta.LeatherArmorMeta;

import java.util.Comparator;
import java.util.List;

final class BedwarsBridge implements Listener {
    private final GunbedCore plugin;
    final NativeShop shop;
    private final LegacyStats placeholders;
    private final BedwarsAPI api = BedwarsAPI.getInstance();
    private final java.util.Set<String> normalizedArenas = new java.util.HashSet<>();

    private record ArenaMenu(int page) implements InventoryHolder {
        @Override public Inventory getInventory() { throw new UnsupportedOperationException(); }
    }

    BedwarsBridge(GunbedCore plugin) {
        this.plugin = plugin;
        shop = new NativeShop(plugin);
        for(Game game:api.getGames())if(game instanceof org.screamingsandals.bedwars.game.Game impl)impl.setSpectatorJoin(org.screamingsandals.bedwars.api.InGameConfigBooleanConstants.TRUE);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        placeholders = Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI") ? new LegacyStats(plugin) : null;
        if (placeholders != null) placeholders.register();
        plugin.getCommand("gunbed").setExecutor((sender, command, label, args) -> command(sender, args));
        plugin.getLogger().info("Bedwars adapter loaded: " + api.getGames().size() + " arenas; native shop, upgrades and legacy placeholders.");
    }

    long extra(org.bukkit.OfflinePlayer p,String name){return placeholders==null?0:Long.parseLong(placeholders.extra(p,name));}
    void close() {
        shop.close();
        if (placeholders != null) { placeholders.save(); placeholders.unregister(); }
    }

    List<Game> games() {
        return api.getGames().stream().sorted(Comparator.comparing(Game::getName)).toList();
    }

    private boolean command(CommandSender sender, String[] args) {
        String action = args.length == 0 ? "arenas" : args[0].toLowerCase(java.util.Locale.ROOT);
        if (action.equals("teamsync")) {
            if (!sender.hasPermission("gunbedcore.admin")) return true;
            for (Player player : Bukkit.getOnlinePlayers()) {
                Game game = api.getGameOfPlayer(player);
                syncTeam(player, game == null ? null : game.getTeamOfPlayer(player));
            }
            sender.sendMessage("배드워즈 팀 정보를 동기화했습니다."); return true;
        }
        if (action.equals("validate")) {
            if (!sender.hasPermission("gunbedcore.admin")) return true;
            long disabled = api.getGames().stream().filter(g -> g.getStatus() == GameStatus.DISABLED).count();
            sender.sendMessage("Gunbed: arenas=" + api.getGames().size() + ", disabled=" + disabled
                    + ", shop-products=" + shop.productCount() + ", upgrades=" + shop.upgradeCount());
            for (Game game : games()) {
                if (args.length > 1 && !game.getName().equalsIgnoreCase(args[1])) continue;
                if (args.length > 1) {
                    for (var team : game.getAvailableTeams()) {
                        sender.sendMessage(game.getName() + "/" + team.getName() + " bed="
                                + team.getTargetBlock().getBlock().getType() + " spawn="
                                + team.getTeamSpawn().getBlock().getType());
                    }
                }
            }
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage("플레이어만 사용할 수 있습니다."); return true;
        }
        switch (action) {
            case "arenas" -> openArenas(player, 0);
            case "quick", "join" -> quickJoin(player);
            case "shop" -> shop.open(player, false, -1);
            case "upgrades" -> shop.open(player, true, 0);
            case "start" -> {
                if(plugin.waiting!=null){plugin.waiting.toggle(player);return true;}
                Game game = api.getGameOfPlayer(player);
                if (game != null && game.getStatus() == GameStatus.WAITING
                        && game.getConnectedPlayers().size() >= game.getMinPlayers()
                        && game instanceof org.screamingsandals.bedwars.game.Game implementation) {
                    implementation.forceGameToStart = true;
                    player.sendMessage(ChatColor.GREEN + "경기를 시작합니다.");
                }
            }
            default -> { return false; }
        }
        return true;
    }

    private void syncTeam(Player player, RunningTeam team) {
        // Screaming BedWars is the only team authority.

    }

    private void kit(Game game, Player player) {
        RunningTeam team = game.getTeamOfPlayer(player);
        if (team == null || game.getStatus() != GameStatus.RUNNING) return;
        var color = TeamPalette.of(game,team).dye();
        for (var piece : java.util.Map.of(org.bukkit.inventory.EquipmentSlot.HEAD, Material.LEATHER_HELMET,
                org.bukkit.inventory.EquipmentSlot.CHEST, Material.LEATHER_CHESTPLATE,
                org.bukkit.inventory.EquipmentSlot.LEGS, Material.LEATHER_LEGGINGS,
                org.bukkit.inventory.EquipmentSlot.FEET, Material.LEATHER_BOOTS).entrySet()) {
            ItemStack item = new ItemStack(piece.getValue());
            var meta = (LeatherArmorMeta) item.getItemMeta(); meta.setColor(org.bukkit.Color.fromRGB(TeamPalette.of(game,team).rgb())); var equipment=meta.getEquippable();equipment.setModel(new org.bukkit.NamespacedKey("gunbed","churi_cloth"));meta.setEquippable(equipment); item.setItemMeta(meta);
            player.getInventory().setItem(piece.getKey(), item);
        }
        MatchVitals.armor(player,true);
    }

    @EventHandler public void onStart(BedwarsGameStartedEvent event) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (Player player : event.getGame().getConnectedPlayers()) kit(event.getGame(), player);
        });
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onJoin(BedwarsPlayerJoinEvent event) {
        Game game = event.getGame();
        if (!normalizedArenas.add(game.getName())) return;
        for (var team : game.getAvailableTeams()) {
            var block = team.getTargetBlock().getBlock();
            if (block.getBlockData() instanceof org.bukkit.block.data.type.Bed bed
                    && bed.getPart() == org.bukkit.block.data.type.Bed.Part.FOOT
                    && team instanceof org.screamingsandals.bedwars.game.Team definition) {
                var head = block.getRelative(bed.getFacing());
                if (head.getBlockData() instanceof org.bukkit.block.data.type.Bed headBed
                        && headBed.getPart() == org.bukkit.block.data.type.Bed.Part.HEAD) {
                    definition.bed = head.getLocation();
                    plugin.getLogger().info("Normalized imported bed head: " + game.getName() + "/" + team.getName());
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST) public void onRespawn(BedwarsPlayerRespawnedIngameEvent event) {
        kit(event.getGame(), event.getPlayer());
        event.getPlayer().addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.SPEED, 100, 2));
        event.getPlayer().addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.JUMP_BOOST, 100, 0));
    }

    @EventHandler public void onLeave(BedwarsPlayerLeaveEvent event) { syncTeam(event.getPlayer(), null); }

    void quickJoin(Player p){var available=games().stream().filter(g->!AiPractice.arena(g)).filter(g->g.getStatus()==GameStatus.WAITING&&!plugin.restores.busy(g)&&g.getConnectedPlayers().size()<g.getMaxPlayers()).toList();var occupied=available.stream().filter(g->!g.getConnectedPlayers().isEmpty()).sorted(Comparator.comparingInt((Game g)->g.getConnectedPlayers().size()).reversed()).toList();if(available.isEmpty()){p.sendMessage("§e현재 참가할 수 있는 경기장이 없습니다.");return;}Game target=occupied.isEmpty()?available.get(java.util.concurrent.ThreadLocalRandom.current().nextInt(available.size())):occupied.getFirst();target.joinToGame(p);}

    void openArenas(Player player, int page) {
        List<Game> games = games().stream().filter(g->!AiPractice.arena(g)).toList();
        Inventory menu = Bukkit.createInventory(new ArenaMenu(page), 54, "Gunbed 경기장 " + (page + 1));
        for (int index = page * 45; index < Math.min(games.size(), (page + 1) * 45); index++) {
            Game game = games.get(index);
            ItemStack icon = new ItemStack(game.getStatus() == GameStatus.WAITING ? Material.LIME_CONCRETE : Material.YELLOW_CONCRETE);
            var meta = icon.getItemMeta();
            meta.setDisplayName(ChatColor.YELLOW + game.getName());
            meta.setLore(List.of(game.getStatus()==GameStatus.WAITING?"§a대기 중":game.getStatus()==GameStatus.RUNNING?"§c경기 중":"§7복구·준비 중",
                    ChatColor.WHITE + "참가자 " + game.getConnectedPlayers().size() + "/" + game.getMaxPlayers(),
                    game.getStatus()==GameStatus.RUNNING?"§e클릭하여 관전":"§a클릭하여 참가"));
            icon.setItemMeta(meta); menu.setItem(index % 45, icon);
        }
        if (page > 0) menu.setItem(45, new ItemStack(Material.ARROW));
        if ((page + 1) * 45 < games.size()) menu.setItem(53, new ItemStack(Material.ARROW));
        var quick=new ItemStack(Material.NETHER_STAR);var qm=quick.getItemMeta();qm.setDisplayName("§a빠른 참가");qm.setLore(List.of("§7대기 중인 사람이 있는 경기장 우선","§7대기자가 없으면 빈 경기장 무작위 선택"));quick.setItemMeta(qm);menu.setItem(49,quick);if(plugin.practice!=null)menu.setItem(50,plugin.practice.entry());player.openInventory(menu);if(plugin.practice!=null)plugin.practice.attachEntry(player);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLegacyCommand(PlayerCommandPreprocessEvent event) {
        String text = event.getMessage().toLowerCase(java.util.Locale.ROOT);
        if (text.startsWith("/bw arenasgui ") || text.equals("/bw arenasgui") || text.equals("/map")) {
            event.setCancelled(true); openArenas(event.getPlayer(), 0);
        } else if (text.equals("/bw forcestart")) {
            event.setCancelled(true); command(event.getPlayer(), new String[]{"start"});
        }
    }

    @EventHandler public void onMenu(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof ArenaMenu menu)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        int slot = event.getRawSlot();
        if(slot==50&&plugin.practice!=null){plugin.practice.maps(player);return;}
        if(slot==49){player.closeInventory();quickJoin(player);return;}
        if (slot == 45 && menu.page() > 0) { openArenas(player, menu.page() - 1); return; }
        List<Game> games = games().stream().filter(g->!AiPractice.arena(g)).toList();
        if (slot == 53 && (menu.page() + 1) * 45 < games.size()) { openArenas(player, menu.page() + 1); return; }
        int index = menu.page() * 45 + slot;
        if (slot >= 0 && slot < 45 && index < games.size()) {
            Game selected=games.get(index);if(selected.getStatus()!=GameStatus.WAITING&&selected.getStatus()!=GameStatus.RUNNING){player.sendMessage("§e복구 중인 경기장입니다.");return;}player.closeInventory();selected.joinToGame(player);
        }
    }

    @EventHandler public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof ArenaMenu) event.setCancelled(true);
    }
}
