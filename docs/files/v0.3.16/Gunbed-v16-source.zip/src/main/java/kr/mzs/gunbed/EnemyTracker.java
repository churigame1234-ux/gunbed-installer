package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.*;
import org.screamingsandals.bedwars.api.events.*;
import java.util.*;

/** Match-scoped enemy tracker. It never intercepts lobby or loadout compasses. */
final class EnemyTracker implements Listener {
    private record Menu(Game game,List<UUID> targets,int page) implements InventoryHolder {public Inventory getInventory(){throw new UnsupportedOperationException();}}
    private final GunbedCore plugin;
    private final Map<Game,Set<UUID>> unlocked=new HashMap<>();
    private final Map<UUID,UUID> targets=new HashMap<>();
    private final NamespacedKey key;
    EnemyTracker(GunbedCore plugin){this.plugin=plugin;FixedTracker.install(plugin);TrackerStatus.install(plugin);key=new NamespacedKey(plugin,"enemy_tracker");Bukkit.getPluginManager().registerEvents(this,plugin);Bukkit.getScheduler().runTaskTimer(plugin,this::tick,20,20);}
    private Game active(Player p){var game=BedwarsAPI.getInstance().getGameOfPlayer(p);return game!=null&&game.getStatus()==GameStatus.RUNNING&&game.getTeamOfPlayer(p)!=null&&p.getGameMode()!=GameMode.SPECTATOR?game:null;}
    void open(Player p){open(p,0);}
    private void open(Player p,int page){Game game=active(p);if(game==null)return;List<Player> enemies=game.getConnectedPlayers().stream().filter(e->!game.getTeamOfPlayer(p).isPlayerInTeam(e)&&active(e)==game).sorted(Comparator.comparing(Player::getName)).toList();page=Math.max(0,Math.min(page,Math.max(0,(enemies.size()-1)/28)));Inventory inv=Bukkit.createInventory(new Menu(game,enemies.stream().map(Player::getUniqueId).toList(),page),54,"적 추적 · "+(page+1)+"페이지 · 1 에메랄드");for(int i=0;i<28&&page*28+i<enemies.size();i++){Player enemy=enemies.get(page*28+i);ItemStack head=new ItemStack(Material.PLAYER_HEAD);var meta=(org.bukkit.inventory.meta.SkullMeta)head.getItemMeta();meta.setOwningPlayer(enemy);meta.setDisplayName(TeamPalette.of(enemy).legacy()+TeamPalette.display(enemy));meta.setLore(List.of(enemy.getUniqueId().equals(targets.get(p.getUniqueId()))?"§a현재 추적 중 · 다시 선택은 무료":"§7선택/대상 변경: 에메랄드 1개","§7사망하면 추적이 해제됩니다."));head.setItemMeta(meta);inv.setItem(10+(i%7)+(i/7)*9,head);}if(page>0)inv.setItem(45,button(Material.ARROW,"§e이전 페이지"));if((page+1)*28<enemies.size())inv.setItem(53,button(Material.ARROW,"§e다음 페이지"));inv.setItem(49,button(Material.COMPASS,"§e추적 대상 선택 · 같은 대상은 무료"));inv.setItem(48,button(Material.BARRIER,"§c닫기"));p.openInventory(inv);}
    private ItemStack button(Material material,String name){ItemStack item=new ItemStack(material);var meta=item.getItemMeta();meta.setDisplayName(name);item.setItemMeta(meta);return item;}
    @EventHandler public void click(InventoryClickEvent e){if(!(e.getView().getTopInventory().getHolder() instanceof Menu menu))return;e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p)||active(p)!=menu.game)return;int raw=e.getRawSlot();if(raw==45&&menu.page>0){open(p,menu.page-1);return;}if(raw==53&&(menu.page+1)*28<menu.targets.size()){open(p,menu.page+1);return;}if(raw==48){p.closeInventory();return;}if(raw<10||raw>=45)return;int row=(e.getRawSlot()-10)/9,col=(e.getRawSlot()-10)%9,index=menu.page*28+row*7+col;if(e.getRawSlot()<10||col<0||col>=7||index<0||index>=menu.targets.size())return;Player target=Bukkit.getPlayer(menu.targets.get(index));if(target==null||active(target)!=menu.game||menu.game.getTeamOfPlayer(p).isPlayerInTeam(target))return;Set<UUID> paid=unlocked.computeIfAbsent(menu.game,g->new HashSet<>());if(!FixedTracker.ensure(plugin,p)){p.sendMessage("§c추적기 고정을 위해 인벤토리 공간을 비워 주세요.");return;}if(!target.getUniqueId().equals(targets.get(p.getUniqueId()))){if(!plugin.wallet.pay(p,List.of(new ItemStack(Material.EMERALD)))){p.sendMessage("§c에메랄드 1개가 필요합니다.");return;}paid.add(p.getUniqueId());}FixedTracker.selected(plugin,p,compass(target));targets.put(p.getUniqueId(),target.getUniqueId());p.setCompassTarget(target.getLocation());p.closeInventory();}
    private boolean tracker(ItemStack i){return i!=null&&i.hasItemMeta()&&i.getItemMeta().getPersistentDataContainer().has(key);}
    private ItemStack compass(Player target){ItemStack item=new ItemStack(Material.COMPASS);var meta=item.getItemMeta();meta.setDisplayName("§e적 추적: "+target.getName());meta.getPersistentDataContainer().set(key,PersistentDataType.BYTE,(byte)1);item.setItemMeta(meta);return item;}
    @EventHandler public void use(PlayerInteractEvent e){if(e.getHand()==EquipmentSlot.HAND&&e.getAction().isRightClick()&&tracker(e.getItem())){e.setCancelled(true);open(e.getPlayer());}}
    @EventHandler public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof Menu)e.setCancelled(true);}
    private void tick(){TrackerStatus.tick(plugin,targets);for(Player player:Bukkit.getOnlinePlayers())if(FixedTracker.active(player))FixedTracker.ensure(plugin,player);for(var it=targets.entrySet().iterator();it.hasNext();){var entry=it.next();Player p=Bukkit.getPlayer(entry.getKey()),target=Bukkit.getPlayer(entry.getValue());if(p==null||target==null||active(p)==null||BedwarsAPI.getInstance().getGameOfPlayer(p)!=BedwarsAPI.getInstance().getGameOfPlayer(target)||BedwarsAPI.getInstance().getGameOfPlayer(p).getTeamOfPlayer(target)==null){it.remove();continue;}p.setCompassTarget(target.getLocation());}}
    @EventHandler public void end(BedwarsGameEndEvent e){unlocked.remove(e.getGame());for(Player p:e.getGame().getConnectedPlayers())targets.remove(p.getUniqueId());}
    @EventHandler public void leave(BedwarsPlayerLeaveEvent e){targets.remove(e.getPlayer().getUniqueId());}
}
