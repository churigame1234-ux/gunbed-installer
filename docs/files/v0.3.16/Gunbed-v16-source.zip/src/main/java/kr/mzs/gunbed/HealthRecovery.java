package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.potion.PotionEffectType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.GameStatus;
import org.screamingsandals.bedwars.api.events.*;
import java.util.*;

/** 1.8-style natural regeneration; scaled apples use timed, non-stacking effects. */
final class HealthRecovery implements Listener {
    private record Apple(int regenUntil,int absorptionUntil){}
    private final Map<UUID,Apple> apples=new HashMap<>();
    private final Map<UUID,Integer> natural=new HashMap<>();
    private final GunbedCore plugin;
    HealthRecovery(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,1);}
    private boolean active(Player p){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);return g!=null&&g.getStatus()==GameStatus.RUNNING&&g.getTeamOfPlayer(p)!=null&&!p.isDead()&&p.getGameMode()!=GameMode.SPECTATOR;}
    private void heal(Player p,double hp){p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(),p.getHealth()+hp));}
    void milk(Player p){apples.remove(p.getUniqueId());p.setAbsorptionAmount(0);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void vanilla(EntityRegainHealthEvent e){if(e.getEntity() instanceof Player p&&active(p)&&e.getRegainReason()==EntityRegainHealthEvent.RegainReason.SATIATED)e.setCancelled(true);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void apple(PlayerItemConsumeEvent e){if(!active(e.getPlayer())||e.getItem().getType()!=Material.GOLDEN_APPLE)return;Player p=e.getPlayer();Bukkit.getScheduler().runTask(plugin,()->{if(!active(p))return;p.removePotionEffect(PotionEffectType.REGENERATION);p.removePotionEffect(PotionEffectType.ABSORPTION);p.getAttribute(Attribute.MAX_ABSORPTION).setBaseValue(2000);p.setAbsorptionAmount(2000);int now=Bukkit.getCurrentTick();apples.put(p.getUniqueId(),new Apple(now+100,now+2400));});}
    private void tick(){int now=Bukkit.getCurrentTick();for(Player p:Bukkit.getOnlinePlayers()){UUID id=p.getUniqueId();if(!active(p)){natural.remove(id);if(apples.remove(id)!=null)p.setAbsorptionAmount(0);continue;}if(p.getFoodLevel()>=18&&p.getHealth()<p.getAttribute(Attribute.MAX_HEALTH).getValue()){if(natural.merge(id,1,Integer::sum)>=80){heal(p,500);natural.put(id,0);}}else natural.remove(id);Apple a=apples.get(id);if(a!=null){if(now<=a.regenUntil&&now%25==a.regenUntil%25)heal(p,500);if(now>=a.absorptionUntil){p.setAbsorptionAmount(0);apples.remove(id);}}}}
    @EventHandler public void death(PlayerDeathEvent e){apples.remove(e.getEntity().getUniqueId());natural.remove(e.getEntity().getUniqueId());}
    @EventHandler public void leave(BedwarsPlayerLeaveEvent e){apples.remove(e.getPlayer().getUniqueId());natural.remove(e.getPlayer().getUniqueId());e.getPlayer().setAbsorptionAmount(0);}
}
