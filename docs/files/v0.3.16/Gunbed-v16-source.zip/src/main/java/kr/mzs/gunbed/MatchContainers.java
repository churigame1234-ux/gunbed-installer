package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.*;
import org.screamingsandals.bedwars.api.events.*;
import java.util.*;

/** Round-owned team chests and personal ender chests. No currency is saved by death. */
final class MatchContainers implements Listener,AutoCloseable {
    static final int BUTTON_SLOT=17;
    private record Key(Game game,String owner,boolean ender){}
    private static final class Store implements InventoryHolder {
        final Key key;Inventory inventory;Store(Key k){key=k;}
        public Inventory getInventory(){return inventory;}
    }
    private final GunbedCore plugin;
    private final Map<Key,Store> stores=new HashMap<>();
    private final Map<Game,Map<Location,String>> chestOwners=new HashMap<>();
    private final Map<Game,ArrayDeque<Drop>> pendingDrops=new HashMap<>();
    private record Drop(Location at,ItemStack item){}
    private final Map<UUID,Boolean> originalModes=new HashMap<>();
    private final NamespacedKey button;
    MatchContainers(GunbedCore p){plugin=p;button=new NamespacedKey(p,"resource_button");Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,()->{for(Player x:Bukkit.getOnlinePlayers())if(active(x))reserve(x);dropTick();},2,2);}
    private boolean active(Player p){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);return g!=null&&g.getStatus()==GameStatus.RUNNING&&g.getTeamOfPlayer(p)!=null&&p.getGameMode()!=GameMode.SPECTATOR&&!plugin.inventories.locked(p);}
    boolean button(ItemStack i){return i!=null&&i.hasItemMeta()&&i.getItemMeta().getPersistentDataContainer().has(button);}
    ItemStack button(){ItemStack i=new ItemStack(Material.CHEST);var m=i.getItemMeta();m.setDisplayName("§e자원창고");m.setLore(List.of("§7클릭: 자원별 전체 꺼내기 / 다시 입금","§7상자 안: 자원창고 전부 보관 / 비었으면 전부 회수","§8보관함 자원만 사망해도 안전합니다."));m.getPersistentDataContainer().set(button,PersistentDataType.BYTE,(byte)1);i.setItemMeta(m);return i;}
    private void reserve(Player p){ItemStack old=p.getInventory().getItem(BUTTON_SLOT);if(button(old))return;if(old!=null&&!old.getType().isAir()){var bank=plugin.inventories.utility(p);if(plugin.inventories.modeA(p)){if(!plugin.inventories.addUtility(p,old))return;}else{bank[BUTTON_SLOT]=button();Inventory sim=Bukkit.createInventory(null,36);sim.setStorageContents(bank);if(!plugin.stacks.add(sim,old))return;plugin.inventories.utility(p,sim.getStorageContents());}}p.getInventory().setItem(BUTTON_SLOT,button());}
    @EventHandler(priority=EventPriority.LOWEST)public void use(PlayerInteractEvent e){if(e.getHand()!=EquipmentSlot.HAND||!e.getAction().isRightClick()||e.getClickedBlock()==null)return;Material material=e.getClickedBlock().getType();if(!Set.of(Material.CHEST,Material.TRAPPED_CHEST,Material.ENDER_CHEST).contains(material))return;Player p=e.getPlayer();Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(g==null||g.getStatus()!=GameStatus.RUNNING)return;e.setCancelled(true);if(!active(p))return;boolean ender=material==Material.ENDER_CHEST;String owner=ender?p.getUniqueId().toString():owner(g,e.getClickedBlock().getLocation());if(!ender&&!g.getTeamOfPlayer(p).getName().equals(owner)){p.sendMessage("§c다른 팀의 일반상자는 열 수 없습니다.");return;}Key key=new Key(g,owner,ender);Store store=stores.computeIfAbsent(key,k->{Store s=new Store(k);s.inventory=Bukkit.createInventory(s,54,ender?"개인 엔더상자 · 경기 종료 시 초기화":"팀 공유 상자 · 경기 종료 시 초기화");return s;});
        // Migrate resources/items from pre-existing map chests once, without deleting overflow.
        if(!ender&&e.getClickedBlock().getState() instanceof org.bukkit.block.Chest chest){Inventory physical=chest.getBlockInventory();for(int n=0;n<physical.getSize();n++){ItemStack i=physical.getItem(n);if(i==null||plugin.inventories.protectedItem(i))continue;if(plugin.stacks.add(store.inventory,i))physical.setItem(n,null);}}
        originalModes.putIfAbsent(p.getUniqueId(),plugin.inventories.modeA(p));plugin.inventories.mode(p,false);reserve(p);p.openInventory(store.inventory);}
    private String owner(Game g,Location at){return chestOwners.computeIfAbsent(g,k->new HashMap<>()).computeIfAbsent(at.getBlock().getLocation(),k->g.getAvailableTeams().stream().min(Comparator.comparingDouble(t->t.getTeamSpawn().distanceSquared(at))).orElseThrow().getName());}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void built(org.bukkit.event.block.BlockPlaceEvent e){if(!Set.of(Material.CHEST,Material.TRAPPED_CHEST).contains(e.getBlock().getType()))return;Game g=BedwarsAPI.getInstance().getGameOfPlayer(e.getPlayer());if(g!=null&&g.getTeamOfPlayer(e.getPlayer())!=null)chestOwners.computeIfAbsent(g,k->new HashMap<>()).put(e.getBlock().getLocation(),g.getTeamOfPlayer(e.getPlayer()).getName());}
    void eliminated(Game game,String team,Set<UUID> members){Location at=game.getItemSpawners().stream().filter(s->s.getTeam()!=null&&s.getTeam().getName().equals(team)&&Set.of(Material.IRON_INGOT,Material.GOLD_INGOT).contains(s.getItemSpawnerType().getMaterial())).map(s->s.getLocation().clone().add(.5,.35,.5)).findFirst().orElseGet(()->game.getTeamFromName(team).getTeamSpawn().clone());var queue=pendingDrops.computeIfAbsent(game,g->new ArrayDeque<>());for(var entry:List.copyOf(stores.entrySet())){Key k=entry.getKey();if(k.game!=game||!(k.ender?members.stream().anyMatch(id->id.toString().equals(k.owner)):team.equals(k.owner)))continue;Store store=entry.getValue();for(var viewer:List.copyOf(store.inventory.getViewers()))viewer.closeInventory();for(ItemStack i:store.inventory.getContents())if(i!=null&&!i.getType().isAir())queue.add(new Drop(at.clone(),plugin.stacks.sized(i,plugin.stacks.count(i))));store.inventory.clear();stores.remove(k);}}

    private void dropTick(){for(var entry:List.copyOf(pendingDrops.entrySet())){var q=entry.getValue();for(int n=0;n<16&&!q.isEmpty();n++){Drop d=q.removeFirst();var entity=d.at.getWorld().dropItem(d.at,d.item);entity.setPickupDelay(15);entity.setVelocity(new org.bukkit.util.Vector((Math.random()-.5)*.08,.1,(Math.random()-.5)*.08));BedwarsAPI.getInstance().registerEntityToGame(entity,entry.getKey());}if(q.isEmpty())pendingDrops.remove(entry.getKey());}}
    private void transfer(Player p,Inventory store){boolean deposit=ResourceWallet.TYPES.stream().anyMatch(t->plugin.wallet.amount(p,t)>0);for(Material t:ResourceWallet.TYPES){if(deposit){long remaining=plugin.wallet.amount(p,t),moved=0;while(remaining>0){long size=Math.min(VirtualStacks.LIMIT,remaining);if(!plugin.stacks.add(store,plugin.stacks.sized(new ItemStack(t),size)))break;moved+=size;remaining-=size;}plugin.wallet.set(p,t,plugin.wallet.amount(p,t)-moved);}else{long count=0;for(int i=0;i<store.getSize();i++){ItemStack stack=store.getItem(i);if(stack!=null&&stack.getType()==t){count+=plugin.stacks.count(stack);store.setItem(i,null);}}plugin.wallet.add(p,t,count);}}p.playSound(p.getLocation(),Sound.BLOCK_CHEST_CLOSE,.4f,1.4f);}
    @EventHandler(priority=EventPriority.LOWEST)public void click(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p))return;Inventory top=e.getView().getTopInventory();boolean container=top.getHolder() instanceof Store;boolean own=e.getClickedInventory() instanceof PlayerInventory;boolean reserved=own&&e.getSlot()==BUTTON_SLOT;
        if(button(e.getCursor())||button(e.getCurrentItem())||reserved||e.getHotbarButton()==BUTTON_SLOT){e.setCancelled(true);if(reserved&&e.getCursor()!=null&&!e.getCursor().getType().isAir())return;if(reserved&&active(p)){if(container)transfer(p,top);else if(top.getType()==InventoryType.CRAFTING)Bukkit.getScheduler().runTask(plugin,()->plugin.wallet.open(p));}return;}
        if(!container)return;if(plugin.inventories.protectedItem(e.getCurrentItem())||plugin.inventories.protectedItem(e.getCursor())||e.getHotbarButton()>=0&&plugin.inventories.protectedItem(p.getInventory().getItem(e.getHotbarButton()))){e.setCancelled(true);return;}
        if(e.getClickedInventory()==top&&e.getCurrentItem()!=null&&ResourceWallet.TYPES.contains(e.getCurrentItem().getType())){e.setCancelled(true);ItemStack i=e.getCurrentItem();plugin.wallet.add(p,i.getType(),plugin.stacks.count(i));top.setItem(e.getSlot(),null);}
    }
    @EventHandler(priority=EventPriority.LOWEST)public void drag(InventoryDragEvent e){if(button(e.getOldCursor())||e.getRawSlots().stream().anyMatch(n->e.getView().getInventory(n) instanceof PlayerInventory&&e.getView().convertSlot(n)==BUTTON_SLOT))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST)public void drop(PlayerDropItemEvent e){if(button(e.getItemDrop().getItemStack()))e.setCancelled(true);}
    @EventHandler public void close(InventoryCloseEvent e){if(!(e.getInventory().getHolder() instanceof Store)||!(e.getPlayer() instanceof Player p))return;Boolean a=originalModes.remove(p.getUniqueId());if(a!=null&&a)Bukkit.getScheduler().runTask(plugin,()->{if(p.getOpenInventory().getType()==InventoryType.CRAFTING)plugin.inventories.mode(p,true);});}
    @EventHandler public void end(BedwarsGameEndEvent e){clear(e.getGame());}
    @EventHandler public void disabled(BedWarsGameDisabledEvent e){clear(e.getGame());}
    private void clear(Game g){chestOwners.remove(g);pendingDrops.remove(g);for(Store s:List.copyOf(stores.values()))if(s.key.game==g){for(var viewer:List.copyOf(s.inventory.getViewers()))viewer.closeInventory();s.inventory.clear();stores.remove(s.key);}}
    @Override public void close(){for(Game g:stores.keySet().stream().map(Key::game).distinct().toList())clear(g);}
}
