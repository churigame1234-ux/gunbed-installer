package kr.mzs.gunbed;
import java.util.Set;

/** Stable progression IDs. Descriptions state the Gunbed interpretation explicitly. */
enum AiChallenge {
    NONE("일반 경기","추가 제한 없음"),
    RENEGADE("Renegade · 배신자","다이아 획득·사용과 팀 업그레이드·트랩 금지"),
    WARMONGER("Warmonger · 정면 승부","유틸리티·투척·포탑·그래플링 훅 사용 금지"),
    SELFISH("Selfish · 혼자만의 자원","상자·엔더상자·아이템 버리기 금지"),
    MINIMUM_WAGE("Minimum Wage · 최저 임금","사람 팀 철·금 생성 속도 절반 · 대장간 강화 금지"),
    ASSASSIN("Assassin · 암살자","지정된 적 팀의 침대만 공격 · 적 전멸 후 다음 대상"),
    REGULAR_SHOPPER("Regular Shopper · 단골 손님","사망 시 방어구·도구 구매 등급 초기화"),
    INVISIBLE_SHOP("Invisible Shop · 보이지 않는 상점","상점 상품을 섞고 외형·이름·가격을 숨김 · 경기 동안 위치 고정"),
    COLLECTOR("Collector · 수집가","참가 중인 모든 팀 양털을 각자 상점 주민에게 제출한 뒤 승리"),
    WOODWORKER("Woodworker · 목공예가","목재 계열만 구매·획득 · 총·포탑·투척·엔더상자 금지"),
    BRIDGING_FOR_DUMMIES("Bridging for Dummies · 스펀지 다리","스펀지 외 블록 구매·획득·설치 금지 · 다리 달걀·팝업타워·이동기 금지"),
    TOXIC_RAIN("Toxic Rain · 독성 비","지붕 없이 비에 노출되면 보유 아이템 감소 · 오래 노출될수록 가속"),
    DEFUSER("Defuser · 침대 해체","적 침대 옆에서 먼저 5초 해체 · 해체 유효 시간 2분"),
    LAZY_MINER("Lazy Miner · 게으른 광부","영구 채굴 피로 · 피로 함정은 더 강하게 적용"),
    NO_HEALING("No Healing · 회복 금지","자연 회복·황금사과·치유의 샘·회복포탑 금지"),
    SLEIGHT_OF_HAND("Sleight of Hand · 한 손의 승부","핫바 한 칸과 일반 인벤 다섯 칸만 사용 · A/B 이중 수납 금지"),
    WEIGHTED_ITEMS("Weighted Items · 무거운 짐","보유 수량·장비·가상 자원 무게만큼 이동 둔화 · 이동기 금지"),
    SOCIAL_DISTANCING("Social Distancing · 거리 두기","밀치기 막대·밀치기 활만 직접 공격 가능 · 총·공격포탑·투척 금지"),
    SWORDLESS("Swordless · 칼 없는 전투","검·나이프·광선검·전기톱 금지 · 도구 근접 피해 500 제한"),
    MARKSMAN("Marksman · 명사수","활만 공격 가능 · 총·근접·투척·공격포탑 금지"),
    PATRIOT("Patriot · 애국자","자기 생성기 자원만 획득 · 적 아이템·처치 자원 획득 금지 · 적 설치 블록을 밟으면 실패"),
    STAMINA("Stamina · 체력 관리","이동·점프·공격·채굴은 스태미나 소모 · 이동기도 소모 · 사과는 충전 속도 강화"),
    OLD_MAN("Old Man · 천천히 걷기","달리기 금지 · 더블점프·그래플링 훅 금지"),
    CAPPED_RESOURCES("Capped Resources · 한정 상품","팀 상품별 구매 한도 · 자기 생성기 외 자원·적 아이템 획득 금지"),
    RED_LIGHT_GREEN_LIGHT("Red Light Green Light · 신호등","빨간 신호에 이동하면 실패 · 이동기 금지"),
    SLOW_REFLEXES("Slow Reflexes · 느린 반응","공격 피해는 2초마다 한 번 · 총·투척·포탑도 같은 제한"),
    PACIFIST("Pacifist · 평화주의자","총·근접·활 공격 금지 · 유틸리티·투척으로만 공격 · 공격포탑 금지"),
    MASTER_ASSASSIN("Master Assassin · 전문 암살자","지정 적 팀만 공격·침대 파괴 가능"),
    STANDING_TALL("Standing Tall · 당당하게","웅크리면 챌린지 실패"),
    PROTECT_THE_PRESIDENT("Protect the President · 대통령 경호","지정 대통령만 침대 파괴 · 대통령 사망 시 팀 챌린지 실패"),
    CANT_TOUCH_THIS("Can't Touch This · 무피격","피해를 받으면 실패 · 팀 침대 한 개 이상 파괴 후 승리"),
    NO_WOOL("Gunbed 추가 · 양털 금지","양털 구매·획득·설치 금지 · 다리 달걀·팝업타워 금지");
    final String title,description;
    AiChallenge(String title,String description){this.title=title;this.description=description;}
    boolean original(){return this!=NONE&&this!=NO_WOOL;}
    boolean unlocked(Set<String> completed){return new AiChallengeProgress(completed).canSelect(this);}
}
