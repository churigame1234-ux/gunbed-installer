package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerJoinEvent;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** Reads the existing common counter with SQLite mode=ro; never edits the zombie server. */
final class SharedRecommendations implements Listener {
    private final GunbedCore plugin;
    private final Path source;
    private boolean running;
    private final Map<UUID,Long> observed=new HashMap<>();
    private long lastWarning;
    SharedRecommendations(GunbedCore plugin){this.plugin=plugin;String configured=plugin.getConfig().getString("points.shared-recommendations-database","");source=configured.isBlank()?null:Path.of(configured).toAbsolutePath();if(source==null)return;Bukkit.getPluginManager().registerEvents(this,plugin);Bukkit.getScheduler().runTaskTimer(plugin,this::sync,40,100);}
    @EventHandler public void join(PlayerJoinEvent e){Bukkit.getScheduler().runTaskLater(plugin,this::sync,20);}
    private void sync(){if(running||source==null)return;List<UUID> players=Bukkit.getOnlinePlayers().stream().map(p->p.getUniqueId()).toList();if(players.isEmpty())return;running=true;Bukkit.getScheduler().runTaskAsynchronously(plugin,()->{Map<UUID,Long> counts=new HashMap<>();Exception error=null;try{if(!Files.isRegularFile(source))throw new java.io.FileNotFoundException("Common profile database is unavailable");try(Connection connection=DriverManager.getConnection("jdbc:sqlite:"+source.toUri()+"?mode=ro")){try(var settings=connection.createStatement()){settings.execute("PRAGMA query_only=ON");settings.execute("PRAGMA busy_timeout=500");}try(var query=connection.prepareStatement("SELECT votes FROM profile_counters WHERE uuid=?")){for(UUID id:players){query.setString(1,id.toString());try(var row=query.executeQuery()){if(row.next())counts.put(id,row.getLong(1));}}}}}catch(Exception e){error=e;}Exception failure=error;if(plugin.isEnabled())Bukkit.getScheduler().runTask(plugin,()->{running=false;if(failure!=null){if(System.currentTimeMillis()-lastWarning>60000){lastWarning=System.currentTimeMillis();plugin.getLogger().warning("Common recommendation sync will retry: "+failure.getMessage());}return;}for(var entry:counts.entrySet()){UUID id=entry.getKey();Long previous=observed.put(id,entry.getValue());long before=plugin.points.balance(id,PointLedger.Currency.RECOMMEND);plugin.points.syncSharedVotes(id,entry.getValue());if(previous!=null&&entry.getValue()>previous&&plugin.points.balance(id,PointLedger.Currency.RECOMMEND)>before){var voter=Bukkit.getPlayer(id);if(voter!=null){var message=TeamPalette.name(voter).append(net.kyori.adventure.text.Component.text("님이 추천하여 추천포인트를 받았습니다. 추천방법은 ",net.kyori.adventure.text.format.NamedTextColor.YELLOW)).append(net.kyori.adventure.text.Component.text("[여기 클릭]",net.kyori.adventure.text.format.NamedTextColor.AQUA).clickEvent(net.kyori.adventure.text.event.ClickEvent.openUrl("https://minelist.kr/servers/mzs123.mcv.kr")));Bukkit.broadcast(message);}}}});});}
}
