package kr.mzs.gunbed;
import java.util.*;
import java.lang.reflect.Field;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.screamingsandals.bedwars.api.BedwarsAPI;

final class TrackerStatus implements Listener {
 private final GunbedCore plugin;
 private static final Set<GunbedCore> installed=Collections.newSetFromMap(new IdentityHashMap<>());
 private TrackerStatus(GunbedCore p){plugin=p;}
 static void install(GunbedCore p){if(installed.add(p))Bukkit.getPluginManager().registerEvents(new TrackerStatus(p),p);}
 static void tick(GunbedCore plugin,Map<UUID,UUID> targets){for(Player viewer:Bukkit.getOnlinePlayers())if(!targets.containsKey(viewer.getUniqueId()))plugin.protocol.emit(viewer,Map.of("event","tracking","name",""));for(var e:targets.entrySet()){Player p=Bukkit.getPlayer(e.getKey()),target=Bukkit.getPlayer(e.getValue());if(p==null||target==null||!FixedTracker.active(p)||p.getWorld()!=target.getWorld())continue;var g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(g!=BedwarsAPI.getInstance().getGameOfPlayer(target))continue;String text=target.getGameMode()==GameMode.SPECTATOR?"추적: "+TeamPalette.display(target)+" · 리스폰 대기":"추적: "+TeamPalette.display(target)+" · "+String.format(Locale.ROOT,"%.1f",p.getLocation().distance(target.getLocation()))+"m";p.sendActionBar(net.kyori.adventure.text.Component.text(text));plugin.protocol.emit(p,Map.of("event","tracking","name",TeamPalette.display(target),"distance",p.getLocation().distance(target.getLocation()),"waiting",target.getGameMode()==GameMode.SPECTATOR));}}
 @EventHandler(priority=EventPriority.LOWEST) public void death(PlayerDeathEvent e){try{Field f=EnemyTracker.class.getDeclaredField("targets");f.setAccessible(true);((Map<?,?>)f.get(plugin.tracker)).remove(e.getEntity().getUniqueId());plugin.protocol.emit(e.getEntity(),Map.of("event","tracking","name",""));e.getEntity().sendActionBar(net.kyori.adventure.text.Component.empty());}catch(ReflectiveOperationException ex){throw new IllegalStateException(ex);}}
}
