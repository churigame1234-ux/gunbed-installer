package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import java.util.*;
/** Player name plates use the same exact RGB palette as armor, TAB and kill feeds. */
final class PlayerTags implements Listener,AutoCloseable {
    private final GunbedCore plugin;private final Map<UUID,TextDisplay> labels=new HashMap<>();
    PlayerTags(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,4,4);}
    private void tick(){for(Player player:Bukkit.getOnlinePlayers()){
        if(player.getGameMode()==GameMode.SPECTATOR||player.isInvisible()||player.isDead()){remove(player.getUniqueId());continue;}
        TextDisplay label=labels.get(player.getUniqueId());if(label==null||!label.isValid()){label=player.getWorld().spawn(player.getLocation().add(0,player.getHeight()+.3,0),TextDisplay.class,d->{d.setPersistent(false);d.setGravity(false);d.setBillboard(Display.Billboard.CENTER);d.setShadowed(true);d.setDefaultBackground(false);d.setViewRange(4);d.setTeleportDuration(3);});labels.put(player.getUniqueId(),label);player.hideEntity(plugin,label);}
        label.text(TeamPalette.name(player));label.teleport(player.getLocation().add(0,player.getHeight()+.3,0));
    }}
    private void remove(UUID id){TextDisplay label=labels.remove(id);if(label!=null)label.remove();}
    @EventHandler public void quit(PlayerQuitEvent e){remove(e.getPlayer().getUniqueId());}
    @Override public void close(){for(TextDisplay label:labels.values())label.remove();labels.clear();}
}
