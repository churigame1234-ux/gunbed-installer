package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.GameStatus;
import org.screamingsandals.bedwars.api.events.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import java.util.*;

/** Script-free combat, double jump, onboarding and respawn flight. */
final class MatchMechanics implements Listener {
    private final GunbedCore plugin;
    private final Map<UUID,Long> jumps=new HashMap<>(),tips=new HashMap<>();
    private final Map<UUID,Location> anchors=new HashMap<>();
    MatchMechanics(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,5,5);plugin.getCommand("gunbed안내끄기").setExecutor((sender,c,l,args)->{if(sender instanceof Player player&&args.length==1&&Set.of("doublejump","inventory").contains(args[0])){plugin.profiles.set(player.getUniqueId(),"tutorial-v3.hide."+args[0],true);player.sendMessage("§a이 안내를 더 이상 표시하지 않습니다.");}return true;});}
    private boolean lobby(Player p){return BedwarsAPI.getInstance().getGameOfPlayer(p)==null&&p.getGameMode()!=GameMode.SPECTATOR&&p.getGameMode()!=GameMode.CREATIVE;}
    private boolean playing(Player p){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);return g!=null&&g.getStatus()==GameStatus.RUNNING;}
    private void tick(){long now=System.currentTimeMillis();for(Player p:Bukkit.getOnlinePlayers()){
        if(!playing(p)&&!lobby(p))continue;
        if(p.getGameMode()==GameMode.SPECTATOR){p.setAllowFlight(true);p.setFlying(true);p.setFallDistance(0);if(p.getY()<p.getWorld().getMinHeight()+5){Location safe=anchors.get(p.getUniqueId());if(safe==null)safe=BedwarsAPI.getInstance().getGameOfPlayer(p).getSpectatorSpawn();if(safe!=null){p.teleport(safe.clone().add(0,2,0));p.setVelocity(new org.bukkit.util.Vector());}}continue;}
        if(p.getGameMode()==GameMode.SURVIVAL||p.getGameMode()==GameMode.ADVENTURE){if(plugin.inventories.locked(p)||plugin.weaponModes.anchored(p)){p.setAllowFlight(false);p.setVelocity(new org.bukkit.util.Vector());}else if(p.isOnGround()&&now-jumps.getOrDefault(p.getUniqueId(),0L)>=3000)p.setAllowFlight(true);}
        if(now>=tips.getOrDefault(p.getUniqueId(),0L)){tips.put(p.getUniqueId(),now+60000);if(!p.getName().equalsIgnoreCase("GMdong")){tip(p,"doublejump","§b더블점프: §f점프한 뒤 공중에서 스페이스를 한 번 더 누르세요. §7재사용 3초");tip(p,"inventory","§eA/B 인벤토리: §fF로 전환 · A는 무기 4칸, B는 블록·도구·소모품입니다.");}}

    }}
    private void tip(Player p,String kind,String text){if(plugin.profiles.get(p.getUniqueId()).getBoolean("tutorial-v3.hide."+kind,false))return;p.sendMessage(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(text).append(Component.text(" [더 이상 표시하지 않기]",net.kyori.adventure.text.format.NamedTextColor.DARK_GRAY).clickEvent(ClickEvent.runCommand("/gunbed안내끄기 "+kind))));}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void jump(PlayerToggleFlightEvent e){Player p=e.getPlayer();if((!playing(p)&&!lobby(p))||p.getGameMode()==GameMode.SPECTATOR||p.getGameMode()==GameMode.CREATIVE)return;e.setCancelled(true);p.setFlying(false);p.setAllowFlight(false);if(plugin.inventories.locked(p)||System.currentTimeMillis()-jumps.getOrDefault(p.getUniqueId(),0L)<3000)return;jumps.put(p.getUniqueId(),System.currentTimeMillis());DoubleJumpFallGrace.launch(p);var direction=p.getLocation().getDirection().setY(0);if(direction.lengthSquared()>.0001)direction.normalize().multiply(.65);p.setVelocity(direction.setY(.65));String sound=plugin.profiles.get(p.getUniqueId()).getString("cosmetics.jump-effect","");Sound effect=switch(sound){case "chime"->Sound.BLOCK_AMETHYST_BLOCK_CHIME;case "breeze"->Sound.ENTITY_BREEZE_JUMP;case "note"->Sound.BLOCK_NOTE_BLOCK_PLING;default->Sound.ENTITY_BAT_TAKEOFF;};p.playSound(p.getLocation(),effect,.4f,1.4f);}
    @EventHandler(priority=EventPriority.MONITOR)public void gameMode(PlayerGameModeChangeEvent e){if(e.getNewGameMode()==GameMode.SPECTATOR&&playing(e.getPlayer()))Bukkit.getScheduler().runTask(plugin,()->{e.getPlayer().setAllowFlight(true);e.getPlayer().setFlying(true);e.getPlayer().setFallDistance(0);});}
    @EventHandler(priority=EventPriority.LOWEST)public void death(PlayerDeathEvent e){var g=BedwarsAPI.getInstance().getGameOfPlayer(e.getEntity());if(g!=null&&g.getTeamOfPlayer(e.getEntity())!=null)anchors.put(e.getEntity().getUniqueId(),e.getEntity().getLocation().clone());}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void fall(EntityDamageEvent e){if(e.getEntity() instanceof Player p&&playing(p)){if(p.getGameMode()==GameMode.SPECTATOR)e.setCancelled(true);else if(e.getCause()==EntityDamageEvent.DamageCause.FALL&&!RoundFalls.applying())e.setCancelled(true);}}
    static double blade(ItemStack item){if(item==null)return 0;return switch(item.getType()){case WOODEN_SWORD->800;case STONE_SWORD->1000;case IRON_SWORD->1200;case DIAMOND_SWORD,NETHERITE_SWORD->1400;default->0;};}
    void lore(ItemStack item){double damage=blade(item);if(damage>0&&plugin.damages!=null)damage=plugin.damages.melee(item,damage);if(damage==0)return;var meta=item.getItemMeta();List<String> lines=new ArrayList<>(meta.hasLore()?meta.getLore():List.of());lines.removeIf(s->ChatColor.stripColor(s).startsWith("기본 피해:"));lines.add("§7기본 피해: §c"+(int)damage+" §8(방어구 적용 전 · 체력 10,000 기준)");meta.setLore(lines);item.setItemMeta(meta);}
    @EventHandler(priority=EventPriority.HIGH,ignoreCancelled=true)public void melee(EntityDamageByEntityEvent e){if(!(e.getDamager() instanceof Player p)||!playing(p))return;if(plugin.inventories.locked(p)){e.setCancelled(true);return;}if(BlastExposure.applying()||plugin.taWeapons.damageDefinition()!=null||plugin.throwables.damageKind()!=null)return;ItemStack item=p.getInventory().getItemInMainHand();if(plugin.visuals!=null&&plugin.visuals.cs.getWeaponTitle(item)!=null)return;if(plugin.addonMelee.held(p)!=null||plugin.turrets!=null&&plugin.turrets.damageContext())return;double damage=plugin.damages==null?blade(item):plugin.damages.melee(item,1);e.setDamage(damage);}
    @EventHandler public void durability(PlayerItemDamageEvent e){if(playing(e.getPlayer()))e.setCancelled(true);}
    @EventHandler public void start(BedwarsGameStartedEvent e){for(Player p:e.getGame().getConnectedPlayers())tips.remove(p.getUniqueId());}
    @EventHandler public void leave(BedwarsPlayerLeaveEvent e){UUID id=e.getPlayer().getUniqueId();anchors.remove(id);jumps.remove(id);tips.remove(id);}
}
