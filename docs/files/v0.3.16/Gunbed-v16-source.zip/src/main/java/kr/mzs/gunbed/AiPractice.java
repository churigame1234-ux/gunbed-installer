package kr.mzs.gunbed;

import kr.mzs.botcore.api.MzsBot;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.generator.ChunkGenerator;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.*;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/** One real-player team versus an equally sized, server-owned AI team. */
final class AiPractice implements Listener,AutoCloseable {
    enum Difficulty {EASY("쉬움",10,4.0,8),MEDIUM("중간",6,2.0,5),HARD("어려움",3,.8,3);final String title;final int reaction,build;final double error;Difficulty(String t,int r,double e,int b){title=t;reaction=r;error=e;build=b;}}
    static final class Room {Game game;final Difficulty difficulty;final AiChallenge challenge;final List<MzsBot> bots=new ArrayList<>();final Set<UUID> enrolled=new HashSet<>();boolean syncing,closing;long emptySince;Room(Difficulty d,AiChallenge c){difficulty=d;challenge=c;}}
    private record Menu(String kind,Difficulty difficulty) implements InventoryHolder{public Inventory getInventory(){throw new UnsupportedOperationException();}}
    private record Held(ItemStack original){}
    private final GunbedCore plugin;private final BotRuntime runtime;
    private final Map<String,Room> rooms=new HashMap<>();private final Map<Game,Room> games=new HashMap<>();
    private final Map<UUID,Held> menuItems=new HashMap<>();private final Set<UUID> admitted=new HashSet<>();private final Set<String> loading=new HashSet<>();
    private final AtomicInteger sequence=new AtomicInteger();private final NamespacedKey token;
    private final AiBrain brain;private final org.bukkit.scheduler.BukkitTask ticker;
    AiPractice(GunbedCore p){plugin=p;runtime=new BotRuntime();brain=new AiBrain(p,runtime);token=new NamespacedKey(p,"ai_play");Bukkit.getPluginManager().registerEvents(this,p);ticker=Bukkit.getScheduler().runTaskTimer(p,this::tick,2,2);}
    static boolean arena(Game g){return g!=null&&g.getName().startsWith("AI_Orchestra_");}
    Room room(Game g){return games.get(g);}
    Room room(Player p){return room(BedwarsAPI.getInstance().getGameOfPlayer(p));}
    List<Player> humans(Room r){return r.game.getConnectedPlayers().stream().filter(p->!BotRuntime.bot(p)&&(r.game.getStatus()==GameStatus.WAITING||p.getGameMode()!=GameMode.SPECTATOR)).toList();}
    private ItemStack icon(Material material,String name,String...lore){ItemStack i=new ItemStack(material);var m=i.getItemMeta();m.setDisplayName(name);m.setLore(List.of(lore));i.setItemMeta(m);return i;}
    private boolean token(ItemStack item){return item!=null&&item.hasItemMeta()&&item.getItemMeta().getPersistentDataContainer().has(token);}
    ItemStack entry(){ItemStack i=icon(Material.PLAYER_HEAD,"§bAI 유저와 플레이","§7Orchestra · 쉬움/중간/어려움","§7사람 N명 vs AI N명 · 챌린지 선택 가능");var m=i.getItemMeta();m.getPersistentDataContainer().set(token,PersistentDataType.BYTE,(byte)1);i.setItemMeta(m);return i;}
    void attachEntry(Player p){restore(p);ItemStack old=p.getInventory().getItem(22);menuItems.put(p.getUniqueId(),new Held(old==null?null:old.clone()));p.getInventory().setItem(22,entry());}
    private void restore(Player p){Held h=menuItems.remove(p.getUniqueId());if(h!=null&&token(p.getInventory().getItem(22)))p.getInventory().setItem(22,h.original);}
    void maps(Player p){Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(g!=null){p.sendMessage("§e현재 경기를 나간 뒤 AI전에 참가하세요.");return;}Inventory inv=Bukkit.createInventory(new Menu("maps",null),27,"AI 유저와 플레이 · 맵");inv.setItem(13,icon(Material.JUKEBOX,"§aOrchestra","§7첫 실험 지원 맵 · 자동 학습 완료를 뜻하지 않습니다.","§7완료 경기 데이터: "+(plugin.learning==null?0:plugin.learning.episodes()),"§7사람과 AI는 서로 다른 팀 · 5대5 이상 지원","§e클릭하여 난이도 선택"));p.openInventory(inv);}
    private void difficulties(Player p){Inventory inv=Bukkit.createInventory(new Menu("difficulty",null),27,"Orchestra · AI 난이도");for(Difficulty d:Difficulty.values())inv.setItem(10+d.ordinal()*3,icon(d==Difficulty.EASY?Material.LIME_CONCRETE:d==Difficulty.MEDIUM?Material.YELLOW_CONCRETE:Material.RED_CONCRETE,"§e"+d.title,"§7반응 약 "+d.reaction*50+"ms · 조준 오차 "+d.error+"°","§7재료·탄약·피해·블록 규칙은 유저와 동일","§e클릭하여 챌린지 선택"));p.openInventory(inv);}
    private AiChallengeProgress progress(UUID id){return new AiChallengeProgress(plugin.profiles.get(id).getStringList("ai-challenges.completed"));}
    private Set<String> completed(Player p){return new HashSet<>(progress(p.getUniqueId()).saved());}
    /** Called only by the validated challenge result handler, never on joining or selecting. */
    void recordCompletion(UUID id,AiChallenge challenge){
        AiChallengeProgress before=progress(id),after=before.withCompletion(challenge);
        if(before==after)return;
        plugin.profiles.set(id,"ai-challenges.completed",after.saved());
        plugin.profiles.flush();
    }
    void challenges(Player p,Difficulty difficulty){
        Inventory inv=Bukkit.createInventory(new Menu("challenge",difficulty),54,difficulty.title+" · 챌린지 선택");
        AiChallengeProgress progress=progress(p.getUniqueId());
        for(AiChallenge c:AiChallenge.values()){
            boolean open=progress.canSelect(c),done=progress.completed(c);
            Room room=rooms.get(difficulty.name()+"_"+c.name());
            boolean accompany=room!=null&&room.game.getStatus()==GameStatus.WAITING&&!humans(room).isEmpty();
            String state=done?"§a완료 · 다시 도전 가능":open?"§a방 생성 가능":accompany?"§b방장 대기 중 · 미해금이어도 동행 가능":"§c방 생성 잠김 · 앞선 순서를 완료하세요";
            inv.setItem(c.ordinal(),icon(done?Material.EMERALD:open?Material.PAPER:accompany?Material.PLAYER_HEAD:Material.BARRIER,
                    (open?"§e":accompany?"§b":"§c")+c.title,"§7"+c.description,state,
                    "§7동행하여 완료한 챌린지만 개별 해금됩니다.",
                    "§7앞뒤의 미완료 챌린지는 자동으로 열리지 않습니다.",
                    c==AiChallenge.NO_WOOL?"§dGunbed 자체 추가 · 원작 순서와 별개":"§7사람 팀 전체 적용 · 상대 AI는 일반 규칙"));
        }
        p.openInventory(inv);
    }
    void enter(Player p,Difficulty difficulty,AiChallenge challenge){String id=difficulty.name()+"_"+challenge.name();Room existing=rooms.get(id);if(existing!=null&&!humans(existing).isEmpty()){join(p,existing);return;}if(!challenge.unlocked(completed(p))){p.sendMessage("§c아직 직접 선택할 수 없는 챌린지입니다. 대기 중인 방장이 있으면 동행할 수 있습니다.");return;}if(existing!=null){join(p,existing);return;}if(!loading.add(id)){p.sendMessage("§eAI 경기장을 준비하고 있습니다. 잠시 후 다시 눌러주세요.");return;}p.closeInventory();p.sendMessage("§bAI 전용 Orchestra를 준비합니다.");Path template=plugin.getDataFolder().toPath().resolve("ai-template"),destination=Bukkit.getWorldContainer().toPath().toAbsolutePath().resolve("gunbed_ai_"+id.toLowerCase(Locale.ROOT));
        Bukkit.getScheduler().runTaskAsynchronously(plugin,()->{try{if(!Files.isRegularFile(template.resolve("manifest.json")))throw new IOException("AI template missing");if(!destination.normalize().getParent().equals(Bukkit.getWorldContainer().toPath().toAbsolutePath().normalize()))throw new IOException("Unsafe world path");if(!Files.exists(destination)){Files.createDirectories(destination);try(var walk=Files.walk(template)){for(Path from:walk.filter(Files::isRegularFile).toList()){Path relative=template.relativize(from);if(relative.toString().equals("arena.yml")||relative.toString().equals("manifest.json"))continue;Path to=destination.resolve(relative);Files.createDirectories(to.getParent());Files.copy(from,to);}}Files.writeString(destination.resolve(".gunbed-ai-world"),"Orchestra_8");}else if(!Files.isRegularFile(destination.resolve(".gunbed-ai-world")))throw new IOException("Unmanaged AI world folder");Bukkit.getScheduler().runTask(plugin,()->{try{Room r=load(id,difficulty,challenge,destination);if(p.isOnline())join(p,r);}catch(Exception e){plugin.getLogger().log(java.util.logging.Level.SEVERE,"AI arena load failed",e);if(p.isOnline())p.sendMessage("§cAI 경기장 준비에 실패했습니다.");}finally{loading.remove(id);}});}catch(IOException e){loading.remove(id);plugin.getLogger().warning("AI template copy failed: "+e.getMessage());Bukkit.getScheduler().runTask(plugin,()->{if(p.isOnline())p.sendMessage("§cAI 경기장 준비에 실패했습니다. 기존 월드는 변경하지 않았습니다.");});}});
    }
    private Room load(String id,Difficulty d,AiChallenge c,Path destination)throws IOException{World w=Bukkit.getWorld(destination.getFileName().toString());if(w==null)w=Bukkit.createWorld(new WorldCreator(destination.getFileName().toString()).generator(new ChunkGenerator(){@Override public ChunkData generateChunkData(World world,Random random,int x,int z,BiomeGrid biomes){return createChunkData(world);}}));if(w==null)throw new IOException("AI world load failed");w.setAutoSave(true);w.setGameRule(GameRule.DO_MOB_SPAWNING,false);w.setGameRule(GameRule.DO_DAYLIGHT_CYCLE,false);w.setGameRule(GameRule.DO_WEATHER_CYCLE,false);w.setGameRule(GameRule.KEEP_INVENTORY,true);w.setTime(6000);var cfg=YamlConfiguration.loadConfiguration(plugin.getDataFolder().toPath().resolve("ai-template/arena.yml").toFile());cfg.set("name","AI_Orchestra_"+id);cfg.set("world",w.getName());cfg.set("lobbySpawnWorld",w.getName());for(String team:cfg.getConfigurationSection("teams").getKeys(false))cfg.set("teams."+team+".maxPlayers",64);Path file=plugin.getDataFolder().toPath().resolve("ai-arenas/"+id+".yml");Files.createDirectories(file.getParent());cfg.save(file.toFile());Game g=org.screamingsandals.bedwars.game.Game.loadGame(file.toFile());if(g==null)throw new IOException("AI game definition load failed");Room r=new Room(d,c);r.game=g;rooms.put(id,r);games.put(g,r);plugin.restores.recover();return r;}
    private void join(Player p,Room r){if(BedwarsAPI.getInstance().getGameOfPlayer(p)!=null)return;if(r.game.getStatus()!=GameStatus.WAITING||plugin.restores.busy(r.game)){p.sendMessage("§e이 난이도·챌린지 경기가 진행 중이거나 복구 중입니다.");return;}if(humans(r).size()>=64){p.sendMessage("§c사람 팀이 가득 찼습니다.");return;}admitted.add(p.getUniqueId());try{r.game.joinToGame(p);}finally{admitted.remove(p.getUniqueId());}if(BedwarsAPI.getInstance().getGameOfPlayer(p)==r.game){r.enrolled.add(p.getUniqueId());p.sendMessage("§b"+r.difficulty.title+" · "+r.challenge.title+" · 준비하면 동일 인원 AI와 시작합니다.");}}
    boolean canStart(Game g){Room r=room(g);return r!=null&&!r.syncing&&!humans(r).isEmpty()&&humans(r).size()==r.bots.size();}
    boolean assign(Game g){Room r=room(g);if(!canStart(g))return false;for(Player p:g.getConnectedPlayers())plugin.waiting.fixed(p,g.getTeamFromName(BotRuntime.bot(p)?"light_blue":"red"));return true;}
    private void sync(Room r){if(r.closing||r.game.getStatus()!=GameStatus.WAITING)return;r.bots.removeIf(b->{if(b.getPlayer().isOnline())return false;brain.remove(b);runtime.remove(b);return true;});int wanted=humans(r).size();if(wanted==0){for(MzsBot b:List.copyOf(r.bots)){brain.remove(b);runtime.remove(b);}r.bots.clear();return;}if(r.bots.size()>wanted){MzsBot b=r.bots.removeLast();brain.remove(b);runtime.remove(b);return;}if(r.bots.size()<wanted){r.syncing=true;try{MzsBot b=runtime.spawn(r.game.getLobbySpawn(),"GB_AI_"+sequence.incrementAndGet());r.bots.add(b);r.game.joinToGame(b.getPlayer());plugin.waiting.fixed(b.getPlayer(),r.game.getTeamFromName("light_blue"));brain.add(r,b,r.bots.size()-1);}finally{r.syncing=false;}}for(Player p:humans(r))plugin.waiting.fixed(p,r.game.getTeamFromName("red"));}
    private void tick(){int tick=Bukkit.getCurrentTick();for(Room r:List.copyOf(games.values())){if(r.game.getStatus()==GameStatus.WAITING)sync(r);if(r.game.getStatus()==GameStatus.RUNNING){if(r.game.getConnectedPlayers().stream().noneMatch(p->!BotRuntime.bot(p))){if(r.emptySince==0)r.emptySince=System.currentTimeMillis();if(System.currentTimeMillis()-r.emptySince>60000){r.game.stop();((org.screamingsandals.bedwars.game.Game)r.game).rebuild();LegacyActions.clear(r.game);r.game.start();}}else r.emptySince=0;}}brain.tick(tick);}
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void joinEvent(BedwarsPlayerJoinEvent e){Room r=room(e.getGame());if(r==null||BotRuntime.bot(e.getPlayer()))return;if(e.getGame().getStatus()==GameStatus.WAITING&&!admitted.contains(e.getPlayer().getUniqueId())){e.setCancelled(true);e.getPlayer().sendMessage("§e로비 AI 메뉴로 참가하세요.");}}
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void team(BedwarsPlayerJoinTeamEvent e){if(arena(e.getGame())&&!BotRuntime.bot(e.getPlayer())&&e.getTeam()!=null&&!e.getTeam().getName().equals("red"))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST)public void started(BedwarsGameStartedEvent e){Room r=room(e.getGame());if(r!=null)for(Player p:e.getGame().getConnectedPlayers())if(!BotRuntime.bot(p))r.enrolled.add(p.getUniqueId());}
    @EventHandler public void end(BedwarsGameEndEvent e){Room r=room(e.getGame());if(r==null)return;r.closing=true;Bukkit.getScheduler().runTask(plugin,()->{for(MzsBot b:List.copyOf(r.bots)){brain.remove(b);runtime.remove(b);}r.bots.clear();r.enrolled.clear();r.closing=false;r.emptySince=0;});}
    @EventHandler(priority=EventPriority.LOWEST)public void click(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p))return;if(token(e.getCurrentItem())||token(e.getCursor())){e.setCancelled(true);if(token(e.getCurrentItem()))maps(p);return;}if(!(e.getView().getTopInventory().getHolder() instanceof Menu m))return;e.setCancelled(true);int slot=e.getRawSlot();if(m.kind.equals("maps")&&slot==13)difficulties(p);else if(m.kind.equals("difficulty")){int n=List.of(10,13,16).indexOf(slot);if(n>=0)challenges(p,Difficulty.values()[n]);}else if(m.kind.equals("challenge")&&slot>=0&&slot<AiChallenge.values().length)enter(p,m.difficulty,AiChallenge.values()[slot]);}
    @EventHandler public void closeMenu(InventoryCloseEvent e){if(e.getPlayer() instanceof Player p)restore(p);}
    @EventHandler public void drop(PlayerDropItemEvent e){if(token(e.getItemDrop().getItemStack()))e.setCancelled(true);}
    @EventHandler public void drag(InventoryDragEvent e){if(token(e.getOldCursor())||e.getView().getTopInventory().getHolder() instanceof Menu)e.setCancelled(true);}
    @EventHandler public void quit(PlayerQuitEvent e){restore(e.getPlayer());}
    @Override public void close(){ticker.cancel();for(Player p:Bukkit.getOnlinePlayers())restore(p);for(Room r:List.copyOf(games.values())){r.closing=true;for(MzsBot b:List.copyOf(r.bots)){brain.remove(b);runtime.remove(b);}r.bots.clear();}brain.close();}
}
