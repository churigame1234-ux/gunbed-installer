package kr.mzs.gunbed;

import com.google.gson.Gson;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.*;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.io.*;

/** Local outcome-weighted imitation statistics, not a remote model or video trainer. */
final class AiLearning implements Listener,AutoCloseable {
    private record Decision(String context,String action){}
    private static final class Trace {Map<Decision,Integer> decisions=new HashMap<>();Set<String> cells=new HashSet<>();int beds,kills,deaths;}
    private record Aggregate(long samples,double reward){}
    private final GunbedCore plugin;
    private final Gson gson=new Gson();
    private final Map<Game,Map<UUID,Trace>> traces=new HashMap<>();
    private final Map<String,Aggregate> values=new HashMap<>();
    private final ArrayBlockingQueue<String> records=new ArrayBlockingQueue<>(8192);
    private final Path folder,model;
    private final org.bukkit.scheduler.BukkitTask sampler,writer;
    private long episodes,dropped;
    private volatile String pendingModel;
    AiLearning(GunbedCore p){plugin=p;folder=p.getDataFolder().toPath().resolve("ai-learning");model=folder.resolve("policy.yml");try{Files.createDirectories(folder);}catch(IOException e){throw new UncheckedIOException(e);}var cfg=YamlConfiguration.loadConfiguration(model.toFile());episodes=cfg.getLong("episodes");var section=cfg.getConfigurationSection("values");if(section!=null)for(String key:section.getKeys(false))values.put(key,new Aggregate(cfg.getLong("values."+key+".samples"),cfg.getDouble("values."+key+".reward")));Bukkit.getPluginManager().registerEvents(this,p);sampler=Bukkit.getScheduler().runTaskTimer(p,this::sample,4,4);writer=Bukkit.getScheduler().runTaskTimerAsynchronously(p,this::flush,40,40);}
    static String map(Game g){return g.getName().startsWith("AI_Orchestra_")?"Orchestra_8":g.getName();}
    private String encode(String key){return Base64.getUrlEncoder().withoutPadding().encodeToString(key.getBytes(StandardCharsets.UTF_8));}
    private Trace trace(Game g,Player p){return traces.computeIfAbsent(g,k->new HashMap<>()).computeIfAbsent(p.getUniqueId(),k->new Trace());}
    private Player enemy(Player p,Game g){var team=g.getTeamOfPlayer(p);return g.getConnectedPlayers().stream().filter(q->q!=p&&!q.isDead()&&q.getGameMode()!=GameMode.SPECTATOR&&q.getWorld()==p.getWorld()&&g.getTeamOfPlayer(q)!=null&&!team.isPlayerInTeam(q)&&p.hasLineOfSight(q)).min(Comparator.comparingDouble(q->q.getLocation().distanceSquared(p.getLocation()))).orElse(null);}
    String context(Player p,Game g,Player enemy){double distance=enemy==null?999:enemy.getLocation().distance(p.getLocation());double hp=p.getHealth()/Math.max(1,p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());return map(g)+"|"+(distance<5?"close":distance<20?"near":distance<60?"far":"travel")+"|"+(hp<.33?"low":hp<.66?"hurt":"healthy");}
    private String cell(Game g,Player p,Location at){var team=g.getTeamOfPlayer(p);if(team==null)return "";Location origin=team.getTeamSpawn();int sign=origin.getX()<-3196?1:-1;return map(g)+"/"+(int)Math.floor((at.getX()-origin.getX())*sign/2)+"/"+(int)Math.floor((at.getY()-origin.getY())/2)+"/"+(int)Math.floor((at.getZ()-origin.getZ())/2);}
    void action(Player p,String action){Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(g==null||g.getStatus()!=GameStatus.RUNNING||g.getTeamOfPlayer(p)==null||BotRuntime.bot(p))return;trace(g,p).decisions.merge(new Decision(context(p,g,enemy(p,g)),action),1,Integer::sum);}
    private void sample(){for(Game g:BedwarsAPI.getInstance().getGames())if(g.getStatus()==GameStatus.RUNNING)for(Player p:g.getConnectedPlayers()){if(BotRuntime.bot(p)||g.getTeamOfPlayer(p)==null||p.isDead()||p.getGameMode()==GameMode.SPECTATOR)continue;Player foe=enemy(p,g);String action=p.getHealth()/p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue()<.33&&foe!=null?"retreat":p.isSneaking()?"careful":p.getVelocity().lengthSquared()>.015?"advance":"hold";Trace t=trace(g,p);t.decisions.merge(new Decision(context(p,g,foe),action),1,Integer::sum);t.cells.add(cell(g,p,p.getLocation()));Map<String,Object> row=new LinkedHashMap<>();row.put("tick",Bukkit.getCurrentTick());row.put("round",g.getName());row.put("map",map(g));row.put("player",p.getUniqueId().toString());row.put("team",g.getTeamOfPlayer(p).getName());row.put("pos",List.of(p.getX(),p.getY(),p.getZ()));row.put("look",List.of(p.getYaw(),p.getPitch()));row.put("velocity",List.of(p.getVelocity().getX(),p.getVelocity().getY(),p.getVelocity().getZ()));row.put("health",p.getHealth());row.put("weapon",plugin.ammo.id(p.getInventory().getItemInMainHand()));row.put("sprint",p.isSprinting());row.put("sneak",p.isSneaking());row.put("action",action);if(!records.offer(gson.toJson(row)))dropped++;}}
    double preference(String context,String action){var a=values.get(encode("choice/"+context+"/"+action));return a==null||a.samples<3?0:Math.max(-.35,Math.min(.35,a.reward/a.samples*.2));}
    double routeScore(Game g,Player bot,Location at){var a=values.get(encode("route/"+cell(g,bot,at)));return a==null?0:Math.max(-.25,Math.min(.25,a.reward/Math.max(1,a.samples)*.15));}
    long episodes(){return episodes;}
    private void add(String key,int n,double reward){String id=encode(key);Aggregate a=values.getOrDefault(id,new Aggregate(0,0));values.put(id,new Aggregate(a.samples+n,a.reward+reward*n));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void place(BlockPlaceEvent e){action(e.getPlayer(),"build");}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void broken(BlockBreakEvent e){action(e.getPlayer(),"break");}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void consume(PlayerItemConsumeEvent e){action(e.getPlayer(),"heal");}
    @EventHandler(priority=EventPriority.MONITOR)public void bed(BedwarsTargetBlockDestroyedEvent e){if(e.getPlayer()!=null&&!BotRuntime.bot(e.getPlayer()))trace(e.getGame(),e.getPlayer()).beds++;}
    @EventHandler(priority=EventPriority.MONITOR)public void kill(BedwarsPlayerKilledEvent e){if(!BotRuntime.bot(e.getPlayer()))trace(e.getGame(),e.getPlayer()).deaths++;Player p=e.getKiller()==null?plugin.combatPresentation.credit(e.getPlayer()):e.getKiller();if(p!=null&&!BotRuntime.bot(p))trace(e.getGame(),p).kills++;}
    @EventHandler(priority=EventPriority.MONITOR)public void ending(BedwarsGameEndingEvent e){Map<UUID,Trace> round=traces.remove(e.getGame());if(round==null)return;for(var entry:round.entrySet()){Player p=Bukkit.getPlayer(entry.getKey());if(p==null)continue;Trace t=entry.getValue();boolean won=e.getWinningTeam()!=null&&e.getWinningTeam().isPlayerInTeam(p);double reward=(won?1:-1)+Math.min(.5,t.beds*.2+t.kills*.025)-Math.min(.3,t.deaths*.02);for(var d:t.decisions.entrySet())add("choice/"+d.getKey().context+"/"+d.getKey().action,Math.min(100,d.getValue()),reward);for(String cell:t.cells)add("route/"+cell,1,reward);episodes++;}save();}
    @EventHandler public void end(BedwarsGameEndEvent e){traces.remove(e.getGame());}
    private void save(){var cfg=new YamlConfiguration();cfg.set("schema",1);cfg.set("episodes",episodes);cfg.set("dropped-samples",dropped);cfg.set("method","outcome-weighted local imitation statistics");for(var e:values.entrySet()){cfg.set("values."+e.getKey()+".samples",e.getValue().samples);cfg.set("values."+e.getKey()+".reward",e.getValue().reward);}pendingModel=cfg.saveToString();}
    private synchronized void flush(){try{List<String> batch=new ArrayList<>(4096);records.drainTo(batch,4096);if(!batch.isEmpty())Files.write(folder.resolve("observations-"+LocalDate.now()+".jsonl"),batch,StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.APPEND);String next=pendingModel;if(next!=null){Path temp=model.resolveSibling("policy.yml.tmp");Files.writeString(temp,next,StandardCharsets.UTF_8);Files.move(temp,model,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);if(pendingModel==next)pendingModel=null;}}catch(IOException e){plugin.getLogger().warning("AI learning log write failed: "+e.getMessage());}}
    @Override public void close(){sampler.cancel();writer.cancel();save();flush();traces.clear();}
}
