package kr.mzs.gunbed;

import com.google.gson.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;
import org.bukkit.util.Transformation;
import org.joml.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.lang.Math;

/** Independent server-authoritative engine using the free default pack's data, not CrackShot. */
final class TaczWeapons implements Listener,AutoCloseable {
    record Definition(String id,String name,String type,JsonObject data,JsonObject display,JsonObject clips){}
    private record Feed(long at,int count,long start){Feed(long at,int count){this(at,count,0);}}
    private static final class State {String id="";boolean trigger,aim,previous,pendingPress;long nextShot,reloadEnd,inputAt;int mode,burstLeft,slot=-1,feedIndex;long reloadStarted;List<Feed> feeds=List.of();}
    private static final class DamageContext {final Player source;final LivingEntity victim;final double ignore;final Definition gun;boolean applied;DamageContext(Player source,LivingEntity victim,double ignore,Definition gun){this.source=source;this.victim=victim;this.ignore=ignore;this.gun=gun;}}
    private final ThreadLocal<DamageContext> context=new ThreadLocal<>();
    private final GunbedCore plugin;
    private final NamespacedKey weaponKey,ammoKey,reserveKey;
    private final LinkedHashMap<String,Definition> guns=new LinkedHashMap<>();
    private final Map<UUID,State> states=new HashMap<>();
    private final List<Bullet> bullets=new ArrayList<>();
    private final List<Casing> casings=new ArrayList<>();
    TaczWeapons(GunbedCore plugin){this.plugin=plugin;weaponKey=new NamespacedKey(plugin,"ta_weapon");ammoKey=new NamespacedKey(plugin,"ta_ammo");reserveKey=new NamespacedKey(plugin,"ta_reserve_kind");
        try(var in=plugin.getResource("tacz-catalog.json")){var root=JsonParser.parseReader(new InputStreamReader(Objects.requireNonNull(in),StandardCharsets.UTF_8)).getAsJsonObject().getAsJsonObject("guns");for(var e:root.entrySet()){var o=e.getValue().getAsJsonObject();guns.put(e.getKey(),new Definition(e.getKey(),o.get("name").getAsString(),o.get("type").getAsString(),o.getAsJsonObject("data"),o.getAsJsonObject("display"),o.has("clips")?o.getAsJsonObject("clips"):new JsonObject()));}}catch(IOException e){throw new UncheckedIOException(e);}
        Bukkit.getPluginManager().registerEvents(this,plugin);Bukkit.getScheduler().runTaskTimer(plugin,this::tick,1,1);plugin.getLogger().info("Independent TA catalogue: "+guns.size()+" free built-in guns.");
    }
    Definition damageDefinition(){DamageContext active=context.get();return active==null?null:active.gun;}
    Collection<Definition> definitions(){return guns.values();}
    Definition held(Player p){return definition(p.getInventory().getItemInMainHand());}
    Definition definition(ItemStack item){if(item==null||!item.hasItemMeta())return null;return guns.get(item.getItemMeta().getPersistentDataContainer().get(weaponKey,PersistentDataType.STRING));}
    ItemStack create(String id){Definition d=guns.get(id);if(d==null)return null;ItemStack item=new ItemStack(Material.PAPER);var meta=item.getItemMeta();meta.getPersistentDataContainer().set(weaponKey,PersistentDataType.STRING,id);meta.getPersistentDataContainer().set(ammoKey,PersistentDataType.INTEGER,capacity(d));meta.setItemModel(new NamespacedKey("gunbed","ta/"+id));item.setItemMeta(meta);rename(item,d,capacity(d));return item;}
    private void rename(ItemStack item,Definition d,int ammo){var meta=item.getItemMeta();meta.setDisplayName("§6[TA] §f"+d.name+" §7«"+(ammo<0?"∞":ammo)+"»");meta.setLore(plugin.specs==null?List.of("§7왼쪽 발사 · 오른쪽 조준 · R 재장전"):plugin.specs.ta(d));item.setItemMeta(meta);}
    int capacity(Definition d){return d.id.equals("minigun")?200:integer(d.data,"ammo_amount",-1);}
    int ammo(Player p){var d=held(p);if(d==null)return 0;if(capacity(d)<0)return reserve(p,d);return loaded(p.getInventory().getItemInMainHand());}
    int loaded(ItemStack item){var d=definition(item);if(d==null)return 0;int value=item.getItemMeta().getPersistentDataContainer().getOrDefault(ammoKey,PersistentDataType.INTEGER,capacity(d));if(d.id.equals("minigun")&&(value<0||value>200)){value=200;var meta=item.getItemMeta();meta.getPersistentDataContainer().set(ammoKey,PersistentDataType.INTEGER,value);item.setItemMeta(meta);rename(item,d,value);}return value;}
    private String ammunition(Definition d){return d.data.get("ammo").getAsString();}
    int reserve(Player p,Definition d){return plugin.ammo==null?0:plugin.ammo.reserve(p,"ta:"+d.id);}
    ItemStack reserveItem(Definition d,int amount){ItemStack item=new ItemStack(Material.IRON_NUGGET,amount);var meta=item.getItemMeta();meta.setDisplayName("§e[TA 탄약] §f"+ammunition(d).replace("tacz:",""));meta.getPersistentDataContainer().set(reserveKey,PersistentDataType.STRING,ammunition(d));item.setItemMeta(meta);return item;}
    void giveReserve(Player p,Definition d,int amount){plugin.ammo.add(p,"ta:"+d.id,amount);}
    private int consumeReserve(Player p,Definition d,int maximum){return plugin.ammo.consume(p,"ta:"+d.id,maximum);}
    private void ammo(Player p,Definition d,int value){ItemStack item=p.getInventory().getItemInMainHand();if(definition(item)!=d)return;var meta=item.getItemMeta();meta.getPersistentDataContainer().set(ammoKey,PersistentDataType.INTEGER,value);item.setItemMeta(meta);rename(item,d,value);}
    private State state(Player p,Definition d){State s=states.computeIfAbsent(p.getUniqueId(),id->new State());if(!s.id.equals(d.id)||s.slot!=p.getInventory().getHeldItemSlot()){s.id=d.id;s.slot=p.getInventory().getHeldItemSlot();s.previous=false;s.trigger=false;s.reloadEnd=0;s.mode=0;s.burstLeft=0;s.pendingPress=false;}return s;}
    String mode(Player p){Definition d=held(p);if(d==null)return "";var modes=d.data.getAsJsonArray("fire_mode");State s=state(p,d);return modes.get(Math.floorMod(s.mode,modes.size())).getAsString();}
    void input(Player p,boolean trigger,boolean aim){Definition d=held(p);if(d==null)return;State s=state(p,d);if(trigger&&!s.trigger)s.pendingPress=true;s.trigger=trigger;s.aim=aim;s.inputAt=System.currentTimeMillis();}
    void cycleMode(Player p){Definition d=held(p);if(d==null)return;State s=state(p,d);s.burstLeft=0;s.mode++;p.sendMessage("§e사격 모드: "+mode(p));}
    private String clip(Definition gun,String... names){for(String name:names)if(gun.clips.has(name))return name;return "";}
    private Map<String,Object> phase(String clip,long at,long duration){return new HashMap<>(Map.of("clip",clip,"atMs",at,"durationMs",Math.max(1,duration)));}
    void reload(Player player){
        Definition gun=held(player);if(gun==null||capacity(gun)<0)return;State state=state(player,gun);
        long now=System.currentTimeMillis();int current=ammo(player),needed=capacity(gun)-current;
        if(state.reloadEnd>now||needed<=0)return;
        int reserve=reserve(player,gun);if(reserve==0){player.sendMessage("§c예비 탄약이 없습니다.");return;}
        needed=reserve<0?needed:Math.min(needed,reserve);
        boolean empty=current==0;ReloadPlan plan=reloadPlan(gun,needed,empty,mode(player).equals("semi"));long duration=plan.duration;List<Feed> feeds=plan.feeds;List<Map<String,Object>> phases=plan.phases;
        state.burstLeft=0;state.pendingPress=false;state.feeds=feeds;state.feedIndex=0;state.reloadStarted=now;state.reloadEnd=now+duration;
        if(plugin.protocol!=null)plugin.protocol.emit(player,Map.of("event","reload","durationMs",duration,"empty",empty,"phases",phases));
    }
    private record ReloadPlan(long duration,List<Feed> feeds,List<Map<String,Object>> phases){}
    private ReloadPlan reloadPlan(Definition gun,int needed,boolean empty,boolean semi){
        JsonObject reload=gun.data.getAsJsonObject("reload"),params=gun.data.getAsJsonObject("script_param");
        List<Feed> feeds=new ArrayList<>();List<Map<String,Object>> phases=new ArrayList<>();long duration;
        if(params!=null&&params.has("loop")){
            if(empty&&params.has("clip_load")&&gun.clips.has("reload_empty_clip")){
                duration=(long)(1000*(number(params,"clip_load",3)+number(params,"ending",.6)));
                phases.add(phase("reload_empty_clip",0,duration));feeds.add(new Feed((long)(number(params,"clip_load_feed",2.78)*1000),needed));
            }else{
                String suffix=semi?"_semi":"";
                double intro=number(params,empty?(semi&&params.has("intro_empty_semi")?"intro_empty_semi":"intro_empty"):"intro",.5);
                long at=(long)(intro*1000);String introClip=empty?clip(gun,"reload_empty_intro"+suffix,"reload_empty_intro","reload_intro_empty","reload_intro"):clip(gun,"reload_intro"+suffix,"reload_intro");
                phases.add(phase(introClip,0,at));
                double firstFeed=number(params,semi&&params.has("intro_empty_feed_semi")?"intro_empty_feed_semi":"intro_empty_feed",Double.POSITIVE_INFINITY);
                if(empty&&firstFeed<=intro&&needed>0){feeds.add(new Feed((long)(firstFeed*1000),1));needed--;}
                while(needed>0){boolean pair=needed>=2&&params.has("loop_2")&&gun.clips.has("reload_loop_2");int count=pair?2:1;long length=(long)(1000*number(params,pair?"loop_2":"loop",.67));String loopClip=pair?"reload_loop_2":clip(gun,"reload_loop"+suffix,"reload_loop");phases.add(phase(loopClip,at,length));feeds.add(new Feed(at+(long)(1000*number(params,pair?"loop_feed_2":"loop_feed",.33)),count));at+=length;needed-=count;}
                long ending=(long)(1000*number(params,"ending",.6));phases.add(phase(clip(gun,"reload_end"+suffix,"reload_end"),at,ending));duration=at+ending;
            }
        }else{
            double feed=reload!=null&&reload.has("feed")?number(reload.getAsJsonObject("feed"),empty?"empty":"tactical",2):2;
            double cooldown=reload!=null&&reload.has("cooldown")?number(reload.getAsJsonObject("cooldown"),empty?"empty":"tactical",feed):feed;
            duration=(long)(1000*Math.max(feed,cooldown));feeds.add(new Feed((long)(feed*1000),needed));
        }
        long original=duration;double speed=gun.id.equals("minigun")?3000.0/Math.max(1,duration):duration>=4000?.5:1;
        List<Feed> normalized=new ArrayList<>();for(Feed feed:feeds){long start=0,end=original;if(feeds.size()>1){for(var ph:phases){long begin=((Number)ph.get("atMs")).longValue(),finish=begin+((Number)ph.get("durationMs")).longValue();if(feed.at>=begin&&feed.at<=finish){start=begin;end=finish;break;}}}normalized.add(new Feed((long)(end*speed),feed.count,(long)(start*speed)));}feeds=normalized;duration=Math.max(1,(long)(duration*speed));for(var ph:phases){ph.put("atMs",(long)(((Number)ph.get("atMs")).doubleValue()*speed));ph.put("durationMs",Math.max(1,(long)(((Number)ph.get("durationMs")).doubleValue()*speed)));}
        return new ReloadPlan(duration,feeds,phases);
    }
    double reloadSeconds(Definition gun,boolean empty){return reloadPlan(gun,Math.max(1,capacity(gun)),empty,gun.data.getAsJsonArray("fire_mode").get(0).getAsString().equals("semi")).duration/1000.0;}

    void switchSlot(Player p){State s=states.get(p.getUniqueId());Definition d=held(p);if(s==null||d==null||!d.id.equals(s.id)||s.reloadEnd<=0)return;long elapsed=System.currentTimeMillis()-s.reloadStarted;if(s.feedIndex<s.feeds.size()){Feed f=s.feeds.get(s.feedIndex);if(elapsed>=f.start+Math.ceil((f.at-f.start)*.7)){int used=consumeReserve(p,d,Math.min(f.count,Math.max(0,capacity(d)-ammo(p))));ammo(p,d,ammo(p)+used);}}s.reloadEnd=0;s.feeds=List.of();s.trigger=false;s.pendingPress=false;}
    private void tick(){long now=System.currentTimeMillis();for(var it=states.entrySet().iterator();it.hasNext();){var e=it.next();Player p=Bukkit.getPlayer(e.getKey());if(p==null){it.remove();continue;}State s=e.getValue();Definition d=held(p);if(d==null||!d.id.equals(s.id)||s.slot!=p.getInventory().getHeldItemSlot()){s.trigger=false;s.previous=false;s.reloadEnd=0;s.burstLeft=0;s.pendingPress=false;continue;}
        if(p.isDead()||p.getGameMode()==GameMode.SPECTATOR){s.reloadEnd=0;s.feeds=List.of();}if(p.isDead()||p.getGameMode()==GameMode.SPECTATOR||now-s.inputAt>600){s.trigger=false;s.burstLeft=0;s.pendingPress=false;}
        if(s.reloadEnd>0){while(s.feedIndex<s.feeds.size()&&now-s.reloadStarted>=s.feeds.get(s.feedIndex).at){Feed feed=s.feeds.get(s.feedIndex++);int current=ammo(p),count=consumeReserve(p,d,Math.min(feed.count,Math.max(0,capacity(d)-current)));ammo(p,d,current+count);}if(now>=s.reloadEnd){s.reloadEnd=0;s.feeds=List.of();}else continue;}
        boolean auto=mode(p).equals("auto"),burst=mode(p).equals("burst");JsonObject burstData=d.data.getAsJsonObject("burst_data");
        if(burst&&s.burstLeft==0&&(s.pendingPress||s.trigger&&bool(burstData,"continuous_shoot",false))&&now>=s.nextShot)s.burstLeft=Math.max(1,integer(burstData,"count",3));
        if(now>=s.nextShot&&(burst?s.burstLeft>0:s.pendingPress||s.trigger&&auto)){
            s.pendingPress=false;
            if(burst){s.burstLeft--;s.nextShot=now+(s.burstLeft>0?Math.max(50,60000/Math.max(1,integer(burstData,"bpm",900))):(long)(1000*number(burstData,"min_interval",.3)));}
            else {double rpm=integer(d.data,"rpm",600)+number(adjustment(d,mode(p)),"rpm",0);s.nextShot=now+Math.max(50,(long)(60000/Math.max(1,rpm)));}
            shoot(p,d,s);
        }
        s.previous=s.trigger;
    }
        for(var it=bullets.iterator();it.hasNext();)if(!it.next().step())it.remove();
        for(var it=casings.iterator();it.hasNext();)if(!it.next().step())it.remove();
    }
    private void shoot(Player p,Definition d,State state){int ammo=ammo(p);if(ammo==0){reload(p);p.playSound(p.getLocation(),Sound.BLOCK_LEVER_CLICK,.3f,1.4f);return;}if(ammo>0){if(capacity(d)<0)consumeReserve(p,d,1);else ammo(p,d,ammo-1);}
        JsonObject b=d.data.getAsJsonObject("bullet");int count=Math.max(1,Math.min(64,integer(b,"bullet_amount",1)));double spread=0;var inaccurate=d.data.getAsJsonObject("inaccuracy");if(inaccurate!=null)spread=number(inaccurate,state.aim?"aim":p.isSneaking()?"sneak":"stand",0);
        spread=matchedSpread(p,d,state.aim);for(int i=0;i<count;i++){Vector direction=p.getEyeLocation().getDirection();if(spread>0){double r=Math.tan(Math.toRadians(spread));direction.add(new Vector(random(-r,r),random(-r,r),random(-r,r))).normalize();}bullets.add(new Bullet(p,d,p.getEyeLocation().clone(),direction.multiply(Math.max(1,number(b,"speed",200)+number(adjustment(d,mode(p)),"speed",0))/20),count,mode(p)));}
        if(ammo==1)Bukkit.getScheduler().runTask(plugin,()->{if(held(p)==d&&ammo(p)==0)reload(p);});
        double recoilUp=firstRecoil(d,"pitch"),side=firstRecoil(d,"yaw");long bolt=0;if(d.data.has("bolt")&&d.data.get("bolt").getAsString().equals("manual_action")&&!mode(p).equals("burst"))bolt=(long)(1000*number(d.data,"bolt_action_time",number(d.data.getAsJsonObject("script_param"),"bolt_time",0)));if(bolt>0)state.nextShot=Math.max(state.nextShot,System.currentTimeMillis()+bolt);if(plugin.protocol!=null)plugin.protocol.emit(p,Map.of("event","shot","recoilUp",recoilUp,"recoilSide",side,"engine","ta","boltMs",bolt));
        Location muzzle=p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(.9));casings.add(new Casing(p));sound(p,d,"shoot",1);
    }
    double matchedSpread(Player p,Definition d,boolean aim){if(plugin.visuals==null)return aim?.12:.7;String cs=switch(d.type){case "pistol"->"Eagle";case "sniper","marksman","dmr"->"TRG";case "shotgun"->"SPAS-12";case "smg"->"mp5";default->"AK-47";};var handle=plugin.visuals.cs.getHandle();double raw=handle.getDouble(cs+".Shooting.Bullet_Spread");if(raw<=0)raw=d.type.equals("shotgun")?1.2:d.type.equals("sniper")?.06:.4;return Math.toDegrees(Math.atan(raw/50))*(aim?.5:1);}
    private JsonObject adjustment(Definition gun,String mode){var all=gun.data.getAsJsonObject("fire_mode_adjust");return all==null?null:all.getAsJsonObject(mode);}
    private double firstRecoil(Definition d,String axis){var recoil=d.data.getAsJsonObject("recoil");if(recoil==null||!recoil.has(axis)||recoil.getAsJsonArray(axis).isEmpty())return 0;var values=recoil.getAsJsonArray(axis).get(0).getAsJsonObject().getAsJsonArray("value");return random(values.get(0).getAsDouble(),values.get(1).getAsDouble());}
    private ItemStack effectItem(String id){ItemStack item=new ItemStack(Material.PAPER);var meta=item.getItemMeta();meta.setItemModel(new NamespacedKey("gunbed","fx/"+id));item.setItemMeta(meta);return item;}
    private void sound(Player p,Definition d,String kind,float pitch){JsonObject sounds=d.display.getAsJsonObject("sounds");if(sounds==null||!sounds.has(kind))return;String reference=sounds.get(kind).getAsString();if(reference.isBlank())return;String path=reference.contains(":")?reference.split(":",2)[1]:reference;String id="tacz:gunbed."+path.replace('/','.');p.getWorld().playSound(p.getLocation(),id,SoundCategory.PLAYERS,1,pitch);}
    private final class Bullet {
        final Player owner;final Definition gun;final JsonObject config,adjust;final Location start;final ItemDisplay visual;final Set<UUID> hit=new HashSet<>();Location position;Vector velocity;double travelled;int ticks;final int pellets;
        Bullet(Player owner,Definition gun,Location origin,Vector velocity,int pellets,String mode){start=origin.clone();adjust=adjustment(gun,mode);this.owner=owner;this.gun=gun;this.config=gun.data.getAsJsonObject("bullet");position=origin;this.velocity=velocity;this.pellets=pellets;visual=origin.getWorld().spawn(origin,ItemDisplay.class,e->{e.setPersistent(false);e.setGravity(false);e.setItemStack(effectItem("bullet"));e.setViewRange(4);e.setDisplayWidth(.4f);e.setDisplayHeight(.4f);e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);e.setTransformation(new Transformation(new Vector3f(),new Quaternionf(),new Vector3f(.13f,.13f,.13f),new Quaternionf()));e.setTeleportDuration(1);e.setBrightness(new Display.Brightness(15,15));});}
        boolean step(){if(++ticks>Math.ceil(number(config,"life",1)*20)||!owner.isOnline()){visual.remove();return false;}JsonObject explosive=config.getAsJsonObject("explosion");if(bool(explosive,"explode",false)&&number(explosive,"delay",-1)>=0&&ticks>Math.max(1,number(explosive,"delay",0)*20)){explode(position,explosive);visual.remove();return false;}double distance=velocity.length();if(distance<.001){visual.remove();return false;}Vector unit=velocity.clone().normalize();var collision=position.getWorld().rayTrace(position,unit,distance,FluidCollisionMode.NEVER,true,.08,e->e instanceof LivingEntity&&FriendlyProjectiles.hittable(owner,e)&&!hit.contains(e.getUniqueId()));Location next=position.clone().add(velocity);
            if(collision!=null){Location at=collision.getHitPosition().toLocation(position.getWorld());travelled+=position.distance(at);if(collision.getHitEntity() instanceof LivingEntity victim){hit.add(victim.getUniqueId());if(!bool(explosive,"explode",false))damage(victim,at);}if(bool(explosive,"explode",false)){explode(at.clone().subtract(unit.clone().multiply(.05)),explosive,collision.getHitEntity() instanceof LivingEntity direct?direct:null);visual.remove();return false;}if(collision.getHitBlock()!=null&&!bool(explosive,"explode",false))plugin.wool.hit(owner,org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getGameOfPlayer(owner),collision.getHitBlock(),plugin.damageProfiles.gun(owner,"ta:"+gun.id(),CombatBalance.Part.BODY,start.distance(at),pellets,1));if(collision.getHitBlock()!=null||hit.size()>=Math.max(1,integer(config,"pierce",1))){visual.remove();return false;}}
            for(double at=0;at<distance;at+=1)position.getWorld().spawnParticle(Particle.DUST,position.clone().add(unit.clone().multiply(at)),1,0,0,0,0,new Particle.DustOptions(Color.fromRGB(255,211,112),.35f),true);
            travelled+=distance;position=next;position.setDirection(velocity);visual.teleport(position);velocity.multiply(Math.max(0,1-number(config,"friction",0)));velocity.setY(velocity.getY()-number(config,"gravity",0));return true;
        }
        private void explode(Location at,JsonObject explosive){explode(at,explosive,null);}
        private void explode(Location at,JsonObject explosive,LivingEntity direct){double radius=number(explosive,"radius",3),power=number(explosive,"damage",3);if(radius<=0)return;BattleTargets.blastTurrets(plugin,owner,org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getGameOfPlayer(owner),at,radius,d->plugin.damageProfiles.blast("ta:"+gun.id(),"center")*Math.max(0,1-d/radius));World world=at.getWorld();world.spawnParticle(Particle.EXPLOSION_EMITTER,at,1);world.playSound(at,Sound.ENTITY_GENERIC_EXPLODE,SoundCategory.PLAYERS,1,1);plugin.wool.blast(owner,org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getGameOfPlayer(owner),at,radius,d->plugin.damageProfiles.blast("ta:"+gun.id(),"center")*Math.max(0,1-d/radius));
            for(Entity entity:world.getNearbyEntities(at,radius+1,radius+1,radius+1)){if(!(entity instanceof LivingEntity victim)||victim instanceof ArmorStand||!FriendlyProjectiles.hittable(owner,entity)||victim.isDead()||victim instanceof Player p&&p.getGameMode()==GameMode.SPECTATOR)continue;double distance=BlastExposure.distance(at,victim,radius);
                double strength=victim==direct?1:1-distance/radius;if(strength<=0)continue;DamageContext c=new DamageContext(owner,victim,0,gun);context.set(c);try{victim.setNoDamageTicks(0);victim.damage(victim==direct?plugin.damageProfiles.gun(owner,"ta:"+gun.id(),CombatBalance.Part.BODY,0,1,1):plugin.damageProfiles.blast("ta:"+gun.id(),"center")*strength,owner);}finally{context.remove();}}
        }
        private void damage(LivingEntity victim,Location at){double base=number(config,"damage",1);JsonObject extra=config.getAsJsonObject("extra_damage");double ignore=extra==null?0:number(extra,"armor_ignore",0);if(extra!=null&&extra.has("damage_adjust")){double range=start.distance(at);for(JsonElement element:extra.getAsJsonArray("damage_adjust")){JsonObject point=element.getAsJsonObject();JsonElement distance=point.get("distance");if(distance.isJsonPrimitive()&&distance.getAsJsonPrimitive().isString()||range<number(point,"distance",Double.POSITIVE_INFINITY)){base=number(point,"damage",base);break;}}}base=Math.max(0,base+number(adjust,"damage",0));ignore+=number(adjust,"armor_ignore",0);double value=base/pellets;CombatBalance.Part region=CombatBalance.region(victim,at);value=plugin.damageProfiles.gun(owner,"ta:"+gun.id(),region,start.distance(at),pellets,base/Math.max(.001,number(config,"damage",1)));plugin.balance.contact(victim,owner,region);
            if(plugin.flow.dragons.damage(victim,owner,value)||plugin.turrets!=null&&plugin.turrets.damage(victim,owner,value))return;DamageContext c=new DamageContext(owner,victim,Math.max(0,Math.min(1,ignore)),gun);context.set(c);try{victim.setNoDamageTicks(0);victim.damage(value,owner);}finally{context.remove();}if(!c.applied)return;JsonElement ignite=config.get("ignite");if(ignite!=null&&(ignite.isJsonObject()?ignite.getAsJsonObject().has("entity")&&ignite.getAsJsonObject().get("entity").getAsBoolean():ignite.getAsBoolean()))victim.setFireTicks(integer(config,"ignite_entity_time",2)*20);
        }
    }
    private final class Casing {final ItemDisplay entity;Location at;Vector velocity;int age;Casing(Player owner){at=owner.getEyeLocation().add(owner.getEyeLocation().getDirection().multiply(.25));Vector right=owner.getEyeLocation().getDirection().crossProduct(new Vector(0,1,0)).normalize();velocity=right.multiply(.12).add(new Vector(0,.08,0));entity=at.getWorld().spawn(at,ItemDisplay.class,e->{e.setItemStack(effectItem("casing"));e.setViewRange(2);e.setPersistent(false);e.setTransformation(new Transformation(new Vector3f(),new Quaternionf(),new Vector3f(.09f,.09f,.09f),new Quaternionf()));e.setTeleportDuration(1);});}boolean step(){if(++age>16){entity.remove();return false;}velocity.setY(velocity.getY()-.012);at.add(velocity);at.setYaw(at.getYaw()+34);entity.teleport(at);return true;}}
    @SuppressWarnings("removal") @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void armor(EntityDamageByEntityEvent e){DamageContext c=context.get();if(c!=null&&e.getEntity().equals(c.victim)&&e.getDamager().equals(c.source)&&e.isApplicable(EntityDamageEvent.DamageModifier.ARMOR))e.setDamage(EntityDamageEvent.DamageModifier.ARMOR,e.getDamage(EntityDamageEvent.DamageModifier.ARMOR)*(1-c.ignore));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void applied(EntityDamageByEntityEvent e){DamageContext c=context.get();if(c!=null&&e.getEntity().equals(c.victim)&&e.getDamager().equals(c.source))c.applied=true;}
    static int integer(JsonObject o,String key,int def){return o!=null&&o.has(key)?o.get(key).getAsInt():def;}
    static double number(JsonObject o,String key,double def){return o!=null&&o.has(key)?o.get(key).getAsDouble():def;}
    static boolean bool(JsonObject o,String key,boolean def){return o!=null&&o.has(key)?o.get(key).getAsBoolean():def;}
    private static double random(double a,double b){return a==b?a:ThreadLocalRandom.current().nextDouble(Math.min(a,b),Math.max(a,b));}
    @Override public void close(){for(Bullet b:bullets)b.visual.remove();for(Casing c:casings)c.entity.remove();bullets.clear();casings.clear();}
}
