package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.attribute.Attribute;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.events.*;
import java.util.*;

/** Damage attribution is shared by the feed and resource transfer, including knock-off deaths. */
final class CombatPresentation implements Listener,AutoCloseable {
    private record Hit(UUID player,long at,double damage,String weapon,String icon,String origin,int originColor){}
    private final Map<UUID,List<Hit>> hits=new HashMap<>();
    private final Map<UUID,Integer> deathColors=new HashMap<>();
    private final Map<UUID,Boolean> finalDeaths=new HashMap<>();
    private final Set<TextDisplay> displays=new HashSet<>();
    private static final class Label {TextDisplay display;LivingEntity target;long expires;boolean frozen;final Set<UUID> viewers=new HashSet<>();}
    private final Map<UUID,Label> labels=new HashMap<>();
    private record EnemyBar(net.kyori.adventure.bossbar.BossBar bar,long until){}
    private final Map<UUID,EnemyBar> bars=new HashMap<>();
    private final GunbedCore plugin;
    CombatPresentation(GunbedCore plugin){this.plugin=plugin;Bukkit.getPluginManager().registerEvents(this,plugin);Bukkit.getScheduler().runTaskTimer(plugin,this::tickLabels,2,2);}
    private Player attacker(Entity e){if(e instanceof Player p)return p;String summon=e.getPersistentDataContainer().get(SummonCreatures.OWNER,org.bukkit.persistence.PersistentDataType.STRING);if(summon!=null)return Bukkit.getPlayer(UUID.fromString(summon));if(e instanceof Projectile p&&p.getShooter() instanceof Player owner)return owner;return null;}
    private List<Hit> recent(UUID target){var list=hits.computeIfAbsent(target,id->new ArrayList<>());long cutoff=System.currentTimeMillis()-30000;list.removeIf(h->h.at<cutoff);return list;}
    Player credit(Player victim){List<Hit> list=recent(victim.getUniqueId());for(int i=list.size()-1;i>=0;i--){Player p=Bukkit.getPlayer(list.get(i).player);if(p!=null&&!p.equals(victim))return p;}return null;}
    UUID creditId(Player victim){List<Hit> list=recent(victim.getUniqueId());for(int i=list.size()-1;i>=0;i--){UUID id=list.get(i).player;if(!id.equals(victim.getUniqueId()))return id;}return null;}
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void dying(PlayerDeathEvent e){EnvironmentDeaths.capture(plugin,e);var game=BedwarsAPI.getInstance().getGameOfPlayer(e.getEntity());var team=game==null?null:game.getTeamOfPlayer(e.getEntity());if(team!=null)finalDeaths.put(e.getEntity().getUniqueId(),!team.isTargetBlockExists());}
    boolean finalDeath(Player victim){return finalDeaths.getOrDefault(victim.getUniqueId(),false);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void damage(EntityDamageByEntityEvent e){Player source=attacker(e.getDamager());if(source==null||!(e.getEntity() instanceof LivingEntity target)||source.equals(target)||e.getFinalDamage()<=0)return;double absorbed=e.isApplicable(EntityDamageEvent.DamageModifier.ABSORPTION)?Math.max(0,-e.getDamage(EntityDamageEvent.DamageModifier.ABSORPTION)):0;double amount=Math.min(e.getFinalDamage()+absorbed,target.getHealth()+target.getAbsorptionAmount());String weapon="",icon="minecraft:"+source.getInventory().getItemInMainHand().getType().name().toLowerCase(Locale.ROOT);var nativeGun=plugin.taWeapons.damageDefinition();if(plugin.throwables.damageKind()!=null){weapon=Throwables.name(plugin.throwables.damageKind());icon="gunbed:throwable/"+plugin.throwables.damageKind();}else if(nativeGun!=null){weapon=nativeGun.name();icon="gunbed:ta/"+nativeGun.id();}else {String title=plugin.visuals==null?null:e.getDamager() instanceof Projectile projectile?plugin.visuals.cs.getWeaponTitle(projectile):plugin.visuals.title(source);if(title!=null){weapon=ChatColor.stripColor(ChatColor.translateAlternateColorCodes('&',plugin.visuals.cs.getHandle().getString(title+".Item_Information.Item_Name")));try{icon="gunbed:cs/"+java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(title.getBytes(java.nio.charset.StandardCharsets.UTF_8))).substring(0,16);}catch(java.security.NoSuchAlgorithmException impossible){throw new IllegalStateException(impossible);}}}if(plugin.turrets!=null&&plugin.turrets.damageOrigin()!=null){weapon=plugin.turrets.damageOrigin().name();icon="gunbed:turret/"+plugin.turrets.damageOrigin().kind();}recent(target.getUniqueId()).add(new Hit(source.getUniqueId(),System.currentTimeMillis(),amount,weapon,icon,plugin.turrets!=null&&plugin.turrets.damageOrigin()!=null?plugin.turrets.damageOrigin().label():"",plugin.turrets!=null&&plugin.turrets.damageOrigin()!=null?plugin.turrets.damageOrigin().rgb():0));
        if(plugin.profiles.get(source.getUniqueId()).getBoolean("settings.hit-sound",true))source.playSound(source.getLocation(),Sound.UI_BUTTON_CLICK,.15f,1.8f);
        double remaining=Math.max(0,target.getHealth()-amount),maximum=target.getAttribute(Attribute.MAX_HEALTH)==null?20:target.getAttribute(Attribute.MAX_HEALTH).getValue();Location hitAt=target.getLocation().add(0,target.getHeight()+.8,0);
        var old=bars.get(source.getUniqueId());var bar=old==null?net.kyori.adventure.bossbar.BossBar.bossBar(Component.empty(),0,net.kyori.adventure.bossbar.BossBar.Color.GREEN,net.kyori.adventure.bossbar.BossBar.Overlay.NOTCHED_20):old.bar;bar.name(Component.text((target instanceof Player p?TeamPalette.display(p):target.getName())+" · "+Math.round(remaining)+"/"+Math.round(maximum)+" · −"+Math.round(amount)));bar.progress((float)Math.max(0,Math.min(1,remaining/maximum)));bar.color(remaining/maximum<=.33?net.kyori.adventure.bossbar.BossBar.Color.RED:remaining/maximum<=.66?net.kyori.adventure.bossbar.BossBar.Color.YELLOW:net.kyori.adventure.bossbar.BossBar.Color.GREEN);plugin.protocol.emit(source,Map.of("event","enemyHealth","name",(target instanceof Player p?TeamPalette.display(p):target.getName())+" · "+Math.round(remaining)+"/"+Math.round(maximum)+" · −"+Math.round(amount),"progress",Math.max(0,Math.min(1,remaining/maximum))));source.showBossBar(bar);bars.put(source.getUniqueId(),new EnemyBar(bar,System.currentTimeMillis()+4000));
        Bukkit.getScheduler().runTask(plugin,()->show(target,amount,remaining,maximum,hitAt));
    }
    private void show(LivingEntity target,double amount,double remaining,double maximum,Location hitAt){
        double percent=Math.max(0,Math.min(100,remaining/maximum*100));
        int color=percent<=33?0xFF4949:percent<=66?0xFFA339:0xA1E866;
        Label label=labels.computeIfAbsent(target.getUniqueId(),id->new Label());
        if(label.display==null||!label.display.isValid()){label.display=hitAt.getWorld().spawn(hitAt,TextDisplay.class,d->{d.setVisibleByDefault(false);d.setPersistent(false);d.setGravity(false);d.setBillboard(Display.Billboard.CENTER);d.setShadowed(true);d.setDefaultBackground(false);d.setSeeThrough(false);});displays.add(label.display);}
        label.target=target;label.expires=System.currentTimeMillis()+4000;label.frozen=remaining<=0||target.isDead()||target instanceof Player p&&p.getGameMode()==GameMode.SPECTATOR;label.display.text(Component.text("−"+Math.round(amount)+"  "+Math.round(percent)+"%",TextColor.color(color)));
        Set<UUID> allowed=new HashSet<>();recent(target.getUniqueId()).stream().filter(h->h.at>=System.currentTimeMillis()-15000).map(Hit::player).distinct().map(Bukkit::getPlayer).filter(Objects::nonNull).filter(p->plugin.profiles.get(p.getUniqueId()).getBoolean("settings.damage-numbers",true)).forEach(p->{allowed.add(p.getUniqueId());if(label.viewers.add(p.getUniqueId()))p.showEntity(plugin,label.display);});for(UUID previous:Set.copyOf(label.viewers))if(!allowed.contains(previous)){Player p=Bukkit.getPlayer(previous);if(p!=null)p.hideEntity(plugin,label.display);label.viewers.remove(previous);}
    }
    private void tickLabels(){long now=System.currentTimeMillis();for(var e:List.copyOf(bars.entrySet()))if(now>=e.getValue().until){Player p=Bukkit.getPlayer(e.getKey());if(p!=null)p.hideBossBar(e.getValue().bar);bars.remove(e.getKey());}for(var it=labels.entrySet().iterator();it.hasNext();){Label label=it.next().getValue();if(now>=label.expires||!label.display.isValid()){label.display.remove();displays.remove(label.display);it.remove();continue;}if(label.target.isDead()||!label.target.isValid())label.frozen=true;if(!label.frozen)label.display.teleport(label.target.getLocation().add(0,label.target.getHeight()+.8,0));}}
    @EventHandler(priority=EventPriority.MONITOR)public void kill(BedwarsPlayerKilledEvent e){FeedV16.nativeKill(plugin,e);Bukkit.getScheduler().runTask(plugin,()->hits.remove(e.getPlayer().getUniqueId()));}
    @EventHandler public void bed(BedwarsTargetBlockDestroyedEvent e){Map<String,Object> message=Map.of("event","feed","kind","bed","killer",e.getPlayer()==null?"환경":TeamPalette.display(e.getPlayer()),"victim",TeamPalette.of(e.getGame(),e.getTeam()).name(),"killerColor",e.getPlayer()==null?0xAAAAAA:TeamPalette.of(e.getPlayer()).rgb(),"victimColor",TeamPalette.of(e.getGame(),e.getTeam()).rgb(),"assists",List.of(),"icon","minecraft:red_bed");for(Player p:e.getGame().getConnectedPlayers())if(plugin.protocol!=null)plugin.protocol.emit(p,message);}
    @EventHandler(priority=EventPriority.LOWEST)public void deathColor(PlayerDeathEvent e){deathColors.put(e.getEntity().getUniqueId(),TeamPalette.of(e.getEntity()).rgb());}
    @EventHandler(priority=EventPriority.HIGHEST)public void silence(PlayerDeathEvent e){var game=BedwarsAPI.getInstance().getGameOfPlayer(e.getEntity());if(game!=null&&game.getStatus()==org.screamingsandals.bedwars.api.game.GameStatus.RUNNING)e.deathMessage(null);}
    @EventHandler(priority=EventPriority.MONITOR)public void died(PlayerDeathEvent e){Bukkit.getScheduler().runTask(plugin,()->{hits.remove(e.getEntity().getUniqueId());finalDeaths.remove(e.getEntity().getUniqueId());deathColors.remove(e.getEntity().getUniqueId());});}
    @Override public void close(){for(var e:bars.entrySet()){Player p=Bukkit.getPlayer(e.getKey());if(p!=null)p.hideBossBar(e.getValue().bar);}bars.clear();for(TextDisplay d:displays)d.remove();displays.clear();labels.clear();}
}
