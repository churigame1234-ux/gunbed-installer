import json,shutil,time,subprocess,sys
from native_pack_check import launch
from server_audit import ROOT,dump
report={'success':False,'clients':[]}
# Server integration and real clients share the same isolated backend, sequentially.
r=subprocess.run(['node',str(ROOT/'tools/v16_check.cjs')]);assert r.returncode==0
for version in ['1.21.8','26.3']:
 folder=ROOT/'.local/visual-clients'/version;mods=folder/'game/mods';backup=ROOT/'.local/v16-native-backups'/version;backup.mkdir(parents=True,exist_ok=True)
 for old in list(mods.glob('GunbedAssets-*.jar'))+list(mods.glob('GunbedVisuals-*.jar')):
  if old.name not in ['GunbedAssets-0.3.16.jar',f'GunbedVisuals-{version}-0.3.16.jar']:shutil.move(old,backup/old.name) if not (backup/old.name).exists() else old.unlink()
 for file in [ROOT/'client/build/shared/libs/GunbedAssets-0.3.16.jar',ROOT/f'client/build/{version}/libs/GunbedVisuals-{version}-0.3.16.jar']:shutil.copy2(file,mods/file.name)
 name='GBNative'+version.replace('.','');serverlog=ROOT/'.local/test-logs/v16-native-server.log';offset=len(serverlog.read_text(encoding='utf-8',errors='replace'));started=time.time();process,output,log=launch(version,name,folder/'launch.json',['-Dgunbed.capture=true','-Dgunbed.exercise=true','-Dgunbed.auditFeed=true'])
 row={'version':version,'success':False};models=['wat_f90','lr_'+next(iter(json.loads((ROOT/'src/main/resources/addon-melee-v16.json').read_text()))),'qa_labs_he'];ids=['ta:wat_f90','lr:'+models[1][3:],'throw:labs_he'];renderedAt={};step=-1;fed=False;spectated=False;feedAt=0
 try:
  until=time.monotonic()+100
  while process.poll() is None and time.monotonic()<until:
   text=log.read_text(encoding='utf-8',errors='replace');server=serverlog.read_text(encoding='utf-8',errors='replace')[offset:]
   if step<0 and 'Gunbed client: '+name+' MC ' in server and 'player='+name in server and 'status=SUCCESSFULLY_LOADED' in server:
    print('COMMAND\top '+name,flush=True);print('COMMAND\tgamemode creative '+name,flush=True);print('COMMAND\tgbprobe photospot '+name,flush=True);step=0;print('COMMAND\tgbprobe v16 '+name+' give '+ids[0],flush=True)
   if 0<=step<3 and 'Rendered original gun mesh and player arms: '+models[step] in text:renderedAt.setdefault(step,time.monotonic())
   if step in renderedAt and time.monotonic()-renderedAt[step]>4:
    step+=1
    if step<3:print('COMMAND\tgbprobe v16 '+name+' give '+ids[step],flush=True)
   if step==3 and not fed:fed=True;feedAt=time.monotonic();print('COMMAND\tgbprobe v16 '+name+' feed',flush=True)
   if fed and not spectated and time.monotonic()-feedAt>1.5:spectated=True;print('COMMAND\tgamemode spectator '+name,flush=True)
   if spectated and time.monotonic()-feedAt>11.5:
    row['steady_spectator']='Feed audit steady spectator=true' in text;row['fade_spectator']='Feed audit fading spectator=true' in text;row['models_rendered']=[model for model in models if 'Rendered original gun mesh and player arms: '+model in text];row['success']=row['steady_spectator'] and row['fade_spectator'] and len(row['models_rendered'])==3;break
   if any(e in text for e in ['Gun renderer failed','Game crashed!','Reported exception thrown!','Incompatible mods found!','Mixin apply for mod gunbed_visuals failed']):break
   time.sleep(.3)
  row['errors']=[line for line in text.splitlines() if any(e in line for e in ['Gun renderer failed','Game crashed!','Reported exception thrown!','Incompatible mods found!','Mixin apply for mod gunbed_visuals failed'])];row['success']=row['success'] and not row['errors'];evidence=ROOT/'.local/v16-native-evidence'/version;evidence.mkdir(parents=True,exist_ok=True);shutil.copy2(log,evidence/'client.log');row['log']=str(evidence/'client.log')
  shots=sorted([p for p in (folder/'game/screenshots').glob('gunbed-*.png') if p.stat().st_mtime>=started],key=lambda p:p.stat().st_mtime)
  for i,p in enumerate(shots[-15:]):shutil.copy2(p,evidence/f'{i:02d}.png')
  row['screenshots']=len(shots)
 finally:
  if process.poll() is None:process.terminate()
  process.wait(timeout=15);output.close()
 report['clients'].append(row);print(json.dumps(row),flush=True)
report['success']=all(r['success'] for r in report['clients']);dump(ROOT/'reports/v16-native-clients.json',report)
if not report['success']:raise SystemExit(1)
