import json,subprocess,zipfile,time,shutil,sqlite3,datetime,os
from pathlib import Path
from server_audit import ROOT,REFERENCE,dump,sha256
assert json.loads((ROOT/'reports/v16-vote-private.json').read_text())['success']
work=ROOT/'.local/v16-vote';java=Path('C:/Program Files/Java/jdk-21/bin');subprocess.run([str(java/'javac.exe'),'-encoding','UTF-8','-d',str(work),str(ROOT/'tools/agent/CommonVoteV16Agent.java')],check=True)
with zipfile.ZipFile(work/'agent.jar','w') as z:z.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\nAgent-Class: CommonVoteV16Agent\nCan-Redefine-Classes: true\n\n');z.write(work/'CommonVoteV16Agent.class','CommonVoteV16Agent.class')
backup=REFERENCE/'_codex-backups'/('common-vote-v16-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));backup.mkdir(parents=True)
original=REFERENCE/'plugins/MZSProfile.jar';pending=REFERENCE/'plugins/update/MZSProfile.jar';shutil.copy2(original,backup/'MZSProfile-before.jar')
if pending.exists():shutil.copy2(pending,backup/'MZSProfile-pending-before.jar')
with sqlite3.connect('file:'+str(REFERENCE/'plugins/MZSProfile/database.db').replace('\\','/')+'?mode=ro',uri=True) as source,sqlite3.connect(backup/'database-before.db') as dest:source.backup(dest)
attach=Path.home()/'AppData/Local/Temp/gunbed-common-vote-v16';attach.mkdir(exist_ok=True);shutil.copy2(work/'agent.jar',attach/'agent.jar');result=attach/'live-result.txt';result.unlink(missing_ok=True);request=attach/'live-request.txt';request.write_text(str(REFERENCE)+'\n'+str(result)+'\n'+str(work/'classes')+'\n')
pid=subprocess.check_output(['powershell','-NoProfile','-Command','(Get-NetTCPConnection -LocalPort 25577 -State Listen|Select-Object -First 1 -ExpandProperty OwningProcess)'],text=True).strip();assert pid.isdigit()
subprocess.run([str(java/'java.exe'),'--add-modules','jdk.attach','-cp',str(ROOT/'.local/permissions-hotapply'),'AttachPermissions',pid,str(attach/'agent.jar'),str(request)],check=True,timeout=20)
deadline=time.time()+20
while not result.exists() and time.time()<deadline:time.sleep(.1)
text=result.read_text();assert 'success=true' in text,text
pending.parent.mkdir(exist_ok=True);temp=pending.with_suffix('.jar.tmp');shutil.copy2(work/'MZSProfile.jar',temp);os.replace(temp,pending)
report={'success':True,'restarted':False,'pid':int(pid),'backup':str(backup),'patch_sha256':sha256(pending),'runtime':text};dump(ROOT/'reports/v16-vote-deployment.json',report);print(json.dumps(report))
