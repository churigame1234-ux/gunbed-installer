import os,subprocess,sqlite3,json
from server_audit import ROOT,STAGE
import yaml
config=STAGE/'plugins/GunbedCore/config.yml';original=config.read_bytes();private=ROOT/'.local/v16-vote/server/plugins/MZSProfile/database.db';id='9ad1e732-0146-36d3-9d34-074ba2072cfa'
with sqlite3.connect(STAGE/'plugins/GunbedCore/points.sqlite') as db:
 row=db.execute('SELECT shared_votes FROM accounts WHERE uuid=?',(id,)).fetchone();baseline=(row[0] if row else 0)+10
with sqlite3.connect(private) as db:db.execute('INSERT INTO profile_counters(uuid,votes) VALUES(?,?) ON CONFLICT(uuid) DO UPDATE SET votes=?',(id,baseline,baseline));db.commit()
try:
 data=yaml.safe_load(original);data.setdefault('points',{})['shared-recommendations-database']=str(private);config.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
 result=subprocess.run([str(ROOT/'.venv/Scripts/python.exe'),'-X','utf8',str(ROOT/'tools/check_server.py'),'--label','v16-native-server','--scenario','tools/native_v16_check.py','--scenario-timeout','360','--wait','0'],env=dict(os.environ,GUNBED_V16_VOTE_TEST='1'));raise SystemExit(result.returncode)
finally:config.write_bytes(original)
