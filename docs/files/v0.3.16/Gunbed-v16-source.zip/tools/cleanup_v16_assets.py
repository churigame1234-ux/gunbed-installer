import json
from pathlib import Path
from PIL import Image
from server_audit import ROOT,dump
root=ROOT/'client/src/main/resources/assets'
for p in (root/'gunbed/textures/item/melee').glob('delta_*.png'):
 with Image.open(p) as im:
  if im.width&(im.width-1) or im.height&(im.height-1):im.resize((128,128),Image.Resampling.LANCZOS).save(p)
missing=[]
for ns in ['ronmc','delta_wt','42labk']:
 p=root/ns/'sounds.json'
 if not p.exists():continue
 sounds=json.loads(p.read_text())
 for key,event in sounds.items():
  keep=[]
  for entry in event.get('sounds',[]):
   if isinstance(entry,dict) and entry.get('type')=='event':keep.append(entry);continue
   ref=entry if isinstance(entry,str) else entry['name'];namespace,_,path=ref.partition(':')
   if not path:path=namespace;namespace=ns
   if (root/namespace/'sounds'/(path+'.ogg')).exists():keep.append(entry)
   else:missing.append(ns+':'+key+' -> '+ref)
  event['sounds']=keep or [{'type':'event','name':'minecraft:block.stone.hit'}]
 p.write_text(json.dumps(sounds,ensure_ascii=False,indent=2))
dump(ROOT/'reports/v16-sound-reference-cleanup.json',{'success':True,'missing_unused_references_replaced':missing})
