"""Publish only reviewed optic assets/installer/site files; never touch game servers."""
import concurrent.futures,json,shutil,subprocess,urllib.error,urllib.parse,urllib.request
from pathlib import Path
import publish_download_recovery as github
from server_audit import ROOT,dump,sha256
from download_release_guard import validate_download_site

def publish():
    version='0.3.16';repo=github.REPO
    for name in ('v16-client-builds','v16-installer-tests','v16-release-package','v16-native-server','v16-native-clients','v16-scenario','v16-vote-private','v16-vote-deployment','v16-hud-tests','download-recovery-tests','download-page-tests'):
        assert json.loads((ROOT/'reports'/f'{name}.json').read_text())['success'],name
    validate_download_site(ROOT/'distribution/docs',version)
    result=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\nusername=churigame1234-ux\n\n',capture_output=True,text=True,check=True,timeout=30)
    github.TOKEN=dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)['password'];assert github.api('GET','/user')['login']=='churigame1234-ux'
    checkout=ROOT/'.local/download-recovery-checkout';assert checkout.exists()
    assert subprocess.check_output(['git','-C',str(checkout),'remote','get-url','origin'],text=True).strip()=='https://github.com/'+repo+'.git'
    assert not subprocess.check_output(['git','-C',str(checkout),'status','--porcelain'],text=True).strip(),'Publication checkout has pending edits'
    subprocess.run(['git','-C',str(checkout),'pull','--ff-only'],check=True)
    remote=json.loads((checkout/'docs/downloads.json').read_text());assert tuple(map(int,remote['version'].split('.')))<=tuple(map(int,version.split('.'))),'A newer release is already published'
    paths={f'docs/files/v{version}/'+p.name:p for p in (ROOT/f'distribution/docs/files/v{version}').iterdir() if p.is_file()}
    paths.update({'docs/'+name:ROOT/'distribution/docs'/name for name in ('index.html','app.js','downloads.json')})
    paths['README.md']=ROOT/'distribution/README.md'
    paths.update({'installer/'+p.name:p for p in (ROOT/'installer').glob('*.py')})
    paths.update({'bootstrap/'+p.relative_to(ROOT/f'.local/installer-online-v{version}').as_posix():p for p in (ROOT/f'.local/installer-online-v{version}').rglob('*') if p.is_file()})
    for name,p in paths.items():target=checkout/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
    subprocess.run(['git','-C',str(checkout),'add','--',*sorted(paths)],check=True)
    changed=subprocess.check_output(['git','-C',str(checkout),'-c','core.quotepath=false','diff','--cached','--name-only'],text=True,encoding='utf-8').splitlines();assert set(changed)<=set(paths)
    if changed:
        subprocess.run(['git','-C',str(checkout),'-c','user.name=Gunbed Publisher','-c','user.email=churigame1234-ux@users.noreply.github.com','commit','-m','Release Gunbed 0.3.16 client, free addon presets and persistent combat HUD'],check=True)
        subprocess.run(['git','-C',str(checkout),'push','origin','HEAD:main'],check=True)
    commit=subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip()
    try:release=github.api('GET',f'/repos/{repo}/releases/tags/v{version}')
    except urllib.error.HTTPError as error:
        if error.code!=404:raise
        release=github.api('POST',f'/repos/{repo}/releases',{'tag_name':'v'+version,'target_commitish':commit,'name':'Gunbed 0.3.16 — free addon weapons and combat HUD','draft':True,'body':'WAT 총기 57종, DeltaForce 근접 11종, 42Labs 투척 3종을 Gunbed 호환 프리셋으로 추가했습니다. 관전 중 킬로그 유지·10초 표시 후 페이드·추적 거리 HUD·착지음 판정을 수정했습니다.\n\n설치기 / 클라이언트 / 공통 모델 0.3.16. 기존 모드·다른 버전 폴더·설정·월드는 보존합니다. 기존 조준경 시야 수정도 포함합니다.\n\n설치: https://churigame1234-ux.github.io/gunbed-installer/?v=0.3.16\n소스: Gunbed-v16-source.zip. 원본 애드온의 저작자·출처·조건은 THIRD-PARTY.md에 기재되어 있습니다.'})
    existing={a['name']:a for a in release['assets']}
    def upload(path):
        expected=sha256(path)
        if path.name in existing:assert existing[path.name].get('digest')=='sha256:'+expected;return path.name
        url=release['upload_url'].split('{')[0]+'?name='+urllib.parse.quote(path.name)
        headers={'Authorization':'Bearer '+github.TOKEN,'Content-Type':'application/octet-stream','Content-Length':str(path.stat().st_size),'User-Agent':'GunbedOpticRelease'}
        with path.open('rb') as stream:
            with urllib.request.urlopen(urllib.request.Request(url,data=stream,headers=headers,method='POST'),timeout=180) as response:asset=json.load(response)
        assert asset['size']==path.stat().st_size and asset.get('digest')=='sha256:'+expected
        print(json.dumps({'uploaded':path.name,'bytes':path.stat().st_size}),flush=True);return path.name
    files=[p for p in (ROOT/f'.local/publication-assets-v{version}').iterdir() if p.is_file() and p.name!='GunbedInstaller-Offline.exe']
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:uploaded=list(pool.map(upload,files))
    if release['draft']:release=github.api('PATCH',f'/repos/{repo}/releases/{release["id"]}',{'draft':False,'make_latest':'true'})
    dump(ROOT/'reports/v16-release-publication.json',{'success':True,'commit':commit,'release':release['html_url'],'files':uploaded,'site':'https://churigame1234-ux.github.io/gunbed-installer/','production_restarted':False})
    print(json.dumps({'success':True,'commit':commit,'release':release['html_url']}),flush=True)

if __name__=='__main__':publish()
