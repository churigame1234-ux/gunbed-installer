import json,shutil,zipfile
from pathlib import Path
from server_audit import ROOT,dump,sha256
V='0.3.16';meta=ROOT/f'.local/installer-online-v{V}';assets=ROOT/f'.local/publication-assets-v{V}';public=ROOT/f'distribution/docs/files/v{V}'
for p in (assets,public):p.mkdir(parents=True,exist_ok=True)
shutil.copytree(ROOT/'.local/installer-online-v0.3.15',meta,dirs_exist_ok=True)
release=json.loads((meta/'online.json').read_text());manifest=json.loads((meta/'manifest.json').read_text());old=release['asset_base'];base=old.rsplit('/',1)[0]+'/v'+V
release.update(tag='v'+V,asset_base=base,asset_bases=list(dict.fromkeys([base]+release.get('asset_bases',[old])+[old])),client_version=V,shared_assets_version=V)
for version,data in manifest['versions'].items():
 for prefix,source in [('GunbedVisuals-',ROOT/f'client/build/{version}/libs/GunbedVisuals-{version}-{V}.jar'),('GunbedAssets-',ROOT/f'client/build/shared/libs/GunbedAssets-{V}.jar')]:
  with zipfile.ZipFile(source) as z:assert json.loads(z.read('fabric.mod.json'))['version']==V
  assert source.stat().st_size<100*1024*1024
  for folder in (assets,public):shutil.copy2(source,folder/source.name)
  e=next(e for e in data['mods'] if e['file'].startswith(prefix));e.update(file=source.name,path=(version+'/mods/' if prefix.startswith('GunbedVisuals') else 'mods/')+source.name,url=base+'/'+source.name,sha256=sha256(source),size=source.stat().st_size)
  release['mirrors'][e['sha256']]=['https://churigame1234-ux.github.io/gunbed-installer/files/v'+V+'/'+source.name,'https://raw.githubusercontent.com/churigame1234-ux/gunbed-installer/main/docs/files/v'+V+'/'+source.name]
source=assets/'Gunbed-v16-source.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['src/main','client/src/common','client/.generated','tools/visual-model-check','tools/probe']:
  for p in (ROOT/folder).rglob('*'):
   if p.is_file():z.write(p,p.relative_to(ROOT).as_posix())
 for p in (ROOT/'tools').glob('*v16*'):
  if p.is_file():z.write(p,p.relative_to(ROOT).as_posix())
 profile=Path(r'C:/Users/mydon/Documents/마인크래프트 좀비서버 리뉴얼/MZSProfile/src/main/java/kr/mzs/profile')
 for n in ['NuVoteV16.java','VoteHookListener.java']:z.write(profile/n,'profile-vote-source/'+n)
 z.write(ROOT/'tools/agent/CommonVoteV16Agent.java','tools/agent/CommonVoteV16Agent.java')
 for name in ['tools/generate_visual_adapter.py','tools/check_visual_assets.py','tools/server_audit.py','build.gradle.kts','settings.gradle.kts','client/build.gradle','client/THIRD-PARTY.md','reports/addons-v16-import.json','reports/v16-client-builds.json']:
  z.write(ROOT/name,name)
 z.writestr('README.txt','Gunbed 0.3.16 compatibility renderer and server implementation. Native Java 21/25 code for nine supported game versions. Imported artwork remains in GunbedAssets and retains original project terms; third-party packs are documented in THIRD-PARTY.md. Previous build/bootstrap/source links remain in online.json. No Forge runtime bundled.\n')
shutil.copy2(source,public/source.name);release['sources'][source.name]={'url':base+'/'+source.name,'sha256':sha256(source),'size':source.stat().st_size,'mirrors':['https://churigame1234-ux.github.io/gunbed-installer/files/v'+V+'/'+source.name,'https://raw.githubusercontent.com/churigame1234-ux/gunbed-installer/main/docs/files/v'+V+'/'+source.name]}
shutil.copy2(ROOT/'client/THIRD-PARTY.md',meta/'THIRD-PARTY.md');dump(meta/'manifest.json',manifest);dump(meta/'online.json',release)
# A real local payload for all installer preservation/rollback regression checks.
payload=ROOT/'.local/v16-installer-test-payload';shutil.copytree(ROOT/'.local/installer-payload',payload,dirs_exist_ok=True);shutil.copytree(meta,payload,dirs_exist_ok=True)
old_manifest=json.loads((ROOT/'.local/installer-payload/manifest.json').read_text());old_zip=ROOT/'.local/installer-payload/clients.zip'
with zipfile.ZipFile(old_zip) as original,zipfile.ZipFile(payload/'clients.zip','w',zipfile.ZIP_STORED) as out:
 files={}
 for version,data in manifest['versions'].items():
  for entry in data['mods']:
   if entry['path'] in files:continue
   if entry['file'].startswith(('GunbedVisuals-','GunbedAssets-')):blob=(assets/entry['file']).read_bytes()
   else:
    old_entry=next(e for e in old_manifest['versions'][version]['mods'] if e['sha256']==entry['sha256']);blob=original.read(old_entry['path'])
   files[entry['path']]=blob
 for name,blob in files.items():out.writestr(name,blob)
 out.writestr('source/source-links.json',json.dumps(release['sources']))
 for name in ['THIRD-PARTY.md','licenses/Nuit-MIT.txt']:out.write(meta/name,name)
print(json.dumps({'success':True,'version':V,'assets_bytes':(assets/f'GunbedAssets-{V}.jar').stat().st_size}))
