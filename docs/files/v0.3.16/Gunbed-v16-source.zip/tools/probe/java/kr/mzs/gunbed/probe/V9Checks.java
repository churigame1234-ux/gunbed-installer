package kr.mzs.gunbed.probe;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.event.block.*;
import org.bukkit.event.player.*;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.game.*;

final class V9Checks {
 static Object field(Object a,String n)throws ReflectiveOperationException{var f=a.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(a);}
 static Object core(String n)throws ReflectiveOperationException{return field(Bukkit.getPluginManager().getPlugin("GunbedCore"),n);}
 static Object call(Object a,String n,Object...v)throws ReflectiveOperationException{var m=Arrays.stream(a.getClass().getDeclaredMethods()).filter(x->x.getName().equals(n)&&x.getParameterCount()==v.length).findFirst().orElseThrow();m.setAccessible(true);return m.invoke(a,v);}
 static Location wool;
 static Map<String,Object> run(Player p,String[] args)throws ReflectiveOperationException{
  Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);String action=args[2];Map<String,Object> out=new LinkedHashMap<>();out.put("v9",action);
  switch(action){
   case "shopaudit"->{return V9ShopAudit.run(p);}
   case "cleanup"->{for(Item i:p.getWorld().getEntitiesByClass(Item.class))if(i.getItemStack().getType()==Material.DIAMOND_BLOCK||i.getItemStack().getType()==Material.EMERALD_BLOCK)i.remove();}
   case "state"->{Game game=g!=null?g:BedwarsAPI.getInstance().getGameByName("Orchestra_8");out.put("status",game.getStatus().name());out.put("team",g==null||g.getTeamOfPlayer(p)==null?"":g.getTeamOfPlayer(p).getName());out.put("reservations",((Map<?,?>)field(core("presence"),"reservations")).size());out.put("teams",game.getRunningTeams().stream().map(t->Map.of("name",t.getName(),"bed",t.isTargetBlockExists(),"alive",t.isAlive(),"players",t.countConnectedPlayers())).toList());out.put("armor",Arrays.stream(p.getInventory().getArmorContents()).map(i->i==null?"AIR":i.getType().name()).toList());out.put("flying",p.isFlying());out.put("mode",p.getGameMode().name());out.put("health",p.getHealth());out.put("drops",p.getWorld().getEntitiesByClass(Item.class).stream().filter(i->i.getItemStack().getType()==Material.DIAMOND_BLOCK||i.getItemStack().getType()==Material.EMERALD_BLOCK).map(i->Map.of("type",i.getItemStack().getType().name(),"n",i.getItemStack().getAmount())).toList());out.put("invisible",p.hasPotionEffect(org.bukkit.potion.PotionEffectType.INVISIBILITY));out.put("hiddenArmor",field(core("parity"),"hidden"));}
   case "profiles"->{Object rows=call(core("damageProfiles"),"describe");try{java.nio.file.Files.writeString(java.nio.file.Path.of("../../reports/weapon-balance-v9.json"),new com.google.gson.Gson().toJson(rows));}catch(java.io.IOException error){throw new IllegalStateException(error);}out.put("count",((Collection<?>)rows).size());}
   case "zones"->{List<String> failures=new ArrayList<>();List<Location> centers=new ArrayList<>();for(var s:g.getItemSpawners())centers.add(s.getLocation());for(var s:g.getGameStores())centers.add(s.getStoreLocation());boolean op=p.isOp();GameMode mode=p.getGameMode();int n=0;try{for(Location c:centers){p.setOp(false);p.setGameMode(GameMode.SURVIVAL);for(int x=-2;x<2;x++)for(int y=-2;y<2;y++)for(int z=-2;z<2;z++){Location at=c.getBlock().getLocation().add(x,y,z);if((boolean)call(core("volumes"),"allow",g,at,p))failures.add("inside "+at);n++;}p.setOp(true);p.setGameMode(GameMode.SURVIVAL);if((boolean)call(core("volumes"),"allow",g,c,p))failures.add("op survival");p.setOp(false);p.setGameMode(GameMode.CREATIVE);if((boolean)call(core("volumes"),"allow",g,c,p))failures.add("nonop creative");p.setOp(true);p.setGameMode(GameMode.CREATIVE);if(!(boolean)call(core("volumes"),"allow",g,c,p))failures.add("op creative");}}finally{p.setOp(op);p.setGameMode(mode);}out.put("centers",centers.size());out.put("cells",n);out.put("failures",failures);}
   case "line"->{Player ally=Bukkit.getPlayerExact(args[3]),enemy=Bukkit.getPlayerExact(args[4]);Location at=g.getTeamOfPlayer(p).getTeamSpawn().clone();at.setYaw(0);at.setPitch(0);for(int x=-8;x<=8;x++)for(int z=0;z<=12;z++){at.clone().add(x,-1,z).getBlock().setType(Material.STONE,false);for(int y=0;y<3;y++)at.clone().add(x,y,z).getBlock().setType(Material.AIR,false);}p.teleport(at);ally.teleport(at.clone().add(0,0,3));enemy.teleport(at.clone().add(0,0,6));out.put("line",true);}
   case "wool"->{if(args[3].equals("place")){wool=p.getLocation().clone().add(0,1,3).getBlock().getLocation();var block=wool.getBlock();g.getRegion().putOriginalBlock(wool,block.getState());block.setType(Material.RED_WOOL,false);g.getRegion().addBuiltDuringGame(wool);}else if(args[3].equals("hit")){out.put("accepted",call(core("wool"),"hit",p,g,wool.getBlock(),Double.parseDouble(args[4])));}else if(args[3].equals("original")){g.getRegion().removeBlockBuiltDuringGame(wool);wool.getBlock().setType(Material.RED_WOOL,false);out.put("accepted",call(core("wool"),"hit",p,g,wool.getBlock(),999999.0));}else if(args[3].equals("remove"))wool.getBlock().setType(Material.AIR,false);out.put("remaining",call(core("wool"),"remaining",g,wool.getBlock()));out.put("material",wool.getBlock().getType().name());}
   case "chest"->{var team=g.getTeamFromName(args[3]);Location at=team.getTeamSpawn().clone().add(2,0,0);at.getBlock().setType(args[4].equals("ender")?Material.ENDER_CHEST:Material.CHEST,false);p.closeInventory();var e=new PlayerInteractEvent(p,org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK,p.getInventory().getItemInMainHand(),at.getBlock(),org.bukkit.block.BlockFace.UP,EquipmentSlot.HAND);Bukkit.getPluginManager().callEvent(e);out.put("size",p.getOpenInventory().getTopInventory().getSize());out.put("title",p.getOpenInventory().getTitle());}
   case "stash"->{p.getOpenInventory().getTopInventory().addItem(new ItemStack(Material.valueOf(args[3]),Integer.parseInt(args[4])));out.put("stored",true);}
   case "bed"->{var team=(org.screamingsandals.bedwars.game.CurrentTeam)g.getTeamOfPlayer(p);team.isBed=false;out.put("bed",false);}
   case "invis"->{p.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.INVISIBILITY,600,0,false,false,false));out.put("set",true);}
   case "aside"->{p.teleport(p.getLocation().add(4,0,0));}
   case "cover"->{Player target=Bukkit.getPlayerExact(args[3]);target.teleport(p.getLocation().clone().add(0,0,4));wool=p.getLocation().clone().add(0,1,3).getBlock().getLocation();var block=wool.getBlock();g.getRegion().putOriginalBlock(wool,block.getState());block.setType(Material.RED_WOOL,false);g.getRegion().addBuiltDuringGame(wool);call(core("wool"),"hit",p,g,block,2900.0);}
   case "arrow"->{var arrow=p.launchProjectile(Arrow.class,p.getEyeLocation().getDirection().multiply(1.5));arrow.setGravity(false);}
   case "near"->{Bukkit.getPlayerExact(args[3]).teleport(p.getLocation().clone().add(0,0,1));Bukkit.getPlayerExact(args[4]).teleport(p.getLocation().clone().add(0,0,2.2));}
   case "view"->{p.setViewDistance(16);p.setSendViewDistance(16);out.put("view",p.getSendViewDistance());}
   case "mapjoin"->{BedwarsAPI.getInstance().getGameByName("Voidless_Kimetsunoyaiba_Infinity_Caslte_4").joinToGame(p);}
   case "mapcamera"->{p.setAllowFlight(true);p.setFlying(true);p.teleport(new Location(p.getWorld(),4800.5,300,4860.5,0,90));}
   case "map"->{int good=0;for(int x=291;x<=307;x++)for(int z=296;z<=311;z++){g.getGameWorld().getChunkAt(x,z);good++;}out.put("chunksLoaded",good);}
  }
  return out;
 }
}
