package kr.mzs.gunbed.probe;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.screamingsandals.bedwars.api.*;
import java.util.*;
import static kr.mzs.gunbed.probe.V9Checks.*;
final class AiChecks {
 static Map<String,Object> run(Player p,String[] args)throws ReflectiveOperationException{
  String op=args[2];Map<String,Object> out=new LinkedHashMap<>();out.put("ai",op);Object practice=core("practice");
  if(op.equals("enter")){ClassLoader loader=practice.getClass().getClassLoader();Class<?> d=Class.forName("kr.mzs.gunbed.AiPractice$Difficulty",true,loader),c=Class.forName("kr.mzs.gunbed.AiChallenge",true,loader);call(practice,"enter",p,Enum.valueOf((Class)d,args[3]),Enum.valueOf((Class)c,args[4]));}
  if(op.equals("maps"))call(practice,"maps",p);
  if(op.equals("progress-reset")){
   if(!p.getName().startsWith("GBProbe"))throw new IllegalArgumentException("Private test account required");
   call(core("profiles"),"set",p.getUniqueId(),"ai-challenges.completed",null);
  }
  if(op.equals("complete")){
   if(!p.getName().startsWith("GBProbe"))throw new IllegalArgumentException("Private test account required");
   Class<?> c=Class.forName("kr.mzs.gunbed.AiChallenge",true,practice.getClass().getClassLoader());
   call(practice,"recordCompletion",p.getUniqueId(),Enum.valueOf((Class)c,args[3]));
  }
  if(op.equals("progress")||op.equals("complete")||op.equals("progress-reset")){
   Object progress=call(practice,"progress",p.getUniqueId());out.put("completed",call(progress,"saved"));
   Class<?> c=Class.forName("kr.mzs.gunbed.AiChallenge",true,practice.getClass().getClassLoader());
   List<String> open=new ArrayList<>();for(Object challenge:c.getEnumConstants())if((boolean)call(challenge,"original")&&(boolean)call(progress,"canSelect",challenge))open.add(((Enum<?>)challenge).name());
   out.put("openOriginal",open);out.put("saved",call(core("profiles"),"saved"));
  }
  if(op.equals("challenges")){
   Class<?> d=Class.forName("kr.mzs.gunbed.AiPractice$Difficulty",true,practice.getClass().getClassLoader());
   call(practice,"challenges",p,Enum.valueOf((Class)d,"EASY"));
   Map<String,String> icons=new LinkedHashMap<>();Class<?> c=Class.forName("kr.mzs.gunbed.AiChallenge",true,practice.getClass().getClassLoader());
   for(Object challenge:c.getEnumConstants()){var item=p.getOpenInventory().getTopInventory().getItem(((Enum<?>)challenge).ordinal());icons.put(((Enum<?>)challenge).name(),item==null?"AIR":item.getType().name());}out.put("icons",icons);
  }
  if(op.equals("status")){var api=BedwarsAPI.getInstance();var g=api.getGameOfPlayer(p);out.put("arena",g==null?"none":g.getName());out.put("status",g==null?"none":g.getStatus().name());out.put("learningEpisodes",call(core("learning"),"episodes"));List<Map<String,Object>> bots=new ArrayList<>();for(Player b:Bukkit.getOnlinePlayers())if(b.getScoreboardTags().contains("mzs_ai")){Map<String,Object> row=new LinkedHashMap<>();row.put("name",b.getName());row.put("position",List.of(b.getX(),b.getY(),b.getZ()));row.put("health",b.getHealth());row.put("mode",b.getGameMode().name());row.put("arena",api.getGameOfPlayer(b)==null?"none":api.getGameOfPlayer(b).getName());row.put("team",api.getGameOfPlayer(b)==null||api.getGameOfPlayer(b).getTeamOfPlayer(b)==null?"none":api.getGameOfPlayer(b).getTeamOfPlayer(b).getName());row.put("action",call(field(practice,"brain"),"action",b));row.put("resources",call(core("wallet"),"snapshot",b));row.put("inventory",Arrays.stream(b.getInventory().getStorageContents()).filter(Objects::nonNull).map(i->i.getType().name()+":"+i.getAmount()).toList());bots.add(row);}out.put("bots",bots);out.put("team",g==null||g.getTeamOfPlayer(p)==null?"none":g.getTeamOfPlayer(p).getName());out.put("world",p.getWorld().getName());}
  return out;
 }
}
