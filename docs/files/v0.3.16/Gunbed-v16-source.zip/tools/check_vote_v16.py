import subprocess,time,re,sqlite3,json,hashlib,uuid
from server_audit import ROOT,dump
work=ROOT/'.local/v16-vote';stage=work/'server';assert 'server-port=25691' in (stage/'server.properties').read_text()
result={'success':False};log=work/'server.log'
with log.open('w',encoding='utf-8') as stream:
 p=subprocess.Popen([r'C:/Program Files/Java/jdk-21/bin/java.exe','-Xms256M','-Xmx1G','-Dfile.encoding=UTF-8','-jar','server.jar','--nogui'],cwd=stage,stdin=subprocess.PIPE,stdout=stream,stderr=subprocess.STDOUT,text=True)
 try:
  deadline=time.time()+180
  while time.time()<deadline and p.poll() is None:
   text=log.read_text(encoding='utf-8',errors='replace')
   if 'V16_PRIVATE_VOTES_SENT' in text:
    with sqlite3.connect(stage/'plugins/MZSProfile/database.db') as db:
     rows=db.execute("SELECT p.name,c.votes FROM players p JOIN profile_counters c USING(uuid) WHERE lower(p.name)=lower('GBVoteV16')").fetchall();receipts=db.execute('SELECT count(*) FROM gunbed_vote_receipts_v16').fetchone()[0]
    result.update(rows=rows,receipts=receipts);assert rows==[('GBVoteV16',1)] and receipts==1,result;result['success']=True;break
   time.sleep(.5)
  assert result['success'],text[-4000:]
 finally:
  if p.poll() is None:p.stdin.write('stop\n');p.stdin.flush();p.wait(timeout=60)
dump(ROOT/'reports/v16-vote-private.json',result);print(json.dumps(result))
