"""Generate thin Minecraft-specific adapters around one shared display protocol/mesh engine."""
import argparse
import hashlib
import json
import shutil
import urllib.parse
import urllib.request
from pathlib import Path
from server_audit import ROOT, dump

CLIENT = ROOT / "client"
VERSIONS = {
    "1.21.8": {"legacy": True, "id": "ResourceLocation", "range": ">=1.21.8 <=1.21.8"},
    "1.21.9": {"legacy": False, "id": "ResourceLocation", "range": "1.21.9"},
    "1.21.10": {"legacy": False, "id": "ResourceLocation", "range": "1.21.10"},
    "1.21.11": {"legacy": False, "id": "Identifier", "range": "1.21.11"},
    "26.1": {"legacy": False, "id": "Identifier", "range": "26.1"},
    "26.1.1": {"legacy": False, "id": "Identifier", "range": "26.1.1"},
    "26.1.2": {"legacy": False, "id": "Identifier", "range": "26.1.2"},
    "26.2": {"legacy": False, "id": "Identifier", "range": "26.2"},
    "26.3": {"legacy": False, "id": "Identifier", "range": "26.3"},
}

NETWORK = r'''package kr.mzs.gunbedvisual;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.IDENTIFIER;
import java.nio.charset.StandardCharsets;
import org.slf4j.LoggerFactory;
public final class GunbedVisualClient implements ClientModInitializer {
    public static final org.slf4j.Logger LOG=LoggerFactory.getLogger("GunbedVisuals");
    private int tick=0;
    private int exerciseTick=0;
    private boolean previousAim=false;
    private boolean rightWasDown=false;
    private int zoomStage=0;
    private int lastSlot=-1;
    private int savedRenderDistance=-1;
    private void restoreDistance(net.minecraft.client.Minecraft client){if(savedRenderDistance>=0){client.options.renderDistance().set(savedRenderDistance);savedRenderDistance=-1;}}
    private int previousZoom=-1;
    private String lastWeapon="";
    private long exercisedLife=-1;
    private int loadoutExerciseTick,loadoutExercises;
    public record Wire(byte[] bytes) implements CustomPacketPayload {
        public static final Type<Wire> TYPE=new Type<>(IDENTIFIER.fromNamespaceAndPath("gunbed","visuals"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Wire> CODEC=StreamCodec.of(
            (buffer,packet)->buffer.writeBytes(packet.bytes), buffer->{
                if(buffer.readableBytes()>30000)throw new IllegalArgumentException("Oversized visual payload");
                byte[] bytes=new byte[buffer.readableBytes()];buffer.readBytes(bytes);return new Wire(bytes);
            });
        @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
    }
    @Override public void onInitializeClient() {
        GunbedHud.register();
        var reloadKey=net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(new net.minecraft.client.KeyMapping("key.gunbed.reload",com.mojang.blaze3d.platform.InputConstants.Type.KEYSYM,org.lwjgl.glfw.GLFW.GLFW_KEY_R,KEY_CATEGORY));
        PayloadTypeRegistry.playS2C().register(Wire.TYPE,Wire.CODEC);
        PayloadTypeRegistry.playC2S().register(Wire.TYPE,Wire.CODEC);
        ClientPlayNetworking.registerGlobalReceiver(Wire.TYPE,(payload,context)->context.client().execute(()->{
            try {
                String json=new String(payload.bytes,StandardCharsets.UTF_8);
                if(dataWeaponChanged(json)){zoomStage=0;rightWasDown=false;}
                VisualState.INSTANCE.packet(json);
                HudState.INSTANCE.packet(json);
                var data=com.google.gson.JsonParser.parseString(json).getAsJsonObject();
                if(data.has("packId")&&data.has("packUrl"))PackOwnership.confirm(data.get("packId").getAsString(),data.get("packUrl").getAsString());
                var player=context.client().player;
                if(data.has("event")&&data.get("event").getAsString().equals("openSite")&&HudState.INSTANCE.active()){String url=data.get("url").getAsString();if(url.startsWith("https://churigame1234-ux.github.io/gunbed-installer/stats/"))net.minecraft.client.gui.screens.ConfirmLinkScreen.confirmLinkNow(net.minecraft.client.Minecraft.getInstance().screen,java.net.URI.create(url),false);}
                if(Boolean.getBoolean("gunbed.review")&&data.has("event")&&data.get("event").getAsString().equals("reviewInventory"))net.minecraft.client.KeyMapping.click(net.minecraft.client.Minecraft.getInstance().options.keyInventory.getDefaultKey());
                if(player!=null && data.has("recoilUp"))player.setXRot(net.minecraft.util.Mth.clamp(player.getXRot()-data.get("recoilUp").getAsFloat(),-90,90));
                if(player!=null && data.has("recoilSide"))player.setYRot(player.getYRot()+data.get("recoilSide").getAsFloat());
                if(Boolean.getBoolean("gunbed.exercise"))LOG.info("Display state {}",json);
            }
            catch(RuntimeException error){LOG.error("Invalid display state; keeping vanilla rendering",error);VisualState.INSTANCE.clear();}
        }));
        ClientPlayConnectionEvents.DISCONNECT.register((handler,client)->{VisualState.INSTANCE.clear();HudState.INSTANCE.clear();PackOwnership.clear();restoreDistance(client);});
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            if(client.player==null){restoreDistance(client);return;}
            GroundAudio.tick(client.player.getY(),client.player.onGround());
            int requested=HudState.INSTANCE.active()?HudState.INSTANCE.mapViewDistance:0;if(requested>0){if(savedRenderDistance<0)savedRenderDistance=client.options.renderDistance().get();if(client.options.renderDistance().get()<requested)client.options.renderDistance().set(requested);}else restoreDistance(client);
            var expiredPack=PackOwnership.tick();if(expiredPack!=null){client.getDownloadedPackSource().popPack(expiredPack);LOG.info("Released Gunbed pack after backend transition: {} (HUD active={})",expiredPack,HudState.INSTANCE.active());if(Boolean.getBoolean("gunbed.switchTest"))switchReturnAt=tick+80;}
            if(switchReturnAt>0&&tick>=switchReturnAt){switchReturnAt=0;client.player.connection.sendCommand("server gunbed");LOG.info("Requested return to Gunbed after backend transition test");}
            if(Boolean.getBoolean("gunbed.exerciseLoadout")&&client.screen==null&&HudState.INSTANCE.loadoutPending&&exercisedLife!=HudState.INSTANCE.loadoutLife){if(++loadoutExerciseTick>=20){int choice=HudState.INSTANCE.loadoutPrevious&&Boolean.getBoolean("gunbed.exerciseRepeat")?4:(loadoutExercises++%3)+1;net.minecraft.client.KeyMapping.click(client.options.keyHotbarSlots[choice-1].getDefaultKey());exercisedLife=HudState.INSTANCE.loadoutLife;loadoutExerciseTick=0;LOG.info("Exercised physical loadout key {} life {}",choice,exercisedLife);}}
            boolean active=GunbedRender.controlled(client.player);
            if(GunbedRender.active(client.player))for(String sound:VisualState.INSTANCE.sounds())client.getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(net.minecraft.sounds.SoundEvent.createVariableRangeEvent(IDENTIFIER.parse(sound)),1.0f));
            boolean down=client.screen==null && active && client.options.keyUse.isDown();
            if(!active||lastSlot!=client.player.getInventory().getSelectedSlot()){zoomStage=0;rightWasDown=false;}lastSlot=client.player.getInventory().getSelectedSlot();
            if(down&&!rightWasDown&&VisualState.INSTANCE.canAim())zoomStage=(zoomStage+1)%3;rightWasDown=down;
            boolean aiming=VisualState.INSTANCE.canAim()?zoomStage>0:down;
            boolean firing=client.screen==null && !HudState.INSTANCE.loadoutPending && active && client.options.keyAttack.isDown();
            if((aiming!=previousAim || firing!=previousFire || zoomStage!=previousZoom || tick%(firing?1:4)==0&&active) && ClientPlayNetworking.canSend(Wire.TYPE)) {
                input(firing,aiming,zoomStage,down);previousAim=aiming;previousFire=firing;previousRight=down;previousZoom=zoomStage;
            }
            while(reloadKey.consumeClick())if(client.screen==null && active){zoomStage=0;requestReload(client);}
            if(Boolean.getBoolean("gunbed.exercise") && active) {
                exerciseTick++;
                if(exerciseTick==30){client.options.keyAttack.setDown(true);net.minecraft.client.KeyMapping.click(client.options.keyAttack.getDefaultKey());}
                if(exerciseTick==38)client.options.keyAttack.setDown(false);
                if(exerciseTick==60)net.minecraft.client.KeyMapping.click(reloadKey.getDefaultKey());
                if(exerciseTick==120){client.options.keyUse.setDown(true);net.minecraft.client.KeyMapping.click(client.options.keyUse.getDefaultKey());}
                if(exerciseTick==135)client.options.keyUse.setDown(false);
                if(exerciseTick==150){client.options.keyUse.setDown(true);net.minecraft.client.KeyMapping.click(client.options.keyUse.getDefaultKey());}
                if(exerciseTick==165)client.options.keyUse.setDown(false);
                if(exerciseTick==180){client.options.keyUse.setDown(true);net.minecraft.client.KeyMapping.click(client.options.keyUse.getDefaultKey());}
                if(exerciseTick==195)client.options.keyUse.setDown(false);
            }
            if(++tick%40==0&&ClientPlayNetworking.canSend(Wire.TYPE)) {
                String hello="{\"v\":1,\"event\":\"hello\",\"mc\":\"MC_VERSION\",\"client\":\"0.3.16\"}";
                ClientPlayNetworking.send(new Wire(hello.getBytes(StandardCharsets.UTF_8)));
            }
            if(Boolean.getBoolean("gunbed.capture") && tick>=40 && tick<=1800 && tick%(Boolean.getBoolean("gunbed.captureFast")?2:20)==0) {
                net.minecraft.client.Screenshot.grab(client.gameDirectory,"gunbed-"+tick+".png",client.getMainRenderTarget(),1,message->{});
            }
        });
        LOG.info("Gunbed display-only client MC_VERSION ready; no modded item/entity registries");
    }
    private boolean dataWeaponChanged(String json){var data=com.google.gson.JsonParser.parseString(json).getAsJsonObject();if(!data.has("weapon"))return false;String next=data.get("weapon").getAsString();if(next.equals(lastWeapon))return false;lastWeapon=next;return true;}
    private static void requestReload(net.minecraft.client.Minecraft client) {
        if(ClientPlayNetworking.canSend(Wire.TYPE))ClientPlayNetworking.send(new Wire("{\"v\":1,\"event\":\"reload_request\"}".getBytes(StandardCharsets.UTF_8)));
    }
    private boolean previousFire=false;
    private boolean previousRight=false;
    private int switchReturnAt;
    public static void chooseLoadout(int choice){var state=HudState.INSTANCE;if(!state.loadoutPending||choice<1||choice>(state.loadoutPrevious?4:3)||!ClientPlayNetworking.canSend(Wire.TYPE))return;ClientPlayNetworking.send(new Wire(("{\"v\":1,\"event\":\"loadout_choice\",\"choice\":"+choice+",\"life\":"+state.loadoutLife+"}").getBytes(StandardCharsets.UTF_8)));state.loadoutPending=false;}

    private static void input(boolean fire,boolean aim,int zoomStage,boolean right){ClientPlayNetworking.send(new Wire(("{\"v\":1,\"event\":\"input\",\"fire\":"+fire+",\"aim\":"+aim+",\"right\":"+right+",\"zoomStage\":"+zoomStage+"}").getBytes(StandardCharsets.UTF_8)));}
}
'''

RENDER = r'''package kr.mzs.gunbedvisual;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.IDENTIFIER;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.player.PlayerModelPart;
import org.joml.Vector3f;
import kr.mzs.gunbedvisual.model.GunMesh;
RENDER_IMPORTS
public final class GunbedRender {
    private static String failed="";
    public static boolean active(AbstractClientPlayer player) {
        var item=player.getMainHandItem();
        if(HudState.INSTANCE.building())return true;
        return VisualState.INSTANCE.matches(player.getInventory().getSelectedSlot(),net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(item.getItem()).toString(),item.getHoverName().getString());
    }
    public static boolean controlled(AbstractClientPlayer player) {
        var item=player.getMainHandItem();
        return VisualState.INSTANCE.controls(player.getInventory().getSelectedSlot(),net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(item.getItem()).toString(),item.getHoverName().getString());
    }
    public static boolean render(AbstractClientPlayer player,PoseStack matrices,BUFFER_ARG buffers,int light) {
        if(!(player instanceof LocalPlayer local))return false;
        String demo=System.getProperty("gunbed.demo");
        VisualState state=VisualState.INSTANCE;
        state.demo(demo,local.getInventory().getSelectedSlot());
        if(HudState.INSTANCE.building()){
            var build=HudState.INSTANCE;float p=build.buildProgress();matrices.pushPose();matrices.translate(.12,-.42-.04*p,-.86);matrices.scale(.36f,.36f,.36f);matrices.mulPose(new org.joml.Matrix4f().rotationY((float)Math.PI+.12f*(float)Math.sin(p*8)));GunbedWorldMeshes.draw(build.buildKind,matrices,buffers,light);matrices.popPose();
            matrices.pushPose();matrices.mulPose(PlacementPose.arm(false,p));DRAW_RIGHT matrices.popPose();matrices.pushPose();matrices.mulPose(PlacementPose.arm(true,p));DRAW_LEFT matrices.popPose();return true;
        }
        if(!active(local)||failed.equals(state.model()))return false;
        try {
            GunMesh.Frame frame=state.frame();if(state.optic())return true;
            var surfaces=frame.surfaces().isEmpty()?java.util.Map.of(state.texture(),frame.vertices()):frame.surfaces();
            for(var entry:surfaces.entrySet()){IDENTIFIER texture=entry.getKey().equals("$skin")?PLAYER_SKIN:IDENTIFIER.parse(entry.getKey());var surface=new GunMesh.Frame(entry.getValue(),null,null,null);
            DRAW_SURFACE
            }
            IDENTIFIER texture=IDENTIFIER.parse(state.texture());
            DRAW_FLASH
            if(frame.rightArm()!=null){matrices.pushPose();matrices.mulPose(frame.rightArm());DRAW_RIGHT matrices.popPose();}
            if(frame.leftArm()!=null){matrices.pushPose();matrices.mulPose(frame.leftArm());DRAW_LEFT matrices.popPose();}
            if(state.firstFrame())GunbedVisualClient.LOG.info("Rendered original gun mesh and player arms: {} vertices={}",state.model(),frame.vertices().size());
            return true;
        } catch(RuntimeException error) {
            failed=state.model();GunbedVisualClient.LOG.error("Gun renderer failed for {}. Vanilla model retained.",failed,error);return false;
        }
    }
    private static void vertices(GunMesh.Frame frame,PoseStack.Pose pose,VertexConsumer consumer,int light) {
        Vector3f p=new Vector3f(),n=new Vector3f();
        for(var vertex:frame.vertices()) {
            pose.pose().transformPosition(vertex.x(),vertex.y(),vertex.z(),p);
            pose.normal().transform(vertex.nx(),vertex.ny(),vertex.nz(),n).normalize();
            consumer.addVertex(p.x,p.y,p.z).setColor(-1).setUv(vertex.u(),vertex.v()).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(n.x,n.y,n.z);
        }
    }
}
'''

MIXIN = r'''package kr.mzs.gunbedvisual.mixin;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import BUFFER_IMPORT;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import kr.mzs.gunbedvisual.GunbedRender;
@Mixin(ItemInHandRenderer.class)
public abstract class GunbedHandMixin {
    @Inject(method="renderArmWithItem",at=@At("HEAD"),cancellable=true)
    private void gunbed$hand(AbstractClientPlayer player,float delta,float pitch,InteractionHand hand,float swing,ItemStack stack,float equip,PoseStack pose,BUFFER_ARG buffers,int light,CallbackInfo ci) {
        if(hand==InteractionHand.MAIN_HAND) {
            if(GunbedRender.render(player,pose,buffers,light))ci.cancel();
        } else if(GunbedRender.active(player))ci.cancel();
    }
}
'''

MODERN_MIXIN = r'''package kr.mzs.gunbedvisual.mixin;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FirstPersonHandsAndItemsRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import net.minecraft.client.renderer.state.level.FirstPersonHandsAndItemsRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import kr.mzs.gunbedvisual.GunbedRender;
@Mixin(FirstPersonHandsAndItemsRenderer.class)
public abstract class GunbedHandMixin {
    @Inject(method="submitHandsWithItems",at=@At("HEAD"),cancellable=true)
    private void gunbed$hand(float delta,PoseStack pose,SubmitNodeCollector buffers,PlayerRenderState playerState,FirstPersonHandsAndItemsRenderState hands,CallbackInfo ci) {
        var player=Minecraft.getInstance().player;
        if(player!=null && playerState.avatarRenderState!=null && GunbedRender.render(player,pose,buffers,playerState.avatarRenderState.lightCoords))ci.cancel();
    }
}
'''

INPUT_MIXIN = r'''package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.Minecraft;
import kr.mzs.gunbedvisual.GunbedRender;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Minecraft.class)
public abstract class GunbedInputMixin {
    private boolean gunbed$controls(){var client=Minecraft.getInstance();return client.player!=null&&(kr.mzs.gunbedvisual.HudState.INSTANCE.loadoutPending||GunbedRender.controlled(client.player));}
    @Inject(method="handleKeybinds",at=@At("HEAD"),cancellable=true)
    private void gunbed$choice(CallbackInfo ci){var client=Minecraft.getInstance();if(client.screen!=null||!kr.mzs.gunbedvisual.HudState.INSTANCE.active()||!kr.mzs.gunbedvisual.HudState.INSTANCE.loadoutPending)return;for(int i=0;i<(kr.mzs.gunbedvisual.HudState.INSTANCE.loadoutPrevious?4:3);i++)if(client.options.keyHotbarSlots[i].consumeClick()){kr.mzs.gunbedvisual.GunbedVisualClient.chooseLoadout(i+1);break;}ci.cancel();}
    @Inject(method="startAttack",at=@At("HEAD"),cancellable=true)
    private void gunbed$attack(CallbackInfoReturnable<Boolean> ci){if(gunbed$controls())ci.setReturnValue(false);}
    @Inject(method="continueAttack",at=@At("HEAD"),cancellable=true)
    private void gunbed$continue(boolean held,CallbackInfo ci){if(gunbed$controls())ci.cancel();}
    @Inject(method="startUseItem",at=@At("HEAD"),cancellable=true)
    private void gunbed$use(CallbackInfo ci){if(gunbed$controls())ci.cancel();}
}
'''

HUD = r'''package kr.mzs.gunbedvisual;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GUI_CLASS;
import net.minecraft.resources.IDENTIFIER;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
public final class GunbedHud {
    private static final java.util.Set<String> auditFeedStages=new java.util.HashSet<>();
    public static void register(){
        for(var id:java.util.List.of(VanillaHudElements.HEALTH_BAR,VanillaHudElements.ARMOR_BAR,VanillaHudElements.FOOD_BAR,VanillaHudElements.BOSS_BAR,VanillaHudElements.OVERLAY_MESSAGE,VanillaHudElements.HELD_ITEM_TOOLTIP,VanillaHudElements.INFO_BAR,VanillaHudElements.EXPERIENCE_LEVEL))
            HudElementRegistry.replaceElement(id,original->(graphics,delta)->{if(!HudState.INSTANCE.active())original.HUD_CALLBACK(graphics,delta);});
        HudElementRegistry.addFirst(IDENTIFIER.fromNamespaceAndPath("gunbed","optic"),(graphics,delta)->scope(graphics));
        HudElementRegistry.addLast(IDENTIFIER.fromNamespaceAndPath("gunbed","fps"),(graphics,delta)->render(graphics));
    }
    private static void scope(GUI_CLASS g){int w=g.guiWidth(),h=g.guiHeight();
        if(HudState.INSTANCE.active()&&VisualState.INSTANCE.optic()){int cx=w/2,cy=h/2,r=(int)(Math.min(w,h)*.485);for(int row=0;row<h;row+=2){int dy=row-cy;int span=Math.abs(dy)>=r?0:(int)Math.sqrt(r*r-dy*dy);g.fill(0,row,cx-span,row+2,0xFF000000);g.fill(cx+span,row,w,row+2,0xFF000000);}g.fill(cx-r,cy,cx,cy+1,0xFF171B15);g.fill(cx+1,cy,cx+r,cy+1,0xFF171B15);g.fill(cx,cy-r,cx+1,cy,0xFF171B15);g.fill(cx,cy+1,cx+1,cy+r,0xFF171B15);g.fill(cx,cy,cx+1,cy+1,0xFFBE4934);}
    }
    private static void render(GUI_CLASS g){
        renderFeeds(g);HudState state=HudState.INSTANCE;if(!state.active())return;if(state.building()){int cx=g.guiWidth()/2,cy=g.guiHeight()/2+40;g.fill(cx-75,cy,cx+75,cy+5,0xB019202A);g.fill(cx-75,cy,cx-75+(int)(150*state.buildProgress()),cy+5,0xFF72D7CF);g.TEXT(Minecraft.getInstance().font,"포탑 설치 · "+String.format(java.util.Locale.ROOT,"%.1f",5*(1-state.buildProgress()))+"초",cx-60,cy-13,0xFFE9EFF6);}
        var client=Minecraft.getInstance();if(client.player==null)return;var font=client.font;float scale=Math.min((float)state.scale,Math.min(g.guiWidth()/420f,g.guiHeight()/240f));g.pose().pushMatrix();g.pose().scale(scale,scale);int w=(int)(g.guiWidth()/scale),h=(int)(g.guiHeight()/scale);
        int health=(int)Math.ceil(state.health/state.maxHealth*100),color=health<=33?0xFFFF5454:health<=66?0xFFFFA849:0xFFA5EB7B;
        g.fill(8,h-17,116,h-1,0x990C1118);
        var armor=switch(state.armorTier){case 2->Items.CHAINMAIL_CHESTPLATE;case 3->Items.IRON_CHESTPLATE;case 4->Items.DIAMOND_CHESTPLATE;default->Items.LEATHER_CHESTPLATE;};
        g.ITEM(new ItemStack(armor),9,h-17);g.TEXT(font,new String[]{"I","II","III","IV"}[Math.max(0,Math.min(3,state.armorTier-1))],27,h-13,0xFF8EC5EE);
        g.TEXT(font,Integer.toString((int)Math.ceil(state.health/(state.maxHealth<1000?state.maxHealth/100:100))),45,h-15,color);g.TEXT(font,state.absorption>0?"+"+(int)Math.ceil(state.absorption/100):"HP",82,h-15,state.absorption>0?0xFFFFD45A:0xFFC4CDD5);g.fill(43,h-4,110,h-2,0xFF27313B);g.fill(43,h-4,43+(int)(67*Math.max(0,Math.min(1,state.health/state.maxHealth))),h-2,color);
        if(state.tracking()){String tracking="Tracking: "+state.trackingName+" · "+(state.trackingWaiting?"리스폰 대기":String.format(java.util.Locale.ROOT,"%.1fm",state.trackingDistance));g.TEXT(font,tracking,(w-font.width(tracking))/2,h-62,0xFFFFFFFF);}
        var resourceItems=new net.minecraft.world.item.Item[]{Items.IRON_INGOT,Items.GOLD_INGOT,Items.DIAMOND,Items.EMERALD};
        for(int i=0;i<4;i++){int x=8+i*54,y=h-35;g.fill(x,y,x+52,y+17,0x880C1118);g.ITEM(new ItemStack(resourceItems[i]),x,y);g.TEXT(font,HudState.count(state.resources[i]),x+18,y+5,0xFFE2EAF1);}
        if(state.controlled){int x=Math.max(125,w-147);g.fill(x,h-65,w-8,h-23,0x990C1118);g.fill(x,h-25,w-8,h-23,0xFF75AED5);g.ITEM(client.player.getMainHandItem(),x+5,h-60);String name=state.name;while(font.width(name)>w-x-30&&name.length()>3)name=name.substring(0,name.length()-1);g.TEXT(font,name,x+25,h-56,0xFFF2F5F8);g.TEXT(font,(state.ammo<0||state.mode.equals("MELEE")||state.capacity<=1&&state.reserve<0)?"∞":Integer.toString(state.ammo),x+9,h-39,0xFFFFFFFF);g.TEXT(font,"/ "+((state.infinite||state.reserve<0||state.mode.equals("MELEE"))?"∞":Integer.toString(Math.max(state.reserve,0)))+"  "+state.mode.toUpperCase(java.util.Locale.ROOT),x+38,h-38,0xFFA3B7C8);}
        int y=9;


        if(state.loadoutPending){int width=Math.min(w-24,330),x=(w-width)/2,top=h/2-(state.loadoutPrevious?65:55);g.fill(0,0,w,h,0x55070C12);g.fill(x,top,x+width,top+(state.loadoutPrevious?128:108),0xEB101923);g.fill(x,top,x+width,top+2,0xFF91D474);g.TEXT(font,"무기 세트를 선택하세요",x+16,top+15,0xFFFFFFFF);g.TEXT(font,"1  랜덤 무기",x+16,top+37,0xFFA5E987);g.TEXT(font,"2  즐겨찾기 무기",x+16,top+57,0xFFFFD58D);g.TEXT(font,"3  무기 수동 선택",x+16,top+77,0xFF8CC9FF);if(state.loadoutPrevious)g.TEXT(font,"4  이전 목숨의 무기 세트",x+16,top+97,0xFFD8AFF7);}
        g.pose().popMatrix();
        if(state.parkourTime()>=0){long ms=state.parkourTime();String time=String.format(java.util.Locale.ROOT,"파쿠르  %d:%02d.%03d",ms/60000,ms/1000%60,ms%1000);int x=(g.guiWidth()-font.width(time))/2;g.fill(x-5,g.guiHeight()-62,x+font.width(time)+5,g.guiHeight()-48,0xB0101922);g.TEXT(font,time,x,g.guiHeight()-59,0xFF74E4EC);}
        if(System.nanoTime()<state.enemyUntil){int width=Math.min(300,g.guiWidth()-30),x=(g.guiWidth()-width)/2;g.TEXT(font,state.enemyName,(g.guiWidth()-font.width(state.enemyName))/2,7,0xFFFFFFFF);g.fill(x,19,x+width,25,0xD0202828);g.fill(x,19,x+(int)(width*state.enemyProgress),25,state.enemyProgress<=.33?0xFFEF5151:state.enemyProgress<=.66?0xFFFFB347:0xFF95DB68);}
        float alpha=state.blindAlpha();if(alpha>0)g.fill(0,0,g.guiWidth(),g.guiHeight(),((int)(255*alpha)<<24)|0xFFFFFF);
    }
    public static void inventory(GUI_CLASS g,int left,int top){var state=HudState.INSTANCE;if(!state.active())return;var font=Minecraft.getInstance().font;int x=left+82,y=top+5;g.fill(x,y,left+174,top+78,0xF0121922);g.pose().pushMatrix();g.pose().translate((float)x+3,(float)y+3);g.pose().scale(.65f,.65f);int row=0;g.TEXT(font,"무기 · 자원 · 이번 경기",0,row,0xFF8AC8E8);row+=11;for(var gun:state.guns){String name=gun.name();while(font.width(name)>68&&name.length()>1)name=name.substring(0,name.length()-1);String ammo=gun.reserve()<0?"∞":gun.ammo()+"/"+gun.reserve()+" ("+(gun.capacity()>0?gun.reserve()/gun.capacity():0)+"회)";g.TEXT(font,name,0,row,0xFFE3EDF5);g.TEXT(font,ammo,70,row,0xFFA5E987);row+=11;}g.TEXT(font,"철 "+state.resources[0]+"   금 "+state.resources[1],0,row,0xFFFFD58D);row+=11;g.TEXT(font,"다이아 "+state.resources[2]+"   에메 "+state.resources[3],0,row,0xFF70DBC1);row+=11;g.TEXT(font,"K "+state.kills+"   FK "+state.finals+"   침대 "+state.beds,0,row,0xFFA5E987);g.pose().popMatrix();if(state.milkTime()>0){int ex=left+178,ey=top+(Minecraft.getInstance().player==null?0:Minecraft.getInstance().player.getActiveEffects().size())*33;if(ex+108>g.guiWidth())ex=Math.max(0,left-110);g.fill(ex,ey,ex+108,ey+32,0xDC1E252B);g.ITEM(new ItemStack(Items.MILK_BUCKET),ex+4,ey+7);g.TEXT(font,"마법의 우유",ex+25,ey+5,0xFFF0F5FA);long seconds=(state.milkTime()+999)/1000;g.TEXT(font,"함정 면역 · "+seconds+"초",ex+25,ey+18,0xFF86DFC6);}}
    private static void renderFeeds(GUI_CLASS g){var client=Minecraft.getInstance();if(client.player==null)return;var rows=HudState.INSTANCE.feeds();if(rows.isEmpty())return;int total=rows.stream().mapToInt(f->f.kind().equals("final")?31:21).sum();float scale=Math.min((float)HudState.INSTANCE.scale,Math.min(g.guiWidth()/420f,(g.guiHeight()-18f)/Math.max(1,total)));g.pose().pushMatrix();g.pose().scale(scale,scale);int w=(int)(g.guiWidth()/scale),y=12;var font=client.font;for(var feed:rows){float alpha=feed.alpha();if(Boolean.getBoolean("gunbed.auditFeed")){String stage=alpha>.99f?"steady":alpha>.2f&&alpha<.8f?"fading":"edge";String key=feed.victim()+stage+client.player.isSpectator();if(auditFeedStages.add(key))GunbedVisualClient.LOG.info("Feed audit {} spectator={} alpha={}",stage,client.player.isSpectator(),alpha);}int a=Math.max(1,(int)(255*alpha));String lead=feed.killer()+(feed.headshot()&&feed.killer().equals(feed.headshotBy())?" [HS]":"");var credit=net.minecraft.network.chat.Component.empty().append(net.minecraft.network.chat.Component.literal(lead).withColor(feed.killerColor()));for(String helper:feed.assists())credit.append(net.minecraft.network.chat.Component.literal(" + ").withColor(0xA5ADB5)).append(net.minecraft.network.chat.Component.literal(helper+(feed.headshot()&&helper.equals(feed.headshotBy())?" [HS]":"")).withColor(feed.assistColors().getOrDefault(helper,0xE9EFF6)));if(feed.headshot()&&!feed.killer().equals(feed.headshotBy())&&!feed.assists().contains(feed.headshotBy()))credit.append(net.minecraft.network.chat.Component.literal(" [HS: "+feed.headshotBy()+"]").withColor(0xFFD65A));if(feed.extraAssists()>0)credit.append(net.minecraft.network.chat.Component.literal(" 외 "+feed.extraAssists()+"명").withColor(0xA5ADB5));var victim=net.minecraft.network.chat.Component.literal(feed.victim()).withColor(feed.victimColor()).append(net.minecraft.network.chat.Component.literal(feed.kind().equals("bed")?" BED":"").withColor(0xFFD587));int width=font.width(credit)+font.width(victim)+35,x=Math.max(8,w-width-8);boolean fin=feed.kind().equals("final");int line=y+(fin?10:0);g.fill(x,y-3,w-8,line+16,((int)(187*alpha)<<24)|0x11171F);if(fin)g.TEXT(font,net.minecraft.network.chat.Component.literal("파이널 킬!").withStyle(net.minecraft.ChatFormatting.AQUA,net.minecraft.ChatFormatting.BOLD),x+5,y,(a<<24)|0xFFFFFF);g.TEXT(font,credit,x+5,line+2,(a<<24)|0xFFFFFF);int iconX=x+font.width(credit)+9;String path=feed.icon().startsWith("gunbed:")?feed.icon().substring(7):"vanilla/"+feed.icon().split(":")[feed.icon().contains(":")?1:0];g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,IDENTIFIER.parse("gunbed:textures/feed/"+path+".png"),iconX,line-2,0f,0f,16,16,16,16,(a<<24)|0xFFFFFF);g.TEXT(font,victim,iconX+20,line+2,(a<<24)|0xFFFFFF);y+=fin?31:21;}g.pose().popMatrix();}
    private static ItemStack feedIcon(String id){try{if(id.startsWith("gunbed:")){ItemStack item=new ItemStack(Items.PAPER);item.set(net.minecraft.core.component.DataComponents.ITEM_MODEL,IDENTIFIER.parse(id));return item;}return new ItemStack(net.minecraft.core.registries.BuiltInRegistries.ITEM.getValue(IDENTIFIER.parse(id)));}catch(RuntimeException ignored){return new ItemStack(Items.IRON_SWORD);}}
}
'''


def generate(version):
    from generate_turret_adapter import generate as generate_turret
    profile = VERSIONS[version]
    output = CLIENT / ".generated" / version
    package = output / "java/kr/mzs/gunbedvisual"
    package.mkdir(parents=True, exist_ok=True)
    legacy = profile["legacy"]
    buffer_name = "MultiBufferSource" if legacy else "SubmitNodeCollector"
    buffer_import = "net.minecraft.client.renderer." + buffer_name
    if legacy:
        render_imports = "import net.minecraft.client.renderer.MultiBufferSource;\nimport net.minecraft.client.renderer.RenderType;\nimport net.minecraft.client.renderer.entity.player.PlayerRenderer;"
        geometry = "var renderType=(frame.surfaces().isEmpty()?RenderType.entityCutout(texture):RenderType.entityCutoutNoCull(texture)); vertices(frame,matrices.last(),buffers.getBuffer(renderType),light);if(state.flashActive()&&frame.muzzle()!=null){var flash=state.flashFrame(frame);vertices(flash,matrices.last(),buffers.getBuffer(RenderType.entityTranslucent(IDENTIFIER.parse(state.flashTexture()))),15728880);}"
        arm = "((PlayerRenderer)Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(local)).render%sHand(matrices,buffers,light,local.getSkin().texture(),local.isModelPartShown(PlayerModelPart.%s_SLEEVE));"
    else:
        render_imports = "import net.minecraft.client.renderer.SubmitNodeCollector;\nimport net.minecraft.client.renderer.rendertype.RenderTypes;\nimport net.minecraft.client.renderer.entity.player.AvatarRenderer;"
        geometry = "var renderType=(frame.surfaces().isEmpty()?RenderTypes.entityCutout(texture):RenderTypes.entityCutoutNoCull(texture));buffers.submitCustomGeometry(matrices,renderType,(pose,consumer)->vertices(frame,pose,consumer,light));if(state.flashActive()&&frame.muzzle()!=null){var flash=state.flashFrame(frame);buffers.submitCustomGeometry(matrices,RenderTypes.entityTranslucent(IDENTIFIER.parse(state.flashTexture())),(pose,consumer)->vertices(flash,pose,consumer,15728880));}"
        skin = "local.getSkin().body().texturePath()"
        arm = "Minecraft.getInstance().getEntityRenderDispatcher().getPlayerRenderer(local).render%sHand(matrices,buffers,light," + skin + ",local.isModelPartShown(PlayerModelPart.%s_SLEEVE));"
    if version == "26.3":
        arm = arm.replace("Minecraft.getInstance().getEntityRenderDispatcher().getPlayerRenderer(local)", "((AvatarRenderer<?>)Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(local))")
    if version.startswith("26."):geometry=geometry.replace("RenderTypes.entityCutoutNoCull(texture)","RenderTypes.entityCutout(texture)")
    render = RENDER.replace("BUFFER_ARG", buffer_name).replace("RENDER_IMPORTS", render_imports).replace("DRAW_SURFACE",geometry.split("if(state.flashActive()",1)[0].replace("vertices(frame,","vertices(surface,")).replace("DRAW_FLASH",("if(state.flashActive()"+geometry.split("if(state.flashActive()",1)[1]) if "if(state.flashActive()" in geometry else "").replace("IDENTIFIER", profile["id"])
    if version in ("1.21.9", "1.21.10"):
        render = render.replace("net.minecraft.client.renderer.rendertype.RenderTypes", "net.minecraft.client.renderer.RenderType").replace("RenderTypes.", "RenderType.")
    render = render.replace("PLAYER_SKIN", "local.getSkin().texture()" if profile["legacy"] else skin)
    render = render.replace("DRAW_RIGHT", arm % ("Right", "RIGHT"))
    render = render.replace("DRAW_LEFT", arm % ("Left", "LEFT"))
    (package / "GunbedRender.java").write_text(render, encoding="utf-8")
    generate_turret(package,version,profile["id"],legacy)
    category = '"key.categories.gameplay"' if legacy else 'net.minecraft.client.KeyMapping.Category.GAMEPLAY'
    network = NETWORK.replace("IDENTIFIER", profile["id"]).replace("MC_VERSION", version).replace("KEY_CATEGORY",category)
    if version.startswith("26."):
        network = network.replace("playS2C()", "clientboundPlay()").replace("playC2S()", "serverboundPlay()")
        network = network.replace("net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding", "net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper.registerKeyMapping")
    if version in ("26.2", "26.3"):
        network = network.replace("client.screen==null", "client.gui.screen()==null").replace("net.minecraft.client.Minecraft.getInstance().screen,java.net.URI", "net.minecraft.client.Minecraft.getInstance().gui.screen(),java.net.URI")
        network = network.replace('net.minecraft.client.Screenshot.grab(client.gameDirectory,"gunbed-"+tick+".png",client.getMainRenderTarget(),1,message->{});', 'net.minecraft.client.Screenshot.grab(client,false);')
    if version == "26.3":
        network = network.replace("InputConstants.Type.KEYSYM", "InputConstants.Type.KEYBOARD").replace("org.lwjgl.glfw.GLFW.GLFW_KEY_R", "com.mojang.blaze3d.platform.InputConstants.KEY_R").replace("org.lwjgl.glfw.GLFW.GLFW_KEY_V", "com.mojang.blaze3d.platform.InputConstants.KEY_V")
    (package / "GunbedVisualClient.java").write_text(network, encoding="utf-8")
    modern_gui=version.startswith("26.")
    hud=HUD.replace("IDENTIFIER",profile["id"]).replace("GUI_CLASS","GuiGraphicsExtractor" if modern_gui else "GuiGraphics").replace("HUD_CALLBACK","extractRenderState" if modern_gui else "render").replace("g.TEXT", "g.text" if modern_gui else "g.drawString").replace("g.ITEM","g.item" if modern_gui else "g.renderItem")
    (package / "GunbedHud.java").write_text(hud,encoding="utf-8")
    (package / "mixin").mkdir(exist_ok=True)
    mixin = MODERN_MIXIN if version == "26.3" else MIXIN.replace("BUFFER_IMPORT", buffer_import).replace("BUFFER_ARG", buffer_name)
    if version == "26.2":mixin=mixin.replace('method="renderArmWithItem"','method="submitArmWithItem"')
    (package / "mixin/GunbedHandMixin.java").write_text(mixin, encoding="utf-8")
    inventory_mixin = r'''package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(net.minecraft.client.gui.screens.inventory.InventoryScreen.class)
public abstract class GunbedInventoryMixin {
 @Inject(method="init",at=@At("HEAD"))
 private void gunbedHideBook(CallbackInfo ci){var player=net.minecraft.client.Minecraft.getInstance().player;if(player!=null&&kr.mzs.gunbedvisual.HudState.INSTANCE.active())player.getRecipeBook().setOpen(net.minecraft.world.inventory.RecipeBookType.CRAFTING,false);}
 @Inject(method="BACKGROUND",at=@At("TAIL"))
 private void gunbedPanel(net.minecraft.client.gui.GUI g,BGARGSCallbackInfo ci){if(!kr.mzs.gunbedvisual.HudState.INSTANCE.active())return;var screen=(net.minecraft.client.gui.screens.inventory.InventoryScreen)(Object)this;var mc=net.minecraft.client.Minecraft.getInstance();int left=(screen.width-176)/2,top=(screen.height-166)/2;kr.mzs.gunbedvisual.GunbedHud.inventory(g,left,top);}
 @Inject(method="LABELS",at=@At("HEAD"),cancellable=true)
 private void gunbedLabels(net.minecraft.client.gui.GUI g,int mouseX,int mouseY,CallbackInfo ci){if(kr.mzs.gunbedvisual.HudState.INSTANCE.active())ci.cancel();}
 @Inject(method="init",at=@At("TAIL"))
 private void gunbedRecipe(CallbackInfo ci){if(!kr.mzs.gunbedvisual.HudState.INSTANCE.active())return;var screen=(net.minecraft.client.gui.screens.inventory.InventoryScreen)(Object)this;for(var child:screen.children())if(child instanceof net.minecraft.client.gui.components.ImageButton b)b.visible=false;}
}
'''
    inventory_mixin=inventory_mixin.replace("BACKGROUND","extractBackground" if modern_gui else "renderBg").replace("LABELS","extractLabels" if modern_gui else "renderLabels").replace("GUI","GuiGraphicsExtractor" if modern_gui else "GuiGraphics").replace("BGARGS","int mx,int my,float partial," if modern_gui else "float partial,int mx,int my,")
    (package/"mixin/GunbedInventoryMixin.java").write_text(inventory_mixin,encoding="utf8")
    count_mixin=r'''package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
@Mixin(net.minecraft.client.gui.GUI.class)
public abstract class GunbedCountMixin {
 @ModifyVariable(method="DECORATIONS(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;IILjava/lang/String;)V",at=@At("HEAD"),argsOnly=true,ordinal=0)
 private String gunbedCount(String value,net.minecraft.client.gui.Font font,net.minecraft.world.item.ItemStack item,int x,int y,String original){return kr.mzs.gunbedvisual.ItemCounts.label(item,value);}
}
'''
    count_mixin=count_mixin.replace("GUI","GuiGraphicsExtractor" if modern_gui else "GuiGraphics").replace("DECORATIONS","itemDecorations" if modern_gui else "renderItemDecorations")
    (package/"mixin/GunbedCountMixin.java").write_text(count_mixin,encoding="utf8")
    (package / "mixin/GunbedInputMixin.java").write_text(INPUT_MIXIN.replace("client.screen!=null","client.gui.screen()!=null") if version in ("26.2","26.3") else INPUT_MIXIN,encoding="utf-8")
    fov='''package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(TARGET.class)
public abstract class GunbedFovMixin {
    @Inject(method="METHOD",at=@At("RETURN"),cancellable=true)
    private void gunbedZoom(PARAMS CallbackInfoReturnable<Float> ci){var player=net.minecraft.client.Minecraft.getInstance().player;if(CONDITION player!=null&&kr.mzs.gunbedvisual.GunbedRender.active(player))ci.setReturnValue(kr.mzs.gunbedvisual.VisualState.INSTANCE.zoomFov(ci.getReturnValue()));}
}
'''
    if version.startswith('26.'):
        fov=fov.replace('TARGET','net.minecraft.client.Camera').replace('METHOD','calculateFov').replace('PARAMS','float partial,').replace('CONDITION','')
    else:
        fov=fov.replace('TARGET','net.minecraft.client.renderer.GameRenderer').replace('METHOD','getFov').replace('PARAMS','net.minecraft.client.Camera camera,float partial,boolean useFov,').replace('CONDITION','useFov&&')
    (package/'mixin/GunbedFovMixin.java').write_text(fov,encoding='utf-8')
    (package / "mixin/GunbedWorldMixin.java").write_text('''package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(net.minecraft.client.multiplayer.ClientPacketListener.class)
public abstract class GunbedWorldMixin {
    @Inject(method="handleRespawn",at=@At("HEAD"))
    private void gunbedWorld(net.minecraft.network.protocol.game.ClientboundRespawnPacket packet,CallbackInfo ci){kr.mzs.gunbedvisual.PackOwnership.transition();kr.mzs.gunbedvisual.VisualState.INSTANCE.clear();kr.mzs.gunbedvisual.HudState.INSTANCE.transition();}
}
''',encoding="utf-8")
    (package/'mixin/GunbedPackMixin.java').write_text('''package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(net.minecraft.client.multiplayer.ClientCommonPacketListenerImpl.class)
public abstract class GunbedPackMixin {
 @Inject(method="handleResourcePackPush",at=@At("RETURN"))
 private void gunbedPack(net.minecraft.network.protocol.common.ClientboundResourcePackPushPacket packet,CallbackInfo ci){kr.mzs.gunbedvisual.PackOwnership.pushed(packet.id(),packet.url());}
}
''',encoding='utf-8')
    (package/'mixin/GunbedCloudMixin.java').write_text('''package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(net.minecraft.client.renderer.CloudRenderer.class)
public abstract class GunbedCloudMixin {
    @Inject(method="render",at=@At("HEAD"),cancellable=true)
    private void gunbedClouds(CallbackInfo ci){if(kr.mzs.gunbedvisual.HudState.INSTANCE.active())ci.cancel();}
}
''',encoding='utf-8')
    (package/'mixin/GunbedLandingSoundMixin.java').write_text('''package kr.mzs.gunbedvisual.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(net.minecraft.client.sounds.SoundManager.class)
public abstract class GunbedLandingSoundMixin {
 @Inject(method="play",at=@At("HEAD"),cancellable=true)
 private void gunbedLanding(net.minecraft.client.resources.sounds.SoundInstance sound,CallbackInfoReturnable<net.minecraft.client.sounds.SoundEngine.PlayResult> ci){var p=net.minecraft.client.Minecraft.getInstance().player;if(p==null||!kr.mzs.gunbedvisual.HudState.INSTANCE.active())return;double dx=sound.getX()-p.getX(),dy=sound.getY()-p.getY(),dz=sound.getZ()-p.getZ();if(dx*dx+dy*dy+dz*dz<4&&kr.mzs.gunbedvisual.GroundAudio.mute(sound.getLocation().getPath(),p.getY()))ci.setReturnValue(net.minecraft.client.sounds.SoundEngine.PlayResult.NOT_STARTED);}
}
''',encoding='utf-8')
    if profile["id"]=="Identifier":
        sound_file=package/'mixin/GunbedLandingSoundMixin.java'
        sound_file.write_text(sound_file.read_text().replace('sound.getLocation()','sound.getIdentifier()'),encoding='utf-8')
    resources = output / "resources"
    resources.mkdir(exist_ok=True)
    dump(resources / "fabric.mod.json", {"schemaVersion": 1, "id": "gunbed_visuals", "version": "0.3.16", "name": "Gunbed Visuals",
        "environment": "client", "license": "GPL-3.0-only", "entrypoints": {"client": ["kr.mzs.gunbedvisual.GunbedVisualClient"]},
        "mixins": ["gunbed.mixins.json"], "depends": {"fabricloader": ">=0.19.5", "minecraft": profile["range"], "fabric-api": "*", "nuit": ">=1.0.0-beta.1", "gunbed_assets": ">=0.3.16 <0.4.0"}})
    dump(resources / "gunbed.mixins.json", {"required": True, "package": "kr.mzs.gunbedvisual.mixin", "compatibilityLevel": "JAVA_25" if version.startswith("26") else "JAVA_21",
        "client": ["GunbedLandingSoundMixin","GunbedCountMixin","GunbedHandMixin","GunbedInputMixin","GunbedWorldMixin","GunbedFovMixin","GunbedCloudMixin","GunbedPackMixin","GunbedInventoryMixin","GunbedTurretMixin","GunbedTurretStateMixin","GunbedVisibilityMixin"], "injectors": {"defaultRequire": 1}})
    language = resources / "assets/gunbed/lang"
    language.mkdir(parents=True,exist_ok=True)
    dump(language / "en_us.json", {"key.gunbed.reload":"Reload Gunbed weapon","key.gunbed.aim":"Gunbed iron sights (hold)"})
    dump(language / "ko_kr.json", {"key.gunbed.reload":"Gunbed 총기 재장전","key.gunbed.aim":"Gunbed 가늠쇠 조준 (누르는 동안)"})
    url = "https://api.modrinth.com/v2/project/fabric-api/version?loaders=%5B%22fabric%22%5D&game_versions=" + urllib.parse.quote(json.dumps([version]))
    with urllib.request.urlopen(url, timeout=30) as response: releases = json.loads(response.read())
    release = next(r for r in releases if r["version_type"] == "release")
    (output / "fabric-version.txt").write_text(release["version_number"], encoding="utf-8")
    dump(output / "fabric-release.json", release)
    print(json.dumps({"minecraft": version, "fabric_api": release["version_number"]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser();parser.add_argument("version", choices=VERSIONS)
    args = parser.parse_args();generate(args.version)
    # Raw art assets, never converted into Minecraft item models or rewritten.
    art = ROOT / ".local/vendor/TACZ-FabricContinued/src/main/resources/assets/tacz/custom/tacz_default_gun/assets/tacz"
    target = CLIENT / "src/main/resources/assets/tacz"
    for folder in ("geo_models/gun", "animations", "textures/gun"):
        for source in (art / folder).rglob("*"):
            if source.is_file():
                destination=target/folder/source.relative_to(art/folder)
                if not destination.exists():
                    destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,destination)

