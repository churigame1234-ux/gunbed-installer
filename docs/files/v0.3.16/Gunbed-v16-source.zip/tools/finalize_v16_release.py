import json,shutil,zipfile
from server_audit import ROOT,dump,sha256
from download_release_guard import validate_download_site
version='0.3.16';assets=ROOT/f'.local/publication-assets-v{version}';public=ROOT/f'distribution/docs/files/v{version}';meta=ROOT/f'.local/installer-online-v{version}'
build=json.loads((ROOT/'reports/online-installer-build.json').read_text());exe=assets/'GunbedInstaller.exe';assert sha256(exe)==build['sha256'];shutil.copy2(exe,public/exe.name)
archive=public/f'GunbedInstaller-{version}.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.write(exe,exe.name);z.writestr('README.txt','Gunbed Installer 0.3.16 / adapters 0.3.16 / shared assets 0.3.16\r\nWAT guns, DeltaForce melees, 42Labs throwables, persistent spectator feed and tracker HUD.\r\nRun installer, select version and your existing game folder. Other mods, settings and worlds are preserved.\r\n57 firearms, 11 melee presets and 3 throwable presets added.\r\n')
shutil.copy2(archive,assets/archive.name)
source=assets/'GunbedInstaller-source.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
    for p in (ROOT/'installer').glob('*.py'):z.write(p,'installer/'+p.name)
    for p in meta.rglob('*'):
        if p.is_file():z.write(p,'bootstrap/'+p.relative_to(meta).as_posix())
    z.write(ROOT/'distribution/LICENSE','LICENSE')
shutil.copy2(source,public/source.name)
data=json.loads((ROOT/'distribution/docs/downloads.json').read_text());data.update(version=version,client_version=version,shared_assets_version=version,online_bytes=build['size'],direct_url=f'files/v{version}/GunbedInstaller.exe',raw_url=f'https://raw.githubusercontent.com/churigame1234-ux/gunbed-installer/main/docs/files/v{version}/GunbedInstaller.exe',release_base=f'https://github.com/churigame1234-ux/gunbed-installer/releases/download/v{version}/',archive={'url':f'https://churigame1234-ux.github.io/gunbed-installer/files/v{version}/'+archive.name,'size':archive.stat().st_size,'sha256':sha256(archive)},versions=build['files'])
# Old offline executable contains the old optics: do not offer it as an updated alternative.
data.pop('offline',None)
dump(ROOT/'distribution/docs/downloads.json',data)
files=[p for p in assets.iterdir() if p.is_file() and p.name not in ('SHA256SUMS.txt','GunbedInstaller-Offline.exe')]
(assets/'SHA256SUMS.txt').write_text(''.join(sha256(p)+'  '+p.name+'\n' for p in sorted(files)),encoding='utf-8');shutil.copy2(assets/'SHA256SUMS.txt',public/'SHA256SUMS.txt')
result=validate_download_site(ROOT/'distribution/docs',version);dump(ROOT/'reports/v16-release-package.json',{'success':True,**result,'asset_sha256':sha256(assets/f'GunbedAssets-{version}.jar')});print(json.dumps(result))
