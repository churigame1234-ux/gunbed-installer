"""Import the three public archives into Gunbed's existing neutral art/data format."""
import copy,hashlib,json,shutil
from pathlib import Path
import json5
from server_audit import ROOT,dump,sha256

R=ROOT/'client/src/main/resources';work=ROOT/'.local/addons-v16';server=json5.loads((ROOT/'src/main/resources/tacz-catalog.json').read_text(encoding='utf-8'));client=json5.loads((R/'assets/tacz/gunbed_catalog.json').read_text(encoding='utf-8'));original=set(client['guns']);added=[];deduplicated=[]
def read(p):
 text=p.read_text(encoding='utf-8-sig')
 try:return json.loads(text)
 except json.JSONDecodeError:return json5.loads(text)
melee={};throwables={};signatures=set()

def resource(root,kind,ref,ext):
 ns,path=ref.split(':',1);return root/'assets'/ns/kind/(path+ext)

def aliases(root,ns,display,anim):
 dest=R/'assets'/ns;audio={p.relative_to(root/'assets'/ns/'tacz_sounds').with_suffix('').as_posix():p for p in (root/'assets'/ns/'tacz_sounds').rglob('*.ogg')};sounds=read(dest/'sounds.json') if (dest/'sounds.json').exists() else {};refs=set(display.get('sounds',{}).values());mapping={}
 for v in anim.get('animations',{}).values():
  for cues in v.get('sound_effects',{}).values():
   for cue in cues if isinstance(cues,list) else [cues]:
    if isinstance(cue,dict) and isinstance(cue.get('effect'),str):refs.add(cue['effect'])
 for ref in refs:
  path=ref.split(':')[-1];name=path if path in audio else next((n for n in audio if n.endswith('/'+path) or n.rsplit('/',1)[-1]==path),None)
  if name is None:continue
  target=dest/'sounds'/('gunbed/'+name+'.ogg');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(audio[name],target);key='gunbed.'+name.replace('/','.');sounds[key]={'sounds':[{'name':ns+':gunbed/'+name}]};mapping[ref]=ns+':'+key
 dump(dest/'sounds.json',sounds);return mapping

def entry(root,ns,id,name,type,display,data):
 model=resource(root,'geo_models',display['model'],'.json');texture=resource(root,'textures',display['texture'],'.png');animation=resource(root,'animations',display['animation'],'.animation.json');raw=read(animation);sig=tuple(sha256(p) for p in (model,texture,animation))
 if sig in signatures:deduplicated.append(id);return None
 signatures.add(sig);out={'id':id,'name':name,'type':type,'data':data,'model':model.relative_to(root).as_posix(),'texture':display['texture'].split(':')[0]+':textures/'+display['texture'].split(':')[1]+'.png','animation':animation.relative_to(root).as_posix(),'display':display,'clips':{k:{'duration':v.get('animation_length',1),'sound_effects':v.get('sound_effects',{})} for k,v in raw['animations'].items()},'soundAliases':aliases(root,ns,display,raw),'source_pack':ns}
 if display.get('use_default_animation'):
  p=ROOT/'.local/tacz-1.2-defaults'/(display['use_default_animation']+'_default.animation.json');target=R/'assets/tacz/animations/defaults/v12'/p.name
  assert p.exists(),p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);out['defaultAnimation']=target.relative_to(R).as_posix()
 client['guns'][id]=out;added.append(id);return out

def icon(root,display,id,category):
 ref=display.get('slot_texture',display.get('slot',display.get('hud')));src=resource(root,'textures',ref,'.png');target=R/'assets/gunbed/textures/item'/category/(id+'.png');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target);dump(R/f'assets/gunbed/items/{category}/{id}.json',{'model':{'type':'minecraft:model','model':f'gunbed:item/{category}/{id}'}});dump(R/f'assets/gunbed/models/item/{category}/{id}.json',{'parent':'minecraft:item/generated','textures':{'layer0':f'gunbed:item/{category}/{id}'}})

for pack,ns in [('wat','ronmc'),('delta','delta_wt'),('labs','42labk')]:
 root=work/pack;art=root/'assets'/ns;dest=R/'assets'/ns
 for f in art.rglob('*'):
  if f.is_file() and f.suffix.lower() in ('.json','.png','.ogg'):
   target=dest/f.relative_to(art);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
 lang=read(art/'lang/en_us.json')
 if pack=='wat':
  for f in sorted((root/'data'/ns/'index/guns').glob('*.json')):
   idx=read(f);display=read(art/'display/guns'/(idx['display'].split(':')[1]+'.json'));data=read(root/'data'/ns/'data/guns'/(idx['data'].split(':')[1]+'.json'));id='wat_'+f.stem;name='[WAT] '+lang.get(idx['name'],f.stem)
   if entry(root,ns,id,name,idx['type'],display,data):server['guns'][id]=copy.deepcopy(client['guns'][id]);icon(root,display,id,'ta')
 if pack=='delta':
  for f in sorted((root/'data'/ns/'index/melee').glob('*.json')):
   idx=read(f);display=read(art/'display/melee'/f.name);id='delta_'+f.stem;name='[DF] '+lang.get(idx['name'],f.stem.replace('_',' ').title());out=entry(root,ns,'lr_'+id,name,'melee',display,idx['data'])
   if out:melee[id]={'name':name,'data':idx['data'],'model':'lr_'+id};icon(root,display,id,'melee')
 if pack=='labs':
  for f in sorted((root/'data'/ns/'index/throwable').glob('*.json')):
   idx=read(f);display=read(art/'display/throwable'/f.name);kind={'gas':'labs_gas','glt':'labs_he','impact':'labs_impact'}[f.stem];name={'gas':'42Labs 독가스탄','glt':'42Labs 지연 폭발탄','impact':'42Labs 충격 폭발탄'}[f.stem]
   out=entry(root,ns,'qa_'+kind,name,'throwable',display,idx['data'])
   if out:throwables[kind]={'name':name,'data':idx['data'],'model':'qa_'+kind};icon(root,display,kind,'throwable')

dump(ROOT/'src/main/resources/tacz-catalog.json',server);dump(R/'assets/tacz/gunbed_catalog.json',client);dump(ROOT/'src/main/resources/addon-melee-v16.json',melee);dump(ROOT/'src/main/resources/addon-throwables-v16.json',throwables)
dump(ROOT/'reports/addons-v16-import.json',{'success':True,'added':added,'guns':len([s for s in added if s.startswith('wat_')]),'melee':len(melee),'throwables':len(throwables),'exact_duplicates_excluded':deduplicated,'original_ids_preserved':original<=set(client['guns']),'source_files':{name:sha256(work/(name+'.zip')) for name in ['wat','delta','labs']}})
print(json.dumps({'success':True,'guns':len(server['guns']),'new':len(added),'melee':len(melee),'throwables':len(throwables),'duplicates':deduplicated}))
