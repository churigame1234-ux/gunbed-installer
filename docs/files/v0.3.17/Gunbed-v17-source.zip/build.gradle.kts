plugins { java }

group = "kr.mzs.gunbed"
version = "1.0.0"

java { toolchain { languageVersion.set(JavaLanguageVersion.of(21)) } }

dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
    compileOnly(files(".local/downloads/MZSBotCore.jar", ".local/downloads/BedWars-0.2.44.jar", ".local/downloads/ComplexTurrets-3.28.1.jar"))
    compileOnly(fileTree(".local/staging/plugins") { include("TAB*.jar", "PlaceholderAPI*.jar", "CrackShot *.jar", "ProtocolLib*.jar") })
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(21)
}

tasks.jar { archiveFileName.set("GunbedCore.jar") }

val probe by sourceSets.creating {
    java.srcDir("tools/probe/java")
    resources.srcDir("tools/probe/resources")
    compileClasspath += sourceSets.main.get().compileClasspath
}
tasks.register<Jar>("probeJar") {
    dependsOn(tasks.named(probe.classesTaskName))
    from(probe.output)
    archiveFileName.set("GunbedProbe.jar")
    destinationDirectory.set(layout.buildDirectory.dir("probe"))
}

val hub by sourceSets.creating {
    java.srcDir("hub/src/main/java")
    resources.srcDir("hub/src/main/resources")
    compileClasspath += sourceSets.main.get().compileClasspath
}
tasks.register<Jar>("hubJar") {
    dependsOn(tasks.named(hub.classesTaskName))
    from(hub.output)
    archiveFileName.set("MZSSharedHub.jar")
    destinationDirectory.set(layout.buildDirectory.dir("hub"))
}
