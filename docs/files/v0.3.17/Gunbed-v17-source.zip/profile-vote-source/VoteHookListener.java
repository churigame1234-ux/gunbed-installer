package kr.mzs.profile;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.EventExecutor;

import java.lang.reflect.Method;

final class VoteHookListener implements Listener {
    private final MZSProfilePlugin plugin;

    VoteHookListener(MZSProfilePlugin plugin) {
        this.plugin = plugin;
    }

    void registerIfPresent() {
        if (NuVoteV17.install(plugin)) return;
        Class<? extends Event> eventClass = findVoteEvent();
        if (eventClass == null) {
            plugin.getLogger().info("VotingPlugin vote event not found. Vote rewards will wait until VotingPlugin is available.");
            return;
        }
        EventExecutor executor = (listener, event) -> handleVote(event);
        Bukkit.getPluginManager().registerEvent(eventClass, this, EventPriority.MONITOR, executor, plugin, true);
        plugin.getLogger().info("VotingPlugin vote hook registered: " + eventClass.getName());
    }

    @SuppressWarnings("unchecked")
    private Class<? extends Event> findVoteEvent() {
        for (String name : new String[]{
                "com.bencodez.votingplugin.events.PlayerVoteEvent",
                "com.bencodez.votingplugin.events.VotifierEvent"
        }) {
            try {
                Class<?> raw = Class.forName(name);
                if (Event.class.isAssignableFrom(raw)) {
                    return (Class<? extends Event>) raw;
                }
            } catch (ClassNotFoundException ignored) {
            }
        }
        return null;
    }

    private void handleVote(Event event) {
        String name = extractPlayerName(event);
        if (name == null || name.isBlank()) {
            plugin.getLogger().warning("Vote event received but player name could not be read: " + event.getClass().getName());
            return;
        }
        plugin.recordVote(name);
        plugin.getLogger().info("[MZSProfile] vote counted for " + name);
    }

    private String extractPlayerName(Object source) {
        for (String methodName : new String[]{"getPlayer", "getPlayerName", "getUsername", "getName", "getUser"}) {
            try {
                Method method = source.getClass().getMethod(methodName);
                Object value = method.invoke(source);
                String extracted = valueToName(value);
                if (extracted != null && !extracted.isBlank()) {
                    return extracted;
                }
            } catch (ReflectiveOperationException ignored) {
            }
        }
        return null;
    }

    private String valueToName(Object value) {
        if (value instanceof Player player) {
            return player.getName();
        }
        if (value instanceof OfflinePlayer offlinePlayer) {
            return offlinePlayer.getName();
        }
        if (value instanceof String text) {
            return text;
        }
        if (value != null) {
            return extractPlayerName(value);
        }
        return null;
    }
}
