package kr.mzs.profile;
import java.sql.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.bukkit.*;
import org.bukkit.event.*;
import org.bukkit.plugin.*;

/** Count the signed receiver event, even while the voter is on another backend. */
final class NuVoteV17 implements Listener {
 static boolean install(MZSProfilePlugin plugin){try{
  Plugin receiver=Arrays.stream(Bukkit.getPluginManager().getPlugins()).filter(p->p.getName().equalsIgnoreCase("Votifier")||p.getName().equalsIgnoreCase("NuVotifier")).findFirst().orElse(null);
  if(receiver==null)return false;
  Class<?> raw=Class.forName("com.vexsoftware.votifier.model.VotifierEvent",true,receiver.getClass().getClassLoader());
  for(var listener:HandlerList.getRegisteredListeners(plugin))if(listener.getListener().getClass()==NuVoteV17.class)return true;
  repair(plugin);
  var listener=new NuVoteV17();
  Bukkit.getPluginManager().registerEvent(raw.asSubclass(Event.class),listener,EventPriority.MONITOR,(l,event)->{
   try {Object vote=raw.getMethod("getVote").invoke(event);String name=(String)vote.getClass().getMethod("getUsername").invoke(vote),service=(String)vote.getClass().getMethod("getServiceName").invoke(vote),stamp=(String)vote.getClass().getMethod("getTimeStamp").invoke(vote);
    Runnable task=()->count(plugin,name,service,stamp);if(Bukkit.isPrimaryThread())task.run();else Bukkit.getScheduler().runTask(plugin,task);
   }catch(Exception e){throw new EventException(e);}
  },plugin,true);
  plugin.getLogger().info("Direct NuVotifier common vote hook installed; receipt deduplication enabled.");return true;
 }catch(ClassNotFoundException missing){return false;}}
 static void repair(MZSProfilePlugin plugin){try{
  var df=MZSProfilePlugin.class.getDeclaredField("database");df.setAccessible(true);Object database=df.get(plugin);var cf=database.getClass().getDeclaredField("connection");cf.setAccessible(true);Connection db=(Connection)cf.get(database);
  synchronized(database){try(var q=db.createStatement()){q.execute("CREATE TABLE IF NOT EXISTS gunbed_vote_receipts_v16(receipt TEXT PRIMARY KEY,username TEXT NOT NULL,at INTEGER NOT NULL)");q.execute("CREATE TABLE IF NOT EXISTS gunbed_vote_identity_repairs_v17(receipt TEXT PRIMARY KEY,from_uuid TEXT NOT NULL,to_uuid TEXT NOT NULL)");}List<String[]> rows=new ArrayList<>();try(var q=db.createStatement();var r=q.executeQuery("SELECT receipt,username FROM gunbed_vote_receipts_v16 WHERE receipt NOT IN (SELECT receipt FROM gunbed_vote_identity_repairs_v17)")){while(r.next())rows.add(new String[]{r.getString(1),r.getString(2)});}
   for(String[] row:rows){UUID from=UUID.nameUUIDFromBytes(("OfflinePlayer:"+row[1]).getBytes(StandardCharsets.UTF_8)),to=canonical(row[1]);if(from.equals(to)||Bukkit.getOfflinePlayer(from).hasPlayedBefore())continue;
    if(!db.getAutoCommit())throw new IllegalStateException("Repair inside another transaction");db.setAutoCommit(false);try{
     int changed;try(var q=db.prepareStatement("UPDATE profile_counters SET votes=votes-1 WHERE uuid=? AND votes>0")){q.setString(1,from.toString());changed=q.executeUpdate();}
     if(changed==1){plugin.recordVote(to);try(var q=db.prepareStatement("INSERT INTO gunbed_vote_identity_repairs_v17 VALUES(?,?,?)")){q.setString(1,row[0]);q.setString(2,from.toString());q.setString(3,to.toString());q.executeUpdate();}plugin.getLogger().info("Repaired common vote identity: "+row[1]+" -> "+to);}db.commit();
    }catch(Throwable failure){db.rollback();throw failure;}finally{db.setAutoCommit(true);}
   }
  }
 }catch(Exception failure){plugin.getLogger().log(java.util.logging.Level.SEVERE,"Vote identity repair failed and rolled back",failure);}}
 static UUID canonical(String name){
  for(var p:Bukkit.getOnlinePlayers())if(p.getName().equalsIgnoreCase(name))return p.getUniqueId();
  // Mojang UUIDs from actual logins take precedence over case-sensitive offline UUIDs.
  try(var in=java.nio.file.Files.newBufferedReader(new java.io.File(Bukkit.getWorldContainer(),"usercache.json").toPath())){
   for(var row:com.google.gson.JsonParser.parseReader(in).getAsJsonArray()){var o=row.getAsJsonObject();if(o.get("name").getAsString().equalsIgnoreCase(name))return UUID.fromString(o.get("uuid").getAsString());}
  }catch(Exception ignored){}
  return Arrays.stream(Bukkit.getOfflinePlayers()).filter(p->p.hasPlayedBefore()&&p.getName()!=null&&p.getName().equalsIgnoreCase(name)).max(Comparator.comparingLong(OfflinePlayer::getLastPlayed)).map(OfflinePlayer::getUniqueId).orElseGet(()->Bukkit.getOfflinePlayer(name).getUniqueId());
 }
 static void count(MZSProfilePlugin plugin,String name,String service,String stamp){if(name==null||!name.matches("[A-Za-z0-9_]{1,16}"))return;try{
  var df=MZSProfilePlugin.class.getDeclaredField("database");df.setAccessible(true);Object database=df.get(plugin);var cf=database.getClass().getDeclaredField("connection");cf.setAccessible(true);Connection db=(Connection)cf.get(database);
  String normalizedStamp=stamp==null||stamp.isBlank()?Long.toString(System.currentTimeMillis()/300000):stamp.trim();String receipt=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest((Objects.toString(service,"")+"\n"+name.toLowerCase(Locale.ROOT)+"\n"+normalizedStamp).getBytes(StandardCharsets.UTF_8)));
  synchronized(database){try(var sql=db.createStatement()){sql.execute("CREATE TABLE IF NOT EXISTS gunbed_vote_receipts_v16(receipt TEXT PRIMARY KEY,username TEXT NOT NULL,at INTEGER NOT NULL)");}boolean auto=db.getAutoCommit();if(!auto)throw new IllegalStateException("Vote database already in transaction");db.setAutoCommit(false);try{
   int inserted;try(var q=db.prepareStatement("INSERT OR IGNORE INTO gunbed_vote_receipts_v16 VALUES(?,?,?)")){q.setString(1,receipt);q.setString(2,name);q.setLong(3,System.currentTimeMillis());inserted=q.executeUpdate();}
   if(inserted==1)plugin.recordVote(canonical(name));db.commit();if(inserted==1)plugin.getLogger().info("Common recommendation recorded: "+name);
  }catch(Throwable failure){db.rollback();throw failure;}finally{db.setAutoCommit(true);}}
 }catch(Exception failure){plugin.getLogger().log(java.util.logging.Level.SEVERE,"Common vote transaction failed and rolled back",failure);}}
}
