package kr.mzs.gunbed;
import com.shampaggon.crackshot.events.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import java.util.*;

/** Reserve rounds and one authoritative reload transaction per player. */
final class VirtualAmmo implements Listener {
    private final GunbedCore plugin;
    private final Map<UUID,Map<String,Integer>> rounds=new HashMap<>();
    private static final class Reload {String id,title,token;int take;long began,duration;boolean shells;}
    private final Map<UUID,Reload> reloads=new HashMap<>();
    private final NamespacedKey instance;
    VirtualAmmo(GunbedCore p){plugin=p;instance=new NamespacedKey(p,"weapon_instance");Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,1);}
    String id(ItemStack item){if(item==null||item.getType().isAir())return "";var ta=plugin.taWeapons.definition(item);if(ta!=null)return "ta:"+ta.id();String cs=plugin.visuals==null?null:plugin.visuals.cs.getWeaponTitle(item);return cs==null?"":WeaponModes.ammoId(cs);}
    int capacity(String id){if(id.startsWith("ta:")){var g=plugin.taWeapons.definitions().stream().filter(d->d.id().equals(id.substring(3))).findFirst().orElse(null);return g==null?0:plugin.taWeapons.capacity(g);}return id.startsWith("cs:")?Math.max(1,plugin.visuals.cs.getHandle().getInt(id.substring(3)+".Reload.Reload_Amount")):0;}
    private boolean melee(String id){return plugin.arsenal!=null&&plugin.arsenal.weapons().stream().anyMatch(w->w.id().equals(id)&&w.role().equals("melee"));}
    boolean unlimited(Player p,String id){return plugin.weaponLab!=null&&plugin.weaponLab.testing(p)||melee(id);}
    private String canonical(String id){return id.startsWith("cs:")?WeaponModes.ammoId(id.substring(3)):id;}
    int reserve(Player p,String id){id=canonical(id);if(unlimited(p,id)||capacity(id)<0)return -1;return rounds.computeIfAbsent(p.getUniqueId(),u->new HashMap<>()).computeIfAbsent(id,key->Math.max(0,capacity(key)*20));}
    void add(Player p,String id,int count){id=canonical(id);if(id.isEmpty()||count<0)return;int old=reserve(p,id);if(old>=0)rounds.get(p.getUniqueId()).put(id,Math.addExact(old,count));}
    int consume(Player p,String id,int wanted){id=canonical(id);int old=reserve(p,id);if(old<0)return wanted;int used=Math.min(old,Math.max(0,wanted));rounds.get(p.getUniqueId()).put(id,old-used);return used;}
    void reset(Player p){rounds.remove(p.getUniqueId());cancel(p);}
    boolean reloading(Player p){return reloads.containsKey(p.getUniqueId());}
    private String token(ItemStack item){var meta=item.getItemMeta();String value=meta.getPersistentDataContainer().get(instance,PersistentDataType.STRING);if(value==null){value=UUID.randomUUID().toString();meta.getPersistentDataContainer().set(instance,PersistentDataType.STRING,value);item.setItemMeta(meta);}return value;}
    void reload(Player p,String title){String id=WeaponModes.ammoId(title);ItemStack item=p.getInventory().getItemInMainHand();if(reloading(p)||!id.equals(id(item))||melee(id))return;int cap=capacity(id),loaded=plugin.visuals.cs.getHandle().getAmmoBetweenBrackets(p,title,item);plugin.visuals.cs.getHandle().terminateReload(p);if(loaded>=cap||reserve(p,id)==0)return;p.setMetadata("markOfTheReload",new org.bukkit.metadata.FixedMetadataValue(plugin,true));Reload r=new Reload();r.id=id;r.title=title;r.token=token(item);r.shells=plugin.visuals.cs.getHandle().getBoolean(title+".Reload.Reload_Bullets_Individually");r.take=r.shells?1:cap-loaded;r.duration=Math.max(50,plugin.visuals.cs.getHandle().getInt(title+".Reload.Reload_Duration")*50L);if(r.duration>=4000)r.duration/=2;if(title.equals("Minigun"))r.duration=3000;if(title.equals("소드오프"))r.duration=Math.max(50,r.duration/2);r.began=System.currentTimeMillis();reloads.put(p.getUniqueId(),r);long display=r.duration*(r.shells?Math.min(cap-loaded,reserve(p,id)<0?cap:reserve(p,id)):1);plugin.protocol.emit(p,Map.of("event","reload","durationMs",display,"empty",loaded<=0,"phases",List.of()));if(plugin.trgAudio!=null)plugin.trgAudio.virtualReload(p,title,display);}
    private boolean valid(Player p,Reload r){ItemStack i=p.getInventory().getItemInMainHand();return p.isOnline()&&!p.isDead()&&p.getGameMode()!=GameMode.SPECTATOR&&r.id.equals(id(i))&&r.token.equals(token(i));}
    private void feed(Player p,Reload r){if(!valid(p,r))return;ItemStack held=p.getInventory().getItemInMainHand();int current=plugin.visuals.cs.getHandle().getAmmoBetweenBrackets(p,r.title,held);int used=consume(p,r.id,Math.min(r.take,Math.max(0,capacity(r.id)-current)));plugin.visuals.cs.getHandle().ammoOperation(p,r.title,current+used+1,held);p.getInventory().setItemInMainHand(held);}
    private void tick(){long now=System.currentTimeMillis();for(var e:List.copyOf(reloads.entrySet())){Player p=Bukkit.getPlayer(e.getKey());Reload r=e.getValue();if(p==null||!valid(p,r)){if(p!=null)cancel(p);else reloads.remove(e.getKey());continue;}if(now-r.began<r.duration)continue;feed(p,r);int loaded=plugin.visuals.cs.getHandle().getAmmoBetweenBrackets(p,r.title,p.getInventory().getItemInMainHand());if(r.shells&&loaded<capacity(r.id)&&reserve(p,r.id)!=0)r.began=now;else cancel(p);}for(Player p:Bukkit.getOnlinePlayers()){if(p.isDead()||p.getGameMode()==GameMode.SPECTATOR||reloading(p)||plugin.visuals==null||plugin.inventories.locked(p)||plugin.weaponModes.transitioning(p))continue;String title=plugin.visuals.cs.getWeaponTitle(p.getInventory().getItemInMainHand());if(title!=null&&!melee(WeaponModes.ammoId(title))&&capacity(WeaponModes.ammoId(title))>0&&plugin.visuals.cs.getHandle().getAmmoBetweenBrackets(p,title,p.getInventory().getItemInMainHand())==0)reload(p,title);}}
    void switchSlot(Player p){Reload r=reloads.remove(p.getUniqueId());if(r!=null&&System.currentTimeMillis()-r.began>=Math.ceil(r.duration*.7))feed(p,r);p.removeMetadata("markOfTheReload",plugin);if(plugin.visuals!=null)plugin.visuals.cs.getHandle().terminateReload(p);plugin.taWeapons.switchSlot(p);}
    void cancel(Player p){reloads.remove(p.getUniqueId());p.removeMetadata("markOfTheReload",plugin);if(plugin.visuals!=null)plugin.visuals.cs.getHandle().terminateReload(p);}
    @EventHandler(priority=EventPriority.LOWEST)public void prepare(WeaponPrepareShootEvent e){if(reloading(e.getPlayer()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.MONITOR)public void shot(WeaponShootEvent e){String id=WeaponModes.ammoId(e.getWeaponTitle());if(melee(id)){Bukkit.getScheduler().runTask(plugin,()->{ItemStack item=e.getPlayer().getInventory().getItemInMainHand();if(id.equals(id(item))){plugin.visuals.cs.getHandle().terminateReload(e.getPlayer());plugin.visuals.cs.getHandle().ammoOperation(e.getPlayer(),e.getWeaponTitle(),capacity(id)+1,item);}});return;}Bukkit.getScheduler().runTask(plugin,()->{Player p=e.getPlayer();ItemStack i=p.getInventory().getItemInMainHand();if(id.equals(id(i))&&plugin.visuals.cs.getHandle().getAmmoBetweenBrackets(p,e.getWeaponTitle(),i)<=0)reload(p,e.getWeaponTitle());});}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void slot(PlayerItemHeldEvent e){if(e.getNewSlot()!=e.getPreviousSlot())switchSlot(e.getPlayer());}
}
