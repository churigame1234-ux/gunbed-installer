package kr.mzs.gunbed;

import kr.mzs.botcore.api.MzsBot;
import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.game.*;
import java.util.*;
import java.util.Comparator;

/** Local objective/cover controller using the normal shops, weapons and physics. */
final class AiBrain implements AutoCloseable {
    private static final class State {AiPractice.Room room;MzsBot bot;int index,seenAt,target,nextPlan,nextBuild,nextShop,nextThrow,throwUntil,healUntil,mineUntil,nextJump,jumpAt,placed;Location goal;Deque<Location> path=new ArrayDeque<>();Block mining;String action="idle",buildReason="";}
    private final GunbedCore plugin;private final BotRuntime runtime;private final Map<UUID,State> states=new LinkedHashMap<>();private int planner;
    AiBrain(GunbedCore p,BotRuntime r){plugin=p;runtime=r;}
    void add(AiPractice.Room room,MzsBot bot,int index){State s=new State();s.room=room;s.bot=bot;s.index=index;states.put(bot.getPlayer().getUniqueId(),s);}
    void remove(MzsBot bot){states.remove(bot.getPlayer().getUniqueId());}
    void placed(Player p){State s=states.get(p.getUniqueId());if(s!=null)s.placed++;}
    String action(Player p){State s=states.get(p.getUniqueId());return s==null?"none":s.action;}
    Map<String,Object> describe(Player p){State s=states.get(p.getUniqueId());if(s==null)return Map.of();Map<String,Object> out=new LinkedHashMap<>();out.put("placed",s.placed);out.put("path",s.path.stream().limit(3).map(a->List.of(a.getX(),a.getY(),a.getZ())).toList());out.put("goal",s.goal==null?List.of():List.of(s.goal.getX(),s.goal.getY(),s.goal.getZ()));out.put("buildReason",s.buildReason);out.put("velocity",List.of(p.getVelocity().getX(),p.getVelocity().getY(),p.getVelocity().getZ()));out.put("ground",p.isOnGround());out.put("allowFlight",p.getAllowFlight());out.put("floor",p.getLocation().subtract(0,.2,0).getBlock().getType().name());return out;}
    private Player enemy(State s){Player p=s.bot.getPlayer();Game g=s.room.game;RunningTeam own=g.getTeamOfPlayer(p);return own==null?null:g.getConnectedPlayers().stream().filter(q->q!=p&&!q.isDead()&&q.getGameMode()!=GameMode.SPECTATOR&&g.getTeamOfPlayer(q)!=null&&!own.isPlayerInTeam(q)&&q.getWorld()==p.getWorld()&&q.getLocation().distanceSquared(p.getLocation())<6400&&(!q.isInvisible()||q.getLocation().distanceSquared(p.getLocation())<16)&&p.hasLineOfSight(q)).min(Comparator.comparingDouble(q->q.getLocation().distanceSquared(p.getLocation()))).orElse(null);}
    private boolean nearShop(State s){Player p=s.bot.getPlayer();return s.room.game.getGameStores().stream().anyMatch(store->store.getStoreLocation().getWorld()==p.getWorld()&&store.getStoreLocation().distanceSquared(p.getLocation())<49);}
    private int woolSlot(Player p){ItemStack[] items=plugin.inventories.utility(p);for(int n=0;n<36;n++)if(items[n]!=null&&items[n].getType().name().endsWith("_WOOL")&&plugin.stacks.count(items[n])>0)return n;return -1;}
    private long wool(Player p){return Arrays.stream(plugin.inventories.utility(p)).filter(Objects::nonNull).filter(i->i.getType().name().endsWith("_WOOL")).mapToLong(plugin.stacks::count).sum();}
    private boolean utility(Player p,Material type){ItemStack[] items=plugin.inventories.utility(p);for(int n=0;n<36;n++)if(items[n]!=null&&items[n].getType()==type){plugin.inventories.mode(p,false);p.getInventory().setHeldItemSlot(n<9?n:0);if(n>=9){ItemStack old=p.getInventory().getItem(0);p.getInventory().setItem(0,items[n]);p.getInventory().setItem(n,old);}return true;}return false;}
    private void buy(State s,int tick){if(tick<s.nextShop||!nearShop(s))return;s.nextShop=tick+20;Player p=s.bot.getPlayer();String learned=plugin.learning.purchase(s.room.game,p,List.of("gapple","fireball","tnt","iron_armor","chainmail_armor","shears","pickaxe").stream().filter(id->plugin.bedwars.shop.botCanBuy(p,id)).toList());if(wool(p)>=16&&!learned.isEmpty())plugin.bedwars.shop.botBuy(p,learned);if(wool(p)<48&&plugin.wallet.total(p,Material.IRON_INGOT)>=4)plugin.bedwars.shop.botBuy(p,"wool");if(p.getInventory().getLeggings()!=null&&p.getInventory().getLeggings().getType()==Material.LEATHER_LEGGINGS&&plugin.wallet.total(p,Material.GOLD_INGOT)>=12)plugin.bedwars.shop.botBuy(p,"iron_armor");if(p.getHealth()<p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue()*.7&&plugin.wallet.total(p,Material.GOLD_INGOT)>=3)plugin.bedwars.shop.botBuy(p,"gapple");if(plugin.wallet.total(p,Material.IRON_INGOT)>=10)plugin.bedwars.shop.botBuy(p,"pickaxe");if(plugin.wallet.total(p,Material.GOLD_INGOT)>=3&&s.room.difficulty!=AiPractice.Difficulty.EASY&&plugin.inventories.weapons(p).stream().noneMatch(i->plugin.throwables.kind(i)!=null))plugin.throwables.buy(p,"he");}
    private void pickup(Player p){
        // In-memory players do not receive client-driven item collision pickup ticks.
        // Dispatch the ordinary event; the wallet, locks and challenge rules remain authoritative.
        for(Entity entity:p.getNearbyEntities(1,.7,1))if(entity instanceof Item item&&item.isValid()&&item.getPickupDelay()<=0){
            var event=new org.bukkit.event.entity.EntityPickupItemEvent(p,item,0);Bukkit.getPluginManager().callEvent(event);
            if(!event.isCancelled()&&ResourceWallet.TYPES.contains(item.getItemStack().getType())){
                var overflow=p.getInventory().addItem(item.getItemStack());if(overflow.isEmpty())item.remove();
            }
        }
    }
    void tick(int tick){List<State> all=List.copyOf(states.values());if(all.isEmpty())return;int planIndex=Math.floorMod(planner++,all.size());for(int n=0;n<all.size();n++){State s=all.get(n);Player p=s.bot.getPlayer();Game game=s.room.game;if(game.getStatus()!=GameStatus.RUNNING||!p.isOnline()||p.isDead()||p.getGameMode()==GameMode.SPECTATOR||game.getTeamOfPlayer(p)==null){runtime.stop(s.bot);continue;}if(p.getY()<Math.min(game.getPos1().getY(),game.getPos2().getY())-1){runtime.stop(s.bot);p.setNoDamageTicks(0);p.damage(p.getHealth()+p.getAbsorptionAmount()+1000,org.bukkit.damage.DamageSource.builder(org.bukkit.damage.DamageType.OUT_OF_WORLD).build());continue;}if(plugin.arsenal.pending(p)){plugin.arsenal.botLoadout(p,s.index%3==0?"ta:ak47":s.index%3==1?"cs:AK-47":"ta:m4a1");s.path.clear();continue;}if(plugin.inventories.locked(p)){runtime.stop(s.bot);continue;}MatchVitals.ensureBotArmor(p);pickup(p);buy(s,tick);
        if(tick<s.healUntil){s.action="healing";runtime.stop(s.bot);continue;}
        if(p.getHealth()<p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue()*.5&&utility(p,Material.GOLDEN_APPLE)){s.action="heal";runtime.stop(s.bot);runtime.right(s.bot);s.healUntil=tick+36;continue;}
        Player foe=enemy(s);if(foe!=null){if(s.target!=foe.getEntityId()){s.target=foe.getEntityId();s.seenAt=tick;}double distance=p.getLocation().distance(foe.getLocation());if(distance<60&&(s.room.initialHumans==1||s.index!=0||distance<20||p.getHealth()/p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue()<.8)&&tick-s.seenAt>=s.room.difficulty.reaction){combat(s,foe,tick);continue;}}else{s.target=0;plugin.taWeapons.input(p,false,false);if(plugin.visuals!=null)plugin.visuals.input(p,false,false,false);}
        var own=game.getTeamOfPlayer(p);RunningTeam enemyTeam=game.getRunningTeams().stream().filter(t->t!=own&&t.isAlive()).findFirst().orElse(null);if(enemyTeam==null){runtime.stop(s.bot);continue;}
        if(s.index==0&&wool(p)>0&&p.getLocation().distanceSquared(own.getTeamSpawn())<225&&defend(s,tick))continue;
        Location target=foe!=null?foe.getLocation():enemyTeam.getTargetBlock().clone().add(.5,0,.5);
        if(enemyTeam.isTargetBlockExists()&&p.getLocation().distanceSquared(target)<30&&mine(s,target,tick))continue;
        if(wool(p)<16){target=game.getItemSpawners().stream().filter(a->a.getTeam()!=null&&a.getTeam().getName().equals(own.getName())&&a.getItemSpawnerType().getMaterial()==Material.IRON_INGOT).findFirst().map(a->a.getLocation().clone().add(0,1,0)).orElse(own.getTeamSpawn());s.action="gather";}
        else s.action="advance";
        if(wool(p)<16&&plugin.wallet.total(p,Material.IRON_INGOT)>=4){target=game.getGameStores().stream().filter(store->store.getShopFile()!=null&&!store.getShopFile().contains("upgrade")&&store.getTeam()!=null&&store.getTeam().getName().equals(own.getName())).map(store->store.getStoreLocation().clone()).min(Comparator.comparingDouble(at->at.distanceSquared(p.getLocation()))).orElse(own.getTeamSpawn());s.action="shop";}

        boolean bridge=wool(p)>0;if(n==planIndex&&(tick>=s.nextPlan||s.goal==null||s.goal.distanceSquared(target)>9)){s.path=new ArrayDeque<>(AiNavigation.path(game,p.getLocation(),target,bridge,s.room.difficulty==AiPractice.Difficulty.HARD||plugin.learning.preference(game,plugin.learning.context(p,game,foe),"double-jump")>0,plugin.learning,p));s.goal=target.clone();s.nextPlan=tick+40;}
        follow(s,tick);
    }}
    private void slot(Player p,int slot){int old=p.getInventory().getHeldItemSlot();if(old==slot)return;var event=new org.bukkit.event.player.PlayerItemHeldEvent(p,old,slot);Bukkit.getPluginManager().callEvent(event);if(!event.isCancelled())p.getInventory().setHeldItemSlot(slot);}
    private void combat(State s,Player foe,int tick){Player p=s.bot.getPlayer();double distance=p.getLocation().distance(foe.getLocation());plugin.inventories.mode(p,true);if(s.throwUntil>0){p.getInventory().setHeldItemSlot(3);runtime.look(s.bot,foe.getEyeLocation());plugin.throwables.input(p,tick<s.throwUntil,false);if(tick>=s.throwUntil){s.throwUntil=0;s.nextThrow=tick+400;}runtime.stop(s.bot);s.action="throw";return;}
        if(distance>7&&distance<22&&tick>=s.nextThrow&&plugin.throwables.kind(p.getInventory().getItem(3))!=null){s.throwUntil=tick+8;return;}
        slot(p,distance<2.6?2:0);Location aim=foe.getLocation().add(0,s.room.difficulty==AiPractice.Difficulty.HARD?1.45:1.05,0);double jitter=Math.sin(tick*.31+s.index)*Math.tan(Math.toRadians(s.room.difficulty.error))*distance;aim.add(jitter,Math.cos(tick*.23)*jitter*.3,-jitter*.4);runtime.look(s.bot,aim);
        boolean fire=tick%20<16;if(plugin.addonMelee.held(p)!=null)plugin.addonMelee.input(p,fire);plugin.taWeapons.input(p,fire,distance>15);if(plugin.visuals!=null)plugin.visuals.input(p,fire,distance>15,false);s.action=distance<2.6?"melee":"fire";
        Vector delta=foe.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);if(delta.lengthSquared()<.01){runtime.stop(s.bot);return;}delta.normalize();double hp=p.getHealth()/p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();double retreat=(hp<.3?-1:distance<7?-.3:distance>28?.6:0)-Math.max(0,plugin.learning.preference(s.room.game,plugin.learning.context(p,s.room.game,foe),"retreat"));Vector strafe=new Vector(-delta.getZ(),0,delta.getX()).multiply(Math.sin(tick*.1+s.index)>0?.7:-.7).add(delta.multiply(retreat));Location next=p.getLocation().add(strafe.clone().multiply(.7));if(next.getBlock().getRelative(0,-1,0).getType().isSolid())runtime.move(s.bot,strafe.getX(),strafe.getZ(),false,false,false);else runtime.stop(s.bot);}
    private void follow(State s,int tick){Player p=s.bot.getPlayer();while(!s.path.isEmpty()){Location at=s.path.peekFirst();boolean supported=at.getBlock().getRelative(0,-1,0).getType().isSolid();if(supported&&Math.abs(p.getY()-at.getY())<1.1&&p.getLocation().toVector().subtract(at.toVector()).setY(0).lengthSquared()<.16)s.path.removeFirst();else break;}if(s.path.isEmpty()){runtime.stop(s.bot);return;}Location next=s.path.peekFirst();Block floor=next.getBlock().getRelative(0,-1,0);if(!floor.getType().isSolid()){if(woolSlot(p)<0){runtime.stop(s.bot);s.nextPlan=0;return;}s.action="bridge";bridge(s,floor,tick);return;}Vector move=next.toVector().subtract(p.getLocation().toVector()).setY(0);
        if(s.jumpAt>0&&tick>=s.jumpAt){s.jumpAt=0;if(!p.isOnGround()&&p.getAllowFlight())Bukkit.getPluginManager().callEvent(new org.bukkit.event.player.PlayerToggleFlightEvent(p,true));}
        if(move.lengthSquared()>3.3&&move.lengthSquared()<11&&p.isOnGround()&&tick>=s.nextJump){Vector direction=move.clone().normalize();boolean gap=p.getLocation().add(direction.clone().multiply(.9)).getBlock().getRelative(0,-1,0).getType().isAir();if(gap){runtime.look(s.bot,next.clone().add(0,1.3,0));runtime.move(s.bot,move.getX(),move.getZ(),true,true,false);s.jumpAt=tick+4;s.nextJump=tick+60;return;}}
        runtime.look(s.bot,next.clone().add(0,1.3,0));runtime.move(s.bot,move.getX(),move.getZ(),next.getY()>p.getY()+.35,true,false);}
    private void bridge(State s,Block floor,int tick){
        Player p=s.bot.getPlayer();
        List<BlockFace> faces=new ArrayList<>(List.of(BlockFace.EAST,BlockFace.WEST,BlockFace.NORTH,BlockFace.SOUTH));
        faces.removeIf(face->!floor.getRelative(face.getOppositeFace()).getType().isSolid());
        faces.sort(Comparator.comparingDouble(face->floor.getRelative(face.getOppositeFace()).getLocation().add(.5,1,.5).distanceSquared(p.getLocation())));
        for(BlockFace face:faces){
            Block support=floor.getRelative(face.getOppositeFace());
            if(p.getY()<floor.getY()+.9&&p.isOnGround()){s.bot.setMovementInput(0,0,true,false,true);return;}
            double dx=face.getModX(),dz=face.getModZ();
            double ox=p.getX()-support.getX()-.5,oz=p.getZ()-support.getZ()-.5;
            double along=ox*dx+oz*dz,across=ox*(-dz)+oz*dx;
            s.buildReason="edge "+Math.round(along*100)+"/"+Math.round(across*100);
            // Align on the supporting block first, then expose the real side face.
            // Being merely close to the edge is insufficient: the top face still
            // blocks the ray until the player's centre passes that side plane.
            if(Math.abs(across)>.18){runtime.move(s.bot,dz*across,-dx*across,false,false,true);return;}
            if(along<.515){runtime.move(s.bot,dx,dz,false,false,true);return;}
            if(along>.72){runtime.move(s.bot,-dx,-dz,false,false,true);return;}
            s.bot.setMovementInput(0,0,false,false,true);p.setSneaking(true);
            if(tick<s.nextBuild)return;
            int slot=woolSlot(p);if(slot<0)return;plugin.inventories.mode(p,false);
            if(slot>=9){ItemStack item=p.getInventory().getItem(slot),old=p.getInventory().getItem(4);p.getInventory().setItem(4,item);p.getInventory().setItem(slot,old);slot=4;}
            p.getInventory().setHeldItemSlot(slot);
            Location hit=new Location(support.getWorld(),support.getX()+.5+dx*.499,(support.getBoundingBox().getMinY()+support.getBoundingBox().getMaxY())/2,support.getZ()+.5+dz*.499);
            runtime.look(s.bot,hit);
            boolean placed=runtime.useBlock(s.bot,support,face);
            s.buildReason="place="+placed+" at "+floor.getX()+","+floor.getY()+","+floor.getZ();
            s.nextBuild=tick+s.room.difficulty.build;return;
        }
        s.buildReason="no adjacent support";runtime.stop(s.bot);s.nextPlan=0;
    }
    private boolean defend(State s,int tick){Player p=s.bot.getPlayer();Location bed=s.room.game.getTeamOfPlayer(p).getTargetBlock();List<Block> candidates=new ArrayList<>(plugin.learning.defense(s.room.game,p));for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)if(Math.abs(x)+Math.abs(z)<=1)candidates.add(bed.getBlock().getRelative(x,0,z));candidates.add(bed.getBlock().getRelative(0,1,0));for(Block target:candidates){if(!target.getType().isAir()||!s.room.game.isLocationInArena(target.getLocation())||p.getBoundingBox().overlaps(target.getBoundingBox()))continue;Block support=target.getRelative(BlockFace.DOWN);if(!support.getType().isSolid()||p.getEyeLocation().distanceSquared(support.getLocation().add(.5,1,.5))>19)continue;if(tick<s.nextBuild)return false;int slot=woolSlot(p);if(slot<0)return false;plugin.inventories.mode(p,false);if(slot>=9){ItemStack item=p.getInventory().getItem(slot),old=p.getInventory().getItem(4);p.getInventory().setItem(4,item);p.getInventory().setItem(slot,old);slot=4;}p.getInventory().setHeldItemSlot(slot);runtime.look(s.bot,support.getLocation().add(.5,1,.5));runtime.stop(s.bot);if(runtime.useBlock(s.bot,support,BlockFace.UP)){s.nextBuild=tick+s.room.difficulty.build;s.action="defend";return true;}}return false;}
    private boolean mine(State s,Location bed,int tick){Player p=s.bot.getPlayer();runtime.look(s.bot,bed.clone().add(0,.3,0));Block hit=p.getTargetBlockExact(4);if(hit==null)return false;boolean placed=s.room.game.getRegion().isBlockAddedDuringGame(hit.getLocation());boolean target=hit.getBlockData() instanceof org.bukkit.block.data.type.Bed;if(!placed&&!target)return false;if(s.mining==null||!s.mining.equals(hit)){s.mining=hit;s.mineUntil=tick+(hit.getType().name().endsWith("_WOOL")?12:hit.getType()==Material.END_STONE?60:30);}runtime.stop(s.bot);s.action="mine";plugin.inventories.mode(p,false);utility(p,Material.SHEARS);p.swingMainHand();if(tick>=s.mineUntil){LegacyActions.recordBlock(hit);p.breakBlock(hit);s.mining=null;s.nextPlan=0;}return true;}
    @Override public void close(){for(State s:states.values())runtime.stop(s.bot);states.clear();}
}
