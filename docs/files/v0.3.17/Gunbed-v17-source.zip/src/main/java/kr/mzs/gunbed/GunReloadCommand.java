package kr.mzs.gunbed;

import java.lang.reflect.Field;
import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.command.*;

/** Main-thread reload: either both validated snapshots become visible, or neither does. */
final class GunReloadCommand extends Command {
    private final GunbedCore plugin;
    GunReloadCommand(GunbedCore p){super("총리로드","무기 피해·넉백 설정 즉시 반영","/총리로드",List.of());plugin=p;setPermission("gunbedcore.admin");}
    static void install(GunbedCore p){if(Bukkit.getCommandMap().getCommand("총리로드")==null)Bukkit.getCommandMap().register("gunbedcore",new GunReloadCommand(p));}
    static boolean reload(GunbedCore p,CommandSender sender){
        try{
            Field d=DamageSettings.class.getDeclaredField("live"),k=KnockbackSettings.class.getDeclaredField("live");d.setAccessible(true);k.setAccessible(true);
            Object beforeD=d.get(p.damages),beforeK=k.get(p.knockbacks);
            boolean ok=p.damages.reload(null)&&p.knockbacks.reload(null);
            if(!ok){d.set(p.damages,beforeD);k.set(p.knockbacks,beforeK);if(p.specs!=null)p.specs.invalidate();sender.sendMessage("§c설정 오류로 피해·넉백 모두 이전 값을 유지했습니다. 콘솔의 오류 항목을 확인하세요.");return false;}
            sender.sendMessage("§a무기 피해·넉백 설정 반영 완료 · 진행 중인 경기는 유지됩니다.");return true;
        }catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
    }
    @Override public boolean execute(CommandSender sender,String label,String[] args){if(!sender.isOp()){sender.sendMessage("§c운영자만 사용할 수 있습니다.");return true;}reload(plugin,sender);return true;}
    @Override public List<String> tabComplete(CommandSender s,String alias,String[] args){return List.of();}
}
