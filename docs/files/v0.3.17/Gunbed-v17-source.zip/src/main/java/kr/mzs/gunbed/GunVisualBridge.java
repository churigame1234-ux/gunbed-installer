package kr.mzs.gunbed;

import com.shampaggon.crackshot.CSUtility;
import com.shampaggon.crackshot.events.*;
import org.bukkit.*;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import java.io.File;
import java.util.*;

/** Optional CS adapter. Native TA, HUD and networking operate without CrackShot. */
final class GunVisualBridge implements Listener {
    private static Set<String> nativeWeapons=Set.of();
    static boolean nativeReload(String title){return nativeWeapons.contains(title);}
    private final GunbedCore plugin;
    final CSUtility cs=new CSUtility();
    private final Map<String,String> models=new HashMap<>();
    private final GunVisualEffects effects;
    private final Set<UUID> scoped=new HashSet<>();
    private boolean synthetic;
    GunVisualBridge(GunbedCore plugin){this.plugin=plugin;effects=new GunVisualEffects(plugin);File f=new File(plugin.getDataFolder(),"visuals.yml");if(!f.exists())plugin.saveResource("visuals.yml",false);var section=YamlConfiguration.loadConfiguration(f).getConfigurationSection("models");if(section!=null)for(String id:section.getKeys(false)){String model=section.getString(id,"");if(model.matches("[a-z0-9_]{1,64}"))models.put(id,model);}nativeWeapons=Set.copyOf(models.keySet());for(String title:titles())for(String key:List.of(".Ammo.Enable",".Reload.Reload_When_Empty",".Reload.Take_Ammo_On_Reload"))com.shampaggon.crackshot.CSDirector.bools.put(title+key,false);
        // CrackShot's Q listener reloads even when a drop was cancelled. Remove
        // just that event binding; R and reserve consumption belong to VirtualAmmo.
        for(var listener:PlayerDropItemEvent.getHandlerList().getRegisteredListeners())if(listener.getPlugin()==cs.getHandle())PlayerDropItemEvent.getHandlerList().unregister(listener);
        Bukkit.getPluginManager().registerEvents(this,plugin);}
    String title(Player p){ItemStack item=p.getInventory().getItemInMainHand();String title=cs.getWeaponTitle(item);if(title!=null&&decorate(item,title))p.getInventory().setItemInMainHand(item);return title;}
    Collection<String> titles(){Set<String> ids=new TreeSet<>();File[] files=new File(cs.getHandle().getDataFolder(),"weapons").listFiles((d,n)->n.endsWith(".yml"));if(files!=null)for(File file:files)for(String id:YamlConfiguration.loadConfiguration(file).getKeys(false))if(!WeaponModes.retired(id)&&cs.generateWeapon(id)!=null)ids.add(id);return ids;}
    ItemStack create(String title){if(WeaponModes.retired(title))return null;ItemStack item=cs.generateWeapon(title);if(item!=null)decorate(item,title);return item;}
    private boolean decorate(ItemStack item,String title){
        boolean changed=item.getType()!=Material.PAPER;if(changed)item.setType(Material.PAPER);
        String slug;try{slug=java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(title.getBytes(java.nio.charset.StandardCharsets.UTF_8))).substring(0,16);}catch(java.security.NoSuchAlgorithmException impossible){throw new IllegalStateException(impossible);}
        var expected=new NamespacedKey("gunbed","cs/"+slug);var meta=item.getItemMeta();
        if(!expected.equals(meta.getItemModel())){meta.setItemModel(expected);meta.getPersistentDataContainer().set(new NamespacedKey(plugin,"cs_weapon"),org.bukkit.persistence.PersistentDataType.STRING,title);changed=true;}
        if(WeaponModes.auxiliary(title)){
            List<String> lore=new ArrayList<>(meta.hasLore()?meta.getLore():List.of());
            String instruction=Set.of("g36","바스티온").contains(title)?"§e우클릭: 시즈 전개 / 해제 · 전개 중 이동·무기 교체 불가":"§e우클릭: 발사 모드 A/B 전환 · 조준 없음";
            if(!lore.contains(instruction)){lore.removeIf(line->{String plain=ChatColor.stripColor(line).toLowerCase(Locale.ROOT);return plain.contains("모드")||plain.contains("mode")||plain.contains("mod change")||plain.contains("shift click")||plain.contains("siage");});lore.add(instruction);meta.setLore(lore);changed=true;}
        }
        if(plugin.specs!=null){List<String> lore=plugin.specs.cs(title);if(!lore.equals(meta.getLore())){meta.setLore(lore);changed=true;}}
        if(changed)item.setItemMeta(meta);return changed;
    }
    String recoilDescription(String title){return effects.describe(title);}
    Map<String,Object> state(Player p){String title=title(p);if(plugin.trgAudio!=null)plugin.trgAudio.held(p,title);if(title==null||WeaponModes.retired(title))return null;Map<String,Object> result=new HashMap<>();result.put("weapon",title);result.put("name",ChatColor.stripColor(p.getInventory().getItemInMainHand().getItemMeta().getDisplayName()).split("«",2)[0].strip());result.put("controlled",true);result.put("engine","cs");result.put("nativeScope",false);result.put("canAim",!auxiliary(title));result.put("enabled",models.containsKey(title));if(models.containsKey(title))result.put("model",plugin.weaponModes==null||plugin.weaponModes.model(p,title)==null?models.get(title):plugin.weaponModes.model(p,title));result.put("weaponPhase",plugin.weaponModes==null?"mobile":plugin.weaponModes.phase(p));result.put("weaponMode",WeaponModes.alternate(title)?"B":"A");result.put("ammo",cs.getHandle().getAmmoBetweenBrackets(p,title,p.getInventory().getItemInMainHand()));result.put("capacity",cs.getHandle().getInt(title+".Reload.Reload_Amount"));result.put("reserve",reserve(p,title));result.put("mode",cs.getHandle().getBoolean(title+".Fully_Automatic.Enable")?"AUTO":"SEMI");return result;}
    private int reserve(Player player,String title){return plugin.ammo==null?0:plugin.ammo.reserve(player,"cs:"+title);}
    void input(Player p,boolean fire,boolean aim,boolean rightPressed){String title=title(p);if(title==null||WeaponModes.retired(title)||p.isDead()||p.getGameMode()==GameMode.SPECTATOR)return;if(rightPressed&&auxiliary(title))plugin.weaponModes.rightClick(p,title);ensureReserve(p,title);boolean right=cs.getHandle().getBoolean(title+".Shooting.Right_Click_To_Shoot");if(fire&&plugin.arsenal!=null&&!plugin.arsenal.meleeTitle(title)&&cs.getHandle().getAmmoBetweenBrackets(p,title,p.getInventory().getItemInMainHand())==0){plugin.ammo.reload(p,title);return;}if(fire&&!plugin.ammo.reloading(p)&&!plugin.weaponModes.transitioning(p)&&!plugin.inventories.locked(p)){if(cs.getHandle().getBoolean(title+".Item_Information.Melee_Mode")){if(plugin.wool.melee(p,title,plugin.damageProfiles.melee("cs:"+title,cs.getHandle().getDouble(title+".Shooting.Projectile_Damage")),500))return;plugin.protocol.emit(p,Map.of("event","meleeSwing","durationMs",500));var hit=p.getWorld().rayTraceEntities(p.getEyeLocation(),p.getEyeLocation().getDirection(),3.0,.15,e->e instanceof org.bukkit.entity.LivingEntity&&FriendlyProjectiles.hittable(p,e));if(hit!=null&&hit.getHitEntity()!=null&&p.hasLineOfSight(hit.getHitEntity()))p.attack(hit.getHitEntity());}else interact(p,right?Action.RIGHT_CLICK_AIR:Action.LEFT_CLICK_AIR);}if(rightPressed&&!auxiliary(title)&&!models.containsKey(title)&&aim)interact(p,right?Action.LEFT_CLICK_AIR:Action.RIGHT_CLICK_AIR);}
    private boolean auxiliary(String title){return WeaponModes.auxiliary(title);}
    boolean optic(Player p){String id=title(p);return id!=null&&!"secondary".equals(plugin.inventories.role(p.getInventory().getItemInMainHand()))&&!java.util.Set.of("glock17","Eagle","소드오프","m950","골데","골데B","flare").contains(id)&&!auxiliary(id)&&(id.toLowerCase(Locale.ROOT).contains("trg")||id.toLowerCase(Locale.ROOT).contains("awp")||cs.getHandle().getInt(id+".Scope.Zoom_Amount")>=3);}

    private void interact(Player p,Action action){synthetic=true;try{Bukkit.getPluginManager().callEvent(new PlayerInteractEvent(p,action,p.getInventory().getItemInMainHand(),null,BlockFace.SELF,EquipmentSlot.HAND));}finally{synthetic=false;}}
    void reload(Player p){String title=title(p);if(title!=null)plugin.ammo.reload(p,title);}
    void ensureReserve(Player p,String title){}
    @EventHandler(priority=EventPriority.LOWEST)public void physical(PlayerInteractEvent e){if(!synthetic&&e.getHand()==EquipmentSlot.HAND&&plugin.protocol!=null&&plugin.protocol.ready(e.getPlayer())&&title(e.getPlayer())!=null)e.setCancelled(true);}
    @EventHandler(priority=EventPriority.MONITOR)public void shoot(WeaponShootEvent e){if(plugin.protocol==null)return;if(plugin.arsenal!=null&&plugin.arsenal.meleeTitle(e.getWeaponTitle()))plugin.protocol.emit(e.getPlayer(),Map.of("event","meleeSwing","durationMs",e.getWeaponTitle().equals("망치")?650:500));else plugin.protocol.emit(e.getPlayer(),effects.shotFields(e));if(plugin.weaponLab!=null&&plugin.weaponLab.testing(e.getPlayer()))Bukkit.getScheduler().runTask(plugin,()->ensureReserve(e.getPlayer(),e.getWeaponTitle()));}
    @EventHandler(priority=EventPriority.MONITOR)public void reloadEvent(WeaponReloadEvent event){if(plugin.protocol==null)return;Player player=event.getPlayer();String title=event.getWeaponTitle();int amount=cs.getHandle().getAmmoBetweenBrackets(player,title,player.getInventory().getItemInMainHand());long single=Math.max(50,(long)(event.getReloadDuration()*event.getReloadSpeed()*50));boolean individual=cs.getHandle().getBoolean(title+".Reload.Reload_Bullets_Individually");int missing=individual?Math.max(1,cs.getHandle().getInt(title+".Reload.Reload_Amount")-Math.max(0,amount)):1;long duration=single*missing;List<Map<String,Object>> phases=new ArrayList<>();if(individual){String model=models.get(title);var gun=plugin.taWeapons.definitions().stream().filter(d->d.id().equals(model)).findFirst().orElse(null);if(gun!=null&&gun.clips().has("reload_loop"))for(int n=0;n<missing;n++)phases.add(Map.of("clip","reload_loop","atMs",n*single,"durationMs",single));}plugin.protocol.emit(player,Map.of("event","reload","durationMs",duration,"empty",amount==0,"phases",phases));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void scope(WeaponScopeEvent e){if(e.isZoomIn())scoped.add(e.getPlayer().getUniqueId());else scoped.remove(e.getPlayer().getUniqueId());}
    @EventHandler public void quit(PlayerQuitEvent e){scoped.remove(e.getPlayer().getUniqueId());}
}
