package kr.mzs.gunbed;

import kr.mzs.botcore.MZSBotCorePlugin;
import kr.mzs.botcore.api.MzsBot;
import kr.mzs.botcore.api.MzsClickMode;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import java.util.*;

/** The same in-memory player runtime used by MZS zombies; no login tokens. */
final class BotRuntime {
    private final MZSBotCorePlugin core;
    BotRuntime(){core=(MZSBotCorePlugin)Bukkit.getPluginManager().getPlugin("MZSBotCore");}
    static boolean bot(Player p){return p!=null&&(p.getScoreboardTags().contains("mzs_ai")||p.getPersistentDataContainer().has(new NamespacedKey("mzsbotcore","bot"),PersistentDataType.BYTE));}
    MzsBot spawn(Location at,String name){return core.getBotApi().spawnBot(at,name).orElseThrow(()->new IllegalStateException("Could not spawn "+name));}
    void remove(MzsBot bot){core.getBotApi().despawnBot(bot.getName());}
    void move(MzsBot bot,double dx,double dz,boolean jump,boolean sprint,boolean sneak){bot.setWorldMovementInput(dx,dz,jump,sprint,sneak);}
    void stop(MzsBot bot){bot.clearMovementInput();}
    void look(MzsBot bot,Location target){Player p=bot.getPlayer();var direction=target.toVector().subtract(p.getEyeLocation().toVector());var at=p.getLocation().setDirection(direction);core.getBotApi().setHeadYaw(p,at.getYaw());p.setRotation(at.getYaw(),at.getPitch());}
    void left(MzsBot bot){core.getBotApi().leftClick(bot,MzsClickMode.ONCE);}
    boolean useBlock(MzsBot bot,org.bukkit.block.Block block,org.bukkit.block.BlockFace face){return core.getBotApi().useBlock(bot,block,face);}
    void right(MzsBot bot){core.getBotApi().rightClick(bot,MzsClickMode.ONCE);}
}
