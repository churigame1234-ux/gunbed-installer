package kr.mzs.gunbed;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;

/** Server-owned melee hit tests; optional art needs no Forge item registry. */
final class AddonMelee {
    private final GunbedCore plugin;private final NamespacedKey key;
    private final Map<UUID,Long> next=new HashMap<>();
    private static final Map<String,String> NAMES=new LinkedHashMap<>(Map.of("dagger","단검","karambit","카람빗","baseball_bat","야구방망이"));
    private static final Map<String,com.google.gson.JsonObject> EXTRA=new HashMap<>();
    static {try(var in=AddonMelee.class.getResourceAsStream("/addon-melee-v16.json")){if(in!=null)for(var e:com.google.gson.JsonParser.parseReader(new java.io.InputStreamReader(in,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject().entrySet()){var row=e.getValue().getAsJsonObject();NAMES.put(e.getKey(),row.get("name").getAsString());EXTRA.put(e.getKey(),row.getAsJsonObject("data"));}}catch(java.io.IOException e){throw new java.io.UncheckedIOException(e);}}
    static Map<String,String> names(){return Map.copyOf(NAMES);}
    private long cooldown(String id){return EXTRA.containsKey(id)?Math.max(250,EXTRA.get(id).getAsJsonObject("attack").getAsJsonObject("attack_left").get("cooldown").getAsLong()*50):id.equals("baseball_bat")?900:600;}
    private double base(String id){return id.equals("baseball_bat")?3000:EXTRA.containsKey(id)?1400:2500;}
    AddonMelee(GunbedCore p){plugin=p;key=new NamespacedKey(p,"addon_melee");}
    String id(ItemStack item){return item!=null&&item.hasItemMeta()?item.getItemMeta().getPersistentDataContainer().get(key,PersistentDataType.STRING):null;}
    String held(Player p){return id(p.getInventory().getItemInMainHand());}
    ItemStack create(String id){if(!NAMES.containsKey(id))return null;ItemStack item=new ItemStack(Material.PAPER);var meta=item.getItemMeta();meta.getPersistentDataContainer().set(key,PersistentDataType.STRING,id);meta.setItemModel(new NamespacedKey("gunbed","melee/"+id));meta.setDisplayName("§6[근접무기] §f"+NAMES.get(id));meta.setLore(List.of("§7좌클릭: 근접 공격 · 탄약 무제한","§7기본 피해: §c"+(plugin.damageProfiles.melee("lr:"+id,base(id))),"§8별도 무료 애드온 모델 · 무기고 선택 무기"));item.setItemMeta(meta);return item;}
    Map<String,Object> state(Player p){String id=held(p);if(id==null)return null;return new HashMap<>(Map.of("weapon","lr:"+id,"name",NAMES.get(id),"model","lr_"+id,"engine","melee","controlled",true,"enabled",true,"canAim",false,"mode","MELEE","capacity",0));}
    void input(Player p,boolean fire){String id=held(p);if(id==null||!fire||plugin.inventories.locked(p))return;long now=System.currentTimeMillis();if(now<next.getOrDefault(p.getUniqueId(),0L))return;next.put(p.getUniqueId(),now+cooldown(id));p.getWorld().playSound(p.getLocation(),"gunbed:melee.swing_"+(id.equals("baseball_bat")?"baseball_bat":"dagger"),SoundCategory.PLAYERS,.8f,1);plugin.protocol.emit(p,Map.of("event","meleeSwing","durationMs",id.equals("baseball_bat")?750:500));if(plugin.wool.melee(p,id,plugin.damageProfiles.melee("lr:"+id,base(id)),cooldown(id)))return;var game=BedwarsAPI.getInstance().getGameOfPlayer(p);if(game==null||game.getTeamOfPlayer(p)==null)return;var hit=p.getWorld().rayTrace(p.getEyeLocation(),p.getEyeLocation().getDirection(),3.1,FluidCollisionMode.NEVER,true,.3,e->e instanceof LivingEntity&&e!=p&&FriendlyProjectiles.hittable(p,e));if(hit!=null&&hit.getHitEntity() instanceof LivingEntity target){double damage=plugin.damageProfiles.melee("lr:"+id,base(id));if(!plugin.flow.dragons.damage(target,p,damage)&&(plugin.turrets==null||!plugin.turrets.damage(target,p,damage))){target.setNoDamageTicks(0);target.damage(damage,p);}}}
    boolean buy(Player p,String id,List<ItemStack> cost){ItemStack item=create(id);if(item==null||plugin.inventories.locked(p))return false;if(!plugin.wallet.pay(p,cost)){p.sendMessage("§c재료가 부족합니다.");return false;}plugin.inventories.replaceWeapon(p,"melee",item);p.playSound(p.getLocation(),Sound.BLOCK_NOTE_BLOCK_PLING,1,2);return true;}
}
