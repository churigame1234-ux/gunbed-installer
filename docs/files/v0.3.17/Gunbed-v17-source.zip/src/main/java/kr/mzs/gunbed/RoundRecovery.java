package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.*;
import org.screamingsandals.bedwars.api.events.*;
import java.util.*;

/** Unanimous, arena-scoped emergency recovery; never changes account records. */
final class RoundRecovery implements Listener {
    private static final class Vote {Set<UUID> eligible=new HashSet<>(),yes=new HashSet<>();long until;}
    private final Map<Game,Vote> votes=new HashMap<>();private final Map<Game,Long> cooldown=new HashMap<>();
    private final GunbedCore plugin;
    RoundRecovery(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);p.getCommand("초기화").setExecutor((s,c,l,a)->{if(!s.hasPermission("gunbedcore.admin"))return true;if(!plugin.knockbacks.reload(s)||!plugin.damages.reload(s))return true;for(Game g:List.copyOf(BedwarsAPI.getInstance().getGames()))if(g.getStatus()==GameStatus.RUNNING||g.getStatus()==GameStatus.WAITING)reset(g);s.sendMessage("§a모든 경기를 중단하고 복구합니다. 계정 데이터는 유지됩니다.");return true;});p.getCommand("error").setExecutor((s,c,l,a)->{if(s instanceof Player x)vote(x);return true;});Bukkit.getScheduler().runTaskTimer(p,()->{long now=System.currentTimeMillis();for(var e:List.copyOf(votes.entrySet()))if(now>=e.getValue().until){votes.remove(e.getKey());for(Player x:e.getKey().getConnectedPlayers())x.sendMessage("§e초기화 투표가 만료됐습니다.");}},20,20);}
    void reset(Game g){if(plugin.practice!=null)plugin.practice.prepareReset(g);votes.remove(g);List<Player> players=List.copyOf(g.getConnectedPlayers());for(Player p:players){p.closeInventory();ResetLobbyReturn.begin(plugin,p);}g.stop();((org.screamingsandals.bedwars.game.Game)g).rebuild();LegacyActions.clear(g);for(Player p:players)if(BedwarsAPI.getInstance().getGameOfPlayer(p)==g)g.leaveFromGame(p);g.start();for(Player p:players)ResetLobbyReturn.finish(plugin,p);}
    private void vote(Player p){Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(g==null||g.getStatus()!=GameStatus.RUNNING){p.sendMessage("§e진행 중인 경기에서만 초기화 투표를 할 수 있습니다.");return;}long now=System.currentTimeMillis();Vote v=votes.get(g);if(v==null){if(now<cooldown.getOrDefault(g,0L)){p.sendMessage("§e투표 재요청은 60초마다 가능합니다.");return;}v=new Vote();for(Player x:g.getConnectedPlayers())if(!BotRuntime.bot(x)&&(g.getTeamOfPlayer(x)!=null||plugin.roundChat.originalTeam(x)!=null))v.eligible.add(x.getUniqueId());if(!v.eligible.contains(p.getUniqueId()))return;v.until=now+30000;votes.put(g,v);cooldown.put(g,now+60000);}if(!v.eligible.contains(p.getUniqueId()))return;v.yes.add(p.getUniqueId());for(Player x:g.getConnectedPlayers())x.sendMessage(net.kyori.adventure.text.Component.text("경기 초기화 동의 "+v.yes.size()+"/"+v.eligible.size()+" · 30초 내 전원 동의 필요  ",net.kyori.adventure.text.format.NamedTextColor.YELLOW).append(net.kyori.adventure.text.Component.text("[동의]",net.kyori.adventure.text.format.NamedTextColor.GREEN).clickEvent(net.kyori.adventure.text.event.ClickEvent.runCommand("/error"))));if(v.yes.containsAll(v.eligible))reset(g);}
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void chat(AsyncPlayerChatEvent e){if(!Set.of("error","에러").contains(e.getMessage().strip().toLowerCase(Locale.ROOT)))return;e.setCancelled(true);Bukkit.getScheduler().runTask(plugin,()->vote(e.getPlayer()));}
    @EventHandler public void end(BedwarsGameEndEvent e){votes.remove(e.getGame());}
    @EventHandler public void leave(BedwarsPlayerLeaveEvent e){Vote v=votes.remove(e.getGame());if(v!=null)for(Player p:e.getGame().getConnectedPlayers())p.sendMessage("§e참가자가 나가 초기화 투표를 취소했습니다.");}
}
