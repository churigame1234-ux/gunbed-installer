package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scoreboard.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Vanilla scoreboard protocol with blank numeric columns, shared across all supported clients. */
final class MatchBoard implements Listener,AutoCloseable {
    private static final LegacyComponentSerializer TEXT=LegacyComponentSerializer.legacySection();
    private static final class Stats {int kills,finals,beds;}
    private record Board(Scoreboard scoreboard,Objective sidebar,Objective list){}
    private final GunbedCore plugin;
    private final Map<UUID,Board> boards=new HashMap<>();
    private final Map<UUID,Stats> stats=new HashMap<>();
    private final Map<Game,Integer> starts=new HashMap<>();
    MatchBoard(GunbedCore plugin){this.plugin=plugin;Bukkit.getPluginManager().registerEvents(this,plugin);Bukkit.getScheduler().runTaskTimer(plugin,this::update,20,20);}
    Map<String,Integer> snapshot(Player p){Stats s=stats(p);return Map.of("kills",s.kills,"finals",s.finals,"beds",s.beds);}
    private Stats stats(Player p){return stats.computeIfAbsent(p.getUniqueId(),u->new Stats());}
    private Board board(Player p){return boards.computeIfAbsent(p.getUniqueId(),u->{Scoreboard board=Bukkit.getScoreboardManager().getNewScoreboard();Objective side=board.registerNewObjective("gunbed",Criteria.DUMMY,TEXT.deserialize("§e§lBED WARS"));side.setDisplaySlot(DisplaySlot.SIDEBAR);side.numberFormat(NumberFormat.blank());Objective list=board.registerNewObjective("gbhp",Criteria.DUMMY,Component.empty());list.setDisplaySlot(DisplaySlot.PLAYER_LIST);for(int i=0;i<15;i++){Team team=board.registerNewTeam("line"+i);team.addEntry(ChatColor.values()[i]+"§r");}return new Board(board,side,list);});}
    private ChatColor color(org.screamingsandals.bedwars.api.TeamColor color){return switch(color){case LIGHT_BLUE->ChatColor.AQUA;case LIME->ChatColor.GREEN;case GREEN->ChatColor.DARK_GREEN;case ORANGE,BROWN->ChatColor.GOLD;case MAGENTA,PINK->ChatColor.LIGHT_PURPLE;case CYAN->ChatColor.DARK_AQUA;case LIGHT_GRAY->ChatColor.GRAY;case GRAY->ChatColor.DARK_GRAY;default->ChatColor.valueOf(color.name());};}
    private void update(){for(Player listed:Bukkit.getOnlinePlayers()){var game=BedwarsAPI.getInstance().getGameOfPlayer(listed);org.screamingsandals.bedwars.api.Team team=game==null?null:game.getTeamOfPlayer(listed);if(team==null&&plugin.roundChat!=null)team=plugin.roundChat.originalTeam(listed);var palette=TeamPalette.of(listed);Component name=palette.text((team==null?"":palette.name()+" ")+TeamPalette.display(listed));if(!listed.playerListName().equals(name))listed.playerListName(name);listed.displayName(TeamPalette.name(listed));}for(Player p:Bukkit.getOnlinePlayers()){Board board=board(p);Game game=BedwarsAPI.getInstance().getGameOfPlayer(p);List<String> lines=new ArrayList<>();lines.add("§7"+LocalDate.now(ZoneId.of("Asia/Seoul")).format(DateTimeFormatter.ofPattern("MM/dd/yy")));lines.add(" ");
        if(game!=null&&game.getStatus()==GameStatus.RUNNING){lines.add(plugin.flow.next(game));lines.add("  ");for(var team:game.getRunningTeams()){if(lines.size()>=11)break;String color=TeamPalette.of(game,team).legacy(),shortName=TeamPalette.of(game,team).name(),status=team.isTargetBlockExists()?"§a✔":team.isAlive()?"§a"+team.countConnectedPlayers():"§c✘";lines.add(color+shortName+": "+status+(team.isPlayerInTeam(p)?" §7YOU":""));}}
        else {lines.add(game==null?"§a로비":"§e경기 대기 중");lines.add("§f플레이어: §a"+(game==null?Bukkit.getOnlinePlayers().size():game.countConnectedPlayers())+(game==null?"":"§7/"+game.getMaxPlayers()));lines.add(game==null?"§e게임 참가 아이템을 사용하세요":plugin.waiting.status(game));lines.add("  ");lines.add("§f추천포인트: §a"+plugin.points.balance(p.getUniqueId(),PointLedger.Currency.RECOMMEND));lines.add("§f후원포인트: §d"+plugin.points.balance(p.getUniqueId(),PointLedger.Currency.DONATION));}
        Stats current=stats(p);lines.add("   ");if(!plugin.getConfig().getBoolean("client-visuals.inventory-panel",false)){lines.add("§fKills: §e"+current.kills+" §fFinal: §e"+current.finals);lines.add("§fBeds Broken: §e"+current.beds);}lines.add("    ");lines.add("§emzs123.mcv.kr");while(lines.size()>15)lines.remove(lines.size()-5);
        for(int i=0;i<15;i++){String entry=ChatColor.values()[i]+"§r";if(i<lines.size()){board.scoreboard.getTeam("line"+i).prefix(TEXT.deserialize(lines.get(i)));board.sidebar.getScore(entry).setScore(15-i);}else board.scoreboard.resetScores(entry);}
        for(Player listed:Bukkit.getOnlinePlayers()){org.bukkit.scoreboard.Team tag=board.scoreboard.getTeam("tag"+Integer.toHexString(listed.getName().hashCode()));if(tag==null)tag=board.scoreboard.registerNewTeam("tag"+Integer.toHexString(listed.getName().hashCode()));tag.addEntry(listed.getName());tag.setOption(Team.Option.NAME_TAG_VISIBILITY,Team.OptionStatus.NEVER);tag.setOption(Team.Option.COLLISION_RULE,Team.OptionStatus.NEVER);listed.setCollidable(true);var listedGame=BedwarsAPI.getInstance().getGameOfPlayer(listed);var team=listedGame==null?null:listedGame.getTeamOfPlayer(listed);Score health=board.list.getScore(listed.getName());int percent=(int)Math.ceil(listed.getHealth()/listed.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue()*100);health.setScore(percent);health.numberFormat(NumberFormat.fixed(TEXT.deserialize((team==null?"§e0":percent<=33?"§c"+percent:percent<=66?"§6"+percent:"§a"+percent))));}
        if(p.getScoreboard()!=board.scoreboard)p.setScoreboard(board.scoreboard);p.sendPlayerListHeaderAndFooter(TEXT.deserialize("§bYou are playing on §e§lmzs123.mcv.kr"),TEXT.deserialize("§bKills: §e"+current.kills+" §bFinal Kills: §e"+current.finals+" §bBeds Broken: §e"+current.beds+"\n§aMZS FPS Bed Wars §7· §emzs123.mcv.kr"));}}
    @EventHandler public void start(BedwarsGameStartedEvent e){starts.put(e.getGame(),Bukkit.getCurrentTick());for(Player p:e.getGame().getConnectedPlayers())stats.put(p.getUniqueId(),new Stats());}
    @EventHandler public void end(BedwarsGameEndEvent e){starts.remove(e.getGame());}
    @EventHandler(priority=EventPriority.MONITOR)public void killed(BedwarsPlayerKilledEvent e){Player killer=e.getKiller()==null?plugin.combatPresentation.credit(e.getPlayer()):e.getKiller();if(killer==null)return;var team=e.getGame().getTeamOfPlayer(e.getPlayer());if(plugin.combatPresentation.finalDeath(e.getPlayer()))stats(killer).finals++;else stats(killer).kills++;}
    @EventHandler public void bed(BedwarsTargetBlockDestroyedEvent e){if(e.getPlayer()!=null)stats(e.getPlayer()).beds++;}
    @EventHandler public void quit(PlayerQuitEvent e){for(Player p:Bukkit.getOnlinePlayers())p.getCollidableExemptions().remove(e.getPlayer().getUniqueId());boards.remove(e.getPlayer().getUniqueId());stats.remove(e.getPlayer().getUniqueId());}
    @EventHandler public void collisionJoin(org.bukkit.event.player.PlayerJoinEvent e){Player joined=e.getPlayer();joined.setCollidable(true);for(Player p:Bukkit.getOnlinePlayers()){p.getCollidableExemptions().add(joined.getUniqueId());joined.getCollidableExemptions().add(p.getUniqueId());}}
    @Override public void close(){for(Player p:Bukkit.getOnlinePlayers()){Board board=boards.get(p.getUniqueId());if(board!=null&&p.getScoreboard()==board.scoreboard)p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());p.sendPlayerListHeaderAndFooter(Component.empty(),Component.empty());}boards.clear();}
}
