package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.potion.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.*;
import com.comphenix.protocol.*;
import com.comphenix.protocol.events.*;
import com.comphenix.protocol.wrappers.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Equipment is hidden per viewer without unequipping armour or changing its protection. */
final class ItemParity implements Listener,AutoCloseable {
    private final GunbedCore plugin;
    private final Map<Integer,Set<UUID>> hidden=new ConcurrentHashMap<>();
    private final Map<UUID,Boolean> grounded=new HashMap<>();
    private final Map<UUID,Location> previous=new HashMap<>();
    private final PacketAdapter packets;
    ItemParity(GunbedCore p){plugin=p;packets=new PacketAdapter(p,ListenerPriority.HIGHEST,PacketType.Play.Server.ENTITY_EQUIPMENT){@Override public void onPacketSending(PacketEvent e){Set<UUID> viewers=hidden.get(e.getPacket().getIntegers().read(0));if(viewers==null||!viewers.contains(e.getPlayer().getUniqueId()))return;var copy=e.getPacket().shallowClone();List<Pair<EnumWrappers.ItemSlot,ItemStack>> equipment=new ArrayList<>();for(var pair:copy.getSlotStackPairLists().read(0)){boolean armor=Set.of(EnumWrappers.ItemSlot.HEAD,EnumWrappers.ItemSlot.CHEST,EnumWrappers.ItemSlot.LEGS,EnumWrappers.ItemSlot.FEET).contains(pair.getFirst());equipment.add(new Pair<>(pair.getFirst(),armor?new ItemStack(Material.AIR):pair.getSecond()));}copy.getSlotStackPairLists().write(0,equipment);e.setPacket(copy);}};ProtocolLibrary.getProtocolManager().addPacketListener(packets);Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,2,2);}
    private Game game(Player p){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);return g!=null&&g.getStatus()==GameStatus.RUNNING&&g.getTeamOfPlayer(p)!=null&&p.getGameMode()!=GameMode.SPECTATOR?g:null;}
    private void send(Player viewer,Player actor,boolean hide){Map<EquipmentSlot,ItemStack> gear=new EnumMap<>(EquipmentSlot.class);for(var slot:List.of(EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET))gear.put(slot,hide?new ItemStack(Material.AIR):actor.getInventory().getItem(slot));viewer.sendEquipmentChange(actor,gear);}
    private void tick(){Set<Integer> active=new HashSet<>();for(Player p:Bukkit.getOnlinePlayers()){Game g=game(p);Set<UUID> now=new HashSet<>();boolean invisible=g!=null&&p.hasPotionEffect(PotionEffectType.INVISIBILITY);if(invisible){for(Player viewer:g.getConnectedPlayers())if(!FriendlyProjectiles.ally(p,viewer)&&viewer!=p)now.add(viewer.getUniqueId());active.add(p.getEntityId());}Set<UUID> old=hidden.getOrDefault(p.getEntityId(),Set.of());if(now.isEmpty())hidden.remove(p.getEntityId());else hidden.put(p.getEntityId(),Set.copyOf(now));if(!now.equals(old))for(Player viewer:p.getWorld().getPlayers())if(now.contains(viewer.getUniqueId())||old.contains(viewer.getUniqueId()))send(viewer,p,now.contains(viewer.getUniqueId()));
        Location before=previous.put(p.getUniqueId(),p.getLocation());boolean was=grounded.getOrDefault(p.getUniqueId(),p.isOnGround());grounded.put(p.getUniqueId(),p.isOnGround());if(invisible&&p.isOnGround()&&(!was||p.isSprinting()&&before!=null&&before.getWorld()==p.getWorld()&&before.distanceSquared(p.getLocation())>.002&&Bukkit.getCurrentTick()%4==0)){var b=p.getLocation().subtract(0,.12,0).getBlock();if(!b.isEmpty())p.getWorld().spawnParticle(Particle.BLOCK,p.getLocation().add(0,.05,0),!was?12:3,.18,.02,.18,0,b.getBlockData(),true);}}
        hidden.keySet().removeIf(id->!active.contains(id)&&Bukkit.getOnlinePlayers().stream().noneMatch(p->p.getEntityId()==id));}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void drink(PlayerItemConsumeEvent e){if(game(e.getPlayer())==null||e.getItem().getType()!=Material.POTION)return;e.setReplacement(new ItemStack(Material.AIR));Player p=e.getPlayer();EquipmentSlot hand=e.getHand();Bukkit.getScheduler().runTask(plugin,()->{ItemStack held=p.getInventory().getItem(hand);if(held.getType()==Material.GLASS_BOTTLE){held.setAmount(held.getAmount()-1);p.getInventory().setItem(hand,held.getAmount()>0?held:null);}PotionEffect effect=p.getPotionEffect(PotionEffectType.INVISIBILITY);if(effect!=null)p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY,effect.getDuration(),effect.getAmplifier(),false,false,false));});}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void reveal(EntityDamageByEntityEvent e){if(!(e.getEntity() instanceof Player p)||!p.hasPotionEffect(PotionEffectType.INVISIBILITY)||e.getFinalDamage()<=0)return;Player source=e.getDamager() instanceof Player x?x:e.getDamager() instanceof Projectile q&&q.getShooter() instanceof Player x?x:null;if(source!=null&&!FriendlyProjectiles.ally(source,p))p.removePotionEffect(PotionEffectType.INVISIBILITY);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void pearl(ProjectileLaunchEvent e){if(!(e.getEntity() instanceof EnderPearl pearl)||!(pearl.getShooter() instanceof Player p))return;Game g=game(p);if(g==null)return;for(Player viewer:g.getConnectedPlayers())if(viewer.getWorld()!=p.getWorld()||viewer.getLocation().distanceSquared(p.getLocation())>256)viewer.playSound(viewer.getLocation(),Sound.ENTITY_ENDER_PEARL_THROW,1,1);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void arrived(PlayerTeleportEvent e){if(e.getCause()!=PlayerTeleportEvent.TeleportCause.ENDER_PEARL)return;Game g=game(e.getPlayer());if(g==null||e.getTo()==null)return;for(Player viewer:g.getConnectedPlayers())if(viewer.getWorld()!=e.getTo().getWorld()||viewer.getLocation().distanceSquared(e.getTo())>1024)viewer.playSound(viewer.getLocation(),Sound.ENTITY_ENDERMAN_TELEPORT,1,1);}
    @EventHandler public void quit(PlayerQuitEvent e){hidden.remove(e.getPlayer().getEntityId());grounded.remove(e.getPlayer().getUniqueId());previous.remove(e.getPlayer().getUniqueId());}
    @Override public void close(){hidden.clear();ProtocolLibrary.getProtocolManager().removePacketListener(packets);for(Player actor:Bukkit.getOnlinePlayers())for(Player viewer:actor.getWorld().getPlayers())send(viewer,actor,false);}
}
