package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.RunningTeam;
import org.screamingsandals.bedwars.api.game.Game;
import org.screamingsandals.bedwars.api.game.GameStatus;
import org.screamingsandals.bedwars.api.events.*;

import java.io.File;
import java.util.*;
import java.util.regex.Pattern;

/** Reads the owner's existing shop data. Match lifecycle and rollback remain owned by BedWars. */
final class NativeShop implements Listener {
    private final GunbedCore plugin;
    private final Map<UUID,Boolean> shopModes=new HashMap<>();
    private final BedwarsAPI api = BedwarsAPI.getInstance();
    private final YamlConfiguration language;
    private final List<Category> categories = new ArrayList<>();
    private final Map<String, ConfigurationSection> upgrades = new LinkedHashMap<>();
    private final Map<Game, Map<UUID, Map<String, ItemStack>>> permanent = new HashMap<>();
    private final Map<Game, Map<UUID, Set<String>>> purchases = new HashMap<>();
    private final Map<Game, Map<RunningTeam, TeamState>> teamStates = new HashMap<>();
    private final Map<UUID, Long> milkUntil = new HashMap<>();
    private final NamespacedKey specialKey;
    private final NamespacedKey ownerKey;
    private final PopupTower towers;

    private record Category(String name, Material icon, List<Map<?, ?>> items) { }
    private record Menu(Game game, boolean upgrade, int page, boolean editing) implements InventoryHolder {
        @Override public Inventory getInventory() { throw new UnsupportedOperationException(); }
    }
    private record FavoriteChoice(Game game,String id,boolean editing) implements InventoryHolder {public Inventory getInventory(){throw new UnsupportedOperationException();}}
    private static final List<Integer> GRID=List.of(19,20,21,22,23,24,25,28,29,30,31,32,33,34,37,38,39,40,41,42,43);
    private static final List<Integer> TRAP_QUEUE=List.of(29,31,33);
    private static final List<Integer> UPGRADES=List.of(10,11,12,13,14,15,19,20,21,22,23);
    private record Entry(int page,int index,Map<?,?> item){}
    private String entryId(Entry entry){return entry.item.get("id") instanceof String id?id:categories.get(entry.page).name+":"+entry.index;}
    private List<Entry> entries(){List<Entry> result=new ArrayList<>();for(int page=0;page<categories.size();page++)for(int n=0;n<categories.get(page).items.size();n++)result.add(new Entry(page,n,categories.get(page).items.get(n)));return result;}
    private Entry findEntry(String id){return entries().stream().filter(e->entryId(e).equals(id)).findFirst().orElse(null);}
    private List<Integer> mainPages(){List<Integer> pages=new ArrayList<>();for(int i=0;i<categories.size();i++)if(!Set.of("Weapon","Turret").contains(categories.get(i).name))pages.add(i);return pages;}
    private int specialPage(String name){for(int i=0;i<categories.size();i++)if(categories.get(i).name.equals(name))return i;return -1;}
    private List<String> favorites(Player p){List<String> stored=plugin.profiles.get(p.getUniqueId()).getStringList("shop.quick-buy");List<String> result=new ArrayList<>(Collections.nCopies(21,""));if(plugin.profiles.get(p.getUniqueId()).contains("shop.quick-buy")){for(int i=0;i<Math.min(21,stored.size());i++)result.set(i,stored.get(i));}else{List<Entry> initial=entries().stream().filter(e->!Set.of("Weapon","Turret").contains(categories.get(e.page).name)).limit(21).toList();for(int i=0;i<initial.size();i++)result.set(i,entryId(initial.get(i)));}return result;}
    boolean sharp(Player p){var game=api.getGameOfPlayer(p);var team=game==null?null:game.getTeamOfPlayer(p);return team!=null&&teamStates.getOrDefault(game,Map.of()).getOrDefault(team,new TeamState()).levels.getOrDefault("sharpness",0)>0;}
    private boolean largeTeam(Game game){return game!=null&&game.getAvailableTeams().stream().anyMatch(team->team.getMaxPlayers()>=3);}
    private int price(Game game,Map<?,?> spec){return integer(spec,largeTeam(game)?"team-amount":"amount",integer(spec,"amount",1));}
    private static final class TeamState {
        final Map<String, Integer> levels = new HashMap<>();
        final Deque<String> traps = new ArrayDeque<>();
        long nextTrap;
        int forgeSeconds;
    }

    NativeShop(GunbedCore plugin) {
        this.plugin = plugin;
        towers=new PopupTower(plugin,this::allowedTowerBuild);
        specialKey = new NamespacedKey(plugin, "special");
        ownerKey = new NamespacedKey(plugin, "owner");
        language = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "legacy-language.yml"));
        var shop = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "shop.yml"));
        var pages = shop.getConfigurationSection("pages");
        if (pages != null) for (String name : pages.getKeys(false)) {
            var page = pages.getConfigurationSection(name);
            categories.add(new Category(translate(name), material(page.getString("icon")), page.getMapList("items")));
        }
        Map<String,Object> hook=new LinkedHashMap<>();hook.put("id","utility:grapple");hook.put("name","그래플링 훅");hook.put("icon","FISHING_ROD");hook.put("grappling-hook",true);hook.put("products",List.of());List<Map<String,Object>> hookPrices=new ArrayList<>();for(var cost:Map.of("iron",16,"gold",8,"diamond",1,"emerald",1).entrySet())hookPrices.add(Map.of("type","spawner-item","spawner-id",cost.getKey(),"amount",cost.getValue()));hook.put("prices",hookPrices);for(int n=0;n<categories.size();n++)if(categories.get(n).name.equals("Utility")){Category category=categories.get(n);List<Map<?,?>> items=new ArrayList<>(category.items);items.removeIf(item->"utility:grapple".equals(item.get("id")));items.add(hook);categories.set(n,new Category(category.name,category.icon,items));break;}
        for(int n=0;n<categories.size();n++)if(categories.get(n).name.equals("Melee")){Category cat=categories.get(n);List<Map<?,?>> items=new ArrayList<>(cat.items);items.removeIf(i->"knockback-stick".equals(i.get("id")));items.add(Map.of("id","knockback-stick","name","밀치기 막대기","icon","stick","products",List.of(Map.of("type","item","material","stick","amount",1,"enchantments",Map.of("knockback",5))),"prices",List.of(Map.of("type","spawner-item","spawner-id","gold","amount",5))));categories.set(n,new Category(cat.name,cat.icon,items));}
        for(int n=0;n<categories.size();n++){Category category=categories.get(n);if(category.items.stream().noneMatch(item->item.containsKey("throwable-kind")))continue;List<Map<?,?>> items=new ArrayList<>(category.items);for(String kind:List.of("labs_he","labs_impact","labs_gas"))if(items.stream().noneMatch(item->kind.equals(item.get("throwable-kind"))))items.add(Map.of("id","throwable:"+kind,"name",Throwables.name(kind),"icon","paper","throwable-kind",kind,"products",List.of(),"prices",List.of(Map.of("type","spawner-item","spawner-id","gold","amount",3))));categories.set(n,new Category(category.name,category.icon,items));break;}
        var upgradeConfig = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "upgrades.yml"));
        var section = upgradeConfig.getConfigurationSection("upgrades");
        if (section != null) for (String name : section.getKeys(false)) upgrades.put(name, section.getConfigurationSection(name));
        if(!upgrades.containsKey("dragon-buff")){var dragon=upgradeConfig.createSection("upgrades.dragon-buff");dragon.set("levels.lvl-1.icon","dragon_head");dragon.set("levels.lvl-1.price.spawner","diamond");dragon.set("levels.lvl-1.price.amount",5);dragon.set("levels.lvl-1.price.team-amount",5);upgrades.put("dragon-buff",dragon);}
        Bukkit.getPluginManager().registerEvents(this, plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, this::tickTeams, 20, 20);
        plugin.getLogger().info("Imported shop: " + productCount() + " entries and " + upgrades.size() + " team upgrades.");
    }

    int productCount() { return categories.stream().mapToInt(c -> c.items().size()).sum(); }
    int upgradeCount() { return upgrades.size(); }
    void close() { towers.close(); }

    private String translate(String value) {
        if (value == null) return "";
        var matcher = Pattern.compile("%([^%]+)%").matcher(value);
        StringBuilder result = new StringBuilder();
        while (matcher.find()) matcher.appendReplacement(result, java.util.regex.Matcher.quoteReplacement(language.getString(matcher.group(1), matcher.group(1))));
        matcher.appendTail(result);
        return ChatColor.translateAlternateColorCodes('&', result.toString());
    }

    private static Material material(String value) {
        if (value == null) return Material.BARRIER;
        String name = value.split(" \\{")[0].split(":")[0].replace(' ', '_').toUpperCase(Locale.ROOT);
        Material material = Material.matchMaterial(name);
        return material == null || !material.isItem() ? Material.BARRIER : material;
    }

    private static int integer(Map<?, ?> map, String key, int fallback) {
        return map.get(key) instanceof Number number ? number.intValue() : fallback;
    }

    private ItemStack icon(Material type, String name, List<String> lore) {
        ItemStack item = new ItemStack(type);
        var meta = item.getItemMeta(); meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',translate(name))); meta.setLore(lore.stream().map(line->ChatColor.translateAlternateColorCodes('&',line)).toList());meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta); return item;
    }

    void editFavorites(Player player,boolean upgrade){open(player,upgrade,-1,true);}
    void open(Player player,boolean upgrade,int page){open(player,upgrade,page,false);}
    private void open(Player player,boolean upgrade,int page,boolean editing){
        Game game=api.getGameOfPlayer(player);
        if(!editing&&(game==null||game.getStatus()!=GameStatus.RUNNING||game.getTeamOfPlayer(player)==null||player.getGameMode()==GameMode.SPECTATOR)){player.sendMessage("§c경기 중에만 구매할 수 있습니다.");return;}
        if(page>=categories.size())page=-1;
        if(!editing){shopModes.putIfAbsent(player.getUniqueId(),plugin.inventories.modeA(player));plugin.inventories.mode(player,false);}
        final int selectedPage=page;
        Inventory menu=Bukkit.createInventory(new Menu(game,upgrade,page,editing),54,(editing?"즐겨찾기 설정 · ":"")+(upgrade?"팀 업그레이드":"아이템 상점"));
        if(upgrade){int n=0;List<String> quick=plugin.profiles.get(player.getUniqueId()).getStringList("shop.team-favorites");for(var entry:upgrades.entrySet()){if(n>=UPGRADES.size())break;var level=game==null||game.getTeamOfPlayer(player)==null?entry.getValue().getConfigurationSection("levels.lvl-1"):nextUpgrade(game,game.getTeamOfPlayer(player),entry.getKey());if(level==null&&entry.getValue().isConfigurationSection("repeatable-level"))level=entry.getValue().getConfigurationSection("repeatable-level");List<String> lore=new ArrayList<>();lore.add(level==null?"§a최대 레벨":"§b가격: "+upgradePrice(game,game==null?null:game.getTeamOfPlayer(player),entry.getKey(),level)+" 다이아몬드");lore.addAll(description(entry.getKey()));lore.add(quick.contains(entry.getKey())?"§a즐겨찾기 · Shift 클릭으로 해제":"§7Shift 클릭: 팀 상점 즐겨찾기 등록");menu.setItem(UPGRADES.get(n++),icon(level==null?Material.EMERALD_BLOCK:material(level.getString("icon")),upgradeName(entry.getKey()),lore));}for(int i=0;i<Math.min(3,quick.size());i++)menu.setItem(37+i,icon(Material.DIAMOND,"§b★ "+quick.get(i),List.of("§7클릭: 구매 · Shift 클릭: 등록 해제")));}
        else {menu.setItem(0,icon(Material.NETHER_STAR,"§e빠른 구매",List.of("§7Shift 클릭으로 등록·해제")));List<Integer> pages=mainPages();for(int i=0;i<Math.min(8,pages.size());i++){var category=categories.get(pages.get(i));menu.setItem(i+1,icon(category.icon,category.name,List.of("§7클릭하여 분류 선택")));}for(int slot=9;slot<18;slot++)menu.setItem(slot,icon(Material.GRAY_STAINED_GLASS_PANE," ",List.of()));
            List<Entry> displayed=displayed(player,game,page);for(int n=0;n<Math.min(GRID.size(),displayed.size());n++){Entry entry=displayed.get(n);if(entry==null){menu.setItem(GRID.get(n),icon(Material.RED_STAINED_GLASS_PANE,"§c빈 즐겨찾기",List.of("§7분류에서 아이템을 Shift 클릭하여 등록")));continue;}menu.setItem(GRID.get(n),entryIcon(player,game,entry));}
            for(var pair:Map.of(45,"Weapon",46,"Turret").entrySet()){int index=specialPage(pair.getValue());if(index>=0)menu.setItem(pair.getKey(),icon(categories.get(index).icon,pair.getValue().equals("Weapon")?"§e무기 · 터렛":categories.get(index).name,List.of("§7총기 탄약과 전용 장비")));}
        }
        if(upgrade)renderTrapQueue(player,game,menu);
        menu.setItem(48,icon(Material.IRON_NUGGET,"§e총기 탄약",List.of("§7금 1개 + 철 4개","§7보유 주무기·보조무기에 각각 4회 장전분")));
        if(!editing)menu.setItem(50,icon(Material.COMPASS,"§e적 추적",List.of("§7이번 경기 추적 해금: 1 에메랄드")));
        menu.setItem(53,icon(Material.BOOK,"§e즐겨찾기 사용법",List.of("§7아이템 Shift 클릭: 등록 위치 선택","§7빠른 구매에서 Shift 클릭: 해제","§7팀 상점은 최대 3개 등록")));player.openInventory(menu);
    }
    private void renderTrapQueue(Player viewer,Game game,Inventory menu){
        RunningTeam team=game==null?null:game.getTeamOfPlayer(viewer);
        List<String> queue=team==null?List.of():new ArrayList<>(state(game,team).traps);
        for(int n=0;n<3;n++){
            if(n>=queue.size()){menu.setItem(TRAP_QUEUE.get(n),icon(Material.GRAY_STAINED_GLASS_PANE,"§7"+(n+1)+"순위 · 비어 있음",List.of("§7함정을 구매하면 순서대로 등록됩니다.","§7기지 침입 시 1순위부터 발동합니다.")));continue;}
            String name=queue.get(n);ConfigurationSection definition=upgrades.get(name),level=definition==null?null:definition.getConfigurationSection("repeatable-level");
            List<String> lore=new ArrayList<>(description(name));lore.add("§e발동 대기 순서: "+(n+1)+"순위");lore.add("§7앞 함정이 발동하면 자동으로 순서가 당겨집니다.");lore.add("§8확인용 · 클릭해도 구매하거나 해제하지 않습니다.");
            menu.setItem(TRAP_QUEUE.get(n),icon(level==null?Material.TRIPWIRE_HOOK:material(level.getString("icon")),"§e"+(n+1)+"순위 · §f"+upgradeName(name),lore));
        }
    }
    private void refreshTrapQueue(Game game,RunningTeam team){
        for(Player viewer:team.getConnectedPlayers()){
            Inventory inv=viewer.getOpenInventory().getTopInventory();
            if(inv.getHolder() instanceof Menu menu&&menu.upgrade&&!menu.editing&&menu.game==game)renderTrapQueue(viewer,game,inv);
        }
    }
    private int toolTier(Player player,Game game,String tool){if(game==null)return 0;Set<String> owned=purchases.getOrDefault(game,Map.of()).getOrDefault(player.getUniqueId(),Set.of());return owned.stream().filter(s->s.startsWith("tool:"+tool+":")).mapToInt(s->Integer.parseInt(s.substring(s.lastIndexOf(':')+1))).max().orElse(0);}
    private Map<?,?> resolved(Player player,Game game,Map<?,?> item){if(!(item.get("tool") instanceof String tool))return item;var tiers=maps(item.get("tiers"));int current=toolTier(player,game,tool);Map<Object,Object> next=new LinkedHashMap<>(tiers.get(Math.min(current,tiers.size()-1)));next.put("tool",tool);next.put("tool-tier",Math.min(4,current+1));return next;}
    private String tool(ItemStack item){return item==null||!item.hasItemMeta()?null:item.getItemMeta().getPersistentDataContainer().get(new NamespacedKey(plugin,"shop_tool"),PersistentDataType.STRING);}
    private void markTool(ItemStack item,String tool){var meta=item.getItemMeta();meta.getPersistentDataContainer().set(new NamespacedKey(plugin,"shop_tool"),PersistentDataType.STRING,tool);item.setItemMeta(meta);}
    private List<Entry> displayed(Player p,Game game,int page){List<Entry> list=new ArrayList<>(page<0?favorites(p).stream().map(this::findEntry).toList():entries().stream().filter(e->e.page==page).toList());if(plugin.aiRules!=null&&plugin.aiRules.invisibleShop(p))Collections.shuffle(list,new Random(plugin.aiRules.shopSeed(p)+page*7919L));return list;}
    void forgetEquipment(Player p,Game game){permanent(game,p.getUniqueId()).clear();var map=purchases.get(game);if(map!=null)map.remove(p.getUniqueId());}
    private ItemStack entryIcon(Player player,Game game,Entry entry){if(plugin.aiRules!=null&&plugin.aiRules.invisibleShop(player))return icon(Material.PAPER,"§7알 수 없는 상품",List.of("§7상품 위치는 이번 경기 동안 고정됩니다."));var item=resolved(player,game,entry.item);List<String> lore=new ArrayList<>(description(translate((String)item.get("name"))));for(Map<?,?> cost:maps(item.get("prices")))lore.add("§7가격: "+currency(cost.get("spawner-id").toString(),price(game,cost)));if(item.get("tool") instanceof String tool){lore.add("§7사망하면 한 단계 낮아짐 · 최소 I 유지");if(toolTier(player,game,tool)>=4)lore.add("§a최대 등급");}else if(Boolean.TRUE.equals(item.get("keep-on-death")))lore.add("§a이번 경기에서 사망 후 유지");lore.add("§7Shift 클릭: 즐겨찾기 설정");ItemStack shown=icon(material((String)item.get("icon")),(String)item.get("name"),lore);if(Boolean.TRUE.equals(item.get("grappling-hook"))&&plugin.grapple!=null){var custom=plugin.grapple.create();var meta=custom.getItemMeta();List<String> detail=new ArrayList<>(meta.getLore());detail.addAll(lore);meta.setLore(detail);custom.setItemMeta(meta);shown=custom;}else if(item.get("addon-melee") instanceof String kind){var custom=plugin.addonMelee.create(kind);var meta=custom.getItemMeta();meta.setDisplayName(translate((String)item.get("name")));meta.setLore(lore);custom.setItemMeta(meta);shown=custom;}else if(item.get("throwable-kind") instanceof String kind){var custom=plugin.throwables.create(kind);var meta=custom.getItemMeta();meta.setDisplayName(translate((String)item.get("name")));meta.setLore(lore);custom.setItemMeta(meta);shown=custom;}else if(item.get("turret-kind") instanceof String kind&&plugin.turrets!=null){var custom=plugin.turrets.item(kind);var meta=custom.getItemMeta();meta.setDisplayName(translate((String)item.get("name")));meta.setLore(lore);custom.setItemMeta(meta);shown=custom;}if(shown.getType()==Material.POTION){var actual=product(player,game,maps(item.get("products")).getFirst());var pm=(PotionMeta)shown.getItemMeta();pm.setColor(((PotionMeta)actual.getItemMeta()).getColor());shown.setItemMeta(pm);}return shown;}
    private String upgradeName(String key){return switch(key){case "sharpness"->"강화 검";case "protection"->"방어구 강화";case "forge"->"대장간";case "haste"->"성급한 채굴자";case "heal-pool"->"치유의 샘";case "dragon-buff"->"드래곤 강화";case "alarm-trap"->"경보 함정";case "miner-fatigue-trap","mining-fatigue-trap"->"채굴 피로 함정";case "counter-offensive-trap"->"반격 함정";case "blindness-trap","regular-trap"->"실명 함정";case "cushioned-boots"->"충격 흡수 부츠";default->key;};}
    private List<String> description(String raw){String n=ChatColor.stripColor(raw).toLowerCase(Locale.ROOT);String specific=n.contains("황금 사과")?"2분간 흡수 체력 +20 · 5초 동안 체력 20 회복":n.contains("사슬 갑옷")?"영구 사슬 바지·신발 · 최대 체력 110":n.equals("철 갑옷")?"영구 철 바지·신발 · 최대 체력 130":n.contains("다이아몬드 갑옷")?"영구 다이아 바지·신발 · 최대 체력 150":n.startsWith("신속")?"45초 동안 이동 속도 II":n.startsWith("점프")?"45초 동안 점프 강화 V":n.startsWith("투명")?"30초 동안 투명 · 갑옷도 숨김":n.contains("섬광탄")?"금 3개 · 시야와 거리에 따라 최대 5초 섬광":n.contains("화염탄")?"금 3개 · 불길 안 적에게 지속 피해 · 밀어내기 없음":n.contains("수류탄")?"금 3개 · 피해 반경 8블록 · 벽 뒤 피해 차단":n.contains("회복 포탑")?"체력 1,000~5,000 무작위 · 아군 회복 · 5분 + 회복 성공마다 1초":n.contains("포탑")?"체력 1,000~5,000 무작위 · 5초 설치 · 5분 + 적중 성공마다 1초":n.contains("팝업")?"팀 색 양털 방어 타워를 방향에 맞춰 설치":n.contains("다리 달걀")?"던진 경로를 따라 팀 양털 다리 생성":n.contains("엔더 진주")?"착지 위치로 순간이동":n.contains("마법의 우유")?"30초 동안 적의 기지 함정 발동 방지":n.contains("드림 수호자")?"기지에서 적을 공격하는 임시 철 골렘 소환":n.equals("빈대")?"투척 지점에 적을 공격하는 임시 좀벌레 소환":n.contains("물 양동이")?"흐르는 물로 낙하와 폭발 방어":n.equals("스펀지")?"근처 물을 흡수":n.equals("tnt")?"설치 후 점화 · 적 침대 방어 블록 파괴":n.contains("화염구")?"조준 방향으로 발사 · 충돌 시 폭발":n.contains("방폭 유리")?"폭발에 강한 침대 방어 · 직접 채굴 가능":n.contains("흑요석")?"높은 내구도의 침대 방어 · 다이아 곡괭이 권장":n.contains("사다리")?"수직 이동과 낙하 완충":n.contains("활")?"일반 활 피해 "+Math.round(plugin.damages.value("items.bow.normal",4500))+" · 힘 I 활 "+Math.round(plugin.damages.value("items.bow.power",6000))+" · 방어 적용 전":n.contains("화살")?"활에 사용하는 소모 탄약":null;if(specific!=null)return List.of("§7"+specific);String text=switch(n){case "sharpness"->"모든 팀 무기에 적중마다 1~5% 무작위 추가 피해";case "protection"->"팀 방어구에 보호 인챈트 적용·강화";case "forge"->"팀 기지 철·금 생성 속도 증가";case "haste"->"팀원에게 성급함을 부여해 채굴 가속";case "heal-pool"->"팀 기지 안에서 아군 체력 회복";case "dragon-buff"->"서든데스에서 아군 드래곤 추가";case "alarm-trap"->"침입자에게 경보·투명 효과 제거";case "miner-fatigue-trap","mining-fatigue-trap"->"기지 침입자에게 채굴 피로 적용";case "counter-offensive-trap"->"기지 침입 시 아군에게 속도·점프 강화";case "blindness-trap","regular-trap"->"기지 침입자에게 실명·둔화 적용";case "cushioned-boots"->"아군 부츠의 낙하 피해 감소";default->n.contains("물약")?"마시면 표시된 강화 효과를 일정 시간 획득":n.contains("칼")||n.contains("검")?"근접 공격 무기·방어구에 따라 피해 감소":n.contains("갑옷")||n.contains("방어")?"방어 등급을 올려 받는 피해 감소":n.contains("곡괭이")||n.contains("도끼")||n.contains("가위")?"블록 방어를 빠르게 제거하는 도구":n.contains("양털")||n.contains("블록")||n.contains("목재")||n.contains("석")?"길을 잇거나 침대를 방어하는 설치용 블록":n.contains("탄약")?"보유 주무기·보조무기에 장전분 추가":"클릭하여 표시된 아이템·효과 구매";};return List.of("§7"+text);}
    private String currency(String id,int amount){return switch(id){case "gold"->"§6"+amount+" 골드";case "diamond"->"§b"+amount+" 다이아몬드";case "emerald"->"§a"+amount+" 에메랄드";default->"§f"+amount+" 철";};}
    private void fail(Player p){p.playSound(p.getLocation(),Sound.ENTITY_VILLAGER_NO,1,1);}
    private int upgradePrice(Game game,RunningTeam team,String name,ConfigurationSection level){int amount=largeTeam(game)?level.getInt("price.team-amount",level.getInt("price.amount")):level.getInt("price.amount");return name.endsWith("trap")&&team!=null?amount*(1<<state(game,team).traps.size()):amount;}
    private void favoritePosition(Player p,Menu source,Entry entry){Inventory inv=Bukkit.createInventory(new FavoriteChoice(source.game,entryId(entry),source.editing),54,"즐겨찾기 등록 위치 선택");List<String> ids=favorites(p);for(int i=0;i<21;i++){Entry previous=findEntry(ids.get(i));inv.setItem(GRID.get(i),previous==null?icon(Material.LIME_STAINED_GLASS_PANE,"§a"+(i+1)+"번에 등록",List.of()):entryIcon(p,source.game,previous));}inv.setItem(4,entryIcon(p,source.game,entry));p.openInventory(inv);}

    @SuppressWarnings("unchecked")
    private static List<Map<?, ?>> maps(Object value) {
        return value instanceof List<?> list ? (List<Map<?, ?>>) list : List.of();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onShop(BedwarsOpenShopEvent event) {
        event.setResult(BedwarsOpenShopEvent.Result.DISALLOW_THIRD_PARTY_SHOP);
        String file = event.getStore() == null ? "" : event.getStore().getShopFile();
        open(event.getPlayer(), "gunbed-upgrades.yml".equals(file), -1);
    }

    @EventHandler public void onClick(InventoryClickEvent event){
        if(!(event.getWhoClicked() instanceof Player player))return;var holder=event.getView().getTopInventory().getHolder();int slot=event.getRawSlot();
        if(holder instanceof FavoriteChoice choice){event.setCancelled(true);int index=GRID.indexOf(slot);if(index<0)return;List<String> ids=favorites(player);for(int i=0;i<ids.size();i++)if(ids.get(i).equals(choice.id))ids.set(i,"");ids.set(index,choice.id);plugin.profiles.set(player.getUniqueId(),"shop.quick-buy",ids);open(player,false,-1,choice.editing);return;}
        if(!(holder instanceof Menu menu))return;event.setCancelled(true);if(slot<0||slot>=54)return;
        if(!menu.editing&&(api.getGameOfPlayer(player)!=menu.game||menu.game==null||menu.game.getStatus()!=GameStatus.RUNNING||player.getGameMode()==GameMode.SPECTATOR)){player.closeInventory();return;}
        if(slot==49)return;if(slot==48&&!menu.editing){buyTaAmmo(player);return;}if(slot==50&&!menu.editing){plugin.tracker.open(player);return;}
        if(menu.upgrade){String name=null;int index=UPGRADES.indexOf(slot);if(index>=0&&index<upgrades.size())name=new ArrayList<>(upgrades.keySet()).get(index);else if(slot>=37&&slot<=39){List<String> ids=plugin.profiles.get(player.getUniqueId()).getStringList("shop.team-favorites");if(slot-37<ids.size())name=ids.get(slot-37);}if(name==null)return;if(event.isShiftClick()||menu.editing){List<String> ids=new ArrayList<>(plugin.profiles.get(player.getUniqueId()).getStringList("shop.team-favorites"));if(ids.contains(name))ids.remove(name);else if(ids.size()<3)ids.add(name);else {player.sendMessage("§c팀 상점 즐겨찾기는 최대 3개입니다.");return;}plugin.profiles.set(player.getUniqueId(),"shop.team-favorites",ids);open(player,true,-1,menu.editing);}else buyUpgrade(player,menu.game,name);return;}
        if(slot==0){open(player,false,-1,menu.editing);return;}List<Integer> pages=mainPages();if(slot>=1&&slot<=8&&slot-1<pages.size()){open(player,false,pages.get(slot-1),menu.editing);return;}if(slot==45||slot==46){int page=specialPage(slot==45?"Weapon":"Turret");if(page>=0)open(player,false,page,menu.editing);return;}
        int index=GRID.indexOf(slot);if(index<0)return;List<Entry> shown=displayed(player,menu.game,menu.page);Entry entry=index<shown.size()?shown.get(index):null;
        if(menu.page<0&&event.isShiftClick()&&(plugin.aiRules==null||!plugin.aiRules.invisibleShop(player))){List<String> ids=favorites(player);ids.set(index,"");plugin.profiles.set(player.getUniqueId(),"shop.quick-buy",ids);open(player,false,-1,menu.editing);return;}
        if(entry==null)return;if((event.isShiftClick()||menu.editing)&&(plugin.aiRules==null||!plugin.aiRules.invisibleShop(player)))favoritePosition(player,menu,entry);else {buy(player,menu.game,entry.item,entryId(entry));open(player,false,menu.page,menu.editing);}
    }
    @EventHandler public void onDrag(InventoryDragEvent event){if(event.getView().getTopInventory().getHolder() instanceof Menu||event.getView().getTopInventory().getHolder() instanceof FavoriteChoice)event.setCancelled(true);}

    boolean botCanBuy(Player p,String id){Entry e=findEntry(id);Game g=api.getGameOfPlayer(p);return e!=null&&g!=null&&plugin.wallet.affordable(p,costs(maps(resolved(p,g,e.item).get("prices")),g));}
    void botBuy(Player player,String id){var entry=findEntry(id);if(entry!=null)buy(player,api.getGameOfPlayer(player),entry.item,id);}

    private void buyTaAmmo(Player player){plugin.inventories.mode(player,false);List<ItemStack> prices=List.of(new ItemStack(Material.GOLD_INGOT),new ItemStack(Material.IRON_INGOT,4));List<ItemStack> guns=plugin.inventories.weapons(player).stream().filter(item->{String role=plugin.inventories.role(item);return "primary".equals(role)||"secondary".equals(role);}).toList();if(guns.isEmpty()){player.sendMessage("§c주무기 또는 보조무기가 필요합니다.");return;}if(!plugin.wallet.pay(player,prices)){fail(player);player.sendMessage("§c금 1개와 철 4개가 필요합니다.");return;}for(ItemStack item:guns){String id=plugin.ammo.id(item);plugin.ammo.add(player,id,Math.max(1,plugin.ammo.capacity(id))*4);}player.playSound(player.getLocation(),Sound.BLOCK_NOTE_BLOCK_PLING,1,2);player.sendMessage("§a주무기·보조무기에 각각 4회 장전분을 추가했습니다.");}

    private List<ItemStack> costs(List<Map<?, ?>> prices,Game game) {
        List<ItemStack> costs = new ArrayList<>();
        for (var price : prices) {
            if (!"spawner-item".equals(price.get("type"))) throw new IllegalArgumentException("Unsupported currency");
            var type = api.getItemSpawnerTypeByName((String) price.get("spawner-id"));
            if (type == null) throw new IllegalArgumentException("Unknown generator");
            costs.add(type.getStack(price(game,price)));
        }
        return costs;
    }

    private Map<String, ItemStack> permanent(Game game, UUID player) {
        return permanent.computeIfAbsent(game, g -> new HashMap<>()).computeIfAbsent(player, p -> new LinkedHashMap<>());
    }

    @EventHandler public void closed(InventoryCloseEvent e){if(!(e.getPlayer() instanceof Player p)||!shopModes.containsKey(p.getUniqueId()))return;Bukkit.getScheduler().runTask(plugin,()->{var holder=p.getOpenInventory().getTopInventory().getHolder();if(holder instanceof Menu||holder instanceof FavoriteChoice)return;Boolean previous=shopModes.remove(p.getUniqueId());if(previous!=null&&p.isOnline())plugin.inventories.mode(p,previous);});}
    private void buy(Player player, Game game, Map<?, ?> entry, String id) {
        if(plugin.aiRules!=null&&!plugin.aiRules.buy(player,id,entry))return;
        if(!entry.containsKey("throwable-kind"))plugin.inventories.mode(player,false);
        RunningTeam team = game.getTeamOfPlayer(player);
        if (team == null) return;
        if(Boolean.TRUE.equals(entry.get("grappling-hook"))){plugin.grapple.buy(player,costs(maps(entry.get("prices")),game));return;}
        if(entry.get("addon-melee") instanceof String kind){plugin.addonMelee.buy(player,kind,costs(maps(entry.get("prices")),game));return;}
        if(entry.get("turret-kind") instanceof String kind&&plugin.turrets!=null){plugin.turrets.buy(player,kind,costs(maps(entry.get("prices")),game));return;}
        if(Boolean.TRUE.equals(entry.get("legacy-disabled"))){fail(player);player.sendMessage("§e이 장비는 플러그인 이관 중입니다. 재료는 차감하지 않았습니다.");return;}
        if(entry.get("throwable-kind") instanceof String kind){if(plugin.throwables.buy(player,kind))plugin.inventories.mode(player,true);return;}
        if("virtual-ammo".equals(entry.get("special-action"))){buyTaAmmo(player);return;}
        Set<String> owned = purchases.computeIfAbsent(game, g -> new HashMap<>()).computeIfAbsent(player.getUniqueId(), p -> new HashSet<>());
        String countPrefix="count:"+id+":";int bought=owned.stream().filter(s->s.startsWith(countPrefix)).mapToInt(s->Integer.parseInt(s.substring(countPrefix.length()))).max().orElse(0);
        if(integer(entry,"purchase-limit",0)>0&&bought>=integer(entry,"purchase-limit",0)){player.sendMessage("§c이번 경기의 구매 한도에 도달했습니다.");return;}
        if (Boolean.TRUE.equals(entry.get("one-time-purchase")) && owned.contains(id)) { player.sendMessage(ChatColor.RED + "이미 구매했습니다."); return; }
        Map<?, ?> group = entry.get("buy-group") instanceof Map<?, ?> value ? value : Map.of();
        String groupPrefix = "group:" + group.get("name") + ":";
        int groupLevel = integer(group, "level", 0);
        if (!group.isEmpty() && owned.stream().filter(s -> s.startsWith(groupPrefix)).anyMatch(s -> Integer.parseInt(s.substring(groupPrefix.length())) >= groupLevel)) {
            player.sendMessage(ChatColor.RED + "이미 같은 등급 이상의 장비가 있습니다."); return;
        }
        try {
            if(entry.get("tool") instanceof String tool&&toolTier(player,game,tool)>=4){player.sendMessage("§c이미 최대 등급입니다.");return;}
            entry=resolved(player,game,entry);
            String purchasedTool=entry.get("tool") instanceof String tool?tool:null;
            List<ItemStack> cost = costs(maps(entry.get("prices")),game);
            if (!plugin.wallet.affordable(player,cost)) { fail(player);player.sendMessage(ChatColor.RED + "재료가 부족합니다."); return; }
            Inventory simulation = plugin.wallet.purchaseInventory(player);
            if(purchasedTool!=null)for(int slot=0;slot<36;slot++)if(purchasedTool.equals(tool(simulation.getItem(slot))))simulation.setItem(slot,null);
            List<ItemStack> products = new ArrayList<>();
            Map<EquipmentSlot, ItemStack> armor = new EnumMap<>(EquipmentSlot.class);
            for (Map<?, ?> product : maps(entry.get("products"))) {
                ItemStack item = product(player, game, product);
                if(purchasedTool!=null)markTool(item,purchasedTool);
                if (Boolean.TRUE.equals(entry.get("unbreakable"))) {
                    var meta = item.getItemMeta(); meta.setUnbreakable(true); item.setItemMeta(meta);
                }
                if (Boolean.TRUE.equals(product.get("auto-wear"))) {
                    EquipmentSlot slot = item.getType().getEquipmentSlot();
                    if (Set.of(EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET).contains(slot)) armor.put(slot, item);
                    else throw new IllegalArgumentException("Invalid armor slot");
                } else {
                    if (!plugin.hotbar.place(player,simulation,item)) { player.sendMessage(ChatColor.RED + "인벤토리 공간이 부족합니다."); return; }
                }
                products.add(item);
            }
            if(plugin.aiRules!=null&&!plugin.aiRules.compact(player,simulation)){player.sendMessage("§c챌린지 보관 공간이 부족합니다.");return;}
            // All validation finishes before the first real inventory mutation.
            if (!plugin.wallet.pay(player,cost)) return;
            plugin.inventories.utility(player,simulation.getStorageContents());plugin.hotbar.changed(player);
            for (var piece : armor.entrySet()) player.getInventory().setItem(piece.getKey(), piece.getValue().clone());
            if(!armor.isEmpty())MatchVitals.armor(player,false);
            if (Boolean.TRUE.equals(entry.get("keep-on-death"))) {
                Map<String, ItemStack> saved = permanent(game, player.getUniqueId());
                if(purchasedTool!=null)saved.entrySet().removeIf(e->purchasedTool.equals(tool(e.getValue())));
                for (ItemStack item : products) saved.put(item.getType().name(), item.clone());
                if (!armor.isEmpty()) {
                    // Higher armor tiers replace the previous permanent leggings and boots.
                    saved.entrySet().removeIf(e -> e.getValue().getType().getEquipmentSlot() == EquipmentSlot.LEGS && !armor.containsValue(e.getValue())
                            || e.getValue().getType().getEquipmentSlot() == EquipmentSlot.FEET && !armor.containsValue(e.getValue()));
                    for (ItemStack item : armor.values()) saved.put(item.getType().name(), item.clone());
                }
            }
            if(plugin.learning!=null)plugin.learning.action(player,"buy:"+id);
            if(plugin.aiRules!=null)plugin.aiRules.bought(player,id);
            owned.add(id);
            owned.removeIf(s->s.startsWith(countPrefix));owned.add(countPrefix+(bought+1));
            if(purchasedTool!=null){owned.removeIf(s->s.startsWith("tool:"+purchasedTool+":"));owned.add("tool:"+purchasedTool+":"+integer(entry,"tool-tier",1));}
            if (!group.isEmpty()) { owned.removeIf(s -> s.startsWith(groupPrefix)); owned.add(groupPrefix + groupLevel); }
            applyTeamEffects(game, team);
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 2f);
            player.sendMessage(ChatColor.GREEN + "구매: " + translate((String) entry.get("name")));
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().warning("Purchase refused (no materials charged): " + entry.get("name") + ": " + ex.getMessage());
            player.sendMessage(ChatColor.RED + "이 아이템의 설정을 확인해야 합니다. 재료는 차감되지 않았습니다.");
        }
    }

    private ItemStack product(Player player, Game game, Map<?, ?> spec) {
        String id = (String) spec.get("special-id");
        String value = (String) spec.get("material");
        Material type = id == null ? material(value) : switch (id) {
            case "tower" -> Material.CHEST;
            case "Trap" -> Material.STONE_PRESSURE_PLATE;
            case "egg-bridger" -> Material.EGG;
            case "Bridge" -> Material.BLUE_DYE;
            case "MagicMilk" -> Material.MILK_BUCKET;
            case "Fireball" -> Material.FIRE_CHARGE;
            case "silverfish" -> Material.SNOWBALL;
            case "GuardDog" -> Material.IRON_GOLEM_SPAWN_EGG;
            case "TNTSheep" -> Material.SHEEP_SPAWN_EGG;
            case "FrostbiteArrow" -> Material.ARROW;
            default -> throw new IllegalArgumentException("Unknown special " + id);
        };
        if(plugin.aiRules!=null&&plugin.aiRules.rule(player)==AiChallenge.BRIDGING_FOR_DUMMIES&&type.name().endsWith("_WOOL"))type=Material.SPONGE;
        if (type == Material.BARRIER) throw new IllegalArgumentException("Unknown material " + value);
        ItemStack item = new ItemStack(type, integer(spec, "amount", 1));
        if (value != null && value.startsWith("potion:")) {
            String[] parts = value.split(":");
            String effect = parts[1].equals("jump") ? "jump_boost" : parts[1];
            var potion = PotionEffectType.getByKey(NamespacedKey.minecraft(effect));
            if (potion == null) throw new IllegalArgumentException("Unknown potion");
            var meta = (PotionMeta) item.getItemMeta();
            meta.setColor(potion.getColor());
            meta.addCustomEffect(new PotionEffect(potion, Integer.parseInt(parts[2]), Math.max(0, Integer.parseInt(parts[3]) - 1)), true);
            item.setItemMeta(meta);
        }
        if(spec.get("enchantments") instanceof Map<?,?> enchants)for(var enchant:enchants.entrySet()){var key=NamespacedKey.minecraft(enchant.getKey().toString());var valueEnchantment=org.bukkit.enchantments.Enchantment.getByKey(key);if(valueEnchantment==null)throw new IllegalArgumentException("Unknown enchantment "+key);item.addUnsafeEnchantment(valueEnchantment,((Number)enchant.getValue()).intValue());}
        if(spec.get("bow-damage") instanceof Number damage){var meta=item.getItemMeta();meta.getPersistentDataContainer().set(new NamespacedKey(plugin,"bow_damage"),PersistentDataType.DOUBLE,damage.doubleValue());item.setItemMeta(meta);}
        String property = id == null ? null : switch (id) {
            case "Trap" -> "Trap";
            case "Fireball" -> null;
            case "GuardDog" -> null;
            case "TNTSheep" -> "TNTSheep";
            default -> null;
        };
        if (property != null) {
            var event = new BedwarsApplyPropertyToBoughtItem(game, player, item, Map.of("name", property));
            Bukkit.getPluginManager().callEvent(event); item = event.getStack();
        } else if (id != null) {
            var meta = item.getItemMeta(); meta.getPersistentDataContainer().set(specialKey, PersistentDataType.STRING, id);
            meta.setDisplayName(ChatColor.YELLOW + id); item.setItemMeta(meta);
        }
        if (type == Material.WHITE_WOOL || type == Material.WHITE_TERRACOTTA || type == Material.GLASS) {
            String suffix=type==Material.WHITE_WOOL?"_WOOL":type==Material.WHITE_TERRACOTTA?"_TERRACOTTA":"_STAINED_GLASS";
            item.setType(Material.valueOf(TeamPalette.of(game,game.getTeamOfPlayer(player)).dye().name()+suffix));
        }
        if(plugin.mechanics!=null)plugin.mechanics.lore(item); return item;
    }

    private TeamState state(Game game, RunningTeam team) {
        return teamStates.computeIfAbsent(game, g -> new HashMap<>()).computeIfAbsent(team, t -> new TeamState());
    }

    private ConfigurationSection nextUpgrade(Game game, RunningTeam team, String name) {
        var definition = upgrades.get(name);
        if (definition == null) return null;
        if (definition.isConfigurationSection("repeatable-level")) return definition.getConfigurationSection("repeatable-level");
        var levels = definition.getConfigurationSection("levels");
        if (levels == null) return null;
        return levels.getConfigurationSection("lvl-" + (state(game, team).levels.getOrDefault(name, 0) + 1));
    }

    private void buyUpgrade(Player player, Game game, String name) {
        if(plugin.aiRules!=null&&!plugin.aiRules.upgrade(player,name))return;
        plugin.inventories.mode(player,false);
        RunningTeam team = game.getTeamOfPlayer(player);
        if (team == null) return;
        var level = nextUpgrade(game, team, name);
        if (level == null) return;
        var state = state(game, team);
        boolean trap = name.endsWith("trap");
        if (trap && state.traps.size() >= 3) { player.sendMessage(ChatColor.RED + "함정은 최대 3개입니다."); return; }
        int price = upgradePrice(game,team,name,level);
        var currency = api.getItemSpawnerTypeByName(level.getString("price.spawner", "diamond"));
        ItemStack payment = currency.getStack(price);
        if (!plugin.wallet.pay(player,List.of(payment))) { fail(player);player.sendMessage(ChatColor.RED + "재료가 부족합니다."); return; }
        if (trap) {state.traps.addLast(name);refreshTrapQueue(game,team);}
        else state.levels.merge(name, 1, Integer::sum);
        if (name.equals("spawner-multiplier")) for (var spawner : game.getItemSpawners()) {
            if (team.getName().equals(spawner.getTeam() == null ? null : spawner.getTeam().getName())
                    && Set.of(Material.IRON_INGOT,Material.GOLD_INGOT).contains(spawner.getItemSpawnerType().getMaterial())) spawner.setCurrentLevel(spawner.getStartLevel() * level.getDouble("amplifier", 1));
        }
        applyTeamEffects(game, team);
        player.playSound(player.getLocation(),Sound.BLOCK_NOTE_BLOCK_PLING,1,2);
        for (Player teammate : team.getConnectedPlayers()) teammate.sendMessage(ChatColor.GREEN + TeamPalette.display(player)+" 구매: "+upgradeName(name)+(trap?"":" "+state.levels.getOrDefault(name,0)+"티어"));
        open(player, true, 0);
    }

    int level(Game g,RunningTeam t,String key){return state(g,t).levels.getOrDefault(key,0);}
    int level(Player p,String key){Game g=api.getGameOfPlayer(p);RunningTeam t=g==null?null:g.getTeamOfPlayer(p);return t==null?0:state(g,t).levels.getOrDefault(key,0);}
    long milkRemaining(Player p){return Math.max(0,milkUntil.getOrDefault(p.getUniqueId(),0L)-System.currentTimeMillis());}
    private void applyTeamEffects(Game game, RunningTeam team) {
        TeamState state = state(game, team);
        int protection = state.levels.getOrDefault("protection", 0);
        int haste = state.levels.getOrDefault("haste", 0);
        for (Player player : team.getConnectedPlayers()) {
            ItemStack boots=player.getInventory().getBoots();if(boots!=null)boots.removeEnchantment(org.bukkit.enchantments.Enchantment.FEATHER_FALLING);
            if (protection > 0) for (ItemStack item : player.getInventory().getArmorContents()) {
                if (item == null || item.getType().isAir()) continue;
                var enchant = org.bukkit.enchantments.Enchantment.PROTECTION;
                if (item.getEnchantmentLevel(enchant) < protection) item.addUnsafeEnchantment(enchant, protection);
            }
            if (haste > 0) player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 60, haste - 1, false, false));
            if (state.levels.getOrDefault("heal-pool", 0) > 0 && player.getGameMode() != GameMode.SPECTATOR
                    && player.getLocation().distanceSquared(team.getTeamSpawn()) <= 400) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 60, 0, false, false));
            }
        }
    }

    private void tickTeams() {
        for (var gameEntry : teamStates.entrySet()) {
            Game game = gameEntry.getKey();
            if (game.getStatus() != GameStatus.RUNNING) continue;
            for (var teamEntry : gameEntry.getValue().entrySet()) {
                RunningTeam team = teamEntry.getKey(); TeamState state = teamEntry.getValue();
                applyTeamEffects(game, team);
                int forge=state.levels.getOrDefault("spawner-multiplier",0);
                if(forge>=3&&team.isAlive()){
                    int interval=Math.max(1,plugin.getConfig().getInt(forge>=4?"shop.molten-emerald-seconds":"shop.forge-emerald-seconds",forge>=4?36:65));
                    if(++state.forgeSeconds>=interval){state.forgeSeconds=0;Location at=game.getItemSpawners().stream().filter(s->s.getTeam()!=null&&s.getTeam().getName().equals(team.getName())&&s.getItemSpawnerType().getMaterial()==Material.IRON_INGOT).min(Comparator.comparingDouble(s->s.getLocation().distanceSquared(team.getTeamSpawn()))).map(s->s.getLocation().clone()).orElseGet(()->team.getTeamSpawn().clone());
                        long nearby=at.getWorld().getNearbyEntities(at,2,2,2).stream().filter(e->e instanceof org.bukkit.entity.Item item&&item.getItemStack().getType()==Material.EMERALD).mapToLong(e->((org.bukkit.entity.Item)e).getItemStack().getAmount()).sum();
                        if(nearby<2){for(int i=0;i<5&&!at.getBlock().isPassable();i++)at.add(0,1,0);at.add(0,.15,0);var item=at.getWorld().dropItem(at,api.getItemSpawnerTypeByName("emerald").getStack());item.setVelocity(new org.bukkit.util.Vector());item.setGravity(false);api.registerEntityToGame(item,game);}
                    }
                }
                if (state.traps.isEmpty() || System.currentTimeMillis() < state.nextTrap) continue;
                for (Player enemy : game.getConnectedPlayers()) {
                    if (enemy.getGameMode() == GameMode.SPECTATOR || game.getTeamOfPlayer(enemy) == null
                            || team.isPlayerInTeam(enemy) || milkUntil.getOrDefault(enemy.getUniqueId(), 0L) > System.currentTimeMillis()) continue;
                    if (enemy.getLocation().distanceSquared(team.getTargetBlock()) > 64) continue;
                    String trap = state.traps.removeFirst(); state.nextTrap = System.currentTimeMillis() + 15000;refreshTrapQueue(game,team);
                    switch (trap) {
                        case "regular-trap" -> {
                            enemy.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 160, 0));
                            enemy.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 160, 0));
                        }
                        case "mining-fatigue-trap" -> enemy.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 200, 0));
                        case "alarm-trap" -> enemy.removePotionEffect(PotionEffectType.INVISIBILITY);
                        case "counter-offensive-trap" -> {
                            for (Player defender : team.getConnectedPlayers()) {
                                if(defender.getGameMode()==GameMode.SPECTATOR||defender.getLocation().distanceSquared(team.getTargetBlock())>400)continue;
                                defender.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 0));
                                defender.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 200, 1));
                            }
                        }
                        default -> { }
                    }
                    for (Player defender : team.getConnectedPlayers()){defender.sendMessage(ChatColor.RED+"함정 발동! "+upgradeName(trap)+" · "+TeamPalette.display(enemy));defender.sendTitle("§c함정 발동!","§f"+upgradeName(trap),5,45,10);defender.playSound(defender.getLocation(),Sound.ENTITY_ENDERMAN_TELEPORT,1,.6f);if(trap.equals("alarm-trap"))for(int n=0;n<10;n++){int tone=n;Bukkit.getScheduler().runTaskLater(plugin,()->{if(defender.isOnline()&&api.getGameOfPlayer(defender)==game)defender.playSound(defender.getLocation(),Sound.BLOCK_NOTE_BLOCK_PLING,1.5f,tone%2==0?1.8f:.8f);},n*4L);}}
                    break;
                }
            }
        }
    }

    @EventHandler public void onRespawn(BedwarsPlayerRespawnedIngameEvent event) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (api.getGameOfPlayer(event.getPlayer()) != event.getGame()) return;
            for (ItemStack item : permanent(event.getGame(), event.getPlayer().getUniqueId()).values()) {
                EquipmentSlot slot = item.getType().getEquipmentSlot();
                if (Set.of(EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET).contains(slot)) event.getPlayer().getInventory().setItem(slot, item.clone());
                else if(Arrays.stream(plugin.inventories.utility(event.getPlayer())).noneMatch(existing->plugin.stacks.same(existing,item)&&plugin.stacks.count(existing)>=plugin.stacks.count(item))){Inventory sim=Bukkit.createInventory(null,36);sim.setStorageContents(plugin.inventories.utility(event.getPlayer()));if(plugin.hotbar.place(event.getPlayer(),sim,item))plugin.inventories.utility(event.getPlayer(),sim.getStorageContents());}
            }
            applyTeamEffects(event.getGame(), event.getTeam());
            MatchVitals.armor(event.getPlayer(),true);
        });
    }

    @EventHandler(priority=EventPriority.LOWEST)public void onStart(BedwarsGameStartedEvent event){towers.cancel(event.getGame());permanent.remove(event.getGame());purchases.remove(event.getGame());teamStates.remove(event.getGame());}
    @EventHandler public void disabled(BedWarsGameDisabledEvent event){towers.cancel(event.getGame());permanent.remove(event.getGame());purchases.remove(event.getGame());teamStates.remove(event.getGame());}
    @EventHandler public void onEnd(BedwarsGameEndEvent event) {
        towers.cancel(event.getGame());
        LegacyActions.clear(event.getGame());
        for (Player player : event.getGame().getConnectedPlayers()) milkUntil.remove(player.getUniqueId());
        permanent.remove(event.getGame()); purchases.remove(event.getGame()); teamStates.remove(event.getGame());
    }

    @EventHandler(priority=EventPriority.LOW,ignoreCancelled=true)
    public void retainedDrops(org.bukkit.event.entity.PlayerDeathEvent event){Player player=event.getEntity();Game game=api.getGameOfPlayer(player);if(game==null||game.getStatus()!=GameStatus.RUNNING||game.getTeamOfPlayer(player)==null)return;Set<Material> retained=new HashSet<>();for(ItemStack item:permanent(game,player.getUniqueId()).values())retained.add(item.getType());event.getDrops().removeIf(item->retained.contains(item.getType())||tool(item)!=null||Set.of(EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET).contains(item.getType().getEquipmentSlot()));}

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onKilled(BedwarsPlayerKilledEvent event) {
        Set<Material> retained = new HashSet<>();
        for (ItemStack item : permanent(event.getGame(), event.getPlayer().getUniqueId()).values()) retained.add(item.getType());
        event.getDrops().removeIf(item -> !ResourceWallet.TYPES.contains(item.getType()));
        for(String kind:List.of("axe","pickaxe")){int tier=toolTier(event.getPlayer(),event.getGame(),kind);if(tier==0)continue;int lower=Math.max(1,tier-1);Map<?,?> definition=entries().stream().map(Entry::item).filter(e->kind.equals(e.get("tool"))).findFirst().orElse(null);if(definition==null)continue;var level=maps(definition.get("tiers")).get(lower-1);ItemStack item=product(event.getPlayer(),event.getGame(),maps(level.get("products")).get(0));var meta=item.getItemMeta();meta.setUnbreakable(true);item.setItemMeta(meta);markTool(item,kind);var saved=permanent(event.getGame(),event.getPlayer().getUniqueId());saved.entrySet().removeIf(e->kind.equals(tool(e.getValue())));saved.put(item.getType().name(),item);var owned=purchases.get(event.getGame()).get(event.getPlayer().getUniqueId());owned.removeIf(s->s.startsWith("tool:"+kind+":"));owned.add("tool:"+kind+":"+lower);}
    }

    private String special(ItemStack item) {
        return item == null || !item.hasItemMeta() ? null : item.getItemMeta().getPersistentDataContainer().get(specialKey, PersistentDataType.STRING);
    }

    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void bowShot(org.bukkit.event.entity.EntityShootBowEvent e){if(e.getBow()==null||!e.getBow().hasItemMeta())return;var key=new NamespacedKey(plugin,"bow_damage");Double amount=e.getBow().getItemMeta().getPersistentDataContainer().get(key,PersistentDataType.DOUBLE);if(amount!=null)e.getProjectile().getPersistentDataContainer().set(key,PersistentDataType.DOUBLE,amount);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void frostShot(org.bukkit.event.entity.EntityShootBowEvent e){if(!(e.getEntity() instanceof Player player)||api.getGameOfPlayer(player)==null)return;for(int slot=0;slot<36;slot++){ItemStack arrow=player.getInventory().getItem(slot);if(!"FrostbiteArrow".equals(special(arrow)))continue;e.setConsumeItem(false);if(player.getGameMode()!=GameMode.CREATIVE)plugin.stacks.consume(arrow,1);e.getProjectile().getPersistentDataContainer().set(specialKey,PersistentDataType.STRING,"FrostbiteArrow");break;}}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void frostHit(org.bukkit.event.entity.EntityDamageByEntityEvent e){if(e.getEntity() instanceof Player player&&e.getDamager().getPersistentDataContainer().getOrDefault(specialKey,PersistentDataType.STRING,"").equals("FrostbiteArrow")&&e.getFinalDamage()>0)player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,60,0));}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void bowDamage(org.bukkit.event.entity.EntityDamageByEntityEvent e){if(!(e.getDamager() instanceof AbstractArrow arrow)||!(arrow.getShooter() instanceof Player player))return;Game game=api.getGameOfPlayer(player);if(game==null||game.getStatus()!=GameStatus.RUNNING)return;Double amount=arrow.getPersistentDataContainer().get(new NamespacedKey(plugin,"bow_damage"),PersistentDataType.DOUBLE);boolean punch=arrow.getKnockbackStrength()>0;e.setDamage(plugin.damages.value(punch?"items.bow.punch":amount!=null&&amount>=8000?"items.bow.power":"items.bow.normal",amount!=null&&amount>=8000?6000:4500));}
    @EventHandler(priority=EventPriority.HIGH,ignoreCancelled=true)
    public void glassExplosion(org.bukkit.event.entity.EntityExplodeEvent e){e.blockList().removeIf(b->b.getType()==Material.GLASS||b.getType().name().endsWith("_STAINED_GLASS"));}

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND || !event.getAction().isRightClick()) return;
        String id = special(event.getItem());
        if (id == null || id.equals("MagicMilk") || id.equals("FrostbiteArrow") || plugin.inventories.locked(event.getPlayer())) return;
        Player player = event.getPlayer(); Game game = api.getGameOfPlayer(player);
        if (game == null || game.getStatus() != GameStatus.RUNNING || game.getTeamOfPlayer(player) == null || player.getGameMode() == GameMode.SPECTATOR) return;
        event.setCancelled(true);
        if (id.equals("tower") || id.equals("Bridge")) {
            if (event.getClickedBlock() == null) return;
            Location origin = event.getClickedBlock().getRelative(event.getBlockFace()).getLocation();
            if (id.equals("tower")) {
                if(!towers.start(player,game,event.getClickedBlock(),event.getBlockFace()))return;
            } else {
                var forward = player.getLocation().getDirection().setY(0).normalize();
                for (int i = 0; i < 32; i++) build(game, player, origin.clone().add(forward.clone().multiply(i)));
            }
        } else if(id.equals("Fireball")){plugin.explosions.fireball(player,game);
        } else if(id.equals("GuardDog")){if(event.getClickedBlock()==null)return;plugin.summons.spawn(player,game,event.getClickedBlock().getRelative(event.getBlockFace()).getLocation().add(.5,0,.5),true);
        } else {
            Projectile projectile = id.equals("egg-bridger") ? player.launchProjectile(Egg.class) : player.launchProjectile(Snowball.class);
            projectile.getPersistentDataContainer().set(specialKey, PersistentDataType.STRING, id);
            if (id.equals("egg-bridger")) new BukkitRunnable() {
                int ticks;Location previous=projectile.getLocation();
                public void run() {
                    if (ticks++ > 160 || game.getStatus() != GameStatus.RUNNING) { cancel(); return; }
                    Location current=projectile.getLocation();Vector segment=current.toVector().subtract(previous.toVector());double length=segment.length();
                    for(double distance=0;distance<=length;distance+=.35)build(game,player,previous.clone().add(length<.001?new Vector():segment.clone().multiply(distance/length)).subtract(0,2,0));
                    build(game,player,current.clone().subtract(0,2,0));previous=current;
                    if(!projectile.isValid())cancel();
                }
            }.runTaskTimer(plugin, 1, 1);
        }
        plugin.stacks.consume(event.getItem(),1);
    }

    private boolean allowedTowerBuild(Game game,Location location) {
        Location lo=game.getPos1(),hi=game.getPos2();
        // The old add-on skipped occupied blocks rather than excluding every
        // air block within three blocks of a bed. PopupTower already preserves
        // beds/terrain, so the bridge-only bed-radius rule must not cut holes.
        return location.getWorld().equals(game.getGameWorld())&&location.getY()>=location.getWorld().getMinHeight()&&location.getY()<location.getWorld().getMaxHeight()
                &&location.getX()>=Math.min(lo.getX(),hi.getX())&&location.getX()<=Math.max(lo.getX(),hi.getX())
                &&location.getY()>=Math.min(lo.getY(),hi.getY())&&location.getY()<=Math.max(lo.getY(),hi.getY())
                &&location.getZ()>=Math.min(lo.getZ(),hi.getZ())&&location.getZ()<=Math.max(lo.getZ(),hi.getZ());
    }
    private boolean allowedBuild(Game game,Location location) {
        Location lo=game.getPos1(),hi=game.getPos2();if(!location.getWorld().equals(game.getGameWorld())||location.getX()<Math.min(lo.getX(),hi.getX())||location.getX()>Math.max(lo.getX(),hi.getX())||location.getY()<Math.min(lo.getY(),hi.getY())||location.getY()>Math.max(lo.getY(),hi.getY())||location.getZ()<Math.min(lo.getZ(),hi.getZ())||location.getZ()>Math.max(lo.getZ(),hi.getZ()))return false;return true;
    }
    private void build(Game game, Player player, Location location) {
        Location lo = game.getPos1(), hi = game.getPos2();
        if (!location.getWorld().equals(game.getGameWorld()) || location.getX() < Math.min(lo.getX(), hi.getX()) || location.getX() > Math.max(lo.getX(), hi.getX())
                || location.getY() < Math.min(lo.getY(), hi.getY()) || location.getY() > Math.max(lo.getY(), hi.getY())
                || location.getZ() < Math.min(lo.getZ(), hi.getZ()) || location.getZ() > Math.max(lo.getZ(), hi.getZ())) return;
        Block block = location.getBlock();
        if (!block.getType().isAir() || !plugin.volumes.allow(game,block.getLocation(),player)) return;
        var team = game.getTeamOfPlayer(player);
        if (team == null) return;
        Material wool = Material.matchMaterial(TeamPalette.of(game,team).dye().name() + "_WOOL");
        game.getRegion().addBuiltDuringGame(block.getLocation());
        block.setType(wool == null ? Material.WHITE_WOOL : wool, false);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMilk(PlayerItemConsumeEvent event) {
        if (!"MagicMilk".equals(special(event.getItem()))) return;
        Game game = api.getGameOfPlayer(event.getPlayer());
        if (game == null || game.getStatus() != GameStatus.RUNNING || event.getPlayer().getGameMode() == GameMode.SPECTATOR) return;
        milkUntil.put(event.getPlayer().getUniqueId(), System.currentTimeMillis() + 30000);
    }

    @EventHandler(ignoreCancelled=true) public void onHit(ProjectileHitEvent event) {
        if (!"silverfish".equals(event.getEntity().getPersistentDataContainer().get(specialKey, PersistentDataType.STRING))) return;
        if (!(event.getEntity().getShooter() instanceof Player owner)) return;
        Game game = api.getGameOfPlayer(owner);
        if (game == null || game.getStatus() != GameStatus.RUNNING || game.getTeamOfPlayer(owner) == null) return;
        for(int i=0;i<3;i++)plugin.summons.spawn(owner,game,event.getEntity().getLocation(),false);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTarget(EntityTargetLivingEntityEvent event) {
        String owner = event.getEntity().getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        if (owner == null || !(event.getTarget() instanceof Player target)) return;
        Player player = Bukkit.getPlayer(UUID.fromString(owner));
        Game game = player == null ? null : api.getGameOfPlayer(player);
        if (game == null || game.getTeamOfPlayer(player) == null || game.getTeamOfPlayer(player).isPlayerInTeam(target)) event.setCancelled(true);
    }
}
