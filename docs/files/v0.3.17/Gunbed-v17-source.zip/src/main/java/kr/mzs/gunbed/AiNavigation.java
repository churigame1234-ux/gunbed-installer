package kr.mzs.gunbed;
import org.bukkit.*;
import org.screamingsandals.bedwars.api.game.Game;
import java.util.*;

/** Bounded ground A*: planned bridge cells still require actual block placement. */
final class AiNavigation {
    record Cell(int x,int y,int z){Location at(World w){return new Location(w,x+.5,y,z+.5);}Cell offset(int x,int y,int z){return new Cell(this.x+x,this.y+y,this.z+z);}}
    private record Node(Cell cell,double g,double f){}
    static List<Location> path(Game game,Location from,Location target,boolean bridge,boolean jump,AiLearning learning,org.bukkit.entity.Player bot){
        World world=from.getWorld();Cell start=new Cell(from.getBlockX(),(int)Math.ceil(from.getY()-.05),from.getBlockZ());
        // A sneaking player can stand with their centre over the next air block.
        // Start at the block supporting the player's actual body, otherwise A*
        // omits the unbuilt block under that centre and deadlocks one cell later.
        if(!world.getBlockAt(start.x,start.y-1,start.z).getType().isSolid()){
            Cell supported=null;double nearest=Double.MAX_VALUE;var body=bot.getBoundingBox();
            for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++){Cell c=start.offset(dx,0,dz);var floor=world.getBlockAt(c.x,c.y-1,c.z);if(!floor.getType().isSolid()||body.getMaxX()<=c.x||body.getMinX()>=c.x+1||body.getMaxZ()<=c.z||body.getMinZ()>=c.z+1)continue;double distance=c.at(world).distanceSquared(from);if(distance<nearest){supported=c;nearest=distance;}}
            if(supported!=null)start=supported;
        }
        PriorityQueue<Node> open=new PriorityQueue<>(Comparator.comparingDouble(Node::f));Map<Cell,Cell> parent=new HashMap<>();Map<Cell,Double> score=new HashMap<>();open.add(new Node(start,0,0));score.put(start,0.0);Cell best=start;double distance=metric(start,target);int budget=3000;long deadline=System.nanoTime()+2_000_000;
        while(!open.isEmpty()&&budget-->0){if((budget&31)==0&&System.nanoTime()>deadline)break;Node node=open.poll();Cell c=node.cell;if(node.g>score.getOrDefault(c,Double.MAX_VALUE))continue;double remaining=metric(c,target);if(remaining<distance){best=c;distance=remaining;}if(remaining<.6)break;
            for(int[] delta:new int[][]{{1,0},{-1,0},{0,1},{0,-1}})for(int dy:new int[]{0,1,-1}){
                Cell next=c.offset(delta[0],dy,delta[1]);if(next.y<39||next.y>65||!world.isChunkLoaded(next.x>>4,next.z>>4)||!game.isLocationInArena(next.at(world)))continue;
                var feet=world.getBlockAt(next.x,next.y,next.z);if(!feet.isPassable()||!feet.getRelative(0,1,0).isPassable())continue;boolean ground=world.getBlockAt(next.x,next.y-1,next.z).getType().isSolid();
                if(!ground&&(!bridge||next.y!=start.y||dy!=0))continue;if(dy>0&&!world.getBlockAt(c.x,c.y+2,c.z).isPassable())continue;
                double cost=node.g-(learning==null?0:learning.edgeScore(game,bot,c.at(world),next.at(world)))+(ground?1:3.5)+(dy==0?0:.25)-(learning==null?0:learning.routeScore(game,bot,next.at(world)));if(cost>=score.getOrDefault(next,Double.MAX_VALUE))continue;
                score.put(next,cost);parent.put(next,c);open.add(new Node(next,cost,cost+metric(next,target)));break;
            }
            if(jump)for(int[] delta:new int[][]{{2,0},{-2,0},{0,2},{0,-2},{3,0},{-3,0},{0,3},{0,-3}}){Cell next=c.offset(delta[0],0,delta[1]);if(!world.isChunkLoaded(next.x>>4,next.z>>4)||!game.isLocationInArena(next.at(world))||!world.getBlockAt(next.x,next.y-1,next.z).getType().isSolid()||!world.getBlockAt(next.x,next.y,next.z).isPassable()||!world.getBlockAt(next.x,next.y+1,next.z).isPassable())continue;var fromEye=c.at(world).add(0,1.5,0);var direction=next.at(world).add(0,1.5,0).toVector().subtract(fromEye.toVector());if(world.rayTraceBlocks(fromEye,direction,direction.length(),FluidCollisionMode.NEVER,true)!=null)continue;double cost=node.g+Math.abs(delta[0])+Math.abs(delta[1])+1.2;if(cost>=score.getOrDefault(next,Double.MAX_VALUE))continue;score.put(next,cost);parent.put(next,c);open.add(new Node(next,cost,cost+metric(next,target)));}
        }
        LinkedList<Location> result=new LinkedList<>();for(Cell c=best;!c.equals(start);c=parent.get(c)){if(c==null)return List.of();result.addFirst(c.at(world));}return result;
    }
    private static double metric(Cell c,Location at){return Math.abs(c.x+.5-at.getX())+Math.abs(c.z+.5-at.getZ())+Math.abs(c.y-at.getY())*.5;}
}
