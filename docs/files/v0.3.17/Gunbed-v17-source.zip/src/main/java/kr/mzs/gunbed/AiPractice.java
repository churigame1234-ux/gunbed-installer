package kr.mzs.gunbed;

import kr.mzs.botcore.api.MzsBot;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.generator.ChunkGenerator;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.*;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/** One shared, isolated Orchestra room. All admission decisions run on the server thread. */
final class AiPractice implements Listener,AutoCloseable {
    enum Difficulty {EASY("쉬움",10,4.0,8),MEDIUM("중간",6,2.0,5),HARD("어려움",3,.8,3);final String title;final int reaction,build;final double error;Difficulty(String t,int r,double e,int b){title=t;reaction=r;error=e;build=b;}}
    static final class Room {
        Game game; Difficulty difficulty; AiChallenge challenge; UUID host;
        final List<MzsBot> bots=new ArrayList<>();final Set<UUID> enrolled=new LinkedHashSet<>();
        boolean syncing,closing;int initialHumans;long emptySince;
        Room(Difficulty d,AiChallenge c){difficulty=d;challenge=c;}
    }
    private record Menu(String kind,Difficulty difficulty) implements InventoryHolder{public Inventory getInventory(){throw new UnsupportedOperationException();}}
    private final GunbedCore plugin;private final BotRuntime runtime;
    private final Map<Game,Room> games=new HashMap<>();
    private final Set<UUID> admitted=new HashSet<>(),configuring=new LinkedHashSet<>(),queued=new LinkedHashSet<>();
    private final AtomicInteger sequence=new AtomicInteger();
    private final AiBrain brain;private final org.bukkit.scheduler.BukkitTask ticker;
    private Room active,shared;private boolean loading,closed;private UUID claim;
    AiPractice(GunbedCore p){plugin=p;runtime=new BotRuntime();brain=new AiBrain(p,runtime);Bukkit.getPluginManager().registerEvents(this,p);ticker=Bukkit.getScheduler().runTaskTimer(p,this::tick,2,2);}
    static boolean arena(Game g){return g!=null&&g.getName().startsWith("AI_Orchestra_");}
    Room room(Game g){return games.get(g);}
    Room room(Player p){return room(BedwarsAPI.getInstance().getGameOfPlayer(p));}
    List<Player> humans(Room r){return r.game.getConnectedPlayers().stream().filter(p->!BotRuntime.bot(p)&&(r.game.getStatus()==GameStatus.WAITING||r.enrolled.contains(p.getUniqueId()))).toList();}
    private ItemStack icon(Material material,String name,String...lore){ItemStack i=new ItemStack(material);var m=i.getItemMeta();m.setDisplayName(name);m.setLore(List.of(lore));i.setItemMeta(m);return i;}
    void maps(Player p){if(BedwarsAPI.getInstance().getGameOfPlayer(p)!=null){p.sendMessage("§e현재 경기를 나간 뒤 참가하세요.");return;}Inventory inv=Bukkit.createInventory(new Menu("maps",null),27,"AI 유저와 플레이 · 맵");String status=loading?"§e경기장 준비 중 · 클릭하여 함께 참가":active==null?"§a빈 경기장 · 클릭하여 모드 설정":active.closing||plugin.restores.busy(active.game)?"§7복구 중":active.game.getStatus()==GameStatus.WAITING?"§e대기 중 · 클릭하여 참가":"§c경기 중 · 클릭하여 관전";inv.setItem(13,icon(Material.JUKEBOX,"§aOrchestra",status,"§7사람 1~8명 vs 같은 수의 AI","§7일반: 중간 · 챌린지: 어려움","§7검증 완료 학습 경기: "+plugin.learning.episodes()));p.openInventory(inv);}
    private void modes(Player p){if(existing(p))return;configuring.add(p.getUniqueId());Inventory inv=Bukkit.createInventory(new Menu("mode",null),27,"Orchestra · 모드 선택");inv.setItem(11,icon(Material.IRON_SWORD,"§a일반 모드","§7중간 난이도 · 추가 제한 없음","§e클릭하면 방 생성 확정"));inv.setItem(15,icon(Material.NETHER_STAR,"§c챌린지 모드","§7어려움 난이도 · 방장 해금 목록","§e클릭하여 챌린지 선택"));p.openInventory(inv);}
    private boolean existing(Player p){if(loading){queued.add(p.getUniqueId());configuring.remove(p.getUniqueId());p.closeInventory();p.sendMessage("§e확정된 방을 준비하고 있습니다. 준비되면 자동 참가합니다.");return true;}if(active!=null){join(p,active);return true;}return false;}
    private AiChallengeProgress progress(UUID id){return new AiChallengeProgress(plugin.profiles.get(id).getStringList("ai-challenges.completed"));}
    private Set<String> completed(Player p){return new HashSet<>(progress(p.getUniqueId()).saved());}
    /** Called only by the validated challenge result handler, never on joining or selecting. */
    void recordCompletion(UUID id,AiChallenge challenge){
        AiChallengeProgress before=progress(id),after=before.withCompletion(challenge);
        if(before==after)return;
        plugin.profiles.set(id,"ai-challenges.completed",after.saved());
        plugin.profiles.flush();
    }
    void challenges(Player p,Difficulty ignored){
        if(existing(p))return;configuring.add(p.getUniqueId());
        Inventory inv=Bukkit.createInventory(new Menu("challenge",Difficulty.HARD),54,"어려움 · 챌린지 선택");
        AiChallengeProgress progress=progress(p.getUniqueId());
        for(AiChallenge c:AiChallenge.values()){
            if(c==AiChallenge.NONE)continue;
            boolean open=progress.canSelect(c),done=progress.completed(c);
            inv.setItem(c.ordinal(),icon(done?Material.EMERALD:open?Material.PAPER:Material.BARRIER,
                (open?"§e":"§c")+c.title,"§7"+c.description,
                done?"§a완료 · 다시 도전 가능":open?"§a클릭하면 방 생성 확정":"§c앞선 챌린지를 완료해야 직접 선택 가능",
                "§7동행자는 미해금이어도 참가 가능","§7완료한 단계만 기록 · 앞 단계는 자동 해금 안 됨"));
        }inv.setItem(49,icon(Material.ARROW,"§e모드 선택으로"));p.openInventory(inv);
    }
    void enter(Player p,Difficulty difficulty,AiChallenge challenge){
        if(BedwarsAPI.getInstance().getGameOfPlayer(p)!=null)return;
        if(existing(p))return;
        if(!challenge.unlocked(completed(p))){p.sendMessage("§c아직 직접 선택할 수 없는 챌린지입니다.");return;}
        // The first final selection claims the only room before asynchronous copying starts.
        claim=p.getUniqueId();loading=true;queued.add(claim);queued.addAll(configuring);configuring.clear();
        for(UUID id:queued){Player other=Bukkit.getPlayer(id);if(other!=null){other.closeInventory();other.sendMessage("§b"+p.getName()+"님이 AI방 설정을 확정했습니다. 함께 입장합니다.");}}
        Difficulty chosen=challenge==AiChallenge.NONE?Difficulty.MEDIUM:Difficulty.HARD;
        if(shared!=null){finishLoad(shared,chosen,challenge,claim);return;}
        UUID owner=claim;Path template=plugin.getDataFolder().toPath().resolve("ai-template");
        Path container=Bukkit.getWorldContainer().toPath().toAbsolutePath().normalize();Path destination=container.resolve("gunbed_ai_shared");
        Bukkit.getScheduler().runTaskAsynchronously(plugin,()->{try{
            if(!Files.isRegularFile(template.resolve("manifest.json")))throw new IOException("AI template missing");
            if(!destination.normalize().getParent().equals(container))throw new IOException("Unsafe world path");
            if(!Files.exists(destination)){Files.createDirectories(destination);try(var walk=Files.walk(template)){for(Path from:walk.filter(Files::isRegularFile).toList()){Path relative=template.relativize(from);if(Set.of("arena.yml","manifest.json").contains(relative.toString()))continue;Path to=destination.resolve(relative);Files.createDirectories(to.getParent());Files.copy(from,to);}}Files.writeString(destination.resolve(".gunbed-ai-world"),"Orchestra_8");}
            else if(!Files.isRegularFile(destination.resolve(".gunbed-ai-world")))throw new IOException("Unmanaged AI world folder");
            Bukkit.getScheduler().runTask(plugin,()->{if(closed)return;try{if(shared==null)shared=load(destination);finishLoad(shared,chosen,challenge,owner);}catch(Exception e){failed(e);}});
        }catch(IOException e){Bukkit.getScheduler().runTask(plugin,()->failed(e));}});
    }
    private void failed(Exception e){loading=false;claim=null;for(UUID id:queued){Player p=Bukkit.getPlayer(id);if(p!=null)p.sendMessage("§cAI 경기장 준비에 실패했습니다. 포인트·기존 경기장은 변경되지 않았습니다.");}queued.clear();plugin.getLogger().log(java.util.logging.Level.SEVERE,"AI arena load failed",e);}
    private Room load(Path destination)throws IOException{
        World w=Bukkit.getWorld(destination.getFileName().toString());
        if(w==null)w=Bukkit.createWorld(new WorldCreator(destination.getFileName().toString()).generator(new ChunkGenerator(){@Override public ChunkData generateChunkData(World world,Random random,int x,int z,BiomeGrid biomes){return createChunkData(world);}}));
        if(w==null)throw new IOException("AI world load failed");
        w.setAutoSave(true);w.setGameRule(GameRule.DO_MOB_SPAWNING,false);w.setGameRule(GameRule.DO_DAYLIGHT_CYCLE,false);w.setGameRule(GameRule.DO_WEATHER_CYCLE,false);w.setGameRule(GameRule.KEEP_INVENTORY,true);w.setTime(6000);
        var cfg=YamlConfiguration.loadConfiguration(plugin.getDataFolder().toPath().resolve("ai-template/arena.yml").toFile());cfg.set("constant.join-randomly-on-lobby-join","false");cfg.set("name","AI_Orchestra_Shared");cfg.set("world",w.getName());cfg.set("lobbySpawnWorld",w.getName());
        for(String team:cfg.getConfigurationSection("teams").getKeys(false))cfg.set("teams."+team+".maxPlayers",8);
        Path file=plugin.getDataFolder().toPath().resolve("ai-arenas/shared.yml");Files.createDirectories(file.getParent());cfg.save(file.toFile());
        Game g=org.screamingsandals.bedwars.game.Game.loadGame(file.toFile());if(g==null)throw new IOException("AI game definition load failed");waitingCage(g);((org.screamingsandals.bedwars.game.Game)g).setSpectatorJoin(InGameConfigBooleanConstants.TRUE);((org.screamingsandals.bedwars.game.Game)g).setJoinRandomTeamOnJoin(InGameConfigBooleanConstants.FALSE);Room r=new Room(Difficulty.MEDIUM,AiChallenge.NONE);r.game=g;games.put(g,r);plugin.restores.recover();return r;
    }
    private void waitingCage(Game game){
        // Permanent lobby-only shell, far above the combat map. A roof prevents double-jump escapes.
        var centre=game.getLobbySpawn().getBlock();
        for(int x=-8;x<=8;x++)for(int z=-8;z<=8;z++)for(int y=-1;y<=5;y++){
            if(y!=-1&&y!=5&&Math.abs(x)!=8&&Math.abs(z)!=8)continue;
            var block=centre.getRelative(x,y,z);if(block.isEmpty())block.setType(Material.BARRIER,false);
        }
    }
    private void finishLoad(Room r,Difficulty d,AiChallenge c,UUID owner){
        loading=false;claim=null;Player host=Bukkit.getPlayer(owner);
        if(host==null||BedwarsAPI.getInstance().getGameOfPlayer(host)!=null){queued.clear();return;}
        if(r.game.getStatus()!=GameStatus.WAITING||plugin.restores.busy(r.game)){queued.clear();host.sendMessage("§e경기장 복구가 끝난 뒤 다시 선택하세요.");return;}
        r.difficulty=d;r.challenge=c;r.host=owner;r.closing=false;r.initialHumans=0;r.enrolled.clear();active=r;
        List<UUID> waiting=new ArrayList<>(queued);queued.clear();join(host,r);
        if(!r.enrolled.contains(owner)){cancel(r,"§e방장 입장 실패로 AI방이 취소됐습니다.");return;}
        for(UUID id:waiting)if(!id.equals(owner)){Player other=Bukkit.getPlayer(id);if(other!=null)join(other,r);}
    }
    private void join(Player p,Room r){
        if(BedwarsAPI.getInstance().getGameOfPlayer(p)!=null)return;
        configuring.remove(p.getUniqueId());
        if(r.closing||plugin.restores.busy(r.game)){p.sendMessage("§eAI 경기장을 복구 중입니다.");return;}
        boolean spectate=r.game.getStatus()==GameStatus.RUNNING;
        if(!spectate&&r.game.getStatus()!=GameStatus.WAITING){p.sendMessage("§e경기 종료 처리 중입니다.");return;}
        if(!spectate&&humans(r).size()>=8){p.sendMessage("§c사람 팀 8명이 모두 찼습니다.");return;}
        admitted.add(p.getUniqueId());try{r.game.joinToGame(p);}finally{admitted.remove(p.getUniqueId());}
        if(BedwarsAPI.getInstance().getGameOfPlayer(p)==r.game&&!spectate){r.enrolled.add(p.getUniqueId());plugin.waiting.fixed(p,r.game.getTeamFromName("red"));p.sendMessage("§b"+r.difficulty.title+" · "+r.challenge.title+" · 사람 vs AI · 모두 준비하면 시작합니다.");}
    }
    boolean canStart(Game g){Room r=room(g);return r!=null&&active==r&&!r.closing&&!r.syncing&&!humans(r).isEmpty()&&humans(r).size()<=8&&humans(r).size()==r.bots.size();}
    boolean assign(Game g){Room r=room(g);if(!canStart(g))return false;for(Player p:g.getConnectedPlayers())plugin.waiting.fixed(p,g.getTeamFromName(BotRuntime.bot(p)?"light_blue":"red"));return true;}
    private void removeBots(Room r){for(MzsBot b:List.copyOf(r.bots)){brain.remove(b);runtime.remove(b);}r.bots.clear();}
    void prepareReset(Game game){Room r=room(game);if(r!=null){r.closing=true;removeBots(r);}}
    private void cancel(Room r,String message){if(r.closing)return;r.closing=true;for(Player p:humans(r))p.sendMessage(message);removeBots(r);for(Player p:List.copyOf(r.game.getConnectedPlayers())){r.game.leaveFromGame(p);ResetLobbyReturn.finish(plugin,p);}r.enrolled.clear();r.host=null;active=null;r.closing=false;}
    private void sync(Room r){
        if(r.closing||r.game.getStatus()!=GameStatus.WAITING||active!=r)return;
        r.bots.removeIf(b->{if(b.getPlayer().isOnline())return false;brain.remove(b);runtime.remove(b);return true;});int wanted=Math.min(8,humans(r).size());
        if(r.bots.size()>wanted){MzsBot b=r.bots.removeLast();brain.remove(b);runtime.remove(b);return;}
        if(r.bots.size()<wanted){r.syncing=true;try{MzsBot b=runtime.spawn(r.game.getLobbySpawn(),"GB_AI_"+sequence.incrementAndGet());r.bots.add(b);r.game.joinToGame(b.getPlayer());plugin.waiting.fixed(b.getPlayer(),r.game.getTeamFromName("light_blue"));brain.add(r,b,r.bots.size()-1);}catch(Exception error){plugin.getLogger().log(java.util.logging.Level.SEVERE,"AI bot spawn failed",error);cancel(r,"§cAI 생성에 실패하여 방이 취소됐습니다.");}finally{r.syncing=false;}}
        for(Player p:humans(r))plugin.waiting.fixed(p,r.game.getTeamFromName("red"));
    }
    private void tick(){if(active!=null){Room r=active;if(r.game.getStatus()==GameStatus.WAITING){if(r.closing){if(r.game.getConnectedPlayers().isEmpty()&&!plugin.restores.busy(r.game)){active=null;r.closing=false;r.host=null;}}else sync(r);}else if(r.game.getStatus()==GameStatus.RUNNING){if(r.game.getConnectedPlayers().stream().noneMatch(p->!BotRuntime.bot(p)&&r.enrolled.contains(p.getUniqueId()))){if(r.emptySince==0)r.emptySince=System.currentTimeMillis();if(System.currentTimeMillis()-r.emptySince>60000)plugin.recovery.reset(r.game);}else r.emptySince=0;}}brain.tick(Bukkit.getCurrentTick());}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void placed(org.bukkit.event.block.BlockPlaceEvent e){if(!BotRuntime.bot(e.getPlayer()))return;Game game=BedwarsAPI.getInstance().getGameOfPlayer(e.getPlayer());if(room(game)==null||game.getStatus()!=GameStatus.RUNNING)return;var region=game.getRegion();if(!region.isBlockAddedDuringGame(e.getBlock().getLocation())){region.putOriginalBlock(e.getBlock().getLocation(),e.getBlockReplacedState());region.addBuiltDuringGame(e.getBlock().getLocation());}brain.placed(e.getPlayer());}
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void joinEvent(BedwarsPlayerJoinEvent e){Room r=room(e.getGame());if(r==null||BotRuntime.bot(e.getPlayer()))return;if(!admitted.contains(e.getPlayer().getUniqueId())){e.setCancelled(true);e.getPlayer().sendMessage("§e로비 AI 메뉴로 참가하세요.");}}
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)public void team(BedwarsPlayerJoinTeamEvent e){if(arena(e.getGame())&&!BotRuntime.bot(e.getPlayer())&&e.getTeam()!=null&&!e.getTeam().getName().equals("red"))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST)public void started(BedwarsGameStartedEvent e){Room r=room(e.getGame());if(r!=null){List<UUID> roster=humans(r).stream().map(Player::getUniqueId).toList();r.enrolled.clear();r.enrolled.addAll(roster);r.initialHumans=roster.size();if(plugin.learning!=null)plugin.learning.freeze(e.getGame());}}
    @EventHandler public void end(BedwarsGameEndEvent e){Room r=room(e.getGame());if(r==null)return;r.closing=true;Bukkit.getScheduler().runTask(plugin,()->{removeBots(r);r.enrolled.clear();r.emptySince=0;});}
    @EventHandler(priority=EventPriority.MONITOR)public void leave(BedwarsPlayerLeaveEvent e){Room r=room(e.getGame());if(r!=null&&e.getGame().getStatus()==GameStatus.WAITING)r.enrolled.remove(e.getPlayer().getUniqueId());if(r!=null&&!r.closing&&e.getGame().getStatus()==GameStatus.WAITING&&e.getPlayer().getUniqueId().equals(r.host))Bukkit.getScheduler().runTask(plugin,()->{if(active==r&&!r.closing&&r.game.getStatus()==GameStatus.WAITING)cancel(r,"§e방장이 나가 AI방이 취소됐습니다. 로비로 이동합니다.");});}
    @EventHandler public void click(InventoryClickEvent e){if(!(e.getView().getTopInventory().getHolder() instanceof Menu m)||!(e.getWhoClicked() instanceof Player p))return;e.setCancelled(true);int slot=e.getRawSlot();if(slot<0||slot>=e.getView().getTopInventory().getSize())return;if(m.kind.equals("maps")&&slot==13)modes(p);else if(m.kind.equals("mode")){if(slot==11)enter(p,Difficulty.MEDIUM,AiChallenge.NONE);if(slot==15)challenges(p,Difficulty.HARD);}else if(m.kind.equals("challenge")){if(slot==49)modes(p);else if(slot>0&&slot<AiChallenge.values().length)enter(p,Difficulty.HARD,AiChallenge.values()[slot]);}}
    @EventHandler public void closeMenu(InventoryCloseEvent e){if(e.getInventory().getHolder() instanceof Menu)Bukkit.getScheduler().runTask(plugin,()->{var holder=e.getPlayer().getOpenInventory().getTopInventory().getHolder();if(!(holder instanceof Menu m)||m.kind.equals("maps"))configuring.remove(e.getPlayer().getUniqueId());});}
    @EventHandler public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof Menu)e.setCancelled(true);}
    @EventHandler public void quit(PlayerQuitEvent e){configuring.remove(e.getPlayer().getUniqueId());queued.remove(e.getPlayer().getUniqueId());}
    @Override public void close(){closed=true;ticker.cancel();for(Room r:List.copyOf(games.values())){r.closing=true;removeBots(r);}brain.close();}
}
