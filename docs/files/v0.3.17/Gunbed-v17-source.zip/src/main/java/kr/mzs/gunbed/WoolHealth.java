package kr.mzs.gunbed;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.*;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.game.*;
import org.screamingsandals.bedwars.api.events.*;
import com.shampaggon.crackshot.events.WeaponShootEvent;
import java.util.*;
import java.util.function.DoubleUnaryOperator;

/** Only the engine's player-built wool journal is damageable. Terrain wool never enters this table. */
final class WoolHealth implements Listener,AutoCloseable {
    private record Pos(UUID world,int x,int y,int z){static Pos of(Block b){return new Pos(b.getWorld().getUID(),b.getX(),b.getY(),b.getZ());}}
    private static final class Cell {Game game;Block block;double hp=3000;int source;}
    private record Shot(Player owner,String id,Location start){}
    private record Debris(ItemDisplay entity,org.bukkit.util.Vector velocity,int until){}
    private final Map<Pos,Cell> cells=new HashMap<>();
    private final Map<UUID,Shot> shots=new HashMap<>();
    private final Map<UUID,Long> meleeNext=new HashMap<>();
    private final List<Debris> debris=new ArrayList<>();
    private final GunbedCore plugin;private int sequence=950000;
    WoolHealth(GunbedCore p){plugin=p;Bukkit.getPluginManager().registerEvents(this,p);Bukkit.getScheduler().runTaskTimer(p,this::tick,1,1);}
    boolean eligible(Game g,Block b){return g!=null&&g.getStatus()==GameStatus.RUNNING&&b.getType().name().endsWith("_WOOL")&&g.isLocationInArena(b.getLocation())&&g.getRegion().isBlockAddedDuringGame(b.getLocation());}
    double remaining(Game g,Block b){Cell c=cells.get(Pos.of(b));return eligible(g,b)?c==null?3000:c.hp:0;}
    boolean hit(Player owner,Game g,Block b,double amount){if(!eligible(g,b)||!Double.isFinite(amount)||amount<=0)return false;Cell c=cells.computeIfAbsent(Pos.of(b),k->{Cell n=new Cell();n.game=g;n.block=b;n.source=sequence++;return n;});c.hp-=amount;if(c.hp<=0){var data=b.getBlockData();Material material=b.getType();clear(c);cells.remove(Pos.of(b));g.getRegion().removeBlockBuiltDuringGame(b.getLocation());b.setType(Material.AIR,false);var at=b.getLocation().add(.5,.5,.5);at.getWorld().spawnParticle(Particle.BLOCK,at,18,.35,.35,.35,0,data,true);at.getWorld().playSound(at,Sound.BLOCK_WOOL_BREAK,1,1);ItemDisplay image=at.getWorld().spawn(at,ItemDisplay.class,d->{d.setPersistent(false);d.setItemStack(new ItemStack(material));d.setTransformation(new Transformation(new Vector3f(),new Quaternionf(),new Vector3f(.35f),new Quaternionf()));d.setTeleportDuration(1);});var v=owner==null?new org.bukkit.util.Vector(.1,.22,.08):at.toVector().subtract(owner.getLocation().toVector()).setY(.25);if(v.lengthSquared()>.001)v.normalize().multiply(.25).setY(.22);debris.add(new Debris(image,v,Bukkit.getCurrentTick()+10));}else display(c);return true;}
    void blast(Player owner,Game game,Location at,double radius,DoubleUnaryOperator damage){if(game==null)return;int r=(int)Math.ceil(Math.min(16,radius));for(int x=-r;x<=r;x++)for(int y=-r;y<=r;y++)for(int z=-r;z<=r;z++){Block b=at.getBlock().getRelative(x,y,z);if(!eligible(game,b))continue;double d=b.getLocation().add(.5,.5,.5).distance(at);if(d<=radius)hit(owner,game,b,damage.applyAsDouble(d));}}
    private void display(Cell c){float progress=(float)Math.clamp(1-c.hp/3000,.001,.99);for(Player p:c.block.getWorld().getPlayers())if(p.getLocation().distanceSquared(c.block.getLocation())<36864)p.sendBlockDamage(c.block.getLocation(),progress,c.source);}
    private void clear(Cell c){for(Player p:c.block.getWorld().getPlayers())p.sendBlockDamage(c.block.getLocation(),0,c.source);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void replaced(BlockPlaceEvent e){Cell c=cells.remove(Pos.of(e.getBlock()));if(c!=null)clear(c);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void mined(BlockBreakEvent e){Cell c=cells.remove(Pos.of(e.getBlock()));if(c!=null)clear(c);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void explosion(EntityExplodeEvent e){if(e.getEntity() instanceof TNTPrimed||e.getEntity() instanceof Fireball)return;var g=BedwarsAPI.getInstance().getGames().stream().filter(a->a.getStatus()==GameStatus.RUNNING&&a.isLocationInArena(e.getLocation())).findFirst().orElse(null);if(g==null)return;Player owner=e.getEntity() instanceof Projectile q&&q.getShooter() instanceof Player p?p:e.getEntity() instanceof TNTPrimed t&&t.getSource() instanceof Player p?p:null;for(var it=e.blockList().iterator();it.hasNext();){Block b=it.next();if(!b.getType().name().endsWith("_WOOL"))continue;it.remove();if(eligible(g,b))hit(owner,g,b,1600*Math.max(.25,1-b.getLocation().add(.5,.5,.5).distance(e.getLocation())/6));}}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)public void blockExplosion(BlockExplodeEvent e){e.blockList().removeIf(b->b.getType().name().endsWith("_WOOL")&&BedwarsAPI.getInstance().getGames().stream().anyMatch(g->g.getStatus()==GameStatus.RUNNING&&g.isLocationInArena(b.getLocation())));}
    boolean melee(Player p,String id,double damage,long interval){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);var ray=p.getWorld().rayTraceBlocks(p.getEyeLocation(),p.getEyeLocation().getDirection(),3.2,FluidCollisionMode.NEVER,true);if(ray==null||ray.getHitBlock()==null||!eligible(g,ray.getHitBlock()))return false;long now=System.currentTimeMillis();if(now<meleeNext.getOrDefault(p.getUniqueId(),0L))return true;meleeNext.put(p.getUniqueId(),now+interval);plugin.protocol.emit(p,Map.of("event","meleeSwing","durationMs",interval));hit(p,g,ray.getHitBlock(),damage);return true;}
    @EventHandler(priority=EventPriority.MONITOR)public void shot(WeaponShootEvent e){String id="cs:"+e.getWeaponTitle();if(e.getProjectile()!=null){shots.put(e.getProjectile().getUniqueId(),new Shot(e.getPlayer(),id,e.getPlayer().getEyeLocation()));Bukkit.getScheduler().runTaskLater(plugin,()->shots.remove(e.getProjectile().getUniqueId()),240);return;}if(Set.of("골데B","소드오프").contains(e.getWeaponTitle()))return;var ray=e.getPlayer().getWorld().rayTraceBlocks(e.getPlayer().getEyeLocation(),e.getPlayer().getEyeLocation().getDirection(),256,FluidCollisionMode.NEVER,true);if(ray!=null&&ray.getHitBlock()!=null){var g=BedwarsAPI.getInstance().getGameOfPlayer(e.getPlayer());double amount=plugin.arsenal.meleeTitle(e.getWeaponTitle())?plugin.damageProfiles.melee(id,plugin.visuals.cs.getHandle().getDouble(e.getWeaponTitle()+".Shooting.Projectile_Damage")):plugin.damageProfiles.gun(e.getPlayer(),id,CombatBalance.Part.BODY,e.getPlayer().getEyeLocation().distance(ray.getHitPosition().toLocation(e.getPlayer().getWorld())),1,1);hit(e.getPlayer(),g,ray.getHitBlock(),amount);}}
    @EventHandler(priority=EventPriority.LOW,ignoreCancelled=true)public void impact(ProjectileHitEvent e){if(e.getHitBlock()==null)return;Shot s=shots.remove(e.getEntity().getUniqueId());if(s==null||Set.of("cs:골데B","cs:소드오프").contains(s.id))return;int pellets=Math.max(1,plugin.visuals.cs.getHandle().getInt(s.id.substring(3)+".Shooting.Projectile_Amount"));hit(s.owner,BedwarsAPI.getInstance().getGameOfPlayer(s.owner),e.getHitBlock(),plugin.damageProfiles.gun(s.owner,s.id,CombatBalance.Part.BODY,s.start.distance(e.getEntity().getLocation()),pellets,1));}
    private void tick(){int tick=Bukkit.getCurrentTick();for(var it=cells.values().iterator();it.hasNext();){Cell c=it.next();if(!eligible(c.game,c.block)){clear(c);it.remove();}else if(tick%20==0)display(c);}for(var it=debris.iterator();it.hasNext();){Debris d=it.next();if(tick>=d.until||!d.entity.isValid()){d.entity.remove();it.remove();continue;}d.velocity.setY(d.velocity.getY()-.025);d.entity.teleport(d.entity.getLocation().add(d.velocity));}}
    @EventHandler public void end(BedwarsGameEndingEvent e){for(var it=cells.values().iterator();it.hasNext();){Cell c=it.next();if(c.game==e.getGame()){clear(c);it.remove();}}}
    @Override public void close(){cells.values().forEach(this::clear);cells.clear();debris.forEach(d->d.entity.remove());debris.clear();}
}
