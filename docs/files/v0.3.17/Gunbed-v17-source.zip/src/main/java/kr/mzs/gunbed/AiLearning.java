package kr.mzs.gunbed;

import com.google.gson.Gson;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.*;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.io.*;

/** Local outcome-weighted imitation statistics, not a remote model or video trainer. */
final class AiLearning implements Listener,AutoCloseable {
    private record Decision(String context,String action){}
    private static final class Trace {Map<Decision,Integer> decisions=new HashMap<>();Set<String> cells=new HashSet<>();Set<String> edges=new HashSet<>();Set<String> structures=new HashSet<>();Location last;String lastCell,team="";int beds,kills,deaths,samples;boolean teacher;}
    private record Aggregate(long samples,double reward){}
    private final GunbedCore plugin;
    private final Gson gson=new Gson();
    private final Map<Game,Map<UUID,Trace>> traces=new HashMap<>();
    private final Map<String,Aggregate> values=new HashMap<>();
    private final Map<Game,Map<String,Aggregate>> frozen=new HashMap<>();
    private final Map<Game,Map<UUID,List<org.bukkit.block.Block>>> defenses=new HashMap<>();
    private long rejected;private LocalDate cleaned;
    private final ArrayBlockingQueue<String> records=new ArrayBlockingQueue<>(8192);
    private final Path folder,model;
    private final org.bukkit.scheduler.BukkitTask sampler,writer;
    private long episodes,dropped;
    private volatile String pendingModel;
    AiLearning(GunbedCore p){plugin=p;folder=p.getDataFolder().toPath().resolve("ai-learning");model=folder.resolve("policy.yml");try{Files.createDirectories(folder);}catch(IOException e){throw new UncheckedIOException(e);}var cfg=YamlConfiguration.loadConfiguration(model.toFile());episodes=cfg.getLong("episodes");var section=cfg.getConfigurationSection("values");if(section!=null)for(String key:section.getKeys(false)){long count=cfg.getLong("values."+key+".samples");double reward=cfg.getDouble("values."+key+".reward");if(count>0&&Double.isFinite(reward)&&Math.abs(reward)<=count*3&&values.size()<200000)values.put(key,new Aggregate(count,reward));}Bukkit.getPluginManager().registerEvents(this,p);sampler=Bukkit.getScheduler().runTaskTimer(p,this::sample,4,4);writer=Bukkit.getScheduler().runTaskTimerAsynchronously(p,this::flush,40,40);}
    static String map(Game g){return g.getName().startsWith("AI_Orchestra_")?"Orchestra_8":g.getName();}
    private String encode(String key){return Base64.getUrlEncoder().withoutPadding().encodeToString(key.getBytes(StandardCharsets.UTF_8));}
    private Trace trace(Game g,Player p){Trace t=traces.computeIfAbsent(g,k->new HashMap<>()).computeIfAbsent(p.getUniqueId(),k->new Trace());var team=g.getTeamOfPlayer(p);if(team!=null)t.team=team.getName();t.teacher=p.getName().equalsIgnoreCase("GMdong");return t;}
    void freeze(Game g){defenses.remove(g);frozen.put(g,Map.copyOf(values));}
    private Map<String,Aggregate> policy(Game g){return frozen.computeIfAbsent(g,k->Map.copyOf(values));}
    private void record(Player p,Game g,String action,Map<String,Object> detail){Map<String,Object> row=new LinkedHashMap<>();row.put("time",System.currentTimeMillis());row.put("tick",Bukkit.getCurrentTick());row.put("round",g.getName());row.put("map",map(g));row.put("player",p.getUniqueId().toString());row.put("teacher",p.getName().equalsIgnoreCase("GMdong"));row.put("action",action);row.putAll(detail);if(!records.offer(gson.toJson(row)))dropped++;}

    private Player enemy(Player p,Game g){var team=g.getTeamOfPlayer(p);return g.getConnectedPlayers().stream().filter(q->q!=p&&!q.isDead()&&q.getGameMode()!=GameMode.SPECTATOR&&q.getWorld()==p.getWorld()&&g.getTeamOfPlayer(q)!=null&&!team.isPlayerInTeam(q)&&p.hasLineOfSight(q)).min(Comparator.comparingDouble(q->q.getLocation().distanceSquared(p.getLocation()))).orElse(null);}
    String context(Player p,Game g,Player enemy){double distance=enemy==null?999:enemy.getLocation().distance(p.getLocation());double hp=p.getHealth()/Math.max(1,p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());return map(g)+"|"+(distance<5?"close":distance<20?"near":distance<60?"far":"travel")+"|"+(hp<.33?"low":hp<.66?"hurt":"healthy");}
    private int sign(Game g,Player p){var own=g.getTeamOfPlayer(p);if(own==null)return 1;double centre=g.getAvailableTeams().stream().mapToDouble(t->t.getTeamSpawn().getX()).average().orElse(own.getTeamSpawn().getX());return own.getTeamSpawn().getX()<centre?1:-1;}
    private String cell(Game g,Player p,Location at){var team=g.getTeamOfPlayer(p);if(team==null)return "";Location origin=team.getTeamSpawn();int sign=sign(g,p);return map(g)+"/"+(int)Math.floor((at.getX()-origin.getX())*sign/2)+"/"+(int)Math.floor((at.getY()-origin.getY())/2)+"/"+(int)Math.floor((at.getZ()-origin.getZ())/2);}
    void action(Player p,String action){Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(g==null||!map(g).equals("Orchestra_8")||g.getStatus()!=GameStatus.RUNNING||g.getTeamOfPlayer(p)==null||BotRuntime.bot(p)||plugin.inventories.locked(p))return;Trace t=trace(g,p);if(t.decisions.size()<4096)t.decisions.merge(new Decision(context(p,g,enemy(p,g)),action),1,Integer::sum);record(p,g,action,Map.of("weapon",plugin.ammo.id(p.getInventory().getItemInMainHand()),"pos",List.of(p.getX(),p.getY(),p.getZ())));}
    private void sample(){for(Game g:BedwarsAPI.getInstance().getGames())if(map(g).equals("Orchestra_8")&&g.getStatus()==GameStatus.RUNNING)for(Player p:g.getConnectedPlayers()){if(BotRuntime.bot(p)||g.getTeamOfPlayer(p)==null||p.isDead()||p.getGameMode()==GameMode.SPECTATOR||plugin.inventories.locked(p))continue;Player foe=enemy(p,g);String action=p.getHealth()/p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue()<.33&&foe!=null?"retreat":p.isSneaking()?"careful":p.getVelocity().lengthSquared()>.015?"advance":"hold";Trace t=trace(g,p);t.decisions.merge(new Decision(context(p,g,foe),action),1,Integer::sum);t.samples++;Location at=p.getLocation();String current=cell(g,p,at);if(t.cells.size()<4096)t.cells.add(current);
        if(t.last!=null&&t.last.getWorld()==at.getWorld()&&at.distanceSquared(t.last)<=36&&at.getY()>g.getPos1().getWorld().getMinHeight()&&t.edges.size()<8192&&t.lastCell!=null&&!current.equals(t.lastCell))t.edges.add(t.lastCell+">"+current);
        t.last=at;t.lastCell=current;String held=plugin.ammo.id(p.getInventory().getItemInMainHand());if(!held.isEmpty())t.decisions.merge(new Decision(context(p,g,foe),"weapon:"+held),1,Integer::sum);
        Map<String,Object> row=new LinkedHashMap<>();row.put("time",System.currentTimeMillis());row.put("teacher",t.teacher);row.put("tick",Bukkit.getCurrentTick());row.put("round",g.getName());row.put("map",map(g));row.put("player",p.getUniqueId().toString());row.put("team",g.getTeamOfPlayer(p).getName());row.put("pos",List.of(p.getX(),p.getY(),p.getZ()));row.put("look",List.of(p.getYaw(),p.getPitch()));row.put("velocity",List.of(p.getVelocity().getX(),p.getVelocity().getY(),p.getVelocity().getZ()));row.put("health",p.getHealth());row.put("weapon",plugin.ammo.id(p.getInventory().getItemInMainHand()));row.put("sprint",p.isSprinting());row.put("sneak",p.isSneaking());row.put("loaded",held.startsWith("ta:")?plugin.taWeapons.ammo(p):held.startsWith("cs:")?plugin.visuals.cs.getHandle().getAmmoBetweenBrackets(p,plugin.visuals.cs.getWeaponTitle(p.getInventory().getItemInMainHand()),p.getInventory().getItemInMainHand()):0);row.put("reload",plugin.ammo.reloading(p));row.put("utility",Arrays.stream(plugin.inventories.utility(p)).filter(Objects::nonNull).map(i->i.getType().name()+":"+plugin.stacks.count(i)).toList());row.put("resources",plugin.wallet.snapshot(p));row.put("reserve",held.isEmpty()?0:plugin.ammo.reserve(p,held));row.put("ground",p.isOnGround());row.put("inventoryMode",plugin.inventories.modeA(p)?"A":"B");row.put("action",action);if(!records.offer(gson.toJson(row)))dropped++;}}
    double preference(Game g,String context,String action){var a=policy(g).get(encode("choice/"+context+"/"+action));return a==null||a.samples<3?0:Math.max(-.35,Math.min(.35,a.reward/a.samples*.2));}
    double routeScore(Game g,Player bot,Location at){var a=policy(g).get(encode("route/"+cell(g,bot,at)));return a==null?0:Math.max(-.25,Math.min(.25,a.reward/Math.max(1,a.samples)*.15));}
    long episodes(){return episodes;}
    private void add(String key,int n,double reward){String id=encode(key);Aggregate a=values.getOrDefault(id,new Aggregate(0,0));if(values.size()<200000||values.containsKey(id))values.put(id,new Aggregate(a.samples+n,a.reward+reward*n));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void place(BlockPlaceEvent e){Player p=e.getPlayer();action(p,"build:"+e.getBlockPlaced().getType().name());Game g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(g==null||g.getStatus()!=GameStatus.RUNNING||!map(g).equals("Orchestra_8")||BotRuntime.bot(p)||g.getTeamOfPlayer(p)==null)return;Location bed=g.getTeamOfPlayer(p).getTargetBlock(),at=e.getBlockPlaced().getLocation();if(at.distanceSquared(bed)<=36){Trace t=trace(g,p);if(t.structures.size()<128)t.structures.add(map(g)+"/"+((at.getBlockX()-bed.getBlockX())*sign(g,p))+"/"+(at.getBlockY()-bed.getBlockY())+"/"+(at.getBlockZ()-bed.getBlockZ()));}}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void broken(BlockBreakEvent e){action(e.getPlayer(),"break");}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void consume(PlayerItemConsumeEvent e){action(e.getPlayer(),"heal");}
    @EventHandler(priority=EventPriority.MONITOR)public void bed(BedwarsTargetBlockDestroyedEvent e){if(e.getPlayer()!=null&&!BotRuntime.bot(e.getPlayer()))trace(e.getGame(),e.getPlayer()).beds++;}
    @EventHandler(priority=EventPriority.MONITOR)public void kill(BedwarsPlayerKilledEvent e){if(!BotRuntime.bot(e.getPlayer()))trace(e.getGame(),e.getPlayer()).deaths++;Player p=e.getKiller()==null?plugin.combatPresentation.credit(e.getPlayer()):e.getKiller();if(p!=null&&!BotRuntime.bot(p))trace(e.getGame(),p).kills++;}
    @EventHandler(priority=EventPriority.MONITOR)public void ending(BedwarsGameEndingEvent e){
        Map<UUID,Trace> round=traces.remove(e.getGame());if(round==null||e.getWinningTeam()==null)return;
        for(var entry:round.entrySet()){
            Trace t=entry.getValue();
            // Reject incomplete/empty demonstrations and impossible numeric updates.
            if(t.samples<25||t.cells.size()<2||t.team.isEmpty()){rejected++;continue;}
            boolean won=e.getWinningTeam().getName().equals(t.team);double reward=(won?1:-1)+Math.min(.5,t.beds*.2+t.kills*.025)-Math.min(.3,t.deaths*.02);
            if(!Double.isFinite(reward)){rejected++;continue;}
            int weight=t.teacher?4:1;
            for(var d:t.decisions.entrySet())add("choice/"+d.getKey().context+"/"+d.getKey().action,Math.min(100,d.getValue())*weight,reward);
            for(String cell:t.cells)add("route/"+cell,weight,reward);
            for(String edge:t.edges)add("edge/"+edge,weight,reward);for(String structure:t.structures)add("defense/"+structure,weight,reward);
            Map<String,Object> audit=new LinkedHashMap<>();audit.put("time",System.currentTimeMillis());audit.put("action","round-result");audit.put("round",e.getGame().getName());audit.put("map",map(e.getGame()));audit.put("player",entry.getKey().toString());audit.put("teacher",t.teacher);audit.put("won",won);audit.put("reward",reward);audit.put("samples",t.samples);audit.put("cells",t.cells.size());audit.put("edges",t.edges.size());audit.put("kills",t.kills);audit.put("deaths",t.deaths);audit.put("beds",t.beds);audit.put("episode",episodes+1);if(!records.offer(gson.toJson(audit)))dropped++;
            episodes++;
        }save();
    }
    @EventHandler(priority=EventPriority.MONITOR)public void start(BedwarsGameStartedEvent e){freeze(e.getGame());}
    @EventHandler public void end(BedwarsGameEndEvent e){traces.remove(e.getGame());frozen.remove(e.getGame());defenses.remove(e.getGame());}
    private String preferred(Game g,Player p,List<String> legal,String prefix){String context=context(p,g,enemy(p,g));return legal.stream().filter(id->{Aggregate a=policy(g).get(encode("choice/"+context+"/"+prefix+id));return a!=null&&a.samples>=3&&a.reward>0;}).max(Comparator.comparingDouble(id->{Aggregate a=policy(g).get(encode("choice/"+context+"/"+prefix+id));return a.reward/a.samples;})).orElse("");}
    String weapon(Game g,Player p,List<String> legal){return preferred(g,p,legal,"weapon:");}
    String purchase(Game g,Player p,List<String> legal){return preferred(g,p,legal,"buy:");}
    List<org.bukkit.block.Block> defense(Game g,Player p){return defenses.computeIfAbsent(g,k->new HashMap<>()).computeIfAbsent(p.getUniqueId(),id->buildDefense(g,p));}
    private List<org.bukkit.block.Block> buildDefense(Game g,Player p){Location bed=g.getTeamOfPlayer(p).getTargetBlock();List<org.bukkit.block.Block> result=new ArrayList<>();String prefix="defense/"+map(g)+"/";for(var e:policy(g).entrySet()){String decoded=new String(Base64.getUrlDecoder().decode(e.getKey()),StandardCharsets.UTF_8);if(!decoded.startsWith(prefix)||e.getValue().samples<3||e.getValue().reward<=0)continue;String[] xyz=decoded.substring(prefix.length()).split("/");if(xyz.length!=3)continue;try{int x=Integer.parseInt(xyz[0]),y=Integer.parseInt(xyz[1]),z=Integer.parseInt(xyz[2]);if(Math.abs(x)<=5&&Math.abs(y)<=5&&Math.abs(z)<=5)result.add(bed.getBlock().getRelative(x*sign(g,p),y,z));}catch(NumberFormatException ignored){}}result.sort(Comparator.comparingInt(org.bukkit.block.Block::getY));return result.stream().limit(64).toList();}
    double edgeScore(Game g,Player p,Location from,Location to){Aggregate a=policy(g).get(encode("edge/"+cell(g,p,from)+">"+cell(g,p,to)));return a==null?0:Math.max(-.25,Math.min(.25,a.reward/Math.max(1,a.samples)*.15));}
    private void save(){var cfg=new YamlConfiguration();cfg.set("schema",2);cfg.set("teacher","GMdong (weight 4); other real players (weight 1)");cfg.set("retention-days",30);cfg.set("rejected-demonstrations",rejected);cfg.set("activation","validated round end; frozen per next round");cfg.set("episodes",episodes);cfg.set("dropped-samples",dropped);cfg.set("method","outcome-weighted local imitation statistics");for(var e:values.entrySet()){cfg.set("values."+e.getKey()+".samples",e.getValue().samples);cfg.set("values."+e.getKey()+".reward",e.getValue().reward);}pendingModel=cfg.saveToString();}
    private synchronized void flush(){try{LocalDate today=LocalDate.now();if(!today.equals(cleaned)){try(var list=Files.list(folder)){for(Path f:list.filter(f->f.getFileName().toString().matches("observations-[0-9]{4}-[0-9]{2}-[0-9]{2}\\.jsonl")).toList()){String name=f.getFileName().toString();try{LocalDate date=LocalDate.parse(name.substring(13,23));if(date.isBefore(today.minusDays(30)))Files.delete(f);}catch(java.time.format.DateTimeParseException ignored){}}}cleaned=today;}List<String> batch=new ArrayList<>(4096);records.drainTo(batch,4096);if(!batch.isEmpty())Files.write(folder.resolve("observations-"+LocalDate.now()+".jsonl"),batch,StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.APPEND);String next=pendingModel;if(next!=null){Path temp=model.resolveSibling("policy.yml.tmp");Files.writeString(temp,next,StandardCharsets.UTF_8);Files.move(temp,model,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);if(pendingModel==next)pendingModel=null;}}catch(IOException e){plugin.getLogger().warning("AI learning log write failed: "+e.getMessage());}}
    @Override public void close(){sampler.cancel();writer.cancel();save();flush();if(!records.isEmpty())flush();traces.clear();frozen.clear();}
}
