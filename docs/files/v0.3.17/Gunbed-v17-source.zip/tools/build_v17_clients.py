import concurrent.futures,json,os,subprocess
from pathlib import Path
from server_audit import ROOT,dump,sha256
from generate_visual_adapter import generate,VERSIONS

for version in VERSIONS:generate(version)
def build(version):
    modern=version.startswith('26.');env=dict(os.environ,JAVA_HOME=r'C:\Program Files\Java\jdk-25.0.2' if modern else r'C:\Program Files\Java\jdk-21');fabric=(ROOT/f'client/.generated/{version}/fabric-version.txt').read_text().strip();log=ROOT/f'.local/v17-client-{version}.log'
    with log.open('w',encoding='utf-8') as out:
        result=subprocess.run([str(ROOT/'client/gradlew.bat'),'-p',str(ROOT/'client'),'remapJar' if not modern else 'jar','-PmcVersion='+version,'-PfabricVersion='+fabric,'--console=plain'],env=env,stdout=out,stderr=subprocess.STDOUT)
    if result.returncode:raise RuntimeError(version+': '+log.read_text(encoding='utf-8',errors='replace')[-4000:])
    jar=ROOT/f'client/build/{version}/libs/GunbedVisuals-{version}-0.3.17.jar';assert jar.exists();print(json.dumps({'version':version,'built':True}),flush=True);return {'version':version,'jar':str(jar),'sha256':sha256(jar)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(build,VERSIONS))
env=dict(os.environ,JAVA_HOME=r'C:\Program Files\Java\jdk-21');fabric=(ROOT/'client/.generated/1.21.11/fabric-version.txt').read_text().strip();subprocess.run([str(ROOT/'client/gradlew.bat'),'-p',str(ROOT/'client'),'assetsJar','-PmcVersion=1.21.11','-PfabricVersion='+fabric,'--console=plain'],env=env,check=True)
dump(ROOT/'reports/v17-client-builds.json',{'success':True,'clients':rows,'asset_bytes':(ROOT/'client/build/shared/libs/GunbedAssets-0.3.17.jar').stat().st_size})
