import json,subprocess,sys,shutil
from server_audit import ROOT,dump
phases=[]
for label,script in [('features','tools/followup_eight_check.cjs'),('learning','tools/ai_learning_check.cjs')]:
    result=subprocess.run(['node',str(ROOT/script)],cwd=ROOT)
    assert result.returncode==0,label
    path=ROOT/'reports'/('v17-followup-scenario.json' if label=='features' else 'ai-learning-scenario.json')
    data=json.loads(path.read_text('utf8'));assert data['success'],label
    if label=='learning':shutil.copy2(path,ROOT/'reports/v17-learning-scenario.json')
    phases.append(label)
dump(ROOT/'reports/v17-final-scenarios.json',{'success':True,'phases':phases})
