import io,json,os,sys,tempfile,zipfile
from pathlib import Path
from unittest.mock import patch
from server_audit import ROOT,dump,sha256
sys.path.insert(0,str(ROOT/'installer'))
from online import OnlineInstaller
from engine import mod_id

def fake_jar(id):
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w') as z:z.writestr('fabric.mod.json',json.dumps({'id':id,'version':'0.0.1'}))
    return b.getvalue()

meta=ROOT/'.local/installer-online-v0.3.17';manifest=json.loads((meta/'manifest.json').read_text());checked=set()
def local(url,expected,filename,log):
    name=Path(url).name;folder='0.3.17' if name.startswith(('GunbedAssets-','GunbedVisuals-')) else '0.3.13';file=ROOT/f'.local/publication-assets-v{folder}'/name
    assert sha256(file)==expected,(name,expected);checked.add(name);return file
for v,data in manifest['versions'].items():
    assert len(data['mods'])==4
    for entry in data['mods']+data['libraries']:local(entry['url'],entry['sha256'],Path(entry['url']).name,lambda m:None)
report={'success':False,'versions_validated':len(manifest['versions']),'files_verified':len(checked),'fixtures':[]}
with tempfile.TemporaryDirectory(prefix='gunbed-optic-release-') as temp:
    for version in ('1.21.8','26.3'):
        root=Path(temp)/version;game=root/(version+' 모드');mods=game/'mods';mods.mkdir(parents=True);(root/'versions').mkdir()
        (mods/'keep-my-mod.jar').write_bytes(fake_jar('independent_mod'));(mods/'GunbedAssets-0.3.13.jar').write_bytes(fake_jar('gunbed_assets'));(game/'options.txt').write_bytes(b'keep-settings');(game/'saves/my-world').mkdir(parents=True);(game/'saves/my-world/level.dat').write_bytes(b'keep-world')
        before=sha256(mods/'keep-my-mod.jar');engine=OnlineInstaller(meta);engine.fetch=local
        with patch.dict(os.environ,{'LOCALAPPDATA':str(Path(temp)/'cache')}),patch('processes.stop_launchers'):
            result=engine.install(root,version,game_dir=game)
        assert result['success'] and sha256(mods/'keep-my-mod.jar')==before
        assert (game/'options.txt').read_bytes()==b'keep-settings' and (game/'saves/my-world/level.dat').read_bytes()==b'keep-world'
        assert (Path(result['backup'])/'mods/GunbedAssets-0.3.13.jar').exists()
        assert not (mods/'GunbedAssets-0.3.13.jar').exists() and sha256(mods/'GunbedAssets-0.3.17.jar')==sha256(ROOT/'client/build/shared/libs/GunbedAssets-0.3.17.jar')
        assert mod_id((mods/'GunbedAssets-0.3.17.jar').read_bytes())=='gunbed_assets'
        report['fixtures'].append({'version':version,'other_mod_preserved':True,'settings_world_preserved':True,'old_asset_backed_up':True,'new_asset_verified':True})
report['success']=True;dump(ROOT/'reports/v17-installer-tests.json',report);print(json.dumps(report))
