import com.google.gson.*;
import kr.mzs.gunbedvisual.model.GunMesh;
import java.nio.file.*;
import java.util.*;

public final class GunbedAssetCheck {
    public static void main(String[] args)throws Exception {
        var state=kr.mzs.gunbedvisual.VisualState.INSTANCE;
        state.packet("{\"v\":1,\"event\":\"held\",\"enabled\":true,\"model\":\"ak47\",\"slot\":0,\"material\":\"minecraft:wooden_shovel\",\"itemPrefix\":\"AK-47\"}");
        if(!state.matches(0,"minecraft:wooden_shovel","AK-47 «30»"))throw new AssertionError("Server gun not recognized");
        if(state.matches(0,"minecraft:compass","Lobby selector"))throw new AssertionError("Stale gun state affects lobby item");
        if(state.matches(0,"minecraft:wooden_shovel","Ordinary shovel"))throw new AssertionError("Stale gun state affects ordinary tool");
        if(state.matches(1,"minecraft:wooden_shovel","AK-47 «30»"))throw new AssertionError("Stale slot state affects other item");
        state.clear();
        for(String[] melee:new String[][]{{"망치","gunbed_legacy_blaze_rod"},{"나타나이프","gunbed_legacy_golden_sword"}}){
            state.packet(new Gson().toJson(Map.of("v",1,"event","held","enabled",true,"controlled",true,"engine","cs","weapon",melee[0],"model",melee[1],"slot",0)));
            var idle=state.frame();state.packet("{\"v\":1,\"event\":\"meleeSwing\",\"durationMs\":1200}");var started=state.getClass().getDeclaredField("started");started.setAccessible(true);started.setLong(state,System.nanoTime()-300_000_000L);var attack=state.frame();
            if(idle.vertices().equals(attack.vertices()))throw new AssertionError(melee[0]+" reference animation does not move its mesh");
            for(var v:attack.vertices())if(!Float.isFinite(v.x()+v.y()+v.z()))throw new AssertionError(melee[0]+" nonfinite retargeted vertex");
            state.clear();
        }
        Path root=Path.of(args[0]);List<Object> results=new ArrayList<>();int frames=0;
        var catalog=JsonParser.parseString(Files.readString(root.resolve("gunbed_catalog.json"))).getAsJsonObject().getAsJsonObject("guns");
        for(String id:Arrays.copyOfRange(args,1,args.length)) {
            var definition=kr.mzs.gunbedvisual.ModeAssets.definition(catalog,id);
            var loaded=kr.mzs.gunbedvisual.ModeAssets.load(definition,path->{try{return JsonParser.parseString(Files.readString(root.getParent().getParent().resolve(path))).getAsJsonObject();}catch(java.io.IOException e){throw new java.io.UncheckedIOException(e);}});
            var geo=loaded.geometry();var animation=loaded.animation();
            var model=new GunMesh(geo,animation);var clips=animation.getAsJsonObject("animations").keySet();
            List<String> checked=new ArrayList<>();
            for(String clip:clips) {
                if(!clip.equals("static_idle")&&!clip.startsWith("reload")&&!clip.equals("shoot")&&!clip.equals("draw")&&!Set.of("mode_switch","deploy","undeploy","pull_pin","throw","attack_left","attack_right").contains(clip))continue;
                for(int n=0;n<=20;n++) {
                    var frame=model.frame(clip,n/20.0*model.duration(clip),n/20f);
                    if(frame.vertices().isEmpty()&&!(id.startsWith("qa_")&&clip.equals("throw")))throw new AssertionError(id+" "+clip+" frame "+n+" has no mesh");
                    for(var v:frame.vertices())if(!Float.isFinite(v.x()+v.y()+v.z()+v.nx()+v.ny()+v.nz()))throw new AssertionError(id+" "+clip+" invalid vertex");
                    if(frame.leftArm()!=null&&!frame.leftArm().isFinite()||frame.rightArm()!=null&&!frame.rightArm().isFinite())throw new AssertionError(id+" invalid hand pose");
                    frames++;
                }
                checked.add(clip);
            }
            var presets=JsonParser.parseString(Files.readString(root.getParent().resolve("gunbed/default_optics.json"))).getAsJsonObject();
            if(presets.has(id)){state.clear();state.packet("{\"v\":1,\"event\":\"held\",\"enabled\":true,\"controlled\":true,\"engine\":\"ta\",\"model\":\""+id+"\",\"slot\":0}");var mounted=state.frame();if(mounted.surfaces().size()!=2)throw new AssertionError(id+" missing mounted optic");for(var vertices:mounted.surfaces().values())for(var v:vertices)if(!Float.isFinite(v.x()+v.y()+v.z()))throw new AssertionError(id+" invalid optic vertex");}
            if(id.startsWith("lr_delta_")){
                state.clear();state.packet(new Gson().toJson(Map.of("v",1,"event","held","enabled",true,"controlled",true,"engine","melee","weapon","lr:"+id.substring(3),"model",id,"slot",0)));
                var idle=state.frame();state.packet("{\"v\":1,\"event\":\"meleeSwing\",\"durationMs\":800}");var began=state.getClass().getDeclaredField("started");began.setAccessible(true);began.setLong(state,System.nanoTime()-300_000_000L);var swing=state.frame();
                if(idle.vertices().equals(swing.vertices()))throw new AssertionError(id+" attack packet does not animate mesh");
                if(!model.hasClip("attack_left"))throw new AssertionError(id+" missing normalized attack clip");
            }
            results.add(Map.of("model",id,"clips",checked));
        }
        System.out.println(new Gson().toJson(Map.of("success",true,"frames",frames,"models",results)));
    }
}
