import java.util.UUID;
import kr.mzs.gunbedvisual.PackOwnership;
public class PackOwnershipCheck {
 static UUID waitForRemoval(){UUID result=null;for(int i=0;i<40;i++){UUID next=PackOwnership.tick();if(next!=null)result=next;}return result;}
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 public static void main(String[] args){
  UUID gunbed=UUID.randomUUID(),lobby=UUID.randomUUID();
  PackOwnership.clear();PackOwnership.pushed(gunbed,"gunbed");PackOwnership.confirm(gunbed.toString(),"gunbed");PackOwnership.transition();check(gunbed.equals(waitForRemoval()),"remove own pack on backend transition");
  PackOwnership.clear();PackOwnership.pushed(gunbed,"gunbed");PackOwnership.confirm(gunbed.toString(),"gunbed");PackOwnership.transition();PackOwnership.confirm(gunbed.toString(),"gunbed");check(waitForRemoval()==null,"respawn with fresh HUD retains pack");
  PackOwnership.clear();PackOwnership.pushed(gunbed,"gunbed");PackOwnership.confirm(gunbed.toString(),"gunbed");PackOwnership.transition();PackOwnership.pushed(gunbed,"lobby");PackOwnership.confirm(gunbed.toString(),"gunbed");check(waitForRemoval()==null,"same UUID replacement survives stale HUD");
  PackOwnership.clear();PackOwnership.pushed(gunbed,"gunbed");PackOwnership.confirm(gunbed.toString(),"gunbed");PackOwnership.transition();PackOwnership.pushed(lobby,"lobby");check(gunbed.equals(waitForRemoval()),"different UUID replacement is never removed");
  System.out.println("4 pack ownership transition checks passed");
 }
}
