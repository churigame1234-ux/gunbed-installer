"""Back up and update the empty Gunbed backend; retain real learning and player data."""
import datetime,json,os,shutil,sqlite3,subprocess,time
import yaml
from server_audit import ROOT,GUNBED,STAGE,dump,sha256
from deployment_runtime import stop,start

def population():
    text=subprocess.check_output(['node','-e',"require('./.local/client-test/node_modules/minecraft-protocol').ping({host:'127.0.0.1',port:25588,closeTimeout:8000},(e,r)=>{if(e)process.exit(1);console.log(JSON.stringify({online:r.players.online}));});"],cwd=ROOT,text=True,timeout=15)
    return json.loads(text)['online']
def ledger():
    path=GUNBED/'plugins/GunbedCore/points.sqlite'
    with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as db:
        return {'accounts':db.execute('SELECT uuid,recommend,donation,votes,shared_votes FROM accounts ORDER BY uuid').fetchall(),'ownership':db.execute('SELECT uuid,item FROM ownership ORDER BY uuid,item').fetchall()}

validation=json.loads((ROOT/'reports/v17-release-validation.json').read_text('utf8'));assert validation['success']
candidate=ROOT/'build/libs/GunbedCore.jar';digest=sha256(candidate)
assert digest==validation['core_sha256']==sha256(STAGE/'plugins/GunbedCore.jar')
assert population()==0,'Gunbed has players; do not restart'
target=GUNBED/'plugins/GunbedCore.jar';pending=GUNBED/'plugins/update/GunbedCore.jar'
assert sha256(target)=='2b7a3798c5fa204912e893742fb2c6f52effc3e09f1f4b31a47acd0ed4fc33f0' and not pending.exists(),'Production baseline changed'
assert sha256(GUNBED/'plugins/MZSBotCore.jar')=='e747b129a6174685b303bef7e7afc82767de836dd49fe5ba05cf86cdf50d04b1'
backup=GUNBED/'_core-backups'/('followup-v17-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));backup.mkdir(parents=True)
shutil.copy2(target,backup/'GunbedCore-before.jar');shutil.copy2(candidate,backup/'GunbedCore-after.jar')
data=GUNBED/'plugins/GunbedCore'
for name in ['config.yml','damage.yml','knockback.yml','shop.yml']:
    shutil.copy2(data/name,backup/name)
for name in ['players','ai-learning']:
    shutil.copytree(data/name,backup/name)
with sqlite3.connect((data/'points.sqlite').as_uri()+'?mode=ro',uri=True) as db,sqlite3.connect(backup/'points-before.sqlite') as saved:db.backup(saved)
before=ledger();model_before=yaml.safe_load((data/'ai-learning/policy.yml').read_text('utf8'))
protected=['plugins/GunbedCore/'+n for n in ['config.yml','damage.yml','knockback.yml','shop.yml']]+['plugins/ItemsAdder/output/generated.zip']
hashes={name:sha256(GUNBED/name) for name in protected};profiles={p.name:sha256(p) for p in (data/'players').glob('*.yml')}
report={'success':False,'backup':str(backup),'core_sha256':digest,'online_before':population(),'zombie_restarted':False}
stopped=False
try:
    assert population()==0,'A player joined while preparing the deployment'
    stop();stopped=True
    pending.parent.mkdir(exist_ok=True);temporary=pending.with_suffix('.jar.tmp');shutil.copy2(candidate,temporary);os.replace(temporary,pending)
    start();stopped=False
    assert sha256(target)==digest and not pending.exists()
    for name,expected in hashes.items():assert sha256(GUNBED/name)==expected,name
    assert profiles=={p.name:sha256(p) for p in (data/'players').glob('*.yml')},'Player settings changed unexpectedly'
    model_after=yaml.safe_load((data/'ai-learning/policy.yml').read_text('utf8'))
    assert model_after['values']==model_before['values'] and model_after['episodes']==model_before['episodes'],'Real policy must be retained'
    # Read-only common-source polling runs shortly after startup.
    time.sleep(4)
    after=ledger();assert after['ownership']==before['ownership']
    old_accounts={r[0]:r for r in before['accounts']};new_accounts={r[0]:r for r in after['accounts']}
    for id,row in old_accounts.items():assert new_accounts[id][2]==row[2] and new_accounts[id][1]>=row[1],id
    real='7557e561-837f-44ba-8296-2d667193d3c8';assert new_accounts[real][3]==4 and new_accounts[real][4]==4
    report.update(success=True,learning_episodes_preserved=model_after['episodes'],learning_features_preserved=len(model_after['values']),player_settings_preserved=len(profiles),donation_and_ownership_preserved=True,protected_hashes=hashes,repaired_vote_before=old_accounts[real][3],repaired_vote_after=new_accounts[real][3],recommend_points_before=old_accounts[real][1],recommend_points_after=new_accounts[real][1])
except Exception as error:
    report['error']=str(error)
    if not stopped:stop();stopped=True
    pending.unlink(missing_ok=True);shutil.copy2(backup/'GunbedCore-before.jar',target)
    start();stopped=False;report['rolled_back_core']=True
    raise
finally:
    dump(ROOT/'reports/v17-production-deployment.json',report)
print(json.dumps(report,ensure_ascii=False))
