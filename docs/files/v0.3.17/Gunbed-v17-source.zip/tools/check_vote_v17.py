"""Real NuVotifier events: case-insensitive identity and receipt replay prevention."""
import json,os,subprocess,sqlite3,time,uuid,zipfile
from server_audit import ROOT,REFERENCE,dump,sha256
work=ROOT/'.local/v17-vote';stage=ROOT/'.local/v16-vote/server';java='C:/Program Files/Java/jdk-21/bin/'
assert 'server-port=25691' in (stage/'server.properties').read_text()
source=REFERENCE/'plugins/update/MZSProfile.jar'
if not source.exists():source=REFERENCE/'plugins/MZSProfile.jar'
entries={p.relative_to(work/'classes').as_posix():p.read_bytes() for p in (work/'classes').rglob('*.class')}
with zipfile.ZipFile(source) as old,zipfile.ZipFile(work/'MZSProfile.jar','w',zipfile.ZIP_DEFLATED) as out:
    for entry in old.infolist():
        if entry.filename not in entries:out.writestr(entry,old.read(entry))
    for name,data in entries.items():out.writestr(name,data)
import shutil
shutil.copy2(work/'MZSProfile.jar',stage/'plugins/MZSProfile.jar')
target='a03f159d-f6cd-4c29-91c0-30d5c0792777';cache=stage/'usercache.json'
data=json.loads(cache.read_text());data=[r for r in data if r['name'].lower()!='gbvotev17'];data.append({'name':'GBVoteV17','uuid':target,'expiresOn':'2027-01-01 00:00:00 +0900'});dump(cache,data)
with sqlite3.connect(stage/'plugins/MZSProfile/database.db') as db:
    db.execute("DELETE FROM profile_counters WHERE uuid=?",(target,));db.execute("DELETE FROM players WHERE uuid=?",(target,));db.execute("DELETE FROM gunbed_vote_receipts_v16 WHERE lower(username)='gbvotev17'")
    fake=str(uuid.UUID(bytes=__import__('hashlib').md5(b'OfflinePlayer:gbvotev17').digest(),version=3))
    db.execute('INSERT OR REPLACE INTO players(uuid,name) VALUES(?,?)',(fake,'gbvotev17'))
    db.execute('INSERT OR REPLACE INTO profile_counters(uuid,votes) VALUES(?,1)',(fake,))
    db.execute("INSERT INTO gunbed_vote_receipts_v16 VALUES('legacy-case-v17','gbvotev17',1)")
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='gunbed_vote_identity_repairs_v17'").fetchone():db.execute("DELETE FROM gunbed_vote_identity_repairs_v17 WHERE receipt='legacy-case-v17'")
fixture=work/'VoteFixture.java'
fixture.write_text('''import org.bukkit.*;import org.bukkit.event.*;import org.bukkit.plugin.java.JavaPlugin;
public final class VoteFixture extends JavaPlugin{public void onEnable(){if(Bukkit.getPort()!=25691||!Bukkit.getIp().equals("127.0.0.1"))throw new IllegalStateException();Bukkit.getScheduler().runTaskLater(this,()->{try{ClassLoader cl=Bukkit.getPluginManager().getPlugin("Votifier").getClass().getClassLoader();Class<?> v=Class.forName("com.vexsoftware.votifier.model.Vote",true,cl),e=Class.forName("com.vexsoftware.votifier.model.VotifierEvent",true,cl);for(int n=0;n<3;n++){Object vote=v.getConstructor(String.class,String.class,String.class,String.class).newInstance("private-v17",n==1?"GBVoteV17":"gbvotev17","127.0.0.1",n<2?"v17-case-1":"v17-case-2");Bukkit.getPluginManager().callEvent((Event)e.getConstructor(v).newInstance(vote));}getLogger().info("V17_PRIVATE_VOTES_SENT");}catch(Throwable ex){ex.printStackTrace();}},60);}}''',encoding='utf8')
args=(ROOT/'.local/v16-vote/fixture.args').read_text(encoding='utf8').replace('/v16-vote/fixtureclasses','/v17-vote/fixtureclasses').replace('/v16-vote/VoteFixture.java','/v17-vote/VoteFixture.java');(work/'fixtureclasses').mkdir(exist_ok=True);(work/'fixture.args').write_text(args,encoding='utf8')
subprocess.run([java+'javac.exe','@'+str(work/'fixture.args')],check=True,capture_output=True)
fixturejar=next((stage/'plugins').glob('*Fixture*.jar'))
with zipfile.ZipFile(fixturejar) as z:metadata=z.read('plugin.yml')
with zipfile.ZipFile(fixturejar,'w') as z:z.writestr('plugin.yml',metadata);z.write(work/'fixtureclasses/VoteFixture.class','VoteFixture.class')
report={'success':False,'profile_sha256':sha256(work/'MZSProfile.jar')}
with (work/'server.log').open('w',encoding='utf8') as output:
    p=subprocess.Popen([java+'java.exe','-Xms256M','-Xmx1G','-Dfile.encoding=UTF-8','-jar','server.jar','--nogui'],cwd=stage,stdin=subprocess.PIPE,stdout=output,stderr=subprocess.STDOUT,text=True)
    try:
        until=time.time()+160
        while time.time()<until and p.poll() is None:
            text=(work/'server.log').read_text(encoding='utf8',errors='replace')
            if 'V17_PRIVATE_VOTES_SENT' in text:
                with sqlite3.connect(stage/'plugins/MZSProfile/database.db') as db:
                    rows=db.execute('SELECT votes FROM profile_counters WHERE uuid=?',(target,)).fetchall();receipts=db.execute("SELECT count(*) FROM gunbed_vote_receipts_v16 WHERE lower(username)='gbvotev17'").fetchone()[0]
                assert rows==[(3,)] and receipts==3,(rows,receipts)
                report.update(success=True,canonical_uuid=target,votes=3,unique_receipts=3,legacy_case_receipt_repaired=True,duplicate_credited=False);break
            time.sleep(.5)
        assert report['success'],text[-3000:]
    finally:
        if p.poll() is None:p.stdin.write('stop\n');p.stdin.flush();p.wait(timeout=60)
dump(ROOT/'reports/v17-vote-private.json',report);print(json.dumps(report))
