package kr.mzs.gunbed.probe;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.CompassMeta;
import org.bukkit.persistence.PersistentDataType;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import org.screamingsandals.bedwars.game.CurrentTeam;
import static kr.mzs.gunbed.probe.V9Checks.*;
final class TeamTrackerChecks {
 static Location base;
 static Map<String,Object> run(Player p,String[] args)throws Exception{
  Object plugin=Bukkit.getPluginManager().getPlugin("GunbedCore"),tracker=core("tracker");var g=BedwarsAPI.getInstance().getGameOfPlayer(p);String op=args[2];Map<String,Object> out=new LinkedHashMap<>();out.put("teamtracker",op);
  switch(op){
   case "state"->{call(tracker,"tick");Object team=call(tracker,"selectedTeam",p);UUID id=(UUID)((Map<?,?>)field(tracker,"targets")).get(p.getUniqueId());Player target=id==null?null:Bukkit.getPlayer(id);out.put("team",team==null?"":call(team,"getName"));out.put("target",target==null?"":target.getName());out.put("available",call(tracker,"available",p));out.put("money",call(core("wallet"),"amount",p,Material.EMERALD));out.put("modeA",call(core("inventories"),"modeA",p));out.put("mode",p.getGameMode().name());out.put("selected",((Map<?,?>)field(tracker,"selections")).containsKey(p.getUniqueId()));ItemStack item=p.getInventory().getItem(8);out.put("slot8",item==null?"":item.getType().name());if(item!=null&&item.getItemMeta() instanceof CompassMeta cm){out.put("lodestone",cm.hasLodestone()?cm.getLodestone().toVector().toString():"");out.put("lodestoneTracked",cm.isLodestoneTracked());out.put("name",cm.getDisplayName());}out.put("at",p.getLocation().toVector().toString());}
   case "open"->call(tracker,"open",p);
   case "menu"->{Inventory inv=p.getOpenInventory().getTopInventory();out.put("size",inv.getSize());out.put("title",p.getOpenInventory().getTitle());Map<String,Object> teams=new LinkedHashMap<>();for(int n=0;n<inv.getSize();n++){ItemStack i=inv.getItem(n);if(i==null||!i.hasItemMeta())continue;String name=i.getItemMeta().getPersistentDataContainer().get(new NamespacedKey((org.bukkit.plugin.Plugin)plugin,"tracker_team"),PersistentDataType.STRING);if(name!=null)teams.put(name,Map.of("slot",n,"material",i.getType().name(),"lore",i.getItemMeta().getLore()));}out.put("teams",teams);out.put("close",inv.getSize()>31?inv.getItem(31).getType().name():"");}
   case "bed"->{CurrentTeam team=(CurrentTeam)g.getRunningTeams().stream().filter(t->t.getName().equals(args[3])).findFirst().orElseThrow();team.isBed=Boolean.parseBoolean(args[4]);out.put("bed",team.isTargetBlockExists());}
   case "spots"->{base=g.getTeamOfPlayer(p).getTeamSpawn().clone().add(0,5,0);for(int x=-3;x<=20;x++)for(int z=-3;z<=3;z++)for(int y=-1;y<=3;y++)BlastTurretChecks.block(base.clone().add(x,y,z).getBlock(),y==-1?Material.STONE:Material.AIR);int x=0;for(String name:List.of(p.getName(),args[3],args[4],args[5])){Player actor=Bukkit.getPlayerExact(name);actor.setGameMode(GameMode.SURVIVAL);actor.teleport(base.clone().add(x,0,0));actor.setAllowFlight(true);actor.setFlying(true);x+=4;}}
   case "near"->{Bukkit.getPlayerExact(args[3]).teleport(base.clone().add(Double.parseDouble(args[4]),0,0));}
   case "spectator"->{Player actor=Bukkit.getPlayerExact(args[3]);actor.setGameMode(Boolean.parseBoolean(args[4])?GameMode.SPECTATOR:GameMode.SURVIVAL);actor.setAllowFlight(true);actor.setFlying(true);}
   case "utility"->{call(core("inventories"),"mode",p,false);p.getInventory().setItem(8,new ItemStack(Material.GOLDEN_APPLE,3));}
   case "clean"->{for(var item:p.getWorld().getEntitiesByClass(org.bukkit.entity.Item.class))if(item.getItemStack().getType()==Material.EMERALD)item.remove();}
   case "end"->{g.stop();}
  }
  return out;
 }
}
