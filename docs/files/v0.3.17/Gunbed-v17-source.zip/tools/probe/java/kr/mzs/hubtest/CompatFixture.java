package kr.mzs.hubtest;
import org.bukkit.*;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;
import java.io.File;

/** Private test only: load already-public pack metadata without triggering uploads/builds. */
public final class CompatFixture extends JavaPlugin implements Listener {
    @Override public void onEnable(){if(!Bukkit.getIp().equals("127.0.0.1")||Bukkit.getPort()!=25690)throw new IllegalStateException("Private hub fixture only");Bukkit.getPluginManager().registerEvents(this,this);try{var p=Bukkit.getPluginManager().getPlugin("MZSResourceCompat");var loader=p.getClass().getClassLoader();Class<?> variant=Class.forName("kr.mzs.resourcecompat.MZSResourceCompatPlugin$PackVariant",true,loader),info=Class.forName("kr.mzs.resourcecompat.MZSResourceCompatPlugin$PackInfo",true,loader);var ctor=info.getDeclaredConstructor(variant,String.class,String.class,byte[].class);ctor.setAccessible(true);var field=p.getClass().getDeclaredField("packInfos");field.setAccessible(true);Map map=(Map)field.get(p);var data=YamlConfiguration.loadConfiguration(new File(getDataFolder().getParentFile(),"MZSResourceCompat/lobfile-packs.yml"));for(String key:data.getConfigurationSection("variants").getKeys(false)){Object v=Enum.valueOf((Class)variant,key.toUpperCase(Locale.ROOT));String prefix="variants."+key+".";map.put(v,ctor.newInstance(v,data.getString(prefix+"file"),data.getString(prefix+"url"),HexFormat.of().parseHex(data.getString(prefix+"sha1"))));}getLogger().info("Loaded public compatibility metadata: "+map.size());}catch(Exception e){throw new IllegalStateException(e);}}
    @EventHandler public void status(PlayerResourcePackStatusEvent e){getLogger().info("HUB_PACK "+e.getPlayer().getName()+" "+e.getStatus());}
    @EventHandler(priority=EventPriority.LOWEST)public void first(io.papermc.paper.event.player.AsyncPlayerSpawnLocationEvent e){e.setSpawnLocation(new Location(e.getSpawnLocation().getWorld(),185.5,7,-315.2));}
    @EventHandler public void join(org.bukkit.event.player.PlayerJoinEvent e){
        Bukkit.getScheduler().runTaskLater(this,()->{if(!e.getPlayer().isOnline())return;e.getPlayer().teleport(new Location(Bukkit.getWorld("world"),185.5,7,-315.2));e.getPlayer().getInventory().setItem(2,new org.bukkit.inventory.ItemStack(Material.PAPER));},20);
    }
    @Override public boolean onCommand(org.bukkit.command.CommandSender sender,org.bukkit.command.Command cmd,String label,String[] args){
        if(!(sender instanceof org.bukkit.entity.Player p))return true;
        try{var h=Bukkit.getPluginManager().getPlugin("MZSSharedHub");
            if(args.length>0&&args[0].equals("spawn")){Bukkit.dispatchCommand(Bukkit.getConsoleSender(),"spawn "+p.getName());return true;}
            if(args.length>0&&args[0].equals("reload")){Bukkit.dispatchCommand(Bukkit.getConsoleSender(),"plugman reload MZSSharedHub");return true;}
            var ess=Bukkit.getPluginManager().getPlugin("EssentialsSpawn");Location target=(Location)ess.getClass().getMethod("getSpawn",String.class).invoke(ess,"default");
            Map<String,Object> state=new LinkedHashMap<>();state.put("world",p.getWorld().getName());state.put("entry",h.getClass().getMethod("isEntryPlayer",org.bukkit.entity.Player.class).invoke(h,p));state.put("selected",h.getClass().getMethod("hasSelectedZombie",org.bukkit.entity.Player.class).invoke(h,p));state.put("essentialsWorld",target.getWorld().getName());state.put("items",Arrays.stream(p.getInventory().getContents()).filter(Objects::nonNull).map(i->i.getType().name()).toList());state.put("labels",Bukkit.getWorld("mzs_shared_hub").getEntitiesByClass(org.bukkit.entity.TextDisplay.class).size());p.sendMessage("HUBCHECK "+new com.google.gson.Gson().toJson(state));
        }catch(Exception e){throw new IllegalStateException(e);}return true;
    }
}
