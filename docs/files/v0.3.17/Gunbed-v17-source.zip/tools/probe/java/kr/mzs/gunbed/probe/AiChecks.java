package kr.mzs.gunbed.probe;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.screamingsandals.bedwars.api.*;
import java.util.*;
import static kr.mzs.gunbed.probe.V9Checks.*;
final class AiChecks {
 static final Map<Location,String> restoreExpected=new HashMap<>();
 static Map<String,Object> run(Player p,String[] args)throws ReflectiveOperationException{
  String op=args[2];Map<String,Object> out=new LinkedHashMap<>();out.put("ai",op);Object practice=core("practice");
  if(op.equals("enter")){ClassLoader loader=practice.getClass().getClassLoader();Class<?> d=Class.forName("kr.mzs.gunbed.AiPractice$Difficulty",true,loader),c=Class.forName("kr.mzs.gunbed.AiChallenge",true,loader);call(practice,"enter",p,Enum.valueOf((Class)d,args[3]),Enum.valueOf((Class)c,args[4]));}
  if(op.equals("model")||op.equals("fit")){
   Object learning=core("learning");var g=BedwarsAPI.getInstance().getGameOfPlayer(p);
   if(op.equals("fit")){if(g==null)throw new IllegalStateException("Training arena required");call(learning,"ending",new org.screamingsandals.bedwars.api.events.BedwarsGameEndingEvent(g,g.getTeamOfPlayer(p)));}
   out.put("episodes",call(learning,"episodes"));out.put("features",((Map<?,?>)field(learning,"values")).size());var frozen=(Map<?,?>)field(learning,"frozen");out.put("snapshotFeatures",g==null||!frozen.containsKey(g)?0:((Map<?,?>)frozen.get(g)).size());long samples=0,snapshotSamples=0;for(Object value:((Map<?,?>)field(learning,"values")).values())samples+=(long)field(value,"samples");if(g!=null&&frozen.containsKey(g))for(Object value:((Map<?,?>)frozen.get(g)).values())snapshotSamples+=(long)field(value,"samples");out.put("samples",samples);out.put("snapshotSamples",snapshotSamples);out.put("rawQueue",((Collection<?>)field(learning,"records")).size());out.put("rejected",field(learning,"rejected"));
  }
  if(op.equals("rule")){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);Object room=((Map<?,?>)field(practice,"games")).get(BedwarsAPI.getInstance().getGameOfPlayer(p));var f=room.getClass().getDeclaredField("challenge");f.setAccessible(true);Class<?> type=f.getType();f.set(room,Enum.valueOf((Class)type,args[3]));}
  if(op.equals("rules")){
   Object rules=core("aiRules");out.put("rule",call(rules,"rule",p).toString());out.put("movement",call(rules,"movementSkill",p));out.put("healing",call(rules,"healing",p));out.put("container",call(rules,"container",p));
   Map<String,Boolean> weapons=new LinkedHashMap<>();for(String id:List.of("ta:ak47","cs:망치","cs:나타나이프")){var item=(org.bukkit.inventory.ItemStack)call(core("arsenal"),"create",id);weapons.put(id,(boolean)call(rules,"weaponItem",p,item));}out.put("weapons",weapons);
   out.put("woolBuy",call(rules,"buy",p,"wool",Map.of("products",List.of(Map.of("material","white_wool")))));out.put("diamondBuy",call(rules,"buy",p,"diamond_sword",Map.of("prices",List.of(Map.of("spawner-id","diamond")))));out.put("upgrade",call(rules,"upgrade",p,"sharpness"));
   org.bukkit.inventory.Inventory inv=Bukkit.createInventory(null,36);for(int n=0;n<7;n++)inv.setItem(n,new org.bukkit.inventory.ItemStack(List.of(Material.STONE,Material.COBBLESTONE,Material.DIRT,Material.SAND,Material.OAK_PLANKS,Material.GLASS,Material.OBSIDIAN).get(n)));out.put("sevenFit",call(rules,"compact",p,inv));
  }
  if(op.equals("rule-win")||op.equals("rule-fail")){
   var g=BedwarsAPI.getInstance().getGameOfPlayer(p);Object rules=core("aiRules"),m=((Map<?,?>)field(rules,"matches")).get(g);
   var f=m.getClass().getDeclaredField("failed");f.setAccessible(true);f.set(m,op.equals("rule-fail"));call(rules,"ending",new org.screamingsandals.bedwars.api.events.BedwarsGameEndingEvent(g,g.getTeamOfPlayer(p)));
  }
  if(op.equals("bedbot")){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);((org.screamingsandals.bedwars.game.CurrentTeam)g.getTeamFromName("light_blue")).isBed=false;}
  if(op.equals("split")){
   var g=BedwarsAPI.getInstance().getGameOfPlayer(p);Player ally=Bukkit.getPlayerExact(args[4]),enemy=Bukkit.getPlayerExact(args[5]);String test=args[3];Material material=test.equals("diamond")?Material.DIAMOND:test.equals("emerald")?Material.EMERALD:test.equals("gold")?Material.GOLD_INGOT:Material.IRON_INGOT;
   Object flow=core("flow"),state=((Map<?,?>)field(flow,"games")).get(g),chosen=null;List<?> generators=(List<?>)field(state,"generators");
   for(Object gen:generators){var next=gen.getClass().getDeclaredField("next");next.setAccessible(true);next.setInt(gen,(int)field(state,"ticks")+100000);var pile=(Item)field(gen,"pile");if(pile!=null)pile.remove();var f=gen.getClass().getDeclaredField("pile");f.setAccessible(true);f.set(gen,null);if(chosen==null&&field(gen,"material")==material)chosen=gen;}
   if(chosen==null)throw new IllegalStateException("Missing generator fixture");
   Location at=((Location)field(chosen,"at")).clone();Location feet=at.clone().add(0,.35,0);p.teleport(feet);ally.teleport(feet.clone().add(test.equals("far")?5:.7,0,0));enemy.teleport(feet.clone().add(0,0,.7));
   for(Player player:List.of(p,ally,enemy)){call(core("wallet"),"clear",player);player.setGameMode(GameMode.SURVIVAL);Object bank=((Map<?,?>)field(core("inventories"),"states")).get(player.getUniqueId());var f=bank.getClass().getDeclaredField("locked");f.setAccessible(true);f.setBoolean(bank,false);}
   for(Player extra:g.getConnectedPlayers())if(extra!=p&&extra!=ally&&extra!=enemy){extra.teleport(test.equals("all")?feet.clone().add(-.5,0,.5):feet.clone().add(6,0,6));call(core("wallet"),"clear",extra);}
   if(test.equals("spectator"))ally.setGameMode(GameMode.SPECTATOR);
   if(test.equals("locked")){Object bank=((Map<?,?>)field(core("inventories"),"states")).get(ally.getUniqueId());var f=bank.getClass().getDeclaredField("locked");f.setAccessible(true);f.setBoolean(bank,true);}
   Item drop=at.getWorld().dropItem(at,new org.bukkit.inventory.ItemStack(material,5));drop.setPickupDelay(0);drop.setGravity(false);BedwarsAPI.getInstance().registerEntityToGame(drop,g);
   if(!test.equals("manual")){var f=chosen.getClass().getDeclaredField("pile");f.setAccessible(true);f.set(chosen,drop);drop.getPersistentDataContainer().set(new NamespacedKey("gunbedcore","generator_pile"),org.bukkit.persistence.PersistentDataType.BYTE,(byte)1);}
   var event=new org.bukkit.event.entity.EntityPickupItemEvent(p,drop,0);Bukkit.getPluginManager().callEvent(event);Bukkit.getPluginManager().callEvent(new org.bukkit.event.entity.EntityPickupItemEvent(ally,drop,0));
   out.put("collector",call(core("wallet"),"amount",p,material));out.put("ally",call(core("wallet"),"amount",ally,material));out.put("enemy",call(core("wallet"),"amount",enemy,material));Map<String,Long> teamAmounts=new LinkedHashMap<>();for(Player member:g.getTeamOfPlayer(p).getConnectedPlayers())teamAmounts.put(member.getName(),(long)call(core("wallet"),"amount",member,material));out.put("teamAmounts",teamAmounts);out.put("type",test);out.put("detached",field(chosen,"pile")==null);
   if(test.equals("race")){var f=chosen.getClass().getDeclaredField("next");f.setAccessible(true);f.setInt(chosen,(int)field(state,"ticks")+1);call(flow,"tick");Item next=(Item)field(chosen,"pile");out.put("nextPile",next!=null&&!next.getUniqueId().equals(drop.getUniqueId())&&next.getItemStack().getAmount()==1);}
  }
  if(op.equals("nearbot")){Object r=((Map<?,?>)field(practice,"games")).get(BedwarsAPI.getInstance().getGameOfPlayer(p));var list=(List<?>)field(r,"bots");Player bot=(Player)call(list.getFirst(),"getPlayer");double distance=args.length>3?Double.parseDouble(args[3]):6;var at=bot.getLocation().clone().add(0,0,-distance);if(distance>10){boolean found=false;for(int n=0;n<64;n++){double angle=n*Math.PI/32;var candidate=bot.getLocation().clone().add(Math.cos(angle)*distance,0,Math.sin(angle)*distance);var delta=candidate.clone().add(0,bot.getEyeHeight(),0).toVector().subtract(bot.getEyeLocation().toVector());if(!candidate.getBlock().isPassable()||!candidate.clone().add(0,1,0).getBlock().isPassable())continue;if(bot.getWorld().rayTraceBlocks(bot.getEyeLocation(),delta.normalize(),distance,FluidCollisionMode.NEVER,true)==null){at=candidate;found=true;break;}}if(!found)throw new IllegalStateException("No clear long-range fixture ray");}for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++){var block=at.clone().add(x,-1,z).getBlock();var g=BedwarsAPI.getInstance().getGameOfPlayer(p);g.getRegion().putOriginalBlock(block.getLocation(),block.getState());block.setType(Material.STONE,false);}p.teleport(at);out.put("hp",p.getHealth());out.put("lineOfSight",bot.hasLineOfSight(p));out.put("distance",bot.getLocation().distance(at));}
  if(op.equals("health"))out.put("hp",p.getHealth());
  if(op.equals("voidbot")){Object r=((Map<?,?>)field(practice,"games")).get(BedwarsAPI.getInstance().getGameOfPlayer(p));var list=(List<?>)field(r,"bots");Player bot=(Player)call(list.getFirst(),"getPlayer");bot.teleport(bot.getLocation().clone().add(0,-80,0));}
  if(op.equals("click")){int slot=Integer.parseInt(args[3]);var e=new org.bukkit.event.inventory.InventoryClickEvent(p.getOpenInventory(),org.bukkit.event.inventory.InventoryType.SlotType.CONTAINER,slot,org.bukkit.event.inventory.ClickType.LEFT,org.bukkit.event.inventory.InventoryAction.PICKUP_ALL);Bukkit.getPluginManager().callEvent(e);}
  if(op.equals("avatar")){
   var labels=(Map<UUID,TextDisplay>)field(core("tags"),"labels");TextDisplay own=labels.get(p.getUniqueId());out.put("selfVisible",own!=null&&p.canSee(own));out.put("defaultVisible",own!=null&&own.isVisibleByDefault());
   List<Object> rows=new ArrayList<>();for(Player bot:Bukkit.getOnlinePlayers())if(bot.getScoreboardTags().contains("mzs_ai"))rows.add(Map.of("name",bot.getName(),"armor",Arrays.stream(bot.getInventory().getArmorContents()).map(i->i==null?"AIR":i.getType().name()).toList(),"labelVisible",labels.containsKey(bot.getUniqueId())&&p.canSee(labels.get(bot.getUniqueId()))));out.put("bots",rows);
  }
  if(op.equals("stripbot")){for(Player bot:Bukkit.getOnlinePlayers())if(bot.getScoreboardTags().contains("mzs_ai"))bot.getInventory().setArmorContents(new org.bukkit.inventory.ItemStack[4]);}
  if(op.equals("cage")){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);var centre=g.getLobbySpawn().getBlock();int missing=0,total=0;for(int x=-8;x<=8;x++)for(int z=-8;z<=8;z++)for(int y=-1;y<=5;y++)if(y==-1||y==5||Math.abs(x)==8||Math.abs(z)==8){total++;if(centre.getRelative(x,y,z).isEmpty())missing++;}out.put("cells",total);out.put("missing",missing);}
  if(op.equals("killsound")){Player victim=Bukkit.getOnlinePlayers().stream().filter(b->b.getScoreboardTags().contains("mzs_ai")).map(b->(Player)b).findFirst().orElse(p);call(core("cosmetics"),"killed",p,victim,false);}
  if(op.equals("voteledger")||op.equals("votesignal")){
   Object ledger=core("points");Class<?> c=Class.forName("kr.mzs.gunbed.PointLedger$Currency",true,ledger.getClass().getClassLoader());
   if(op.equals("votesignal"))try{var path=Bukkit.getPluginManager().getPlugin("GunbedCore").getDataFolder().toPath().resolve("v17-shared-fixture.db");if(Bukkit.getPort()!=25688)throw new IllegalStateException("Private backend required");try(var db=java.sql.DriverManager.getConnection("jdbc:sqlite:"+path);var q=db.prepareStatement("INSERT INTO profile_counters(uuid,votes) VALUES(?,1) ON CONFLICT(uuid) DO UPDATE SET votes=votes+1")){q.setString(1,p.getUniqueId().toString());q.executeUpdate();}try(var db=java.sql.DriverManager.getConnection("jdbc:sqlite:"+path);var q=db.prepareStatement("INSERT OR REPLACE INTO players(uuid,name) VALUES(?,?)")){q.setString(1,p.getUniqueId().toString());q.setString(2,p.getName());q.executeUpdate();}}catch(java.sql.SQLException e){throw new IllegalStateException(e);}
   out.put("votes",call(ledger,"votes",p.getUniqueId()));out.put("points",call(ledger,"balance",p.getUniqueId(),Enum.valueOf((Class)c,"RECOMMEND")));
  }
  if(op.equals("flow"))call(core("controls"),"play",p);
  if(op.equals("arenas"))call(core("bedwars"),"openArenas",p,0);
  if(op.equals("category"))call(core("cosmetics"),"category",p,args[3],args[4]);
  if(op.equals("shopstate")||op.equals("fund")){
   Object ledger=core("points");Class<?> c=Class.forName("kr.mzs.gunbed.PointLedger$Currency",true,ledger.getClass().getClassLoader());
   if(op.equals("fund")){if(!p.getName().startsWith("GBProbe"))throw new IllegalArgumentException("Test only");call(ledger,"change",p.getUniqueId(),Enum.valueOf((Class)c,"DONATION"),100000L,"private-test");call(ledger,"change",p.getUniqueId(),Enum.valueOf((Class)c,"RECOMMEND"),1000L,"private-test");}
   out.put("donation",call(ledger,"balance",p.getUniqueId(),Enum.valueOf((Class)c,"DONATION")));out.put("recommend",call(ledger,"balance",p.getUniqueId(),Enum.valueOf((Class)c,"RECOMMEND")));
   out.put("owned",call(ledger,"owns",p.getUniqueId(),args.length>3?args[3]:"upgrade:loadout-slots"));
  }
  if(op.equals("leave")){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(g!=null)g.leaveFromGame(p);}
  if(op.equals("reset")){var g=BedwarsAPI.getInstance().getGameOfPlayer(p);if(g!=null){restoreExpected.clear();for(Object value:(Collection<?>)field(g.getRegion(),"builtBlocks"))restoreExpected.put(((Location)value).clone(),"minecraft:air");for(var e:((Map<Location,org.bukkit.block.data.BlockData>)field(g.getRegion(),"brokenOriginalBlocks")).entrySet())restoreExpected.put(e.getKey().clone(),e.getValue().getAsString());call(core("recovery"),"reset",g);out.put("queuedBlocks",restoreExpected.size());}}
  if(op.equals("restored")){out.put("blocks",restoreExpected.size());out.put("remaining",restoreExpected.entrySet().stream().filter(e->!e.getKey().getBlock().getBlockData().getAsString().equals(e.getValue())).count());}
  if(op.equals("maps"))call(practice,"maps",p);
  if(op.equals("progress-reset")){
   if(!p.getName().startsWith("GBProbe"))throw new IllegalArgumentException("Private test account required");
   call(core("profiles"),"set",p.getUniqueId(),"ai-challenges.completed",null);
  }
  if(op.equals("complete")){
   if(!p.getName().startsWith("GBProbe"))throw new IllegalArgumentException("Private test account required");
   Class<?> c=Class.forName("kr.mzs.gunbed.AiChallenge",true,practice.getClass().getClassLoader());
   call(practice,"recordCompletion",p.getUniqueId(),Enum.valueOf((Class)c,args[3]));
  }
  if(op.equals("progress")||op.equals("complete")||op.equals("progress-reset")){
   Object progress=call(practice,"progress",p.getUniqueId());out.put("completed",call(progress,"saved"));
   Class<?> c=Class.forName("kr.mzs.gunbed.AiChallenge",true,practice.getClass().getClassLoader());
   List<String> open=new ArrayList<>();for(Object challenge:c.getEnumConstants())if((boolean)call(challenge,"original")&&(boolean)call(progress,"canSelect",challenge))open.add(((Enum<?>)challenge).name());
   out.put("openOriginal",open);out.put("saved",call(core("profiles"),"saved"));
  }
  if(op.equals("challenges")){
   Class<?> d=Class.forName("kr.mzs.gunbed.AiPractice$Difficulty",true,practice.getClass().getClassLoader());
   call(practice,"challenges",p,Enum.valueOf((Class)d,"EASY"));
   Map<String,String> icons=new LinkedHashMap<>();Class<?> c=Class.forName("kr.mzs.gunbed.AiChallenge",true,practice.getClass().getClassLoader());
   for(Object challenge:c.getEnumConstants()){var item=p.getOpenInventory().getTopInventory().getItem(((Enum<?>)challenge).ordinal());icons.put(((Enum<?>)challenge).name(),item==null?"AIR":item.getType().name());}out.put("icons",icons);
  }
  if(op.equals("status")){var api=BedwarsAPI.getInstance();var g=api.getGameOfPlayer(p);out.put("arena",g==null?"none":g.getName());out.put("status",g==null?"none":g.getStatus().name());out.put("learningEpisodes",call(core("learning"),"episodes"));Object active=field(practice,"active");out.put("host",active==null?"none":Objects.toString(field(active,"host")));out.put("initialHumans",active==null?0:field(active,"initialHumans"));out.put("difficulty",active==null?"none":field(active,"difficulty").toString());out.put("challenge",active==null?"none":field(active,"challenge").toString());out.put("coreTps",Bukkit.getTPS()[0]);List<Map<String,Object>> bots=new ArrayList<>();for(Player b:Bukkit.getOnlinePlayers())if(b.getScoreboardTags().contains("mzs_ai")){Map<String,Object> row=new LinkedHashMap<>();row.put("name",b.getName());row.put("uuid",b.getUniqueId().toString());row.put("position",List.of(b.getX(),b.getY(),b.getZ()));row.put("health",b.getHealth());row.put("mode",b.getGameMode().name());row.put("arena",api.getGameOfPlayer(b)==null?"none":api.getGameOfPlayer(b).getName());row.put("team",api.getGameOfPlayer(b)==null||api.getGameOfPlayer(b).getTeamOfPlayer(b)==null?"none":api.getGameOfPlayer(b).getTeamOfPlayer(b).getName());row.put("action",call(field(practice,"brain"),"action",b));row.put("resources",call(core("wallet"),"snapshot",b));row.put("brain",call(field(practice,"brain"),"describe",b));row.put("held",call(core("ammo"),"id",b.getInventory().getItemInMainHand()));row.put("woolPlaced",g==null?0:b.getWorld().getEntitiesByClass(Item.class).size());row.put("inventory",Arrays.stream(b.getInventory().getStorageContents()).filter(Objects::nonNull).map(i->i.getType().name()+":"+i.getAmount()).toList());if(active!=null&&((Collection<?>)field(active,"bots")).size()>2)for(String key:List.of("inventory","brain","mode","arena","held","woolPlaced","uuid"))row.remove(key);bots.add(row);}out.put("bots",bots);out.put("team",g==null||g.getTeamOfPlayer(p)==null?"none":g.getTeamOfPlayer(p).getName());out.put("world",p.getWorld().getName());}
  if(Set.of("ui","category","maps","flow","arenas","click").contains(op)){out.put("title",p.getOpenInventory().getTitle());Map<String,String> slots=new LinkedHashMap<>();for(int n=0;n<p.getOpenInventory().getTopInventory().getSize();n++){var item=p.getOpenInventory().getTopInventory().getItem(n);if(item!=null)slots.put(""+n,item.getType().name()+":"+(item.hasItemMeta()?item.getItemMeta().getDisplayName():""));}out.put("slots",slots);}
  return out;
 }
}
