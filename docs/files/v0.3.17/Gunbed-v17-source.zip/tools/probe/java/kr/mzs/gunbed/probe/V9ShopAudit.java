package kr.mzs.gunbed.probe;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import java.util.*;
import static kr.mzs.gunbed.probe.V9Checks.*;
final class V9ShopAudit {
 static Map<String,Object> run(Player p)throws ReflectiveOperationException{
  var g=org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getGameOfPlayer(p);Object shop=field(core("bedwars"),"shop");List<Map<String,Object>> rows=new ArrayList<>();List<String> failures=new ArrayList<>();Object wallet=core("wallet"),banks=core("inventories");
  for(Object entry:(List<?>)call(shop,"entries")){
   Map<?,?> item=(Map<?,?>)field(entry,"item");String id=(String)call(shop,"entryId",entry);if(item.containsKey("turret-kind")||item.containsKey("throwable-kind")||item.containsKey("special-action"))continue;
   call(banks,"mode",p,false);call(banks,"utility",p,new ItemStack[36]);
   for(Material type:List.of(Material.IRON_INGOT,Material.GOLD_INGOT,Material.DIAMOND,Material.EMERALD))call(wallet,"set",p,type,100000L);
   Map<?,?> resolved=(Map<?,?>)call(shop,"resolved",p,g,item);List<?> cost=(List<?>)call(shop,"costs",resolved.get("prices"),g);
   ItemStack icon=(ItemStack)call(shop,"entryIcon",p,g,entry);if(!icon.hasItemMeta()||!icon.getItemMeta().hasLore())failures.add(id+" missing description");
   call(shop,"buy",p,g,item,id);long spent=0;for(Object value:cost){ItemStack stack=(ItemStack)value;long after=(long)call(wallet,"amount",p,stack.getType());spent+=100000-after;if(after!=100000-stack.getAmount())failures.add(id+" wrong cost "+stack.getType()+" "+after);}
   rows.add(Map.of("id",id,"spent",spent,"icon",icon.getType().name()));p.closeInventory();
  }
  // Exercise each upgrade level using its normal purchasing method and real wallet.
  var upgrades=(Map<String,?>)field(shop,"upgrades");List<String> levels=new ArrayList<>();for(String name:upgrades.keySet()){
   // Isolate trap queues so all four trap types can be purchased and tested.
   Object teamState=call(shop,"state",g,g.getTeamOfPlayer(p));((Deque<?>)field(teamState,"traps")).clear();
   for(int n=0;n<5;n++){Object level=call(shop,"nextUpgrade",g,g.getTeamOfPlayer(p),name);if(level==null)break;call(wallet,"set",p,Material.DIAMOND,100000L);int price=(int)call(shop,"upgradePrice",g,g.getTeamOfPlayer(p),name,level);call(shop,"buyUpgrade",p,g,name);long after=(long)call(wallet,"amount",p,Material.DIAMOND);if(after!=100000-price)failures.add(name+" wrong upgrade charge");levels.add(name+":"+(n+1));p.closeInventory();if(name.endsWith("trap"))break;}
  }
  var result=Map.of("v9","shopaudit","items",rows,"upgradeLevels",levels,"failures",failures);try{java.nio.file.Files.writeString(java.nio.file.Path.of("../../reports/shop-audit-v9.json"),new com.google.gson.Gson().toJson(result));}catch(java.io.IOException error){throw new IllegalStateException(error);}return Map.of("v9","shopaudit","items",rows.size(),"levels",levels.size(),"failures",failures);
 }
}
