package kr.mzs.gunbed.probe;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.event.block.*;
import java.util.*;
import static kr.mzs.gunbed.probe.V9Checks.*;
final class V10Checks {
 static Map<String,Object> run(Player p,String[] args)throws ReflectiveOperationException{
  String action=args[2];var g=org.screamingsandals.bedwars.api.BedwarsAPI.getInstance().getGameOfPlayer(p);Map<String,Object> out=new LinkedHashMap<>();out.put("v10",action);
  switch(action){
   case "zones"->{List<String> failures=new ArrayList<>();Object volumes=core("volumes");boolean op=p.isOp();GameMode mode=p.getGameMode();int checked=0,overlaps=0;try{p.setOp(false);p.setGameMode(GameMode.SURVIVAL);List<Location> centers=new ArrayList<>();g.getItemSpawners().forEach(s->centers.add(s.getLocation()));g.getGameStores().forEach(s->centers.add(s.getStoreLocation()));for(Location center:centers){for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)for(int z=-1;z<=1;z++){Location at=center.getBlock().getLocation().add(x,y,z);boolean bed=(boolean)call(volumes,"bedArea",g,at),allowed=(boolean)call(volumes,"allow",g,at,p);if(allowed!=bed)failures.add("real cube "+at);checked++;if(bed)overlaps++;}if((boolean)call(volumes,"inside",center.clone().add(2,0,0),center))failures.add("3 cube includes +2");if((boolean)call(volumes,"inside",center.clone().add(-2,0,0),center))failures.add("3 cube includes -2");}
    Location bed=g.getTeamOfPlayer(p).getTargetBlock();var source=(org.screamingsandals.bedwars.game.ItemSpawner)g.getItemSpawners().getFirst();Location oldSource=source.loc;Object store=g.getGameStores().getFirst();Location storeLoc=(Location)field(store,"loc"),oldStore=storeLoc.clone();source.loc=bed.clone();storeLoc.setX(bed.getX());storeLoc.setY(bed.getY());storeLoc.setZ(bed.getZ());try{for(int x=-2;x<=2;x++)for(int y=-2;y<=2;y++)for(int z=-2;z<=2;z++){Location at=bed.clone().add(x,y,z);if(!(boolean)call(volumes,"allow",g,at,p))failures.add("bed loses to generator/shop");checked++;}Location at=bed.clone().add(0,2,0);var block=at.getBlock();var original=block.getState();try{if(!block.isEmpty())throw new IllegalStateException("Fixture above bed occupied");call(field(core("bedwars"),"shop"),"build",g,p,at);if(!block.getType().name().endsWith("_WOOL"))failures.add("bridge rejects protected-overlap bed defence");}finally{g.getRegion().removeBlockBuiltDuringGame(at);original.update(true,false);}}finally{source.loc=oldSource;storeLoc.setX(oldStore.getX());storeLoc.setY(oldStore.getY());storeLoc.setZ(oldStore.getZ());}
    Location center=g.getItemSpawners().getFirst().getLocation();p.setOp(true);p.setGameMode(GameMode.CREATIVE);if(!(boolean)call(volumes,"allow",g,center,p))failures.add("editor denied");out.put("centers",centers.size());out.put("checks",checked);out.put("actualOverlapCells",overlaps);
   }finally{p.setOp(op);p.setGameMode(mode);}out.put("failures",failures);}
   case "arrow"->{Player target=Bukkit.getPlayerExact(args[3]);boolean power=Boolean.parseBoolean(args[4]);var bow=new ItemStack(Material.BOW);var meta=bow.getItemMeta();meta.getPersistentDataContainer().set(new NamespacedKey("gunbedcore","bow_damage"),org.bukkit.persistence.PersistentDataType.DOUBLE,power?8000.0:5000.0);bow.setItemMeta(meta);p.getInventory().setItemInMainHand(bow);var arrow=p.launchProjectile(Arrow.class,p.getEyeLocation().getDirection().multiply(1.6));arrow.setGravity(false);arrow.setCritical(false);var shoot=new org.bukkit.event.entity.EntityShootBowEvent(p,bow,new ItemStack(Material.ARROW),arrow,EquipmentSlot.HAND,1f,true);Bukkit.getPluginManager().callEvent(shoot);out.put("power",power);out.put("before",target.getHealth());}
  }
  return out;
 }
}
