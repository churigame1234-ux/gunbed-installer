package kr.mzs.hubtest;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
/** Test-only contract for the reviewed MZSProfile lobby interface. */
public final class ProfileFixture extends JavaPlugin {
    private final Lobby lobby=new Lobby();
    private Lobby lobby(){return lobby;}
    public static final class Lobby {private void enterLobby(Player p){p.getInventory().setItem(4,new ItemStack(Material.PAPER));}}
    @Override public void onEnable(){if(Bukkit.getPort()!=25690)throw new IllegalStateException("Fixture port only");}
}
