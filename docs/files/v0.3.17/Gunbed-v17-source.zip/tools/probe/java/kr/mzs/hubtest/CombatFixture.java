package kr.mzs.hubtest;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
/** Test-only contract for the reviewed MZSCombat lobby-item interface. */
public final class CombatFixture extends JavaPlugin {
    private final Items lobbyItemManager=new Items();
    public static final class Items {
        public int resets;
        public void resetLobby(Player p){resets++;p.getInventory().clear();for(int n=0;n<4;n++){ItemStack i=new ItemStack(Material.PAPER);var m=i.getItemMeta();m.setDisplayName("Zombie lobby "+n);i.setItemMeta(m);p.getInventory().setItem(n,i);}}
    }
    @Override public void onEnable(){if(Bukkit.getPort()!=25690)throw new IllegalStateException("Fixture port only");World w=Bukkit.getWorld("world");for(int x=181;x<=190;x++)for(int z=-320;z<=-310;z++)w.getBlockAt(x,6,z).setType(Material.STONE,false);}
}
