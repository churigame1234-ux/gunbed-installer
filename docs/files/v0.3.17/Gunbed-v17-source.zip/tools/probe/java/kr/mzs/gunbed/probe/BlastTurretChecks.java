package kr.mzs.gunbed.probe;
import java.util.*;
import java.nio.file.*;
import org.bukkit.*;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.*;
import org.screamingsandals.bedwars.api.BedwarsAPI;
import static kr.mzs.gunbed.probe.V9Checks.*;

final class BlastTurretChecks {
 static String yamlBackup;
 static void set(Object o,String name,Object value)throws Exception{var f=o.getClass().getDeclaredField(name);f.setAccessible(true);f.set(o,value);}
 static Object sc(String c,String m,Object...args)throws Exception{return TrackerReloadChecks.staticCall(c,m,args);}
 static void block(org.bukkit.block.Block b,Material m)throws Exception{sc("LegacyActions","recordBlock",b);b.setType(m,false);}
 static void ready(Player p)throws Exception{V13Checks.gProtect(p);p.setInvulnerable(false);p.setNoDamageTicks(0);p.setGameMode(GameMode.SURVIVAL);p.getInventory().setArmorContents(null);p.getAttribute(Attribute.MAX_HEALTH).setBaseValue(10000);p.setHealth(10000);p.setAbsorptionAmount(0);for(var fx:p.getActivePotionEffects())p.removePotionEffect(fx.getType());p.setAllowFlight(true);p.setFlying(true);}
 static Map<String,Object> run(Player p,String[] args)throws Exception{
  var plugin=Bukkit.getPluginManager().getPlugin("GunbedCore");var g=BedwarsAPI.getInstance().getGameOfPlayer(p);String action=args[2];Map<String,Object> out=new LinkedHashMap<>();out.put("btt",action);
  switch(action){
   case "blast"->{Player enemy=Bukkit.getPlayerExact(args[3]);String variant=args[4];ready(enemy);Location base=g.getTeamOfPlayer(p).getTeamSpawn().clone().add(0,5,0);base.setX(base.getBlockX()+.5);base.setY(base.getBlockY());base.setZ(base.getBlockZ()+.5);for(int x=-2;x<=7;x++)for(int z=-2;z<=2;z++)for(int y=-1;y<=4;y++)block(base.clone().add(x,y,z).getBlock(),y==-1?Material.STONE:Material.AIR);
    if(variant.equals("step"))block(base.clone().add(2,0,0).getBlock(),Material.STONE);if(variant.equals("wall"))for(int z=-2;z<=2;z++)for(int y=0;y<=4;y++)block(base.clone().add(1,y,z).getBlock(),Material.STONE);
    enemy.teleport(base.clone().add(variant.equals("far")?6:2,variant.equals("step")?1:0,0));Location raw=base.clone().subtract(0,.00001,0),origin=(Location)sc("BlastExposure","impact",raw,base.clone().subtract(0,1,0).getBlock(),BlockFace.UP);out.put("originY",origin.getY()-base.getY());double distance=(double)sc("BlastExposure","distance",origin,enemy,3d);out.put("distance",Double.isFinite(distance)?distance:"blocked");double before=enemy.getHealth();Object explosive=Arrays.stream(com.shampaggon.crackshot.events.WeaponShootEvent.getHandlerList().getRegisteredListeners()).map(l->l.getListener()).filter(l->l.getClass().getSimpleName().equals("ExplosiveRounds")).findFirst().orElseThrow();call(explosive,"blast",p,"소드오프",origin);out.put("damage",before-enemy.getHealth());}
   case "death"->{ready(p);String cause=args[3];var f=Class.forName("kr.mzs.gunbed.RoundFalls",true,plugin.getClass().getClassLoader()).getDeclaredField("APPLYING");f.setAccessible(true);ThreadLocal<Boolean> guard=(ThreadLocal<Boolean>)f.get(null);guard.set(true);try{p.damage(50000,org.bukkit.damage.DamageSource.builder(cause.equals("fall")?org.bukkit.damage.DamageType.FALL:org.bukkit.damage.DamageType.OUT_OF_WORLD).build());}finally{guard.remove();}out.put("dead",p.isDead());out.put("target",((Map<?,?>)field(core("tracker"),"targets")).containsKey(p.getUniqueId()));}
   case "trackdebug"->{var targets=(Map<UUID,UUID>)field(core("tracker"),"targets");UUID id=targets.get(p.getUniqueId());Player target=id==null?null:Bukkit.getPlayer(id);out.put("target",id==null?"":id.toString());out.put("mode",p.getGameMode().name());out.put("sameGame",target!=null&&g==BedwarsAPI.getInstance().getGameOfPlayer(target));sc("TrackerStatus","tick",plugin,targets);p.sendActionBar(net.kyori.adventure.text.Component.text("TRACKER-PROBE"));}
   case "indices"->{var inv=p.getOpenInventory().getTopInventory();Map<String,Integer> indices=new HashMap<>();for(int n=0;n<45;n++){var item=inv.getItem(n);if(item!=null&&item.getItemMeta() instanceof org.bukkit.inventory.meta.SkullMeta meta&&meta.getOwningPlayer()!=null)indices.put(meta.getOwningPlayer().getName(),n);}out.put("indices",indices);}
   case "healwrite"->{Path file=plugin.getDataFolder().toPath().resolve("damage.yml");yamlBackup=Files.readString(file);var yaml=org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(file.toFile());for(String key:List.of("minimum","maximum","critical-minimum","critical-maximum"))yaml.set("turrets.healing."+key,666);yaml.save(file.toFile());}
   case "healrestore"->{Files.writeString(plugin.getDataFolder().toPath().resolve("damage.yml"),yamlBackup);}
   case "turrets"->{Object engine=core("turrets");Class<?> build=Class.forName("kr.mzs.gunbed.MatchTurrets$Build",true,engine.getClass().getClassLoader());var constructor=build.getDeclaredConstructors()[0];constructor.setAccessible(true);Player enemy=Bukkit.getPlayerExact(args[3]);List<Map<String,Object>> samples=new ArrayList<>();Location base=g.getTeamOfPlayer(p).getTeamSpawn().clone().add(0,5,0);
    for(int x=-6;x<=6;x++)for(int z=-6;z<=6;z++)for(int y=0;y<3;y++)block(base.clone().add(x,y,z).getBlock(),Material.AIR);
    for(String kind:List.of("burst","slowness","healing","siege")){p.getInventory().setItem(0,(ItemStack)call(engine,"item",kind));p.getInventory().setHeldItemSlot(0);call(engine,"finish",p,constructor.newInstance(g,kind,p.getLocation(),base,0,Bukkit.getCurrentTick()));Object t=((Map<?,?>)field(engine,"placed")).values().stream().filter(q->{try{return field(q,"kind").equals(kind);}catch(Exception e){throw new RuntimeException(e);}}).findFirst().orElseThrow();ItemDisplay model=(ItemDisplay)field(t,"model");Player target=kind.equals("healing")?p:enemy;ready(target);target.setHealth(8000);
     for(int side=0;side<4;side++){double angle=side*Math.PI/2;target.teleport(base.clone().add(Math.sin(angle)*4,0,Math.cos(angle)*4));for(int n=0;n<35;n++)call(engine,"aim",t,n);org.bukkit.util.Vector forward=(org.bukkit.util.Vector)sc("TurretGeometry","forward",model,kind),direction=target.getLocation().toVector().subtract(base.toVector()).setY(0).normalize();double dot=forward.dot(direction);out.put("lastDot",dot);if(dot<.985)throw new IllegalStateException(kind+" bad yaw "+side+" "+dot);}
     double before=target.getHealth();call(engine,"shoot",t,target);if(kind.equals("healing")){out.put("healed",target.getHealth()-before);}else{var shots=(List<?>)field(engine,"shots");Object shot=shots.get(shots.size()-1);Location from=(Location)field(shot,"at");Location muzzle=(Location)sc("TurretGeometry","muzzle",model,kind,field(t,"aimPitch"));samples.add(Map.of("kind",kind,"muzzleError",from.distance(muzzle)));for(Object s:List.copyOf(shots))((Entity)field(s,"image")).remove();shots.clear();}call(engine,"remove",t);
    }out.put("samples",samples);}
  }return out;
 }
}
