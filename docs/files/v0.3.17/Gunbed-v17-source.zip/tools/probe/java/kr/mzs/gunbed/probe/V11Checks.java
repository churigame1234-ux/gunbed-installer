package kr.mzs.gunbed.probe;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.*;

final class V11Checks {
 static Object core(String n)throws ReflectiveOperationException{return V9Checks.core(n);}
 static Object call(Object o,String n,Object...v)throws ReflectiveOperationException{return V9Checks.call(o,n,v);}
 static Map<String,Object> run(Player p,String[] args)throws ReflectiveOperationException{
  Map<String,Object> out=new LinkedHashMap<>();String action=args[2];out.put("v11",action);
  switch(action){
   case "audit"->{List<String> failures=new ArrayList<>();List<Map<String,Object>> rows=new ArrayList<>();var arsenal=core("arsenal");for(Object weapon:(Collection<?>)call(arsenal,"weapons")){String id=(String)call(weapon,"id");ItemStack item=(ItemStack)call(arsenal,"create",id);if(item==null){failures.add(id+" null");continue;}List<String> lore=item.getItemMeta().getLore();if(id.startsWith("ta:")||id.startsWith("cs:")){if(lore==null||lore.stream().noneMatch(s->s.contains("RPM"))||lore.stream().noneMatch(s->s.contains("반동")))failures.add(id+" missing specifications");}String role=(String)call(weapon,"role");String category=role.equals("primary")?(String)call(arsenal,"category",id):role;if(role.equals("primary")&&!Set.of("rifle","shotgun","sniper").contains(category))failures.add(id+" wrong category "+category);rows.add(Map.of("id",id,"category",category,"lore",lore==null?List.of():lore));}try{java.nio.file.Files.writeString(java.nio.file.Path.of("../../reports/weapon-specifications-v11.json"),new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(rows));}catch(java.io.IOException error){throw new IllegalStateException(error);}out.put("weapons",rows.size());out.put("ta",((Collection<?>)call(core("taWeapons"),"definitions")).size());out.put("failures",failures);}
   case "equip"->{String id=args[3];p.getInventory().clear();ItemStack item=(ItemStack)call(core("taWeapons"),"create",id);p.getInventory().setHeldItemSlot(0);p.getInventory().setItem(0,item);p.setGameMode(GameMode.CREATIVE);p.setAllowFlight(true);p.setFlying(true);out.put("id",id);out.put("loaded",call(core("taWeapons"),"loaded",item));}
   case "ammo"->{Object ta=core("taWeapons"),d=call(ta,"held",p);if(args.length>3)call(ta,"ammo",p,d,Integer.parseInt(args[3]));out.put("loaded",call(ta,"ammo",p));out.put("capacity",call(ta,"capacity",d));out.put("id",call(d,"id"));out.put("reload",call(ta,"reloadSeconds",d,true));out.put("lore",p.getInventory().getItemInMainHand().getItemMeta().getLore());}
   case "favorites"->{call(core("arsenal"),"favorites",p);out.put("title",p.getOpenInventory().getTitle());}
  }
  return out;
 }
}
