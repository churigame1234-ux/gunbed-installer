"""Repair addon motion/sound aliases and make every kill-feed item self-contained."""
import copy,json,hashlib,shutil
from pathlib import Path
import numpy as np
import subprocess,concurrent.futures,imageio_ffmpeg
from server_audit import ROOT,STAGE,dump

R=ROOT/'client/src/main/resources'
catalog=R/'assets/tacz/gunbed_catalog.json'
client=json.loads(catalog.read_text(encoding='utf8'))
serverpath=ROOT/'src/main/resources/tacz-catalog.json'
server=json.loads(serverpath.read_text(encoding='utf8'))
report={'success':False,'melee_clips':[],'icons':[],'audio':[],'fallback_shots':[]}

# The original packs name their swings melee_1/2, whereas the protocol uses attack_left/right.
for id,d in client['guns'].items():
    if not id.startswith('lr_delta_'):continue
    path=R/d['animation'];raw=json.loads(path.read_text(encoding='utf8'));clips=raw['animations']
    for canonical,source in [('attack_left','melee_1'),('attack_right','melee_2')]:
        assert source in clips,(id,source)
        clips[canonical]=copy.deepcopy(clips[source])
        d.setdefault('clips',{})[canonical]={'duration':clips[source].get('animation_length',.5),'sound_effects':clips[source].get('sound_effects',{})}
    dump(path,raw);report['melee_clips'].append(id)

events={}
for p in (R/'assets').glob('*/sounds.json'):
    events.update({p.parent.name+':'+k:v for k,v in json.loads(p.read_text(encoding='utf8')).items()})

for id,d in client['guns'].items():
    if 'display' not in d:continue
    aliases=d.setdefault('soundAliases',{})
    for ref in d['display'].get('sounds',{}).values():
        if not isinstance(ref,str) or not ref:continue
        ns,path=ref.split(':',1) if ':' in ref else ('tacz',ref)
        candidate=ns+':gunbed.'+path.replace('/','.')
        if ref not in aliases:
            if candidate in events:aliases[ref]=candidate
            elif ref in events:aliases[ref]=ref
    if id in server['guns']:
        shoot=d['display'].get('sounds',{}).get('shoot','')
        if shoot and shoot not in aliases:
            # v1.2 WAT occasionally references a newer default pack sound absent from v1.1.
            role=d.get('type','rifle');base={'pistol':'glock_17','sniper':'awp','shotgun':'db_long','rpg':'rpg7'}.get(role,'ak47')
            fallback=client['guns'].get(base,client['guns']['ak47']);ref=fallback['display']['sounds']['shoot'];resolved=fallback.get('soundAliases',{}).get(ref,ref.split(':')[0]+':gunbed.'+ref.split(':')[-1].replace('/','.'))
            assert resolved in events,(id,resolved)
            aliases[shoot]=resolved;report['fallback_shots'].append({'id':id,'event':resolved})
        server['guns'][id]['soundAliases']=copy.deepcopy(aliases)

# Include the existing IA CrackShot icons in the client pack, independent of pack load order.
source=STAGE/'plugins/ItemsAdder/contents/gunbed_fps/resourcepack/assets/gunbed'
for folder in ['items/cs','models/item','textures/item']:
    for path in (source/folder).rglob('*'):
        if not path.is_file():continue
        dest=R/'assets/gunbed'/path.relative_to(source)
        # Existing dedicated TaCZ/Delta icons take priority over the old pack.
        if dest.exists():continue
        dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
        if folder=='items/cs':report['icons'].append(path.stem)

# Fix any missing CS mapping directly from the actual title->model configuration.
import yaml
visual=yaml.safe_load((STAGE/'plugins/GunbedCore/visuals.yml').read_text(encoding='utf8'))
for title,model in visual['models'].items():
    slug=hashlib.sha256(title.encode()).hexdigest()[:16];dest=R/f'assets/gunbed/items/cs/{slug}.json'
    if dest.exists():continue
    fallback='gunbed:item/ta/'+model if (R/f'assets/gunbed/models/item/ta/{model}.json').exists() else 'minecraft:item/iron_sword'
    dump(dest,{'model':{'type':'minecraft:model','model':fallback}});report['icons'].append(slug)

# The HUD uses dedicated PNGs, not item-model rendering. Cover every active CS title.
from PIL import Image
for title,model in visual['models'].items():
    slug=hashlib.sha256(title.encode()).hexdigest()[:16];dest=R/f'assets/gunbed/textures/feed/cs/{slug}.png'
    if dest.exists():continue
    source=R/f'assets/gunbed/textures/feed/ta/{model}.png'
    if not source.exists() and model=='gunbed_m79':source=R/'assets/gunbed/textures/item/m79.png'
    if not source.exists() and model.startswith('gunbed_legacy_'):
        replacement={'망치':'baseball_bat','나타나이프':'dagger','광선검':'karambit','광선검무료':'dagger'}[title]
        source=R/f'assets/gunbed/textures/feed/melee/{replacement}.png'
    assert source.exists(),(title,model,source)
    im=Image.open(source).convert('RGBA');im.thumbnail((16,16),Image.Resampling.LANCZOS);canvas=Image.new('RGBA',(16,16));canvas.alpha_composite(im,((16-im.width)//2,(16-im.height)//2));dest.parent.mkdir(parents=True,exist_ok=True);canvas.save(dest)
report['feed_icons']=len(list((R/'assets/gunbed/textures/feed/cs').glob('*.png')))

# Normalize only the newly imported weapon sounds, with a peak limit and bounded gain.
# A saved source prevents repeated invocations from repeatedly changing the audio.
audio_backup=ROOT/'.local/v17-original-audio'
ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
def normalize(path):
    saved=audio_backup/path.relative_to(R)
    if not saved.exists():saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,saved)
    raw=subprocess.run([ffmpeg,'-v','error','-i',str(saved),'-f','f32le','-ac','1','-ar','44100','-'],capture_output=True,check=True).stdout
    samples=np.frombuffer(raw,dtype='<f4');peak=float(np.max(np.abs(samples))) if samples.size else 0;rms=float(np.sqrt(np.mean(samples*samples))) if samples.size else 0
    if peak<=0 or rms<=0:return {'file':str(path.relative_to(R)),'gain':1}
    gain=max(1,min(6,.16/rms,.92/peak))
    if gain>1.03:subprocess.run([ffmpeg,'-v','error','-y','-i',str(saved),'-af','volume='+str(gain),'-c:a','libvorbis','-q:a','5',str(path)],capture_output=True,check=True)
    else:shutil.copy2(saved,path)
    return {'file':str(path.relative_to(R)),'gain':round(gain,3)}
paths=[path for ns in ['ronmc','delta_wt'] for path in (R/f'assets/{ns}/sounds/gunbed').rglob('*.ogg')]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:report['audio']=list(pool.map(normalize,paths))

dump(catalog,client);dump(serverpath,server)
report['success']=len(report['melee_clips'])==11
dump(ROOT/'reports/v17-assets-preparation.json',report)
print(json.dumps({k:(len(v) if isinstance(v,list) else v) for k,v in report.items()}))
