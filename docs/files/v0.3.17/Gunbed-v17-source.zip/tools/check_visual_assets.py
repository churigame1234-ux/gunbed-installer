import json,os,subprocess
from pathlib import Path
import yaml
from server_audit import ROOT,dump
config=json.loads((ROOT/".local/resourcepack/clients/1.21.11/launch.json").read_text(encoding="utf-8"))
libraries=[p for p in config["classpath"].split(os.pathsep) if "/gson/" in p.replace("\\","/") or "/joml/" in p.replace("\\","/")]
assert len(libraries)==2
classes=ROOT/".local/visual-model-check";classes.mkdir(exist_ok=True)
sources=list((ROOT/"client/src/common/java/kr/mzs/gunbedvisual/model").glob("*.java"))+[ROOT/"client/src/common/java/kr/mzs/gunbedvisual/VisualState.java",ROOT/"client/src/common/java/kr/mzs/gunbedvisual/ModePose.java",ROOT/"client/src/common/java/kr/mzs/gunbedvisual/ThrowablePose.java",ROOT/"client/src/common/java/kr/mzs/gunbedvisual/ModeAssets.java",ROOT/"client/src/common/java/kr/mzs/gunbedvisual/LegacyMeleePose.java",ROOT/"client/src/common/java/kr/mzs/gunbedvisual/M79Pose.java",ROOT/"tools/visual-model-check/GunbedAssetCheck.java"]
subprocess.run([r"C:\Program Files\Java\jdk-21\bin\javac.exe","-encoding","UTF-8","-cp",os.pathsep.join(libraries),"-d",str(classes),*map(str,sources)],check=True)
models=sorted(json.loads((ROOT/'client/src/main/resources/assets/tacz/gunbed_catalog.json').read_text(encoding='utf-8'))['guns'])
run=subprocess.run([r"C:\Program Files\Java\jdk-21\bin\java.exe","-cp",os.pathsep.join([str(classes),str(ROOT/"client/src/main/resources"),*libraries]),"GunbedAssetCheck",str(ROOT/"client/src/main/resources/assets/tacz"),*models],check=True,capture_output=True,text=True,encoding="utf-8")
report=json.loads(run.stdout);dump(ROOT/"reports/visual-assets.json",report)
print(json.dumps({"success":report["success"],"models":len(models),"frames":report["frames"]}))
