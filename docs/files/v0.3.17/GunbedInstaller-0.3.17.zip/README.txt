Gunbed Installer 0.3.17 / adapters 0.3.17 / shared assets 0.3.17
Repaired DeltaForce attack motions, addon audio and CrackShot kill-feed textures.
Run installer, select version and your existing game folder. Other mods, settings and worlds are preserved.
57 firearms, 11 melee presets and 3 throwable presets added.
