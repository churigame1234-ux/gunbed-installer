package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.block.data.type.Bed;
import org.bukkit.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import org.screamingsandals.bedwars.api.RunningTeam;
import java.util.*;
import java.util.Comparator;

/** Economic objectives and real item use sit above the local gunfight controller. */
final class AiStrategy {
    static final class Memory {
        boolean openingDone,diamondVisited,emeraldVisited;int started,nextEconomy,nextUse,arrived,nextAudit,nextShop,placedDefense,purchases,upgrades,uses;
        String phase="opening",lastObjective="",consuming="";boolean finishing;int serviceSince,nextSupply;Location serviceAt;Location resource,defenseStand;Block defenseTarget;int defensePlan;long resourceBefore,consumeBefore;int consumeUntil,blastUntil;Location blastAt;Material consumingType;
    }
    private final AiBrain brain;private final GunbedCore plugin;private final BotRuntime runtime;
    AiStrategy(AiBrain b,GunbedCore p,BotRuntime r){brain=b;plugin=p;runtime=r;}
    private Player player(AiBrain.State s){return s.bot.getPlayer();}
    private void release(AiBrain.State s){Player p=player(s);plugin.taWeapons.input(p,false,false);plugin.addonMelee.input(p,false);if(plugin.visuals!=null)plugin.visuals.input(p,false,false,false);}
    private void goal(AiBrain.State s,String action,String reason){s.action=action;s.reason=reason;Memory m=s.strategy;if(!reason.equals(m.lastObjective)){m.lastObjective=reason;plugin.learning.telemetry.record(player(s),"objective",Map.of("phase",m.phase,"reason",reason,"resources",plugin.wallet.snapshot(player(s)),"defenseBlocks",defenseCount(s)));}}
    long count(Player p,Material type){return Arrays.stream(plugin.inventories.utility(p)).filter(Objects::nonNull).filter(i->i.getType()==type).mapToLong(plugin.stacks::count).sum();}
    private boolean has(Player p,Material type){return count(p,type)>0;}
    Location store(AiBrain.State s,boolean upgrades){Player p=player(s);RunningTeam own=s.room.game.getTeamOfPlayer(p);return s.room.game.getGameStores().stream().filter(x->x.getTeam()!=null&&x.getTeam().getName().equals(own.getName())&&x.getShopFile()!=null&&x.getShopFile().contains("upgrade")==upgrades).map(x->x.getStoreLocation()).min(Comparator.comparingDouble(x->x.distanceSquared(p.getLocation()))).map(at->approach(s,at)).orElse(own.getTeamSpawn());}
    private Location approach(AiBrain.State s,Location at){Player p=player(s);Location best=null;double score=Double.MAX_VALUE;for(int x=-3;x<=3;x++)for(int z=-3;z<=3;z++)for(int y=-2;y<=1;y++){Location candidate=at.clone().add(x,y,z);candidate.setX(candidate.getBlockX()+.5);candidate.setZ(candidate.getBlockZ()+.5);candidate.setY(Math.ceil(candidate.getY()-.05));if(candidate.distanceSquared(at)>12||!AiTerrain.floor(candidate)||!s.room.game.isLocationInArena(candidate)||!AiTerrain.visible(candidate.clone().add(0,1.4,0),at.clone().add(0,1,0)))continue;double value=candidate.distanceSquared(p.getLocation())+candidate.distanceSquared(at)*.15;if(value<score){score=value;best=candidate;}}return best==null?at.clone():best;}
    boolean nearStore(AiBrain.State s,boolean upgrades){Player p=player(s);var team=s.room.game.getTeamOfPlayer(p);return s.room.game.getGameStores().stream().anyMatch(store->store.getTeam()!=null&&store.getTeam().getName().equals(team.getName())&&store.getShopFile()!=null&&store.getShopFile().contains("upgrade")==upgrades&&store.getStoreLocation().distanceSquared(p.getLocation())<16);}
    private boolean near(Player p,Location at,double distance){return at.getWorld()==p.getWorld()&&at.distanceSquared(p.getLocation())<distance*distance;}
    boolean buy(AiBrain.State s,String id){if(!plugin.bedwars.shop.botPurchase(player(s),id))return false;s.strategy.purchases++;return true;}
    private List<Block> defense(AiBrain.State s,boolean outer){
        Block bed=s.room.game.getTeamOfPlayer(player(s)).getTargetBlock().getBlock();List<Block> bases=new ArrayList<>();bases.add(bed);
        if(bed.getBlockData() instanceof Bed data){Block other=bed.getRelative(data.getPart()==Bed.Part.FOOT?data.getFacing():data.getFacing().getOppositeFace());if(other.getBlockData() instanceof Bed)bases.add(other);}else{Vector delta=s.room.game.getTeamOfPlayer(player(s)).getTeamSpawn().toVector().subtract(bed.getLocation().toVector());BlockFace face=Math.abs(delta.getX())>Math.abs(delta.getZ())?(delta.getX()>0?BlockFace.EAST:BlockFace.WEST):(delta.getZ()>0?BlockFace.SOUTH:BlockFace.NORTH);bases.add(bed.getRelative(face));}
        Set<Block> result=new LinkedHashSet<>();int radius=outer?2:1;
        for(Block base:bases)for(int y=0;y<=radius;y++)for(int x=-radius;x<=radius;x++)for(int z=-radius;z<=radius;z++)if(Math.abs(x)+Math.abs(z)+y<=radius&&!bases.contains(base.getRelative(x,y,z)))result.add(base.getRelative(x,y,z));
        if(outer)result.removeAll(defense(s,false));
        return result.stream().filter(b->s.room.game.isLocationInArena(b.getLocation())&&plugin.volumes.allow(s.room.game,b.getLocation(),player(s))).sorted(Comparator.comparingInt(Block::getY).thenComparingDouble(b->b.getLocation().distanceSquared(player(s).getLocation()))).toList();
    }
    int defenseCount(AiBrain.State s){if(s.room.game.getTeamOfPlayer(player(s))==null)return 0;return (int)defense(s,false).stream().filter(b->!b.isPassable()).count();}
    Location forge(AiBrain.State s){Player p=player(s);String own=s.room.game.getTeamOfPlayer(p).getName();return s.room.game.getItemSpawners().stream().filter(x->x.getTeam()!=null&&x.getTeam().getName().equals(own)&&x.getItemSpawnerType().getMaterial()==Material.IRON_INGOT).map(x->x.getLocation().clone().add(0,1,0)).findFirst().orElse(s.room.game.getTeamOfPlayer(p).getTeamSpawn());}
    void travel(AiBrain.State s,Location at,int tick,String action,String reason){release(s);goal(s,action,reason);brain.navigate(s,at,tick,brain.wool(player(s))>0,true);}
    boolean finishMode(AiBrain.State s){var own=s.room.game.getTeamOfPlayer(player(s));return own!=null&&s.room.game.getRunningTeams().stream().filter(t->t!=own&&t.isAlive()).noneMatch(RunningTeam::isTargetBlockExists);}
    void refresh(AiBrain.State s,int tick){if(finishMode(s)&&!s.strategy.finishing){s.strategy.finishing=true;s.strategy.phase="hunt";s.strategy.arrived=0;s.strategy.nextEconomy=tick+600;s.path.clear();s.goal=null;s.nextPlan=0;goal(s,"hunt","enemy-bed-destroyed-stop-long-economy-detours");}}
    boolean economyBusy(AiBrain.State s){return !finishMode(s)&&(!s.strategy.openingDone||s.strategy.phase.equals("ready")&&!s.strategy.diamondVisited||Set.of("diamond","emerald","return-upgrade","return-shop").contains(s.strategy.phase));}
    void shop(AiBrain.State s,int tick){
        Player p=player(s);Memory m=s.strategy;if(tick<m.nextShop||m.consumeUntil>0||AiGuns.reloading(plugin,p))return;m.nextShop=tick+20;
        if(nearStore(s,true)){
            for(String id:plugin.bedwars.shop.botHasFatigue(p)?List.of("protection","sharpness","forge","heal-pool","haste"):List.of("mining-fatigue-trap","protection","sharpness","forge","heal-pool","haste"))if(plugin.bedwars.shop.botCanUpgrade(p,id)&&plugin.bedwars.shop.botUpgrade(p,id)){m.upgrades++;break;}
        }
        if(!nearStore(s,false))return;
        if(brain.beds.reserve(s))return;
        long wool=brain.wool(p);if(wool<32&&plugin.wallet.total(p,Material.IRON_INGOT)>=4){buy(s,"wool");return;}
        if(p.getInventory().getLeggings()!=null&&p.getInventory().getLeggings().getType()==Material.LEATHER_LEGGINGS){if(plugin.bedwars.shop.botCanBuy(p,"iron_armor")&&buy(s,"iron_armor"))return;if(plugin.wallet.total(p,Material.IRON_INGOT)>=100&&buy(s,"chainmail_armor"))return;}
        if(!has(p,Material.GOLDEN_APPLE)&&plugin.wallet.total(p,Material.GOLD_INGOT)>=3&&buy(s,"gapple"))return;
        if(s.plan.style==AiPlan.Style.DEFENDER&&!finishMode(s)&&s.room.bots.size()>1&&!has(p,Material.END_STONE)&&defenseCount(s)>=8&&defense(s,true).stream().filter(Block::isPassable).count()>0&&plugin.wallet.total(p,Material.IRON_INGOT)>=24&&buy(s,"endstone"))return;
        if(plugin.inventories.utility(p).length>0&&Arrays.stream(plugin.inventories.utility(p)).filter(Objects::nonNull).noneMatch(i->i.getType().name().endsWith("PICKAXE"))&&buy(s,"pickaxe"))return;
        if(!Arrays.stream(plugin.inventories.utility(p)).filter(Objects::nonNull).anyMatch(i->i.getType().name().endsWith("_AXE"))&&buy(s,"axe"))return;
        String grenade=s.plan.style==AiPlan.Style.DEFENDER||s.plan.style==AiPlan.Style.ARCHER?"fire":s.plan.style==AiPlan.Style.SABOTEUR?"labs_impact":"he";
        if(plugin.inventories.weapons(p).stream().noneMatch(i->plugin.throwables.kind(i)!=null)&&plugin.wallet.total(p,Material.GOLD_INGOT)>=3&&plugin.throwables.buy(p,grenade)){m.purchases++;plugin.learning.telemetry.record(p,"purchase",Map.of("item","throwable:"+grenade,"after",plugin.wallet.snapshot(p)));return;}
        if(brain.plans.shopping(s))return;
        if(wool<64&&plugin.wallet.total(p,Material.IRON_INGOT)>=Math.max(20,brain.plans.ironReserve(s)+4)&&buy(s,"wool"))return;
        Map<String,Material> options=new LinkedHashMap<>();options.put("tnt",Material.TNT);options.put("fireball",Material.FIRE_CHARGE);options.put("bedbug",Material.SNOWBALL);options.put("invisibility",Material.POTION);options.put("speed",Material.POTION);options.put("bridge_egg",Material.EGG);options.put("pearl",Material.ENDER_PEARL);options.put("milk",Material.MILK_BUCKET);options.put("golem",Material.IRON_GOLEM_SPAWN_EGG);
        List<String> legal=options.entrySet().stream().filter(e->!has(p,e.getValue())&&plugin.bedwars.shop.botCanBuy(p,e.getKey())).map(Map.Entry::getKey).collect(java.util.stream.Collectors.toCollection(ArrayList::new));String demonstrated=plugin.learning.purchase(s.room.game,p,legal);if(!demonstrated.isEmpty()&&legal.remove(demonstrated))legal.addFirst(demonstrated);for(String id:legal)if(buy(s,id))return;
    }
    boolean urgent(AiBrain.State s,LivingEntity foe,int tick){
        Player p=player(s);Memory m=s.strategy;if(m.started==0){m.started=tick;m.nextEconomy=tick+40;}
        if(m.blastAt!=null&&tick<m.blastUntil){Vector away=p.getLocation().toVector().subtract(m.blastAt.toVector()).setY(0);if(away.lengthSquared()<.1)away=p.getLocation().getDirection().setY(0).multiply(-1);away.normalize();Location safe=p.getLocation().clone().add(away.clone().multiply(4));goal(s,"retreat","leave-own-tnt-blast");release(s);if(AiTerrain.floor(safe))brain.navigate(s,safe,tick,false,false);else if(AiTerrain.safeStep(p.getLocation(),away))runtime.move(s.bot,away.getX(),away.getZ(),false,true,false);else runtime.stop(s.bot);return true;}
        if(AiGuns.reloading(plugin,p)||s.combat.lastSeen!=null&&tick-s.combat.seenTick<60)return false;
        if(foe!=null&&(p.getLocation().distanceSquared(foe.getLocation())<=Math.pow(AiGuns.reach(plugin,p,AiGuns.slot(plugin,p,0)),2)||plugin.learning.telemetry.pressured(p,tick)))return false;
        var own=s.room.game.getTeamOfPlayer(p);boolean bed=own.isTargetBlockExists();
        if(brain.beds.tick(s,tick))return true;
        if(!m.openingDone&&bed){
            if(brain.wool(p)==0){supplies(s,tick);return true;}
            if((s.room.bots.size()==1||brain.plans.duty(s)==AiPlan.Duty.DEFENDER)&&defenseCount(s)<8){if(buildDefense(s,tick,false))return true;}
            if(brain.wool(p)<64){supplies(s,tick);return true;}
            m.openingDone=true;m.phase="ready";goal(s,"prepare","opening-defense-and-blocks-ready");
        }else if(!bed)m.openingDone=true;
        if((s.room.bots.size()==1||brain.plans.duty(s)==AiPlan.Duty.DEFENDER)&&bed&&near(p,own.getTargetBlock(),18)&&defenseCount(s)<8&&brain.wool(p)>0){if(buildDefense(s,tick,false))return true;}
        if(bed&&has(p,Material.END_STONE)&&near(p,own.getTargetBlock(),18)&&defense(s,true).stream().anyMatch(Block::isPassable)){if(buildDefense(s,tick,true))return true;}
        if(!finishMode(s)&&brain.wool(p)<16&&!s.room.game.getRunningTeams().stream().anyMatch(t->t!=own&&t.isTargetBlockExists()&&near(p,t.getTargetBlock(),7))){supplies(s,tick);return true;}
        return false;
    }
    private void supplies(AiBrain.State s,int tick){Player p=player(s);if(plugin.wallet.total(p,Material.IRON_INGOT)>=4){Location at=store(s,false);travel(s,at,tick,"shop","restock-blocks-at-item-shop");if(nearStore(s,false)){if(tick>=s.strategy.nextSupply&&brain.wool(p)<64){s.strategy.nextSupply=tick+20;buy(s,"wool");}shop(s,tick);runtime.stop(s.bot);}}else{Location at=forge(s);travel(s,at,tick,"gather","wait-for-real-iron-and-gold");if(near(p,at,1.2))runtime.stop(s.bot);}}
    private boolean buildDefense(AiBrain.State s,int tick,boolean outer){
        Player p=player(s);List<Block> missing=defense(s,outer).stream().filter(Block::isPassable).toList();if(missing.isEmpty())return false;
        Material material=outer?Material.END_STONE:null;
        goal(s,"defend",outer?"reinforce-bed-with-endstone":"complete-bed-cover");release(s);
        for(Block candidate:missing)if(tick>=s.nextBuild&&place(s,candidate,material,tick)){s.strategy.placedDefense++;s.strategy.defenseStand=null;s.strategy.defenseTarget=null;return true;}
        Memory memory=s.strategy;
        if(memory.defenseStand==null||memory.defenseTarget==null||!memory.defenseTarget.isPassable()||tick>=memory.defensePlan){
            memory.defenseStand=null;memory.defensePlan=tick+20;long deadline=System.nanoTime()+3_000_000;
            for(Block candidate:missing){Location at=stand(s,candidate.getLocation());if(at!=null){memory.defenseStand=at;memory.defenseTarget=candidate;break;}if(System.nanoTime()>deadline)break;}
        }
        if(memory.defenseStand!=null){s.buildReason="approach-cover "+memory.defenseTarget.getX()+","+memory.defenseTarget.getY()+","+memory.defenseTarget.getZ();brain.navigate(s,memory.defenseStand,tick,false,false);}
        else {s.buildReason="no-visible-cover-face";brain.navigate(s,s.room.game.getTeamOfPlayer(p).getTargetBlock().clone().add(2,1,2),tick,false,false);}return true;
    }
    private record Attachment(Block support,BlockFace face,Location hit){}
    private Attachment attachment(Block target,Location eye){
        for(BlockFace face:List.of(BlockFace.UP,BlockFace.NORTH,BlockFace.SOUTH,BlockFace.EAST,BlockFace.WEST,BlockFace.DOWN)){
            Block support=target.getRelative(face.getOppositeFace());if(support.isPassable())continue;var box=support.getBoundingBox();Location hit=box.getCenter().toLocation(eye.getWorld()).add(face.getModX()*box.getWidthX()*.5,face.getModY()*box.getHeight()*.5,face.getModZ()*box.getWidthZ()*.5);
            if(hit.distanceSquared(eye)>19.5)continue;Vector ray=hit.toVector().subtract(eye.toVector());if(ray.lengthSquared()<.001)continue;var collision=eye.getWorld().rayTraceBlocks(eye,ray.clone().normalize(),ray.length()+.02,FluidCollisionMode.NEVER,false);if(collision!=null&&support.equals(collision.getHitBlock())&&collision.getHitBlockFace()==face)return new Attachment(support,face,hit);
        }return null;
    }
    boolean place(AiBrain.State s,Block target,Material material,int tick){
        Player p=player(s);if(!target.isPassable()||p.getBoundingBox().overlaps(target.getBoundingBox())||!plugin.volumes.allow(s.room.game,target.getLocation(),p)||tick<s.nextBuild)return false;
        Attachment attach=attachment(target,p.getEyeLocation());if(attach==null)return false;
        if(!(material==null?brain.utilityWool(p):brain.utility(p,material)))return false;runtime.stop(s.bot);p.setSneaking(true);runtime.look(s.bot,attach.hit);boolean success=runtime.useBlock(s.bot,attach.support,attach.face);s.nextBuild=tick+AiPractice.Difficulty.HARD.build;s.buildReason="bed-cover="+success+" "+target.getX()+","+target.getY()+","+target.getZ();return success;
    }
    Location stand(AiBrain.State s,Location target){Player p=player(s);List<Location> candidates=new ArrayList<>();for(int x=-3;x<=3;x++)for(int z=-3;z<=3;z++)for(int y:new int[]{0,1,2}){Location foot=target.clone().add(x,y,z);foot.setX(foot.getBlockX()+.5);foot.setZ(foot.getBlockZ()+.5);if(s.room.game.isLocationInArena(foot)&&AiTerrain.floor(foot)&&foot.distanceSquared(target)>1&&foot.distanceSquared(target)<12)candidates.add(foot);}
        return candidates.stream().sorted(Comparator.comparingDouble(a->a.distanceSquared(p.getLocation()))).limit(24).filter(at->attachment(target.getBlock(),at.clone().add(0,1.62,0))!=null).findFirst().orElse(null);
    }
    void objective(AiBrain.State s,int tick){
        Player p=player(s);Memory m=s.strategy;var own=s.room.game.getTeamOfPlayer(p);var enemy=s.room.game.getRunningTeams().stream().filter(t->t!=own&&t.isAlive()).findFirst().orElse(null);if(enemy==null){runtime.stop(s.bot);return;}
        if(finishMode(s)){Location seen=brain.senses.lastKnown(s,300);if(seen!=null){travel(s,seen,tick,"hunt","pursue-last-observed-survivor");return;}Location patrol=enemy.getTeamSpawn();if(near(p,patrol,5)){var neutral=s.room.game.getItemSpawners().stream().filter(gen->gen.getTeam()==null).map(gen->gen.getLocation().clone().add(0,1,0)).toList();if(!neutral.isEmpty())patrol=neutral.get(Math.floorMod(tick/180+s.index,neutral.size()));}travel(s,patrol,tick,"hunt","search-enemy-base-and-neutral-exits");return;}
        if(m.phase.equals("ready")||m.phase.equals("raid")){
            var duty=brain.plans.duty(s);if(tick>=m.nextEconomy&&!brain.teams.committed(s)){if(duty==AiPlan.Duty.DIAMOND)startResource(s,Material.DIAMOND,tick);else if(duty==AiPlan.Duty.EMERALD)startResource(s,Material.EMERALD,tick);else if(duty==AiPlan.Duty.BOTH)startResource(s,m.diamondVisited&&!m.emeraldVisited?Material.EMERALD:brain.plans.resource(s),tick);else if(duty==AiPlan.Duty.RUSH&&s.room.bots.size()==1&&tick-m.started>1200)startResource(s,m.diamondVisited?Material.EMERALD:Material.DIAMOND,tick);else if(duty==AiPlan.Duty.DEFENDER){travel(s,forge(s),tick,"gather","defender-fund-turrets-after-bed-cover");return;}}
        }
        if(m.phase.equals("diamond")||m.phase.equals("emerald")){
            Material kind=m.phase.equals("diamond")?Material.DIAMOND:Material.EMERALD;long have=plugin.wallet.total(p,kind);if(m.resource==null){m.phase="raid";m.nextEconomy=tick+600;}else{
                if(near(p,m.resource,2)){if(m.arrived==0)m.arrived=tick;long target=kind==Material.EMERALD?Math.max(2,plugin.bedwars.shop.botBudget(p,brain.plans.wanted(s)).getOrDefault(kind,2L)):2;if(have>=target||tick-m.arrived>=360){if(kind==Material.DIAMOND)m.diamondVisited=true;else m.emeraldVisited=true;m.phase=have>0?(kind==Material.DIAMOND?"return-upgrade":"return-shop"):"raid";m.nextEconomy=tick+600;m.arrived=0;if(have>=target)brain.teams.funded(s,tick);}}
                else if(tick-m.nextAudit>1800){m.phase="raid";m.nextEconomy=tick+600;}
                if(m.phase.equals("diamond")||m.phase.equals("emerald")){travel(s,m.resource,tick,"collect",kind==Material.DIAMOND?"secure-diamonds":"secure-emeralds");if(near(p,m.resource,1.2))runtime.stop(s.bot);return;}
            }
        }
        if(m.phase.startsWith("return-")){if(m.serviceSince==0)m.serviceSince=tick;if(tick-m.serviceSince>400){m.phase="raid";m.arrived=0;m.serviceSince=0;m.nextEconomy=tick+300;goal(s,"advance","shop-approach-timeout-resume-play");return;}boolean upgrades=m.phase.equals("return-upgrade");Location at=store(s,upgrades);travel(s,at,tick,"shop",upgrades?"spend-diamonds-on-team-upgrades":"spend-emeralds-on-utility");if(nearStore(s,upgrades)){if(m.arrived==0)m.arrived=tick;shop(s,tick);runtime.stop(s.bot);if(tick-m.arrived>=80){m.arrived=0;m.serviceSince=0;m.phase=upgrades?"return-shop":"raid";m.nextEconomy=tick+(m.emeraldVisited?1800:300);}}return;}
        if(own.isTargetBlockExists()&&brain.plans.duty(s)==AiPlan.Duty.DEFENDER&&(tick-m.started)%900<300){travel(s,forge(s),tick,"guard","hold-home-and-repair-bed");return;}
        m.phase="raid";Location target=enemy.getTargetBlock().clone().add(.5,0,.5);
        if(brain.plans.rush(s,enemy,tick))return;
        if(enemy.isTargetBlockExists()&&p.getLocation().distanceSquared(target)<30){
            if(tick>=m.nextUse&&has(p,Material.TNT)){Block spot=defensePlacement(enemy,p);if(spot!=null&&place(s,spot,Material.TNT,tick)){m.blastAt=spot.getLocation().add(.5,.5,.5);m.blastUntil=tick+65;used(s,"tnt",tick);return;}}
            if(brain.mine(s,target,tick))return;
        }
        if(tick>=m.nextUse&&s.action.equals("bridge")){
            Location landing=enemy.getTeamSpawn();double d=p.getLocation().distance(landing);
            if(has(p,Material.ENDER_PEARL)&&d>=16&&d<=40&&useProjectile(s,Material.ENDER_PEARL,landing,true,tick))return;
            if(has(p,Material.EGG)&&d>12&&useProjectile(s,Material.EGG,target,false,tick))return;
        }
        travel(s,target,tick,"advance","raid-after-preparation");
    }
    private Block defensePlacement(RunningTeam enemy,Player p){Block bed=enemy.getTargetBlock().getBlock();for(int y=1;y<=3;y++)for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++){Block b=bed.getRelative(x,y,z);if(b.isPassable()&&!b.getRelative(BlockFace.DOWN).isPassable()&&b.getLocation().distanceSquared(p.getLocation())<16)return b;}return null;}
    private void startResource(AiBrain.State s,Material kind,int tick){Player p=player(s);Memory m=s.strategy;List<Location> options=s.room.game.getItemSpawners().stream().filter(x->x.getTeam()==null&&x.getItemSpawnerType().getMaterial()==kind).map(x->x.getLocation().clone().add(0,1,0)).sorted(Comparator.comparingDouble(a->a.distanceSquared(p.getLocation())*plugin.learning.adaptation.resource(s.room.game,p,kind,a))).toList();if(options.isEmpty()){m.diamondVisited=true;m.emeraldVisited=true;m.phase="raid";return;}m.resource=options.get(Math.min(s.index/2,options.size()-1));m.phase=kind==Material.DIAMOND?"diamond":"emerald";m.resourceBefore=plugin.wallet.total(p,kind);m.arrived=0;m.nextAudit=tick;}
    void used(AiBrain.State s,String id,int tick){Memory m=s.strategy;m.nextUse=tick+120;m.uses++;plugin.learning.telemetry.record(player(s),"utility-use",Map.of("item",id,"verified",true));goal(s,"use-item","use-"+id);}
    boolean consume(AiBrain.State s,LivingEntity foe,int tick){
        Player p=player(s);Memory m=s.strategy;if(m.consumeUntil>0){if(tick<m.consumeUntil){if(foe!=null&&p.getLocation().distanceSquared(foe.getLocation())<64&&plugin.learning.telemetry.pressured(p,tick)){p.clearActiveItem();m.consumeUntil=0;}else{release(s);runtime.stop(s.bot);goal(s,"consume","consume-"+m.consuming);return true;}}
            if(count(p,m.consumingType)>=m.consumeBefore&&p.getInventory().getItemInMainHand().getType()==m.consumingType)runtime.finishUse(s.bot);if(count(p,m.consumingType)<m.consumeBefore)used(s,m.consuming,tick);else plugin.learning.telemetry.record(p,"utility-cancel",Map.of("item",m.consuming,"reason","native-use-not-completed"));m.consumeUntil=0;
        }
        if(tick<m.nextUse||AiGuns.reloading(plugin,p))return false;boolean healing=p.getHealth()<p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue()*.7&&has(p,Material.GOLDEN_APPLE);if(foe!=null&&foe.hasLineOfSight(p)&&(p.getLocation().distanceSquared(foe.getLocation())<(healing?64:144)||plugin.learning.telemetry.pressured(p,tick)))return false;
        Material type=p.getHealth()<p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue()*.7&&has(p,Material.GOLDEN_APPLE)?Material.GOLDEN_APPLE:null;
        if(type==null&&!economyBusy(s)&&brain.plans.potionWanted(s)!=null)type=Material.POTION;
        if(type==null&&!economyBusy(s)&&has(p,Material.MILK_BUCKET)&&plugin.bedwars.shop.milkRemaining(p)==0&&s.room.game.getRunningTeams().stream().anyMatch(t->t!=s.room.game.getTeamOfPlayer(p)&&near(p,t.getTargetBlock(),20)))type=Material.MILK_BUCKET;if(type==null)return false;
        release(s);if(!(type==Material.POTION?brain.plans.choosePotion(s):brain.utility(p,type)))return false;if(type==Material.POTION&&p.getInventory().getItemInMainHand().getItemMeta() instanceof PotionMeta meta&&meta.getCustomEffects().stream().anyMatch(e->p.hasPotionEffect(e.getType())))return false;
        m.consumeBefore=count(p,type);m.consumingType=type;m.consuming=type==Material.POTION?"potion":type==Material.MILK_BUCKET?"milk":"gapple";m.consumeUntil=tick+38;runtime.stop(s.bot);if(!runtime.beginUse(s.bot)){m.consumeUntil=0;m.nextUse=tick+40;plugin.learning.telemetry.record(p,"utility-cancel",Map.of("item",m.consuming,"reason","item-use-denied"));return false;}goal(s,"consume","consume-"+m.consuming);return true;
    }
    boolean useProjectile(AiBrain.State s,Material type,Location target,boolean pearl,int tick){
        Player p=player(s);Vector delta=target.toVector().subtract(p.getEyeLocation().toVector());double horizontal=Math.hypot(delta.getX(),delta.getZ());if(horizontal<1)return false;Vector direction;
        if(pearl){double v=1.5,g=.03,disc=v*v*v*v-g*(g*horizontal*horizontal+2*delta.getY()*v*v);if(disc<=0)return false;double angle=Math.atan((v*v-Math.sqrt(disc))/(g*horizontal));direction=new Vector(delta.getX()/horizontal*Math.cos(angle),Math.sin(angle),delta.getZ()/horizontal*Math.cos(angle));}
        else direction=delta.setY(0).normalize().setY(.1).normalize();
        release(s);if(!brain.utility(p,type))return false;long before=count(p,type);runtime.look(s.bot,p.getEyeLocation().add(direction.multiply(10)));runtime.right(s.bot);if(count(p,type)<before){used(s,pearl?"pearl":"bridge-egg",tick);return true;}s.strategy.nextUse=tick+20;return false;
    }
    boolean combatUtility(AiBrain.State s,LivingEntity foe,int tick){
        if(foe==null||tick<s.strategy.nextUse||AiGuns.reloading(plugin,player(s)))return false;Player p=player(s);
        if(has(p,Material.IRON_GOLEM_SPAWN_EGG)&&near(p,s.room.game.getTeamOfPlayer(p).getTargetBlock(),18)&&near(p,foe.getLocation(),18)){
            release(s);if(brain.utility(p,Material.IRON_GOLEM_SPAWN_EGG)){Block ground=p.getLocation().subtract(0,.1,0).getBlock();long before=count(p,Material.IRON_GOLEM_SPAWN_EGG);runtime.look(s.bot,ground.getLocation().add(.5,1,.5));runtime.useBlock(s.bot,ground,BlockFace.UP);if(count(p,Material.IRON_GOLEM_SPAWN_EGG)<before){used(s,"golem",tick);return true;}}
        }
        double distance=p.getLocation().distance(foe.getLocation());Material type=distance>=8&&distance<=30&&has(p,Material.FIRE_CHARGE)?Material.FIRE_CHARGE:distance>=5&&distance<22&&has(p,Material.SNOWBALL)?Material.SNOWBALL:null;if(type==null)return false;
        release(s);if(!brain.utility(p,type))return false;long before=count(p,type);Location aim=foe.getLocation().add(0,type==Material.SNOWBALL?2:.5,0);runtime.look(s.bot,aim);runtime.right(s.bot);if(count(p,type)<before){used(s,type==Material.FIRE_CHARGE?"fireball":"bedbug",tick);runtime.stop(s.bot);return true;}s.strategy.nextUse=tick+20;return false;
    }
}


