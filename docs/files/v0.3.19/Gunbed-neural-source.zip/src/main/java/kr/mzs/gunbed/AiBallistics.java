package kr.mzs.gunbed;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** Discrete drag/gravity interception, using the same position-then-velocity step as the actual bullet. */
final class AiBallistics {
    record Model(double speed,double gravity,double drag,int life,boolean instant){}
    record Aim(Vector velocity,double ticks,boolean reachable){}
    static double number(com.google.gson.JsonObject o,String k,double fallback){return o!=null&&o.has(k)?o.get(k).getAsDouble():fallback;}
    static Model model(GunbedCore plugin,Player p,AiGuns.Gun gun){
        for(int slot=0;slot<9;slot++){var d=plugin.taWeapons.definition(p.getInventory().getItem(slot));if(d==null||!gun.id().equals("ta:"+d.id()))continue;var b=d.data().getAsJsonObject("bullet");var modes=d.data().getAsJsonObject("fire_mode_adjust");var mode=modes==null?null:modes.getAsJsonObject(plugin.taWeapons.mode(p));return new Model(Math.max(1,number(b,"speed",200)+number(mode,"speed",0))/20,number(b,"gravity",0),Math.max(0,1-number(b,"friction",0)),Math.max(1,Math.min(400,(int)Math.ceil(number(b,"life",1)*20))),false);}
        if(gun.id().startsWith("cs:")){String id=gun.id().substring(3);var h=plugin.visuals.cs.getHandle();String type=h.getString(id+".Shooting.Projectile_Type");if("energy".equalsIgnoreCase(type))return new Model(256,0,1,1,true);boolean arrow="arrow".equalsIgnoreCase(type);return new Model(Math.max(.1,Math.min(256,h.getInt(id+".Shooting.Projectile_Speed")*.1)),arrow?.05:.03,.99,200,false);}
        return new Model(256,0,1,1,true);
    }
    static double[] sums(Model m,double time){double a,drop;if(Math.abs(m.drag-1)<1e-8){a=time;double whole=Math.floor(time),part=time-whole;drop=m.gravity*(whole*(whole-1)/2+part*whole);}else{double whole=Math.floor(time),part=time-whole,pow=Math.pow(m.drag,whole);a=(1-pow)/(1-m.drag)+part*pow;double b=(whole-(1-pow)/(1-m.drag))/(1-m.drag)+part*(1-pow)/(1-m.drag);drop=m.gravity*b;}return new double[]{a,drop};}
    static Aim solve(Model m,Vector delta,Vector targetVelocity){if(m.instant)return new Aim(delta.clone().normalize().multiply(m.speed),0,true);double last=.05;double[] prev=required(m,delta,targetVelocity,last);double lastError=prev[3]-m.speed;
        for(double t=.25;t<=m.life;t+=.25){double[] needed=required(m,delta,targetVelocity,t);double error=needed[3]-m.speed;if(error<=0&&lastError>=0){double low=last,high=t;for(int n=0;n<22;n++){double mid=(low+high)/2;if(required(m,delta,targetVelocity,mid)[3]>m.speed)low=mid;else high=mid;}double flight=(low+high)/2;double[] v=required(m,delta,targetVelocity,flight);return new Aim(new Vector(v[0],v[1],v[2]).normalize().multiply(m.speed),flight,true);}last=t;lastError=error;}
        return new Aim(delta.clone().normalize().multiply(m.speed),0,false);
    }
    private static double[] required(Model m,Vector delta,Vector motion,double t){double[] sum=sums(m,t);double a=Math.max(.0001,sum[0]);Vector v=delta.clone().add(motion.clone().multiply(t));v.setY(v.getY()+sum[1]).multiply(1/a);return new double[]{v.getX(),v.getY(),v.getZ(),v.length()};}
    static Location aim(Location eye,Aim shot){return eye.clone().add(shot.velocity.clone().normalize().multiply(20));}
    static boolean clear(Location eye,Model model,Aim shot){if(!shot.reachable)return false;if(model.instant)return true;Location at=eye.clone();Vector velocity=shot.velocity.clone();for(int tick=0;tick<(int)Math.ceil(shot.ticks);tick++){if(!at.getWorld().isChunkLoaded(at.getBlockX()>>4,at.getBlockZ()>>4))return false;double length=velocity.length(),part=Math.min(1,shot.ticks-tick);if(length>.0001&&at.getWorld().rayTraceBlocks(at,velocity.clone().normalize(),length*part,org.bukkit.FluidCollisionMode.NEVER,true)!=null)return false;at.add(velocity.clone().multiply(part));velocity.multiply(model.drag);velocity.setY(velocity.getY()-model.gravity);}return true;}
}
