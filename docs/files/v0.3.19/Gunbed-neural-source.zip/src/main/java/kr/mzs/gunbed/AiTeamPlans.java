package kr.mzs.gunbed;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.screamingsandals.bedwars.api.*;
import org.screamingsandals.bedwars.api.events.*;
import org.screamingsandals.bedwars.api.game.*;
import java.util.*;
import java.util.Comparator;

/** Team commitments survive a teammate death; only observed danger, funding and regrouping replan. */
final class AiTeamPlans implements Listener {
    enum Defense {STAY,JOIN_RUSH,JOIN_COLLECT}
    enum Bedless {FORTIFY,ALL_IN,ROAM,REGROUP}
    enum Tactic {TOOLS,TNT,GLASS_TNT,INVIS,INVIS_JUMP,INVIS_SPEED,FULL_POTS,FULL_MILK,PEARL_INVIS,FIREBALL,HOOK,WATER_TOOLS}
    static final class Plan {
        final Map<UUID,AiPlan.Duty> roles=new HashMap<>();final Map<UUID,Defense> defenses=new HashMap<>();
        UUID builder,glassBreaker;int began,nextReview,revision,returnUntil,lastFunding,openingDeadline;boolean bedLost;
        Bedless bedless;Tactic tactic;Set<UUID> returning=new HashSet<>();
    }
    private final GunbedCore plugin;private final AiBrain brain;private final BotRuntime runtime;private final Random random=new Random();
    private final Map<Game,Plan> plans=new HashMap<>();
    AiTeamPlans(GunbedCore p,AiBrain b,BotRuntime r){plugin=p;brain=b;runtime=r;Bukkit.getPluginManager().registerEvents(this,p);}
    private List<AiBrain.State> members(AiBrain.State s){return brain.all().stream().filter(b->b.room==s.room).sorted(Comparator.comparingInt(b->b.index)).toList();}
    Plan plan(AiBrain.State s){return plans.computeIfAbsent(s.room.game,g->{Plan t=new Plan();t.began=Bukkit.getCurrentTick();t.nextReview=t.began+1200;assign(s,t,true,"초반 러시 중심 팀 조합 추첨");return t;});}
    private void assign(AiBrain.State source,Plan t,boolean early,String reason){List<AiBrain.State> bots=members(source);if(bots.isEmpty())return;int[] composition=AiTeamPolicy.sample(bots.size(),early,random);List<AiPlan.Duty> role=List.of(AiPlan.Duty.RUSH,AiPlan.Duty.DIAMOND,AiPlan.Duty.EMERALD,AiPlan.Duty.BOTH,AiPlan.Duty.DEFENDER);
        t.revision++;t.tactic=Tactic.values()[random.nextInt(Tactic.values().length)];if(early)t.tactic=Tactic.TOOLS;t.bedless=Bedless.values()[random.nextInt(Bedless.values().length)];if(t.builder==null)t.builder=bots.get(random.nextInt(bots.size())).bot.getPlayer().getUniqueId();t.glassBreaker=bots.get(random.nextInt(bots.size())).bot.getPlayer().getUniqueId();
        for(int i=0;i<bots.size();i++){var b=bots.get(i);UUID id=b.bot.getPlayer().getUniqueId();if(!early&&committed(b))continue;var selected=role.get(composition[i]);if(plugin.neural!=null){String learned=plugin.neural.preferred(b,List.of("rush","defend","diamond","emerald"));selected=switch(learned){case "rush"->AiPlan.Duty.RUSH;case "defend"->AiPlan.Duty.DEFENDER;case "diamond"->AiPlan.Duty.DIAMOND;case "emerald"->AiPlan.Duty.EMERALD;default->selected;};}t.roles.put(id,selected);t.defenses.put(id,Defense.values()[random.nextInt(Defense.values().length)]);b.strategy.phase="ready";b.strategy.nextEconomy=0;b.strategy.serviceSince=0;b.strategy.arrived=0;b.path.clear();b.goal=null;}
        // A committed old collector can otherwise collide with a newly drawn collector.
        boolean diamond=false,emerald=false;for(var b:bots){UUID id=b.bot.getPlayer().getUniqueId();var duty=t.roles.getOrDefault(id,AiPlan.Duty.RUSH);boolean d=duty==AiPlan.Duty.DIAMOND||duty==AiPlan.Duty.BOTH,e=duty==AiPlan.Duty.EMERALD||duty==AiPlan.Duty.BOTH;if(d&&diamond||e&&emerald)t.roles.put(id,AiPlan.Duty.RUSH);else{diamond|=d;emerald|=e;}}
        plugin.learning.telemetry.record(source.bot.getPlayer(),"team-plan",Map.of("revision",t.revision,"reason",reason,"tactic",t.tactic.name(),"roles",t.roles.entrySet().stream().collect(java.util.stream.Collectors.toMap(e->e.getKey().toString(),e->e.getValue().name()))));
    }
    AiPlan.Duty duty(AiBrain.State s){Plan t=plan(s);if(opening(s))return AiPlan.Duty.DEFENDER;AiPlan.Duty role=t.roles.getOrDefault(s.bot.getPlayer().getUniqueId(),AiPlan.Duty.RUSH);if(role==AiPlan.Duty.DEFENDER&&!brain.beds.pendingLayout(s))return switch(t.defenses.getOrDefault(s.bot.getPlayer().getUniqueId(),Defense.STAY)){case STAY->role;case JOIN_RUSH->AiPlan.Duty.RUSH;case JOIN_COLLECT->claimCollector(s,t);};return role;}
    private AiPlan.Duty claimCollector(AiBrain.State s,Plan t){boolean d=t.roles.values().stream().anyMatch(r->r==AiPlan.Duty.DIAMOND||r==AiPlan.Duty.BOTH),e=t.roles.values().stream().anyMatch(r->r==AiPlan.Duty.EMERALD||r==AiPlan.Duty.BOTH);var next=!d?AiPlan.Duty.DIAMOND:!e?AiPlan.Duty.EMERALD:AiPlan.Duty.RUSH;t.roles.put(s.bot.getPlayer().getUniqueId(),next);return next;}
    boolean opening(AiBrain.State s){Plan t=plans.get(s.room.game);if(t==null||!s.bot.getPlayer().getUniqueId().equals(t.builder))return false;var own=s.room.game.getTeamOfPlayer(s.bot.getPlayer());if(t.openingDeadline==0&&s.strategy.placedDefense>0)t.openingDeadline=Bukkit.getCurrentTick()+600;return own!=null&&own.isTargetBlockExists()&&!brain.beds.openingDone(s)&&(t.openingDeadline==0?Bukkit.getCurrentTick()-t.began<1200:Bukkit.getCurrentTick()<t.openingDeadline);}
    boolean committed(AiBrain.State s){Player p=s.bot.getPlayer();var own=s.room.game.getTeamOfPlayer(p);return own!=null&&own.isTargetBlockExists()&&s.room.game.getRunningTeams().stream().anyMatch(t->t!=own&&t.isTargetBlockExists()&&t.getTargetBlock().distanceSquared(p.getLocation())<400)&&!p.isDead()&&p.getGameMode()!=GameMode.SPECTATOR;}
    Tactic tactic(AiBrain.State s){return plan(s).tactic;}
    void tick(int tick){Set<Game> processed=new HashSet<>();for(var s:brain.all()){if(s.room.game.getStatus()!=GameStatus.RUNNING||s.bot.getPlayer().isDead()||s.bot.getPlayer().getGameMode()==GameMode.SPECTATOR||!processed.add(s.room.game))continue;Plan t=plan(s);var own=s.room.game.getTeamOfPlayer(s.bot.getPlayer());if(own==null)continue;
        if(!own.isTargetBlockExists()&&!t.bedLost){t.bedLost=true;assign(s,t,false,"자기 침대 파괴: 생존·농성·도주·돌격 운영 선택");t.nextReview=tick+1200;}
        if(tick>=t.nextReview){assign(s,t,tick-t.began<1200,"주기적 자원·팀 운영 재정비: 적 침대 접근 중인 공격자는 유지");t.nextReview=tick+1200;}
        if(own.isTargetBlockExists())danger(s,t,tick);if(tick%20==0)donate(s,t);
    }}
    private void donate(AiBrain.State source,Plan t){var builder=members(source).stream().filter(s->s.bot.getPlayer().getUniqueId().equals(t.builder)).findFirst().orElse(null);if(builder==null||!opening(builder))return;Player to=builder.bot.getPlayer();for(var other:members(source)){Player from=other.bot.getPlayer();if(from==to||from.isDead()||from.getGameMode()==GameMode.SPECTATOR||from.getWorld()!=to.getWorld()||from.getLocation().distanceSquared(to.getLocation())>16)continue;long need=Math.max(0,4-plugin.wallet.amount(to,Material.GOLD_INGOT)),n=Math.min(need,plugin.wallet.amount(from,Material.GOLD_INGOT));if(n>0){plugin.wallet.set(from,Material.GOLD_INGOT,plugin.wallet.amount(from,Material.GOLD_INGOT)-n);plugin.wallet.add(to,Material.GOLD_INGOT,n);plugin.learning.telemetry.record(from,"team-donation",Map.of("target",to.getName(),"gold",n,"reason","목재 한 겹 + 양털 초반 방어"));}}
    }
    private void danger(AiBrain.State s,Plan t,int tick){var own=s.room.game.getTeamOfPlayer(s.bot.getPlayer());var observed=brain.senses.teamObserved(s,40);Location threat=observed.stream().filter(at->at.distanceSquared(own.getTargetBlock())<64).min(Comparator.comparingDouble(at->at.distanceSquared(own.getTargetBlock()))).orElse(null);if(threat==null){if(tick>=t.returnUntil)t.returning.clear();return;}
        long home=members(s).stream().filter(b->alive(b)&&b.bot.getPlayer().getLocation().distanceSquared(own.getTargetBlock())<100).count();if(home>=2||home>=1&&brain.strategy.defenseCount(s)>=8)return;
        t.returning.clear();members(s).stream().filter(this::alive).filter(b->!committed(b)).sorted(Comparator.comparingDouble(b->b.bot.getPlayer().getLocation().distanceSquared(own.getTargetBlock()))).limit(Math.max(1,2-home)).forEach(b->t.returning.add(b.bot.getPlayer().getUniqueId()));t.returnUntil=tick+100;
    }
    private boolean alive(AiBrain.State s){return !s.bot.getPlayer().isDead()&&s.bot.getPlayer().getGameMode()!=GameMode.SPECTATOR;}
    boolean respond(AiBrain.State s,int tick){Plan t=plan(s);Player p=s.bot.getPlayer();var own=s.room.game.getTeamOfPlayer(p);if(own==null)return false;if(t.returning.contains(p.getUniqueId())&&tick<t.returnUntil&&own.isTargetBlockExists()&&!committed(s)){
        if(p.getLocation().distanceSquared(own.getTargetBlock())>900){plugin.learning.telemetry.record(p,"void-return",Map.of("reason","목격된 기지 위협에 일반 귀환이 늦음","resourcesAtRisk",plugin.wallet.snapshot(p)));p.setInvulnerable(false);p.setNoDamageTicks(0);p.setLastDamageCause(new EntityDamageEvent(p,EntityDamageEvent.DamageCause.VOID,p.getHealth()+p.getAbsorptionAmount()));p.setHealth(0);return true;}
        brain.strategy.travel(s,own.getTargetBlock(),tick,"guard","respond-to-shared-observed-bed-danger");return true;
    }return bedless(s,t,tick);}
    private boolean bedless(AiBrain.State s,Plan t,int tick){Player p=s.bot.getPlayer();var own=s.room.game.getTeamOfPlayer(p);if(own.isTargetBlockExists()||t.bedless==Bedless.ALL_IN)return false;boolean damaged=p.getHealth()<p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue()*.7;
        if(t.bedless==Bedless.FORTIFY){if(p.getLocation().distanceSquared(own.getTeamSpawn())>225)brain.strategy.travel(s,own.getTeamSpawn(),tick,"retreat","bedless-fortify-home-and-diamond");else if(brain.wool(p)<32)brain.strategy.travel(s,brain.strategy.forge(s),tick,"gather","bedless-fund-gapple-summon-turret-defense");else return false;return true;}
        if(t.bedless==Bedless.ROAM||t.bedless==Bedless.REGROUP&&damaged){var base=s.room.game.getAvailableTeams().stream().filter(team->team==own||!s.room.game.getRunningTeams().stream().anyMatch(r->r.getName().equals(team.getName())&&r.isAlive())).map(Team::getTeamSpawn).filter(AiTerrain::floor).sorted(Comparator.comparingDouble(at->at.distanceSquared(p.getLocation()))).toList();if(!base.isEmpty()){Location target=base.get(Math.floorMod(tick/600+s.index,base.size()));if(p.getLocation().distanceSquared(target)>16){brain.strategy.travel(s,target,tick,"retreat","bedless-rotate-vacant-bases-before-next-attack");return true;}}}
        return false;
    }
    void funded(AiBrain.State s,int tick){Plan t=plan(s);if(tick-t.lastFunding<200)return;t.lastFunding=tick;t.nextReview=Math.min(t.nextReview,tick+100);plugin.learning.telemetry.record(s.bot.getPlayer(),"team-funding-ready",Map.of("reason","수집 목표 확보 후 공유·장비 재정비·공동 공격 검토"));}
    boolean glassBreaker(AiBrain.State s){return s.bot.getPlayer().getUniqueId().equals(plan(s).glassBreaker);}
    boolean hasPartner(AiBrain.State s,Location at,double range){return members(s).stream().anyMatch(b->b!=s&&alive(b)&&b.bot.getPlayer().getLocation().distanceSquared(at)<range*range);}
    @EventHandler public void end(BedwarsGameEndEvent e){plans.remove(e.getGame());}
}
