package kr.mzs.gunbed;
/** Temporary geometry serves a combat decision; no blueprint completion obligation. */
final class AiCoverPolicy {
 enum Intent {NONE,HEAL,RELOAD,PEEK}
 static Intent choose(double health,boolean pressure,boolean loading,double recentDamage,String task,double confidence,double value){
  if(!pressure)return Intent.NONE;
  if(confidence>=.5){if(task.equals("heal")||task.equals("retreat"))return loading?Intent.RELOAD:Intent.HEAL;if(task.equals("fight")&&value>=.6&&health>.5&&!loading)return Intent.NONE;}
  if(loading)return Intent.RELOAD;
  if(health<.55||recentDamage>=.18)return Intent.HEAL;
  return health<.75?Intent.PEEK:Intent.NONE;
 }
}
