"""Real framebuffer capture adapter; shared protocol with server NeuralVision."""
from pathlib import Path

SOURCE=r'''package kr.mzs.gunbedvisual;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.IDENTIFIER;
import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.ByteArrayOutputStream;

/** Screenshots stay inside a running Gunbed match; human clients send controls only. */
public final class GunbedNeuralClient {
 private static final ExecutorService encoder=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"Gunbed-pixel-encoder");t.setDaemon(true);return t;});
 private static JsonObject request;private static int wait,ticks;private static boolean busy;private static float yaw,pitch;private static boolean positioned;
 private static float yawSum,pitchSum;private static boolean reload,swap,drop;private static long dropped;
 public record Frame(byte[] bytes) implements CustomPacketPayload {
  public static final Type<Frame> TYPE=new Type<>(IDENTIFIER.fromNamespaceAndPath("gunbed","learning"));
  public static final StreamCodec<RegistryFriendlyByteBuf,Frame> CODEC=StreamCodec.of((b,p)->b.writeBytes(p.bytes),b->{if(b.readableBytes()>30000)throw new IllegalArgumentException("Oversized learning frame");byte[] data=new byte[b.readableBytes()];b.readBytes(data);return new Frame(data);});
  @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
 }
 public static void register(){PayloadTypeRegistry.playC2S().register(Frame.TYPE,Frame.CODEC);PayloadTypeRegistry.playS2C().register(Frame.TYPE,Frame.CODEC);}
 public static void packet(JsonObject data){if(data.has("event")&&data.get("event").getAsString().matches("neuralFrame|neuralControls")){request=data.deepCopy();wait=data.get("delay").getAsInt();}}
 private static void send(JsonObject row){if(ClientPlayNetworking.canSend(Frame.TYPE)){byte[] raw=row.toString().getBytes(StandardCharsets.UTF_8);if(raw.length<=30000)ClientPlayNetworking.send(new Frame(raw));}}
 public static void tick(Minecraft client){
  if(client.player==null){request=null;positioned=false;yawSum=pitchSum=0;return;}
  if(!positioned){yaw=client.player.getYRot();pitch=client.player.getXRot();positioned=true;}
  yawSum+=net.minecraft.util.Mth.wrapDegrees(client.player.getYRot()-yaw);pitchSum+=client.player.getXRot()-pitch;yaw=client.player.getYRot();pitch=client.player.getXRot();
  reload|=net.minecraft.client.KeyMapping.isKeyDown(com.mojang.blaze3d.platform.InputConstants.getKey("key.keyboard.r"));
  swap|=client.options.keySwapOffhand.isDown();drop|=client.options.keyDrop.isDown();
  String key=System.getProperty("gunbed.neuralObserverKey","");if(++ticks%40==0&&!key.isEmpty()){JsonObject hello=new JsonObject();hello.addProperty("schema",1);hello.addProperty("event","observer");hello.addProperty("key",key);send(hello);}
  if(request==null||busy||wait-->0)return;
  if(Boolean.getBoolean("gunbed.neuralDebug")&&ticks%20==0)GunbedVisualClient.LOG.info("Pixel request {} camera {} target {} firstPerson {}",request.get("seq"),client.getCameraEntity()==null?"none":client.getCameraEntity().getUUID(),request.get("target"),client.options.getCameraType().isFirstPerson());
  if(client.screen instanceof net.minecraft.client.gui.screens.ChatScreen)return;
  boolean observer=request.get("observer").getAsBoolean();var camera=client.getCameraEntity();
  if(observer&&(!client.options.getCameraType().isFirstPerson()||camera==null||!camera.getUUID().toString().equals(request.get("target").getAsString())))return;
  JsonObject row=request.deepCopy();request=null;row.addProperty("schema",1);row.addProperty("event",observer?"frame":"controls");row.addProperty("capturedAt",System.currentTimeMillis());
  row.addProperty("screen",client.screen==null?"world":"inventory");row.addProperty("slot",client.player.getInventory().getSelectedSlot());
  boolean[] values={client.options.keyUp.isDown(),client.options.keyDown.isDown(),client.options.keyLeft.isDown(),client.options.keyRight.isDown(),client.options.keyJump.isDown(),client.options.keySprint.isDown(),client.options.keyShift.isDown(),client.options.keyAttack.isDown(),client.options.keyUse.isDown(),reload,swap,drop};
  JsonArray buttons=new JsonArray();for(boolean v:values)buttons.add(v?1:0);row.add("buttons",buttons);JsonArray aim=new JsonArray();aim.add(Math.max(-1,Math.min(1,yawSum/90)));aim.add(Math.max(-1,Math.min(1,pitchSum/90)));row.add("aim",aim);yawSum=pitchSum=0;reload=swap=drop=false;
  if(!observer){send(row);if(Boolean.getBoolean("gunbed.neuralDebug"))GunbedVisualClient.LOG.info("Controls sent {} without framebuffer capture",row.get("seq"));return;}
  busy=true;
  try{net.minecraft.client.Screenshot.takeScreenshot(client.getMainRenderTarget(),image->{
   BufferedImage rgb=new BufferedImage(160,90,BufferedImage.TYPE_INT_RGB);
   try{for(int y=0;y<90;y++)for(int x=0;x<160;x++)rgb.setRGB(x,y,image.getPixel(x*image.getWidth()/160,y*image.getHeight()/90));}finally{image.close();}
   encoder.execute(()->{try{ByteArrayOutputStream out=new ByteArrayOutputStream();ImageIO.write(rgb,"jpg",out);row.addProperty("image",Base64.getEncoder().encodeToString(out.toByteArray()));client.execute(()->{send(row);if(Boolean.getBoolean("gunbed.neuralDebug"))GunbedVisualClient.LOG.info("Pixel sent {} bytes {}",row.get("seq"),out.size());});}catch(Exception e){GunbedVisualClient.LOG.warn("Pixel recording skipped",e);}finally{client.execute(()->busy=false);}});
  });}catch(RuntimeException e){busy=false;dropped++;GunbedVisualClient.LOG.warn("Framebuffer unavailable; skipped {} frames",dropped);}
 }
}
'''

def generate(package:Path,version:str,identifier:str):
    text=SOURCE.replace('IDENTIFIER',identifier)
    # Raw key sampling is version independent through GLFW's already-loaded binding.
    text=text.replace('net.minecraft.client.KeyMapping.isKeyDown(com.mojang.blaze3d.platform.InputConstants.getKey("key.keyboard.r"))',
        'org.lwjgl.glfw.GLFW.glfwGetKey(client.getWindow().handle(),org.lwjgl.glfw.GLFW.GLFW_KEY_R)==org.lwjgl.glfw.GLFW.GLFW_PRESS')
    if version=='1.21.8':text=text.replace('client.getWindow().handle()','client.getWindow().getWindow()')
    if version.startswith('26.'):text=text.replace('PayloadTypeRegistry.playC2S()','PayloadTypeRegistry.serverboundPlay()').replace('PayloadTypeRegistry.playS2C()','PayloadTypeRegistry.clientboundPlay()')
    if version in ('26.2','26.3'):text=text.replace('client.screen','client.gui.screen()').replace('client.getMainRenderTarget()','client.gameRenderer.mainRenderTarget()')
    if version=='26.3':text=text.replace('org.lwjgl.glfw.GLFW.glfwGetKey(client.getWindow().handle(),org.lwjgl.glfw.GLFW.GLFW_KEY_R)==org.lwjgl.glfw.GLFW.GLFW_PRESS','com.mojang.blaze3d.platform.InputConstants.isKeyDown(com.mojang.blaze3d.platform.InputConstants.KEY_R)')
    (package/'GunbedNeuralClient.java').write_text(text,encoding='utf8')
