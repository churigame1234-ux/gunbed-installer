"""Loopback-only human demonstration recorder, continual trainer and pixel-policy inference.

Run separately from Paper. Only /frame(actor=human) is a training source. Observer
frames are inference-only. Complete rounds are disjoint between train and validation.
"""
from __future__ import annotations
import argparse,base64,hashlib,io,json,math,os,re,shutil,threading,time,uuid
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import numpy as np
from PIL import Image
import torch
import torch.nn.functional as F
import yaml
from model import PixelPolicy,load_model,SCHEMA,WIDTH,HEIGHT,STATE,BUTTONS,TASKS

def atomic(path:Path,data:bytes):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp');temp.write_bytes(data);os.replace(temp,path)

def pixel(data):
    with Image.open(io.BytesIO(data)) as image:
        if image.width>4096 or image.height>4096:raise ValueError('Image dimensions exceed limit')
        a=np.array(image.convert('RGB').resize((WIDTH,HEIGHT)),copy=True)
    return torch.from_numpy(a).permute(2,0,1).float()/255

def clean_state(v):
    if not isinstance(v,list) or len(v)!=STATE:raise ValueError('Invalid self-state schema')
    a=[float(x) for x in v]
    if not all(math.isfinite(x) for x in a):raise ValueError('Non-finite observation')
    return [max(-10,min(10,x)) for x in a]

class Worker:
    def __init__(self,root:Path,minimum_rounds=3,minimum_frames=600,max_epochs=50):
        self.root=root.resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.minimum_rounds=minimum_rounds;self.minimum_frames=minimum_frames;self.max_epochs=max_epochs
        self.lock=threading.RLock();self.infer_lock=threading.Lock();self.busy=False;self.history={};self.last_train_count=0;self.episode_bytes={}
        self.model=None;self.version='';self.metadata={};self.state='영상 자료 대기';self.error='';self.frames=0;self.observer_frames=0;self.rejected=0
        self.pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='gunbed-human-learning')
        torch.set_num_threads(2)
        policy=self.root/'active.pt'
        if policy.exists():self.model,self.metadata=load_model(policy);self.version=self.metadata.get('version','');self.last_train_count=int(self.metadata.get('frames',0));self.state='검증된 사람 영상 모델 준비'
        index=self.root/'training-index.json'
        if index.exists():
            try:self.last_train_count=max(self.last_train_count,int(json.loads(index.read_text())['frames']))
            except (ValueError,KeyError):pass
        episodes=self.root/'episodes'
        if episodes.exists():
            for folder in episodes.iterdir():
                if not re.fullmatch('[a-f0-9]{24}',folder.name) or folder.is_symlink() or not folder.resolve().is_relative_to(episodes.resolve()):continue
                marker=folder/'outcome.json';stamp=marker.stat().st_mtime if marker.exists() else folder.stat().st_mtime
                if time.time()-stamp>30*86400:shutil.rmtree(folder)
        self.report({'상태':self.state,'설명':'실제 사람의 화면과 조작이 있는 완료 경기만 학습합니다. 기존 통계 로그는 영상 시범으로 대체하지 않습니다.'})
    def report(self,extra):
        atomic(self.root/'최근-신경망학습.yml',yaml.safe_dump({'갱신시각':time.strftime('%Y-%m-%d %H:%M:%S'),**extra},allow_unicode=True,sort_keys=False).encode())
    def status(self):
        with self.lock:return {'schema':SCHEMA,'busy':self.busy,'state':self.state,'error':self.error,'version':self.version,
                               'framesReceived':self.frames,'observerFrames':self.observer_frames,'rejected':self.rejected,'ready':self.model is not None,'model':self.metadata}
    def frame(self,row):
        if row.get('schema')!=SCHEMA:raise ValueError('Invalid schema')
        raw=base64.b64decode(row['image'],validate=True)
        if not 100<=len(raw)<=40000:raise ValueError('Invalid frame size')
        im=pixel(raw);state=clean_state(row['state'])
        if row.get('actor')=='observer':
            self.observer_frames+=1
            if self.observer_frames%4==1:
                key=hashlib.sha256(str(row['player']).encode()).hexdigest()[:24]
                atomic(self.root/'previews'/f'{key}.jpg',raw)
            return self.predict(row,im,state)
        if row.get('actor')!='human':raise ValueError('Only human demonstrations are accepted')
        round_id=str(row['round']);actor=str(row['player']);seq=int(row['seq']);stamp=int(row['time'])
        if seq<0 or stamp<0:raise ValueError('Invalid sequence')
        buttons=row['buttons'];aim=row['aim'];slot=int(row['slot'])
        if len(buttons)!=len(BUTTONS) or any(v not in (0,1,False,True) for v in buttons):raise ValueError('Invalid buttons')
        if len(aim)!=2 or any(not math.isfinite(float(x)) for x in aim) or not 0<=slot<9:raise ValueError('Invalid controls')
        # Round names and user names never become filesystem paths.
        key=hashlib.sha256(round_id.encode()).hexdigest()[:24];person=hashlib.sha256(actor.encode()).hexdigest()[:24]
        folder=self.root/'episodes'/key/person;folder.mkdir(parents=True,exist_ok=True)
        path=folder/f'{seq:010d}.jpg'
        task=row.get('task','rush');task=task if task in TASKS else 'rush'
        record={k:row[k] for k in ('round','player','seq','time','teacher','map','cameraSource') if k in row}
        record.update(schema=SCHEMA,actor='human',state=state,buttons=buttons,aim=[max(-1,min(1,float(x))) for x in aim],slot=slot,task=task,
                      taskLabel='server-observed weak label; not a recorded human intention',image=path.name)
        if row.get('testFixture'):record['testFixture']=True
        with self.lock:
            if path.exists():return {'accepted':False,'reason':'duplicate'}
            # Limit storage without silently deleting another player's files.
            if str(folder) not in self.episode_bytes:self.episode_bytes[str(folder)]=sum(p.stat().st_size for p in folder.glob('*.jpg'))
            stored=self.episode_bytes[str(folder)]
            if stored>256*1024*1024:return {'accepted':False,'reason':'episode storage cap'}
            atomic(path,raw)
            self.episode_bytes[str(folder)]=stored+len(raw)
            with (folder/'frames.jsonl').open('a',encoding='utf8') as stream:stream.write(json.dumps(record,ensure_ascii=False)+'\n')
            self.frames+=1
        return {'accepted':True}
    def finish(self,row):
        key=hashlib.sha256(str(row['round']).encode()).hexdigest()[:24]
        outcome={'round':str(row['round']),'complete':bool(row.get('complete',False)),'winners':list(row.get('winners',[])),
                 'time':int(time.time()*1000),'source':'actual human game; not AI self-play'}
        atomic(self.root/'episodes'/key/'outcome.json',json.dumps(outcome).encode())
        return self.schedule()
    def schedule(self):
        with self.lock:
            if self.busy:return {'queued':False,'busy':True}
            rounds,rows=self.dataset()
            if len(rounds)<self.minimum_rounds or len(rows)<self.minimum_frames:
                self.state='영상 자료 부족';self.report({'상태':self.state,'완료경기':len(rounds),'영상프레임':len(rows),'필요완료경기':self.minimum_rounds,'필요프레임':self.minimum_frames,'모델적용':False})
                return {'queued':False,'reason':'insufficient real human video','rounds':len(rounds),'frames':len(rows)}
            if len(rows)<=self.last_train_count:return {'queued':False,'reason':'no new human frames'}
            actions={tuple(r['buttons']) for r in rows};tasks={r['task'] for r in rows}
            if len(actions)<4 or len(tasks)<3:
                self.state='영상 행동 다양성 부족';self.report({'상태':self.state,'행동조합':len(actions),'상황분류':len(tasks),'모델적용':False})
                return {'queued':False,'reason':'insufficient action diversity'}
            self.busy=True;self.state='사람 영상 신경망 학습 중';self.error='';self.pool.submit(self.train,rounds,rows)
            return {'queued':True,'busy':True}
    def dataset(self):
        rounds=[];rows=[]
        for folder in sorted((self.root/'episodes').glob('*')):
            f=folder/'outcome.json'
            if not f.exists():continue
            try:outcome=json.loads(f.read_text());
            except (ValueError,OSError):continue
            if not outcome.get('complete'):continue
            samples=[]
            for source in sorted(folder.glob('*/frames.jsonl')):
                stream=[]
                for line in source.read_text(encoding='utf8').splitlines():
                    try:
                        r=json.loads(line)
                        if r.get('actor')!='human' or r.get('testFixture'):continue
                        r['_path']=source.parent/r['image'];r['_episode']=folder.name;r['_stream']=str(source)
                        r['_value']=1.0 if r['player'] in outcome['winners'] else 0.0
                        stream.append(r)
                    except (ValueError,KeyError):continue
                # Gaps and life/camera changes are not continuous action sequences.
                stream.sort(key=lambda r:r['seq']);samples.extend(stream)
            if len(samples)>=16:rounds.append(folder.name);rows.extend(samples)
        return rounds,rows
    def sequences(self,rows):
        streams=defaultdict(list)
        for r in rows:streams[r['_stream']].append(r)
        out=[]
        for stream in streams.values():
            for start in range(0,len(stream)-31,16):
                seq=stream[start:start+32]
                if all(0<seq[i+1]['time']-seq[i]['time']<=1200 and seq[i+1]['seq']>seq[i]['seq'] for i in range(31)):out.append(seq)
        return out
    def batch(self,seqs):
        images=torch.stack([torch.stack([pixel(r['_path'].read_bytes()) for r in s]) for s in seqs])
        state=torch.tensor([[r['state'] for r in s] for s in seqs],dtype=torch.float32)
        targets={'buttons':torch.tensor([[r['buttons'] for r in s] for s in seqs],dtype=torch.float32),
                 'aim':torch.tensor([[r['aim'] for r in s] for s in seqs],dtype=torch.float32),
                 'slot':torch.tensor([[r['slot'] for r in s] for s in seqs]),'task':torch.tensor([[TASKS.index(r['task']) for r in s] for s in seqs]),
                 'value':torch.tensor([[r['_value'] for r in s] for s in seqs]),
                 'teacher':torch.tensor([[1.5 if r.get('teacher') else 1. for r in s] for s in seqs])}
        return images,state,targets
    def loss(self,model,batch):
        image,state,y=batch;out,_=model(image,state)
        # Weak strategic labels and eventual victory are auxiliary targets, not proof of causal correctness.
        weight=y.get('teacher',torch.ones_like(y['value']))
        def mean(v):return (v*weight).sum()/weight.sum()
        return mean(F.binary_cross_entropy_with_logits(out['buttons'],y['buttons'],reduction='none').mean(-1))+\
               mean(F.smooth_l1_loss(out['aim'],y['aim'],reduction='none').mean(-1))+\
               .3*mean(F.cross_entropy(out['slot'].flatten(0,1),y['slot'].flatten(),reduction='none').reshape_as(weight))+\
               .15*mean(F.cross_entropy(out['task'].flatten(0,1),y['task'].flatten(),reduction='none').reshape_as(weight))+\
               .1*mean(F.binary_cross_entropy_with_logits(out['value'],y['value'],reduction='none'))
    def train(self,rounds,rows):
        try:
            # Entire held-out rounds prevent adjacent video frames leaking across the split.
            ordered=sorted(rounds,key=lambda x:hashlib.sha256(x.encode()).hexdigest());validation=set(ordered[:max(1,len(ordered)//5)])
            train_seq=self.sequences([r for r in rows if r['_episode'] not in validation]);val_seq=self.sequences([r for r in rows if r['_episode'] in validation])
            if not train_seq or not val_seq:raise ValueError('Insufficient continuous video sequences')
            rng=np.random.default_rng(148);rng.shuffle(train_seq);rng.shuffle(val_seq)
            # Bounded corpus per update includes old rounds; no newest-game-only catastrophic overwrite.
            train_seq=train_seq[:600];val_seq=val_seq[:100]
            train_batches=[self.batch(train_seq[i:i+4]) for i in range(0,len(train_seq),4)]
            val_batches=[self.batch(val_seq[i:i+4]) for i in range(0,len(val_seq),4)]
            model=PixelPolicy()
            with self.infer_lock:
                if self.model is not None:model.load_state_dict(self.model.state_dict())
            def evaluate():
                model.eval()
                with torch.no_grad():return sum(float(self.loss(model,b))*len(b[0]) for b in val_batches)/sum(len(b[0]) for b in val_batches)
            baseline=evaluate();best=baseline;best_weights={k:v.detach().clone() for k,v in model.state_dict().items()}
            optimizer=torch.optim.AdamW(model.parameters(),lr=3e-4,weight_decay=1e-4);stale=0;epochs=0;begin=time.monotonic()
            for epoch in range(self.max_epochs):
                model.train()
                for i in rng.permutation(len(train_batches)):
                    optimizer.zero_grad();loss=self.loss(model,train_batches[i])
                    if not torch.isfinite(loss):raise ValueError('Non-finite training loss')
                    loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1);optimizer.step()
                score=evaluate();epochs=epoch+1
                if score<best-1e-4:best=score;best_weights={k:v.detach().clone() for k,v in model.state_dict().items()};stale=0
                else:stale+=1
                if stale>=6:break
            accepted=math.isfinite(best) and best<baseline*.99
            version=time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6]
            metadata={'schema':SCHEMA,'version':version,'source':'human-video-only','rounds':len(rounds),'frames':len(rows),
                      'validationRounds':sorted(validation),'baselineLoss':baseline,'candidateLoss':best,'epochs':epochs,'seconds':round(time.monotonic()-begin,2),
                      'limitations':'Offline imitation validation does not prove higher live win rate; task labels are weak labels.'}
            if accepted:
                buffer=io.BytesIO();torch.save({**metadata,'weights':best_weights},buffer)
                candidate=self.root/'models'/f'{version}.pt';atomic(candidate,buffer.getvalue())
                with self.infer_lock:
                    active=self.root/'active.pt'
                    if active.exists():atomic(self.root/'previous.pt',active.read_bytes())
                    atomic(active,buffer.getvalue());self.model,self.metadata=load_model(active);self.version=version;self.history.clear()
            self.last_train_count=len(rows);atomic(self.root/'training-index.json',json.dumps({'frames':len(rows),'version':self.version}).encode());self.state='검사 통과 · 다음 경기부터 사용 가능' if accepted else '개선 확인 안 됨 · 기존 모델 유지'
            report={'상태':self.state,'학습자료':'사람의 실제 화면·조작·경기 결과','AI자가대전':False,'완료경기':len(rounds),'영상프레임':len(rows),
                    '학습시퀀스':len(train_seq),'검증시퀀스':len(val_seq),'검증경기분리':True,'학습횟수':epochs,'학습초':metadata['seconds'],
                    '기존검증손실':baseline,'후보검증손실':best,'모델적용':accepted,'후보버전':version,'현재버전':self.version,
                    '주의':'검증 손실 개선은 사람 행동 예측 개선입니다. 실제 승률 향상과 동일하지 않으며 실제 사람 경기에서 별도 확인합니다.'}
            atomic(self.root/'reports'/f'{version}.yml',yaml.safe_dump(report,allow_unicode=True,sort_keys=False).encode());self.report(report)
        except Exception as e:
            self.error=type(e).__name__+': '+str(e);self.state='학습 실패 · 기존 모델 유지';self.report({'상태':self.state,'오류':self.error,'모델적용':False})
        finally:
            with self.lock:self.busy=False
    def predict(self,row,image,state):
        with self.infer_lock:
            if self.model is None:return {'ready':False,'reason':'no validated human-video model'}
            # A new game freezes one exact model; don't hot-swap a recurrent policy mid-match.
            wanted=str(row.get('version',''))
            if not wanted:return {'ready':False,'reason':'no model frozen for this round'}
            if wanted and wanted!=self.version:
                p=self.root/'models'/f'{wanted}.pt'
                if not p.exists():return {'ready':False,'reason':'frozen model not found'}
                model,_=load_model(p)
            else:model=self.model;wanted=self.version
            key=(str(row['round']),str(row['player']),wanted);old=self.history.get(key);now=time.monotonic()
            hidden=old[1] if old and now-old[0]<15 else None
            with torch.no_grad():out,hidden=model(image[None,None],torch.tensor(state)[None,None],hidden)
            self.history[key]=(now,hidden.detach());self.history={k:v for k,v in self.history.items() if now-v[0]<30}
            task=out['task'][0,-1].softmax(-1);buttons=out['buttons'][0,-1].sigmoid();aim=out['aim'][0,-1]
            return {'ready':True,'version':wanted,'task':TASKS[int(task.argmax())],'confidence':float(task.max()),
                    'tasks':task.tolist(),'buttons':buttons.tolist(),'aim':aim.tolist(),'slot':int(out['slot'][0,-1].argmax()),'value':float(out['value'][0,-1].sigmoid())}
    def close(self):self.pool.shutdown(wait=True)

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        if self.path!='/status':self.send_error(404);return
        self.respond(self.server.worker.status())
    def respond(self,row,code=200):
        raw=json.dumps(row,ensure_ascii=False).encode();self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    def do_POST(self):
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=100000:raise ValueError('Body size limit')
            row=json.loads(self.rfile.read(size));worker=self.server.worker
            if self.path=='/frame':result=worker.frame(row)
            elif self.path=='/finish':result=worker.finish(row)
            else:self.send_error(404);return
            self.respond(result)
        except (ValueError,KeyError,TypeError,OSError) as e:self.server.worker.rejected+=1;self.respond({'error':type(e).__name__+': '+str(e)},400)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True);parser.add_argument('--port',type=int,default=25789)
    args=parser.parse_args();worker=Worker(args.root);server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler);server.worker=worker
    print(json.dumps({'listening':f'127.0.0.1:{args.port}','root':str(worker.root),'state':worker.state},ensure_ascii=False),flush=True)
    worker.schedule()
    try:server.serve_forever()
    finally:server.server_close();worker.close()
if __name__=='__main__':main()
