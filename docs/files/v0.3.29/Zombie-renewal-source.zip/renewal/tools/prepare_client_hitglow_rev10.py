"""2026-11-27 client rev 10: attacker-only red hit glow + hello zombie:7.

The server sends {"event":"hitGlow","uuids":[...],"durationMs":3000} to the attacker only; HudState keeps the
expiry per entity. This patch makes those entities report isCurrentlyGlowing() on this client and gives
them the red outline colour (the colour lookup previously only ran while the Gunbed HUD was active).
Run after prepare_client_hands.py. Idempotent.
"""
import re
from prepare_client_controls import CLIENT, VERSIONS

GLOW_OLD = 'private void gunbed$glow(CallbackInfoReturnable<Integer> ci){var state=kr.mzs.gunbedvisual.HudState.INSTANCE;if(!state.active())return;'
GLOW_NEW = ('private void gunbed$glow(CallbackInfoReturnable<Integer> ci){var state=kr.mzs.gunbedvisual.HudState.INSTANCE;'
            'if(state.hitGlowing(((net.minecraft.world.entity.Entity)(Object)this).getUUID())){ci.setReturnValue(kr.mzs.gunbedvisual.HudState.HIT_GLOW_COLOR);return;}'
            'if(!state.active())return;')
HIT = (' @Inject(method="isCurrentlyGlowing",at=@At("RETURN"),cancellable=true,require=0)\n'
       ' private void gunbed$hitGlow(CallbackInfoReturnable<Boolean> ci){if(!ci.getReturnValue()&&kr.mzs.gunbedvisual.HudState.INSTANCE.hitGlowing(((net.minecraft.world.entity.Entity)(Object)this).getUUID()))ci.setReturnValue(true);}\n')

for version in VERSIONS:
    package = CLIENT / '.generated' / version / 'java/kr/mzs/gunbedvisual'
    mixin = package / 'mixin/GunbedVisibilityMixin.java'
    text = mixin.read_text(encoding='utf-8')
    if GLOW_NEW not in text:
        assert GLOW_OLD in text, version
        text = text.replace(GLOW_OLD, GLOW_NEW)
    if 'gunbed$hitGlow' not in text:
        text = text.rstrip()
        assert text.endswith('}'), version
        text = text[:-1] + HIT + '}\n'
    mixin.write_text(text, encoding='utf-8')

    client = package / 'GunbedVisualClient.java'
    text = client.read_text(encoding='utf-8')
    text = re.sub(r'\\"zombie\\":[2-8](?=\D)', r'\\"zombie\\":9', text)  # 0.3.29: glow colour null crash fix
    assert '\\"zombie\\":9' in text, version
    client.write_text(text, encoding='utf-8')
    print('rev10 hit glow', version)
