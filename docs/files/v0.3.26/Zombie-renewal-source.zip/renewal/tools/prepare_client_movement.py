"""Zombie-only physics adapters; the inherited Gunbed paths remain gated off on other backends."""
import json
from prepare_client_controls import CLIENT,VERSIONS

MOVEMENT=r'''package kr.mzs.gunbedvisual;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;
import kr.mzs.renewal.GoldSrcMovement;
import java.util.*;

public final class ZombieMovement {
    private static boolean match,locked,previousSpace,queuedJump,armed=true,escape;
    private static int jumpBuffer;private static boolean ducked;private static long stunUntil;
    private static String role="spectator";
    private static double scale=1;
    private static long nextDoubleJump;
    private static int ladderDetachUntil;
    private static boolean combatReady;
    public static boolean combatReady(){return combatReady;}
    private static Vec3 pendingVelocity;
    private static long velocityUntil;
    private static Vec3 lastNativeVelocity;
    private static long nativeVelocityAt;
    private static final Set<UUID> respawning=new HashSet<>();
    private ZombieMovement(){}
    public static boolean active(){return match&&ZombieControls.active();}
    public static boolean physical(LocalPlayer p){return active()&&!role.equals("spectator")&&!p.isSpectator()&&!p.getAbilities().flying&&!p.isPassenger();}
    public static void packet(JsonObject d){
        String event=d.has("event")?d.get("event").getAsString():"";
        if(event.equals("hud")){
            boolean next=d.has("zombieServer")&&d.get("zombieServer").getAsBoolean()&&d.has("zombieMatch")&&d.get("zombieMatch").getAsBoolean();
            if(!next){clear();return;}match=true;combatReady=d.has("zombieCombatReady")&&d.get("zombieCombatReady").getAsBoolean();role=d.get("zombieRole").getAsString();
            locked=d.has("loadoutPending")&&d.get("loadoutPending").getAsBoolean()||d.has("movementLocked")&&d.get("movementLocked").getAsBoolean();
            if(d.has("movementScale"))scale=d.get("movementScale").getAsDouble();
        }else if(event.equals("zombieRoster")){
            escape=d.get("mode").getAsString().equals("escape");respawning.clear();
            for(var entry:d.getAsJsonArray("players")){var p=entry.getAsJsonObject();if(p.get("respawning").getAsBoolean())respawning.add(UUID.fromString(p.get("uuid").getAsString()));}
        }else if(event.equals("zombieVelocity")){
            pendingVelocity=new Vec3(d.get("vx").getAsDouble(),d.get("vy").getAsDouble(),d.get("vz").getAsDouble());velocityUntil=System.nanoTime()+200_000_000L;
            if(Boolean.getBoolean("gunbed.auditVelocity"))GunbedVisualClient.LOG.info("VELOCITY_RPC {}",pendingVelocity);
            restoreFullVelocity();
        }else if(event.equals("zombieJump")){
            var p=Minecraft.getInstance().player;if(p!=null&&active())p.setDeltaMovement(d.get("vx").getAsDouble(),d.get("vy").getAsDouble(),d.get("vz").getAsDouble());
            if(!d.get("accepted").getAsBoolean())armed=false;
        }
    }
    public static Input input(Input raw){
        if(!active())return raw;
        var p=Minecraft.getInstance().player;
        if(p==null||!physical(p)||p.isInWater()||p.isInLava()||p.onClimbable()){previousSpace=raw.jump();queuedJump=false;return raw;}
        if(raw.jump()&&!previousSpace)queuedJump=true;previousSpace=raw.jump();
        return new Input(raw.forward(),raw.backward(),raw.left(),raw.right(),false,raw.shift(),raw.sprint());
    }
    /** 2026-11-26 rev3: zombies/hosts see their real HP on the HUD; humans keep the Gunbed /100 display. */
    public static boolean zombieRole(){return match&&(role.equals("zombie")||role.equals("host"));}
    public static String hpText(double health,double max){return zombieRole()?Long.toString((long)Math.ceil(health)):Integer.toString((int)Math.ceil(health/(max<1000?max/100:100)));}
    public static boolean wheelEnabled(){var p=Minecraft.getInstance().player;return p!=null&&physical(p);}
    public static void wheel(){if(wheelEnabled())queuedJump=true;}
    public static void clear(){jumpBuffer=0;ducked=false;stunUntil=0;match=false;combatReady=false;locked=false;previousSpace=false;queuedJump=false;armed=true;nextDoubleJump=0;ladderDetachUntil=0;pendingVelocity=null;lastNativeVelocity=null;nativeVelocityAt=0;scale=1;role="spectator";respawning.clear();}
    public static void velocityPacket(int id){
        if(Boolean.getBoolean("gunbed.auditVelocity"))GunbedVisualClient.LOG.info("VELOCITY_NATIVE id={} pending={}",id,pendingVelocity);
        var p=Minecraft.getInstance().player;if(p==null||p.getId()!=id)return;
        lastNativeVelocity=p.getDeltaMovement();nativeVelocityAt=System.nanoTime();restoreFullVelocity();
    }
    private static void restoreFullVelocity(){
        var p=Minecraft.getInstance().player;if(p==null||!physical(p)||pendingVelocity==null||lastNativeVelocity==null||System.nanoTime()>velocityUntil||System.nanoTime()-nativeVelocityAt>200_000_000L)return;
        Vec3 full=pendingVelocity,nativeValue=lastNativeVelocity;
        if(Math.max(Math.abs(full.x),Math.max(Math.abs(full.y),Math.abs(full.z)))<=3.9)return;
        if(legacyMotion(nativeValue.x,full.x)&&legacyMotion(nativeValue.y,full.y)&&legacyMotion(nativeValue.z,full.z)){
            Vec3 current=p.getDeltaMovement();p.setDeltaMovement(Math.abs(full.x)>3.9?full.x:current.x,Math.abs(full.y)>3.9?full.y:current.y,Math.abs(full.z)>3.9?full.z:current.z);pendingVelocity=null;
        }
    }
    private static boolean legacyMotion(double received,double full){return Math.abs(full)<=3.9?Math.abs(received-full)<.005:Math.signum(received)==Math.signum(full)&&Math.abs(received)>=3.895&&Math.abs(received)<=4.096;}
    /** Height to clear when a standing player is right in front (within 1.1 blocks, ahead of the view). 0 = ordinary jump. */
    private static double headLift(LocalPlayer p,Minecraft client){
        double yaw=Math.toRadians(p.getYRot()),fx=-Math.sin(yaw),fz=Math.cos(yaw),best=0;
        for(var other:client.level.players()){
            if(other==p||other.isSpectator()||respawning.contains(other.getUUID()))continue;
            double dx=other.getX()-p.getX(),dz=other.getZ()-p.getZ(),flat=Math.hypot(dx,dz),top=other.getBoundingBox().maxY-p.getY();
            if(flat>1.1||top<1.0||top>2.4||flat>.2&&(dx*fx+dz*fz)/flat<.3)continue;
            best=Math.max(best,top+.2);
        }
        return best;
    }
    public static boolean travel(LocalPlayer p){
        if(!physical(p)||p.isInWater()||p.isInLava())return false;
        var client=Minecraft.getInstance();Input keys=p.input.keyPresses;
        // Jump buffer: a press up to 3 ticks before landing fires on the landing tick (perfect CS hop, made easy at 20 ticks/s).
        if(queuedJump)jumpBuffer=3;queuedJump=false;
        // 2026-11-26: ladders use vanilla climbing + the server's old FastAscend boost; ladder jump and double jump removed.
        if(p.onClimbable()){jumpBuffer=0;ducked=false;return false;}
        boolean ground=p.onGround();GoldSrcMovement.Ladder ladder=null;
        boolean jump=jumpBuffer>0&&ground;if(jumpBuffer>0)jumpBuffer--;if(jump)jumpBuffer=0;
        // CS air duck: crouching mid-air pulls the legs up 18u (duck jump / stand-up bunny); releasing in the air puts them back.
        boolean crouch=p.input.keyPresses.shift();
        if(ground)ducked=false;
        else if(crouch&&!ducked){ducked=true;p.move(MoverType.SELF,new Vec3(0,GoldSrcMovement.DUCK_LIFT,0));}
        else if(!crouch&&ducked){ducked=false;p.move(MoverType.SELF,new Vec3(0,-GoldSrcMovement.DUCK_LIFT,0));ground=p.onGround();}
        double stun=Math.max(0,(stunUntil-System.nanoTime())/1e9)/GoldSrcMovement.STUN_SECONDS;
        boolean canMove=!locked&&NO_SCREEN;
        double forward=canMove?(keys.forward()?1:0)-(keys.backward()?1:0):0;
        double side=canMove?(keys.right()?1:0)-(keys.left()?1:0):0;
        if(!canMove)jump=false;
        Vec3 current=p.getDeltaMovement();
        GoldSrcMovement.Velocity before=new GoldSrcMovement.Velocity(current.x,current.y,current.z);
        var input=new GoldSrcMovement.Input(forward,side,!p.isSprinting(),keys.shift(),jump&&canMove);
        var result=GoldSrcMovement.step(before,input,ground,ladder,p.getYRot(),p.getXRot(),Math.max(.01,scale));
        Vec3 move=new Vec3(result.movement().x(),result.movement().y(),result.movement().z());
        if(ground&&!result.jumped()&&ladder==null)move=new Vec3(move.x,-.05,move.z);
        double nextY=result.next().y();
        // Mild CS landing stun: walking right after a jump is a little slower; a jump during it is a little lower.
        if(stun>0&&ground&&!result.jumped()){double keep=1-GoldSrcMovement.STUN_GROUND_LOSS*stun;move=new Vec3(move.x*keep,move.y,move.z*keep);}
        if(result.jumped()){if(stun>0){double keep=1-GoldSrcMovement.STUN_JUMP_LOSS*stun;nextY=nextY+move.y*(keep-1);move=new Vec3(move.x,move.y*keep,move.z);}stunUntil=System.nanoTime()+(long)(GoldSrcMovement.STUN_SECONDS*1e9);}
        // CS zombie mode: one jump from right in front of someone lands on their head (normal mode only).
        if(result.jumped()&&!escape){double lift=headLift(p,client);if(lift>0){double g=GoldSrcMovement.GRAVITY,v=Math.sqrt(2*g*lift)+g/2;if(v>move.y){move=new Vec3(move.x,v,move.z);nextY=v-g;}}}
        boolean head=false;
        if(!escape)for(var other:client.level.players()){
            if(other==p||other.isSpectator()||respawning.contains(other.getUUID()))continue;
            var box=other.getBoundingBox();double x=p.getX()+move.x,z=p.getZ()+move.z;
            if(Math.abs(x-other.getX())<.55&&Math.abs(z-other.getZ())<.55&&p.getY()>=box.maxY-.12&&p.getY()+move.y<=box.maxY&&move.y<=0){move=new Vec3(move.x,box.maxY-p.getY(),move.z);head=true;}
            else if(p.getY()<box.maxY-.08&&p.getY()+p.getBbHeight()>box.minY+.08&&Math.abs(x-other.getX())<.6&&Math.abs(z-other.getZ())<.6){
                double old=Math.hypot(p.getX()-other.getX(),p.getZ()-other.getZ()),next=Math.hypot(x-other.getX(),z-other.getZ());
                if(next<old-.00001){if(Math.abs(p.getX()-other.getX())>=.6)move=new Vec3(0,move.y,move.z);else if(Math.abs(p.getZ()-other.getZ())>=.6)move=new Vec3(move.x,move.y,0);else move=new Vec3(0,move.y,0);}
            }
        }
        p.setDeltaMovement(move);p.move(MoverType.SELF,move);Vec3 resolved=p.getDeltaMovement();
        if(head)p.setOnGround(true);
        p.setDeltaMovement(resolved.x,p.onGround()?0:nextY,resolved.z);p.fallDistance=0;
        return true;
    }
}
'''

TRAVEL=r'''package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LivingEntity.class)
public abstract class ZombieTravelMixin {
    @Inject(method="travel",at=@At("HEAD"),cancellable=true)
    private void zombie$travel(Vec3 input,CallbackInfo ci){if((Object)this instanceof LocalPlayer player&&kr.mzs.gunbedvisual.ZombieMovement.travel(player))ci.cancel();}
}
'''

KEYBOARD=r'''package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.client.player.ClientInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(KeyboardInput.class)
public abstract class ZombieJumpInputMixin {
    @Inject(method="tick",at=@At("TAIL"))
    private void zombie$jump(CallbackInfo ci){ClientInput input=(ClientInput)(Object)this;input.keyPresses=kr.mzs.gunbedvisual.ZombieMovement.input(input.keyPresses);}
}
'''

WHEEL=r'''package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MouseHandler.class)
public abstract class ZombieWheelMixin {
    @Inject(method="onScroll",at=@At("HEAD"),cancellable=true)
    private void zombie$wheel(long window,double x,double y,CallbackInfo ci){var client=Minecraft.getInstance();if(kr.mzs.gunbedvisual.ZombieMovement.wheelEnabled()&&NO_SCREEN&&y!=0){kr.mzs.gunbedvisual.ZombieMovement.wheel();ci.cancel();}}
}
'''

VELOCITY=r'''package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ClientPacketListener.class)
public abstract class ZombieVelocityMixin {
    @Inject(method="handleSetEntityMotion",at=@At("TAIL"))
    private void zombie$velocity(ClientboundSetEntityMotionPacket packet,CallbackInfo ci){kr.mzs.gunbedvisual.ZombieMovement.velocityPacket(packet.getId());}
}
'''

for version in VERSIONS:
    base=CLIENT/'.generated'/version
    package=base/'java/kr/mzs/gunbedvisual'
    screen='client.gui.screen()==null' if version in ('26.2','26.3') else 'client.screen==null'
    for filename,text in [('ZombieMovement.java',MOVEMENT),('mixin/ZombieTravelMixin.java',TRAVEL),('mixin/ZombieJumpInputMixin.java',KEYBOARD),('mixin/ZombieWheelMixin.java',WHEEL),('mixin/ZombieVelocityMixin.java',VELOCITY)]:
        if version.startswith('26.'):text=text.replace('packet.getId()','packet.id()')
        (package/filename).write_text(text.replace('NO_SCREEN',screen),encoding='utf-8')
    network=package/'GunbedVisualClient.java';text=network.read_text(encoding='utf-8')
    if 'ZombieMovement.packet(data)' not in text:
        text=text.replace('ZombieControls.packet(data);','ZombieControls.packet(data);ZombieMovement.packet(data);')
        text=text.replace('ZombieControls.clear();','ZombieControls.clear();ZombieMovement.clear();')
        position=text.index('        var reloadKey=')
        end=text.index('\n',position)
        reload_line=text[position:end]
        drop_line=reload_line.replace('reloadKey','zombieDropKey').replace('key.gunbed.reload','key.zombie.drop').replace('GLFW_KEY_R','GLFW_KEY_G')
        text=text[:end]+'\n'+drop_line+text[end:]
        text=text.replace('            while(reloadKey.consumeClick())','            while(zombieDropKey.consumeClick())if(ZombieMovement.active()&&'+screen+')zombieEvent("drop_request");\n            while(reloadKey.consumeClick())')
        text=text.replace('    public static void zombieSprint(','''    public static void zombieEvent(String event){if(ClientPlayNetworking.canSend(Wire.TYPE))ClientPlayNetworking.send(new Wire(("{\\"v\\":1,\\"event\\":\\""+event+"\\"}").getBytes(StandardCharsets.UTF_8)));}
    public static void zombieSprint(''')
        network.write_text(text,encoding='utf-8')
    text=network.read_text(encoding='utf-8')
    if 'void zombieJump(double yaw)' not in text:
        text=text.replace('    public static void zombieSprint(','''    public static void zombieJump(double yaw){
        if(!ClientPlayNetworking.canSend(Wire.TYPE))return;
        var data=new com.google.gson.JsonObject();data.addProperty("v",1);data.addProperty("event","zombie_jump");data.addProperty("yaw",yaw);
        ClientPlayNetworking.send(new Wire(data.toString().getBytes(StandardCharsets.UTF_8)));
    }
    public static void zombieSprint(''')
        network.write_text(text,encoding='utf-8')
    config=base/'resources/gunbed.mixins.json';data=json.loads(config.read_text(encoding='utf-8'))
    for mixin in ('ZombieTravelMixin','ZombieJumpInputMixin','ZombieWheelMixin','ZombieVelocityMixin'):
        if mixin not in data['client']:data['client'].append(mixin)
    config.write_text(json.dumps(data,indent=2),encoding='utf-8')
    for lang,label in [('ko_kr','좀비 서버 무기·투척물 버리기'),('en_us','Drop zombie-server equipment')]:
        file=base/f'resources/assets/gunbed/lang/{lang}.json';content=json.loads(file.read_text(encoding='utf-8'));content['key.zombie.drop']=label;file.write_text(json.dumps(content,ensure_ascii=False),encoding='utf-8')
    world=package/'mixin/GunbedWorldMixin.java';text=world.read_text(encoding='utf-8')
    if 'ZombieMovement.clear()' not in text:world.write_text(text.replace('ZombieControls.clear();','ZombieControls.clear();kr.mzs.gunbedvisual.ZombieMovement.clear();'),encoding='utf-8')
    text=world.read_text(encoding="utf-8")
    if "ZombieScene.clear()" not in text:world.write_text(text.replace("kr.mzs.gunbedvisual.ZombieMovement.clear();","kr.mzs.gunbedvisual.ZombieMovement.clear();kr.mzs.gunbedvisual.ZombieScene.clientReady=false;kr.mzs.gunbedvisual.ZombieScene.clear();kr.mzs.gunbedvisual.ZombieResults.clear();kr.mzs.gunbedvisual.ZombieVisuals.clear();"),encoding="utf-8")
    # 2026-11-26: the vanilla drop key is the zombie drop button again (see prepare_client_dropkey_rev2.py).

build=CLIENT/'build.gradle';text=build.read_text(encoding='utf-8')
if "'../shared/java'" not in text:text=text.replace('java.srcDirs = [',"java.srcDirs = ['../shared/java', ",1);build.write_text(text,encoding='utf-8')
print('Prepared CS movement, ladder exits, head collision, wheel jumps and G input for all nine adapters.')
