package kr.mzs.gunbedvisual;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;
import kr.mzs.renewal.GoldSrcMovement;
import java.util.*;

public final class ZombieMovement {
    private static boolean match,locked,previousSpace,queuedJump,armed=true,escape;
    private static int jumpBuffer;private static boolean ducked;private static long stunUntil;
    private static String role="spectator";
    private static double scale=1;
    private static long nextDoubleJump;
    private static int ladderDetachUntil;
    private static boolean combatReady;
    public static boolean combatReady(){return combatReady;}
    private static Vec3 pendingVelocity;
    private static long velocityUntil;
    private static Vec3 lastNativeVelocity;
    private static long nativeVelocityAt;
    private static final Set<UUID> respawning=new HashSet<>();
    private ZombieMovement(){}
    public static boolean active(){return match&&ZombieControls.active();}
    public static boolean physical(LocalPlayer p){return active()&&!role.equals("spectator")&&!p.isSpectator()&&!p.getAbilities().flying&&!p.isPassenger();}
    public static void packet(JsonObject d){
        String event=d.has("event")?d.get("event").getAsString():"";
        if(event.equals("hud")){
            boolean next=d.has("zombieServer")&&d.get("zombieServer").getAsBoolean()&&d.has("zombieMatch")&&d.get("zombieMatch").getAsBoolean();
            if(!next){clear();return;}match=true;combatReady=d.has("zombieCombatReady")&&d.get("zombieCombatReady").getAsBoolean();role=d.get("zombieRole").getAsString();
            locked=d.has("loadoutPending")&&d.get("loadoutPending").getAsBoolean()||d.has("movementLocked")&&d.get("movementLocked").getAsBoolean();
            if(d.has("movementScale"))scale=d.get("movementScale").getAsDouble();
        }else if(event.equals("zombieRoster")){
            escape=d.get("mode").getAsString().equals("escape");respawning.clear();
            for(var entry:d.getAsJsonArray("players")){var p=entry.getAsJsonObject();if(p.get("respawning").getAsBoolean())respawning.add(UUID.fromString(p.get("uuid").getAsString()));}
        }else if(event.equals("zombieVelocity")){
            pendingVelocity=new Vec3(d.get("vx").getAsDouble(),d.get("vy").getAsDouble(),d.get("vz").getAsDouble());velocityUntil=System.nanoTime()+200_000_000L;
            if(Boolean.getBoolean("gunbed.auditVelocity"))GunbedVisualClient.LOG.info("VELOCITY_RPC {}",pendingVelocity);
            restoreFullVelocity();
        }else if(event.equals("zombieJump")){
            var p=Minecraft.getInstance().player;if(p!=null&&active())p.setDeltaMovement(d.get("vx").getAsDouble(),d.get("vy").getAsDouble(),d.get("vz").getAsDouble());
            if(!d.get("accepted").getAsBoolean())armed=false;
        }
    }
    public static Input input(Input raw){
        if(!active())return raw;
        var p=Minecraft.getInstance().player;
        if(p==null||!physical(p)||p.isInWater()||p.isInLava()||p.onClimbable()){previousSpace=raw.jump();queuedJump=false;return raw;}
        if(raw.jump()&&!previousSpace)queuedJump=true;previousSpace=raw.jump();
        return new Input(raw.forward(),raw.backward(),raw.left(),raw.right(),false,raw.shift(),raw.sprint());
    }
    /** 2026-11-26 rev3: zombies/hosts see their real HP on the HUD; humans keep the Gunbed /100 display. */
    public static boolean zombieRole(){return match&&(role.equals("zombie")||role.equals("host"));}
    public static String hpText(double health,double max){return zombieRole()?Long.toString((long)Math.ceil(health)):Integer.toString((int)Math.ceil(health/(max<1000?max/100:100)));}
    public static boolean wheelEnabled(){var p=Minecraft.getInstance().player;return p!=null&&physical(p);}
    public static void wheel(){if(wheelEnabled())queuedJump=true;}
    public static void clear(){jumpBuffer=0;ducked=false;stunUntil=0;match=false;combatReady=false;locked=false;previousSpace=false;queuedJump=false;armed=true;nextDoubleJump=0;ladderDetachUntil=0;pendingVelocity=null;lastNativeVelocity=null;nativeVelocityAt=0;scale=1;role="spectator";respawning.clear();}
    public static void velocityPacket(int id){
        if(Boolean.getBoolean("gunbed.auditVelocity"))GunbedVisualClient.LOG.info("VELOCITY_NATIVE id={} pending={}",id,pendingVelocity);
        var p=Minecraft.getInstance().player;if(p==null||p.getId()!=id)return;
        lastNativeVelocity=p.getDeltaMovement();nativeVelocityAt=System.nanoTime();restoreFullVelocity();
    }
    private static void restoreFullVelocity(){
        var p=Minecraft.getInstance().player;if(p==null||!physical(p)||pendingVelocity==null||lastNativeVelocity==null||System.nanoTime()>velocityUntil||System.nanoTime()-nativeVelocityAt>200_000_000L)return;
        Vec3 full=pendingVelocity,nativeValue=lastNativeVelocity;
        if(Math.max(Math.abs(full.x),Math.max(Math.abs(full.y),Math.abs(full.z)))<=3.9)return;
        if(legacyMotion(nativeValue.x,full.x)&&legacyMotion(nativeValue.y,full.y)&&legacyMotion(nativeValue.z,full.z)){
            Vec3 current=p.getDeltaMovement();p.setDeltaMovement(Math.abs(full.x)>3.9?full.x:current.x,Math.abs(full.y)>3.9?full.y:current.y,Math.abs(full.z)>3.9?full.z:current.z);pendingVelocity=null;
        }
    }
    private static boolean legacyMotion(double received,double full){return Math.abs(full)<=3.9?Math.abs(received-full)<.005:Math.signum(received)==Math.signum(full)&&Math.abs(received)>=3.895&&Math.abs(received)<=4.096;}
    /** Height to clear when a standing player is right in front (within 1.1 blocks, ahead of the view). 0 = ordinary jump. */
    private static double headLift(LocalPlayer p,Minecraft client){
        double yaw=Math.toRadians(p.getYRot()),fx=-Math.sin(yaw),fz=Math.cos(yaw),best=0;
        for(var other:client.level.players()){
            if(other==p||other.isSpectator()||respawning.contains(other.getUUID()))continue;
            double dx=other.getX()-p.getX(),dz=other.getZ()-p.getZ(),flat=Math.hypot(dx,dz),top=other.getBoundingBox().maxY-p.getY();
            if(flat>1.1||top<1.0||top>2.4||flat>.2&&(dx*fx+dz*fz)/flat<.3)continue;
            best=Math.max(best,top+.2);
        }
        return best;
    }
    public static boolean travel(LocalPlayer p){
        if(!physical(p)||p.isInWater()||p.isInLava())return false;
        var client=Minecraft.getInstance();Input keys=p.input.keyPresses;
        // Jump buffer: a press up to 3 ticks before landing fires on the landing tick (perfect CS hop, made easy at 20 ticks/s).
        if(queuedJump)jumpBuffer=3;queuedJump=false;
        // 2026-11-26: ladders use vanilla climbing + the server's old FastAscend boost; ladder jump and double jump removed.
        if(p.onClimbable()){jumpBuffer=0;ducked=false;return false;}
        boolean ground=p.onGround();GoldSrcMovement.Ladder ladder=null;
        boolean jump=jumpBuffer>0&&ground;if(jumpBuffer>0)jumpBuffer--;if(jump)jumpBuffer=0;
        // CS air duck: crouching mid-air pulls the legs up 18u (duck jump / stand-up bunny); releasing in the air puts them back.
        boolean crouch=p.input.keyPresses.shift();
        if(ground)ducked=false;
        else if(crouch&&!ducked){ducked=true;p.move(MoverType.SELF,new Vec3(0,GoldSrcMovement.DUCK_LIFT,0));}
        else if(!crouch&&ducked){ducked=false;p.move(MoverType.SELF,new Vec3(0,-GoldSrcMovement.DUCK_LIFT,0));ground=p.onGround();}
        double stun=Math.max(0,(stunUntil-System.nanoTime())/1e9)/GoldSrcMovement.STUN_SECONDS;
        boolean canMove=!locked&&client.gui.screen()==null;
        double forward=canMove?(keys.forward()?1:0)-(keys.backward()?1:0):0;
        double side=canMove?(keys.right()?1:0)-(keys.left()?1:0):0;
        if(!canMove)jump=false;
        Vec3 current=p.getDeltaMovement();
        GoldSrcMovement.Velocity before=new GoldSrcMovement.Velocity(current.x,current.y,current.z);
        var input=new GoldSrcMovement.Input(forward,side,!p.isSprinting(),keys.shift(),jump&&canMove);
        var result=GoldSrcMovement.step(before,input,ground,ladder,p.getYRot(),p.getXRot(),Math.max(.01,scale));
        Vec3 move=new Vec3(result.movement().x(),result.movement().y(),result.movement().z());
        if(ground&&!result.jumped()&&ladder==null)move=new Vec3(move.x,-.05,move.z);
        double nextY=result.next().y();
        // Mild CS landing stun: walking right after a jump is a little slower; a jump during it is a little lower.
        if(stun>0&&ground&&!result.jumped()){double keep=1-GoldSrcMovement.STUN_GROUND_LOSS*stun;move=new Vec3(move.x*keep,move.y,move.z*keep);}
        if(result.jumped()){if(stun>0){double keep=1-GoldSrcMovement.STUN_JUMP_LOSS*stun;nextY=nextY+move.y*(keep-1);move=new Vec3(move.x,move.y*keep,move.z);}stunUntil=System.nanoTime()+(long)(GoldSrcMovement.STUN_SECONDS*1e9);}
        // CS zombie mode: one jump from right in front of someone lands on their head (normal mode only).
        if(result.jumped()&&!escape){double lift=headLift(p,client);if(lift>0){double g=GoldSrcMovement.GRAVITY,v=Math.sqrt(2*g*lift)+g/2;if(v>move.y){move=new Vec3(move.x,v,move.z);nextY=v-g;}}}
        boolean head=false;
        if(!escape)for(var other:client.level.players()){
            if(other==p||other.isSpectator()||respawning.contains(other.getUUID()))continue;
            var box=other.getBoundingBox();double x=p.getX()+move.x,z=p.getZ()+move.z;
            if(Math.abs(x-other.getX())<.55&&Math.abs(z-other.getZ())<.55&&p.getY()>=box.maxY-.12&&p.getY()+move.y<=box.maxY&&move.y<=0){move=new Vec3(move.x,box.maxY-p.getY(),move.z);head=true;}
            else if(p.getY()<box.maxY-.08&&p.getY()+p.getBbHeight()>box.minY+.08&&Math.abs(x-other.getX())<.6&&Math.abs(z-other.getZ())<.6){
                double old=Math.hypot(p.getX()-other.getX(),p.getZ()-other.getZ()),next=Math.hypot(x-other.getX(),z-other.getZ());
                if(next<old-.00001){if(Math.abs(p.getX()-other.getX())>=.6)move=new Vec3(0,move.y,move.z);else if(Math.abs(p.getZ()-other.getZ())>=.6)move=new Vec3(move.x,move.y,0);else move=new Vec3(0,move.y,0);}
            }
        }
        p.setDeltaMovement(move);p.move(MoverType.SELF,move);Vec3 resolved=p.getDeltaMovement();
        if(head)p.setOnGround(true);
        p.setDeltaMovement(resolved.x,p.onGround()?0:nextY,resolved.z);p.fallDistance=0;
        return true;
    }
}
