Combined Gunbed/zombie client and installer source.
Private server plugins, server configuration, maps and account data are excluded.
Third-party original/derived Tissou art is excluded. The installer obtains the verified official original and creates private namespaced assets locally.
Existing third-party attribution and linked source archives remain applicable.
