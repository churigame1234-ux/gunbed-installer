from prepare_client_controls import CLIENT,VERSIONS
SOURCE=r'''package kr.mzs.gunbedvisual;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import kr.mzs.gunbedvisual.model.GunMesh;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import java.util.*;

/** Articulated forearms, palms and curled fingers using the infected skin, never a flat hand image. */
public final class ZombieHands {
    public static boolean active(AbstractClientPlayer player){return ZombieMovement.active()&&player==Minecraft.getInstance().player&&ZombieScene.zombie(player.getUUID())&&!player.getMainHandItem().isEmpty()&&(SLOT==0||SLOT==1);}
    public static GunMesh.Frame frame(AbstractClientPlayer p){
        List<GunMesh.Vertex> skin=new ArrayList<>(),metal=new ArrayList<>();boolean bomb=SLOT==1;
        float progress=ZombieVisuals.swing(p.getId()),motion=progress>=1?0:(float)Math.sin(Math.PI*progress);
        boolean secondary=ZombieVisuals.secondary(p.getId());
        for(int side:new int[]{-1,1}){
            float strike=bomb?0:((side==-1&&!secondary||side==1&&secondary)?motion:0);
            Matrix4f root=new Matrix4f().translation(side*(.47f-.17f*strike),-.27f+.18f*strike,-.58f-.25f*strike)
                .rotateZ(side*(.2f+.42f*strike)).rotateX(-.16f-.55f*strike);
            box(skin,root,-.095f,-.075f,-.12f,.19f,.15f,.52f,side<0?32:40,side<0?48:16);
            box(skin,root,-.12f,-.055f,-.3f,.24f,.13f,.2f,side<0?36:44,side<0?52:20);
            for(int finger=0;finger<4;finger++){
                Matrix4f digit=new Matrix4f(root).translate(-.095f+finger*.063f,.015f,-.28f).rotateY((finger-1.5f)*-.14f);
                box(skin,digit,-.025f,-.035f,-.15f,.05f,.07f,.16f,44,20);
                digit.translate(0,-.005f,-.14f).rotateX(.9f+.35f*strike);
                box(skin,digit,-.022f,-.03f,-.1f,.044f,.06f,.11f,44,20);
                digit.translate(0,0,-.095f).rotateX(.55f);
                box(skin,digit,-.014f,-.018f,-.065f,.028f,.036f,.07f,44,16);
            }
            Matrix4f thumb=new Matrix4f(root).translate(-side*.11f,-.02f,-.18f).rotateY(side*.9f).rotateX(.7f);
            box(skin,thumb,-.035f,-.03f,-.15f,.07f,.07f,.16f,44,20);
        }
        if(bomb){Matrix4f root=new Matrix4f().translation(.24f,-.32f,-.86f).rotateZ(-.2f);
            box(skin,root,-.12f,-.12f,-.12f,.24f,.24f,.24f,8,8);
            box(metal,root,-.06f,.12f,-.05f,.12f,.07f,.1f,0,0);
            for(int i=0;i<8;i++){double angle=i*Math.PI/4;Matrix4f ring=new Matrix4f(root).translate(.04f+(float)Math.cos(angle)*.065f,.22f+(float)Math.sin(angle)*.065f,0);box(metal,ring,-.018f,-.018f,-.015f,.036f,.036f,.03f,0,0);}
        }
        var surfaces=new LinkedHashMap<String,List<GunMesh.Vertex>>();surfaces.put(ZombieVisuals.texture(p.getId()).toString(),skin);if(!metal.isEmpty())surfaces.put("minecraft:textures/block/iron_block.png",metal);
        return new GunMesh.Frame(skin,null,null,null,surfaces);
    }
    private static void box(List<GunMesh.Vertex> out,Matrix4f matrix,float x,float y,float z,float w,float h,float d,int u,int v){
        float[][] corners={{x,y,z},{x+w,y,z},{x+w,y+h,z},{x,y+h,z},{x,y,z+d},{x+w,y,z+d},{x+w,y+h,z+d},{x,y+h,z+d}};
        int[][] faces={{0,3,2,1},{4,5,6,7},{0,1,5,4},{3,7,6,2},{0,4,7,3},{1,2,6,5}};float[][] normals={{0,0,-1},{0,0,1},{0,-1,0},{0,1,0},{-1,0,0},{1,0,0}};
        float size=4;for(int f=0;f<6;f++){Vector3f normal=matrix.transformDirection(new Vector3f(normals[f])).normalize();float[][] uv={{u,v},{u,v+size},{u+size,v+size},{u+size,v}};
            for(int i=0;i<4;i++){float[] p=corners[faces[f][i]];Vector3f point=matrix.transformPosition(new Vector3f(p));out.add(new GunMesh.Vertex(point.x,point.y,point.z,uv[i][0]/64,uv[i][1]/64,normal.x,normal.y,normal.z));}
        }
    }
}
'''

for version in VERSIONS:
    package=CLIENT/'.generated'/version/'java/kr/mzs/gunbedvisual'
    render=package/'GunbedRender.java';s=render.read_text(encoding='utf-8')
    # Read the already working version-specific inventory accessor and rendering backend.
    import re
    slot=re.search(r'VisualState.INSTANCE.matches\((player.getInventory\(\)\.[^,]+),',s).group(1)
    source=SOURCE.replace('SLOT',slot).replace('public static GunMesh.Frame frame(AbstractClientPlayer p){','public static GunMesh.Frame frame(AbstractClientPlayer player){\n        var p=player;')
    (package/'ZombieHands.java').write_text(source,encoding='utf-8')
    if 'ZombieHands.active(player)' not in s:
        s=s.replace('    public static boolean active(AbstractClientPlayer player) {','    public static boolean active(AbstractClientPlayer player) {\n        if(ZombieHands.active(player))return true;')
        s=s.replace('    public static boolean controlled(AbstractClientPlayer player) {','    public static boolean controlled(AbstractClientPlayer player) {\n        if(ZombieHands.active(player))return true;')
        start=s.index('for(var entry:surfaces.entrySet())');brace=s.index('{',start);depth=1;end=brace+1
        while depth:
            if s[end]=='{':depth+=1
            elif s[end]=='}':depth-=1
            end+=1
        draw=s[start:end]
        marker='        String demo=System.getProperty("gunbed.demo");'
        s=s.replace(marker,'        if(ZombieHands.active(player)){var frame=ZombieHands.frame(player);var surfaces=frame.surfaces();'+draw+'return true;}\n'+marker)
        render.write_text(s,encoding='utf-8')
print('Prepared first-person zombie fingers, left/right attack poses and head-grenade grip.')
