"""Version adapters for infected player textures, gait, ally fading, and smooth client-only corpses."""
import json
from prepare_client_controls import CLIENT,VERSIONS

VISUALS=r'''package kr.mzs.gunbedvisual;
import com.google.gson.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.resources.IDENTIFIER;
import net.minecraft.world.entity.Entity;
import java.util.*;

public final class ZombieVisuals {
    public record Corpse(RemotePlayer entity,UUID source,long began,int pose){}
    private static final Map<Integer,Corpse> corpses=new HashMap<>();
    private static final Map<Integer,Long> swings=new HashMap<>();
    private static final Set<Integer> rightSwings=new HashSet<>();
    public static boolean secondary(int id){return rightSwings.contains(id);}
    private static List<IDENTIFIER> textures=List.of();
    private static long nextTextureScan;
    private static int nextId=-870000,performanceTick;
    public static void clear(){for(var corpse:corpses.values())corpse.entity.discard();corpses.clear();swings.clear();textures=List.of();nextTextureScan=0;}
    public static void packet(JsonObject data){
        String event=data.has("event")?data.get("event").getAsString():"";
        if(event.equals("hud")&&data.has("zombieMatch")&&!data.get("zombieMatch").getAsBoolean()){clear();return;}
        if(event.equals("zombieRespawn")){UUID source=UUID.fromString(data.get("uuid").getAsString());for(var entry:List.copyOf(corpses.entrySet()))if(entry.getValue().source.equals(source)){entry.getValue().entity.discard();corpses.remove(entry.getKey());}return;}
        if(event.equals("zombieSwing")){int id=data.get("entityId").getAsInt();swings.put(id,System.nanoTime());if(data.get("secondary").getAsBoolean())rightSwings.add(id);else rightSwings.remove(id);return;}
        if(!event.equals("zombieDeath"))return;
        var client=Minecraft.getInstance();if(client.level==null||!ZombieMovement.active())return;
        UUID source=UUID.fromString(data.get("uuid").getAsString());
        var corpse=new RemotePlayer(client.level,new com.mojang.authlib.GameProfile(UUID.randomUUID(),"Zombie"));
        corpse.setId(nextId--);corpse.setPos(data.get("x").getAsDouble(),data.get("y").getAsDouble(),data.get("z").getAsDouble());
        float yaw=data.get("yaw").getAsFloat();corpse.setYRot(yaw);corpse.setYBodyRot(yaw);corpse.setYHeadRot(yaw);corpse.setNoGravity(true);
        corpse.setSilent(true);corpse.setDeltaMovement(0,0,0);
        var victim=client.level.getEntity(data.get("entityId").getAsInt());if(victim instanceof net.minecraft.world.entity.LivingEntity living)corpse.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD,living.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD).copy());
        client.level.addEntity(corpse);corpses.put(corpse.getId(),new Corpse(corpse,source,System.nanoTime(),data.get("pose").getAsInt()));
    }
    public static void tick(){
        var client=Minecraft.getInstance();
        if(ZombieMovement.active()&&++performanceTick%100==0)GunbedVisualClient.zombiePerformance(client.getFps());
        long now=System.nanoTime();for(var entry:List.copyOf(corpses.entrySet())){
            Corpse c=entry.getValue();if(now-c.began>8_000_000_000L||c.entity.level()!=Minecraft.getInstance().level){c.entity.discard();corpses.remove(entry.getKey());}
            else{c.entity.setDeltaMovement(0,0,0);c.entity.setNoGravity(true);c.entity.setOnGround(true);}
        }
    }
    public static ZombieScene.Member member(int id){for(var member:ZombieScene.members.values())if(member.entityId()==id)return member;return null;}
    private static UUID source(int id){Corpse corpse=corpses.get(id);if(corpse!=null)return corpse.source;var m=member(id);return m==null?null:m.id();}
    public static boolean infected(int id){
        var p=Minecraft.getInstance().player;if(!ZombieMovement.active()||p==null||id==p.getId())return false;
        UUID source=source(id);return source!=null&&(corpses.containsKey(id)||ZombieScene.zombie(source));
    }
    public static boolean corpse(int id){return corpses.containsKey(id);}
    public static float deathProgress(int id){var c=corpses.get(id);if(c==null)return 0;float t=Math.clamp((System.nanoTime()-c.began)/750_000_000f,0,1);return t*t*(3-2*t);}
    public static int deathPose(int id){return corpses.get(id).pose;}
    public static float swing(int id){long at=swings.getOrDefault(id,0L);return Math.clamp((System.nanoTime()-at)/900_000_000f,0,1);}
    public static boolean fade(int id){
        var p=Minecraft.getInstance().player;var m=member(id);
        return ZombieMovement.active()&&ZombieScene.escape&&p!=null&&id!=p.getId()&&m!=null&&!m.respawning()&&ZombieScene.ally(p.getUUID(),m.id())&&p.distanceToSqr(m.x(),m.y(),m.z())<6.25;
    }
    public static IDENTIFIER texture(int id){
        var client=Minecraft.getInstance();long now=System.nanoTime();
        if(ownCorpse(id)&&client.player!=null)return SELF_SKIN;
        if(textures.isEmpty()&&now>=nextTextureScan){nextTextureScan=now+5_000_000_000L;
            textures=client.getResourceManager().listResources("textures/zombie",p->p.getNamespace().equals("mzs_tissou")&&p.getPath().matches(".*/zombie[0-9]+\\.png")).keySet().stream().sorted(Comparator.comparing(Object::toString)).toList();
        }
        UUID source=source(id);if(textures.isEmpty()||source==null)return IDENTIFIER.parse("minecraft:textures/entity/zombie/zombie.png");
        return textures.get(Math.floorMod(source.hashCode()+(int)(ZombieScene.appearanceSeed^(ZombieScene.appearanceSeed>>>32)),textures.size()));
    }
    public static boolean ownCorpse(int id){var p=Minecraft.getInstance().player;Corpse corpse=corpses.get(id);return p!=null&&corpse!=null&&corpse.source.equals(p.getUUID());}
}
'''

RENDER=r'''package kr.mzs.gunbedvisual.mixin;
import kr.mzs.gunbedvisual.*;
import net.minecraft.client.renderer.entity.player.RENDERER;
import net.minecraft.client.renderer.entity.state.STATE;
import net.minecraft.resources.IDENTIFIER;
import net.minecraft.world.entity.ENTITY;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(RENDERER.class)
public abstract class ZombieAvatarMixin {
    @Inject(method="getTextureLocation(Lnet/minecraft/client/renderer/entity/state/STATE;)Lnet/minecraft/resources/IDENTIFIER;",at=@At("HEAD"),cancellable=true)
    private void zombie$texture(STATE state,CallbackInfoReturnable<IDENTIFIER> ci){if(ZombieVisuals.infected(state.id))ci.setReturnValue(ZombieVisuals.texture(state.id));}
    @Inject(method="extractRenderState(Lnet/minecraft/ENTITYPATH;Lnet/minecraft/client/renderer/entity/state/STATE;F)V",at=@At("TAIL"))
    private void zombie$state(ENTITY entity,STATE state,float partial,CallbackInfo ci){
        if(ZombieVisuals.infected(state.id)&&!ZombieVisuals.ownCorpse(state.id)){
            state.showHat=false;state.showJacket=false;state.showLeftPants=false;state.showRightPants=false;state.showLeftSleeve=false;state.showRightSleeve=false;state.showCape=false;
            state.parrotOnLeftShoulder=null;state.parrotOnRightShoulder=null;
        }
        if(ZombieVisuals.corpse(state.id)){state.deathTime=0;state.walkAnimationSpeed=0;state.pose=net.minecraft.world.entity.Pose.STANDING;state.xRot=0;state.yRot=0;state.isSpectator=false;}
        if(ZombieVisuals.fade(state.id)){state.isInvisible=true;state.isInvisibleToPlayer=false;}
    }
    @Inject(method="setupRotations(Lnet/minecraft/client/renderer/entity/state/STATE;Lcom/mojang/blaze3d/vertex/PoseStack;FF)V",at=@At("TAIL"))
    private void zombie$fall(STATE state,PoseStack pose,float bodyRot,float scale,CallbackInfo ci){
        if(!ZombieVisuals.corpse(state.id))return;
        float progress=ZombieVisuals.deathProgress(state.id);int fall=ZombieVisuals.deathPose(state.id);
        pose.translate(0,.08*progress,0);
        pose.mulPose((fall==1?Axis.ZP:Axis.XP).rotationDegrees((fall==2?-90:90)*progress));
    }
}
'''

MODEL=r'''package kr.mzs.gunbedvisual.mixin;
import kr.mzs.gunbedvisual.*;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.entity.state.STATE;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MODELPATH.class)
public abstract class ZombieGaitMixin {
    @Inject(method="setupAnim(Lnet/minecraft/client/renderer/entity/state/STATE;)V",at=@At("TAIL"))
    private void zombie$gait(STATE state,CallbackInfo ci){
        if(!ZombieVisuals.infected(state.id))return;var model=(HumanoidModel<?>)(Object)this;
        float phase=state.walkAnimationPos,walk=state.walkAnimationSpeed;
        float swing=(float)Math.sin(ZombieVisuals.swing(state.id)*Math.PI);
        boolean corpse=ZombieVisuals.corpse(state.id);float fall=corpse?ZombieVisuals.deathProgress(state.id):0;
        model.rightArm.xRot=(-1.35f+.13f*(float)Math.cos(phase*.65f)-swing*.85f)*(1-fall)+.1f*fall;
        model.leftArm.xRot=(-1.35f-.13f*(float)Math.cos(phase*.65f)-swing*.35f)*(1-fall)+.15f*fall;
        model.rightArm.yRot=-.13f;model.leftArm.yRot=.13f;
        model.body.xRot=.07f*(1-fall);
        model.rightLeg.xRot=(float)Math.cos(phase*.6662f)*1.15f*walk*(1-fall);
        model.leftLeg.xRot=(float)Math.cos(phase*.6662f+(float)Math.PI)*1.15f*walk*(1-fall);
        model.head.zRot=.045f*(float)Math.sin(phase*.3f)*(1-fall);
    }
}
'''

for version in VERSIONS:
    package=CLIENT/'.generated'/version/'java/kr/mzs/gunbedvisual'
    old=version=='1.21.8'
    replacements={'IDENTIFIER':'ResourceLocation' if version in ('1.21.8','1.21.9','1.21.10') else 'Identifier','RENDERER':'PlayerRenderer' if old else 'AvatarRenderer','STATE':'PlayerRenderState' if old else 'AvatarRenderState','ENTITYPATH':'client/player/AbstractClientPlayer' if old else 'world/entity/Avatar','ENTITY':'player.AbstractClientPlayer' if old else 'Avatar','MODELPATH':'net.minecraft.client.model.PlayerModel' if version in ('1.21.8','1.21.9','1.21.10') else 'net.minecraft.client.model.player.PlayerModel'}
    # Old renderer receives AbstractClientPlayer from a different package.
    render=RENDER.replace('import net.minecraft.world.entity.ENTITY;','import net.minecraft.client.player.AbstractClientPlayer;' if old else 'import net.minecraft.world.entity.Avatar;')
    for filename,source in [('ZombieVisuals.java',VISUALS),('mixin/ZombieAvatarMixin.java',render),('mixin/ZombieGaitMixin.java',MODEL)]:
        source=source.replace('SELF_SKIN','client.player.getSkin().texture()' if old else 'client.player.getSkin().body().texturePath()')
        for key in sorted(replacements,key=len,reverse=True):source=source.replace(key,replacements[key])
        source=source.replace('player.AbstractClientPlayer entity','AbstractClientPlayer entity')
        if version=='26.3':source=source.replace('pose.mulPose((fall==1?Axis.ZP:Axis.XP).rotationDegrees((fall==2?-90:90)*progress));','pose.mulPose(new org.joml.Matrix4f().rotation((fall==1?Axis.ZP:Axis.XP).rotationDegrees((fall==2?-90:90)*progress)));')
        (package/filename).write_text(source,encoding='utf-8')
    network=package/'GunbedVisualClient.java';s=network.read_text(encoding='utf-8')
    if 'ZombieVisuals.packet(data)' not in s:s=s.replace('ZombieScene.packet(data);','ZombieScene.packet(data);ZombieVisuals.packet(data);')
    if 'ZombieVisuals.tick();' not in s:s=s.replace('ClientTickEvents.END_CLIENT_TICK.register(client->{','ClientTickEvents.END_CLIENT_TICK.register(client->{ZombieVisuals.tick();')
    if 'ZombieVisuals.clear();' not in s:s=s.replace('ZombieScene.clear();','ZombieScene.clear();ZombieVisuals.clear();')
    if 'void zombiePerformance(int fps)' not in s:
        s=s.replace('    public static void zombieSprint(','''    public static void zombiePerformance(int fps){
        if(!ClientPlayNetworking.canSend(Wire.TYPE))return;
        var data=new com.google.gson.JsonObject();data.addProperty("v",1);data.addProperty("event","client_performance");data.addProperty("fps",fps);
        ClientPlayNetworking.send(new Wire(data.toString().getBytes(StandardCharsets.UTF_8)));
    }
    public static void zombieSprint(''')
    network.write_text(s,encoding='utf-8')
    config=package.parents[2]/'resources/gunbed.mixins.json'
    config=CLIENT/'.generated'/version/'resources/gunbed.mixins.json';d=json.loads(config.read_text(encoding='utf-8'))
    for name in ['ZombieAvatarMixin','ZombieGaitMixin']:
        if name not in d['client']:d['client'].append(name)
    config.write_text(json.dumps(d,indent=2),encoding='utf-8')
    landing=package/'mixin/GunbedLandingSoundMixin.java';s=landing.read_text(encoding='utf-8')
    if 'ZombieMovement.active()' not in s:
        sound='sound.getLocation()' if version in ('1.21.8','1.21.9','1.21.10') else 'sound.getIdentifier()'
        s=s.replace('double dx=sound.getX()',f'if(kr.mzs.gunbedvisual.ZombieMovement.active()&&({sound}.getPath().endsWith(".small_fall")||{sound}.getPath().endsWith(".big_fall"))){{ci.setReturnValue(net.minecraft.client.sounds.SoundEngine.PlayResult.NOT_STARTED);return;}}double dx=sound.getX()')
        landing.write_text(s,encoding='utf-8')
    if version in ('1.21.8','1.21.9','1.21.10'):landing.write_text(landing.read_text(encoding='utf-8').replace('sound.getIdentifier()','sound.getLocation()'),encoding='utf-8')
print('Prepared infected-player renderer, preserved self view, ally fading and 750ms corpse transition.')
