"""Fork the existing display adapters locally; never edit the operating Gunbed project."""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path('C:/Users/mydon/Documents/ChatGPT/배드워즈/client')
CLIENT = ROOT / 'client'
VERSIONS = ('1.21.8', '1.21.9', '1.21.10', '1.21.11', '26.1', '26.1.1', '26.1.2', '26.2', '26.3')


def fork():
    CLIENT.mkdir(exist_ok=True)
    hashes = {}
    for folder in ('src/common', '.generated', 'gradle'):
        for source in (SOURCE / folder).rglob('*'):
            if source.is_file():
                relative = source.relative_to(SOURCE)
                target = CLIENT / relative
                if not target.exists():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, target)
                hashes[str(relative)] = hashlib.sha256(source.read_bytes()).hexdigest()
    for name in ('build.gradle', 'settings.gradle', 'gradlew', 'gradlew.bat', 'LICENSE', 'THIRD-PARTY.md', 'README.md'):
        target = CLIENT / name
        if not target.exists():
            shutil.copy2(SOURCE / name, target)
    manifest = CLIENT / 'gunbed-source-origin.json'
    if not manifest.exists():
        manifest.write_text(json.dumps({'source': str(SOURCE), 'sha256': hashes}, ensure_ascii=False, indent=2), encoding='utf-8')
    build = CLIENT / 'build.gradle'
    text = build.read_text(encoding='utf-8')
    text = text.replace("from('src/main/resources')", "from('C:/Users/mydon/Documents/ChatGPT/배드워즈/client/src/main/resources')")
    text = text.replace("from('../tools/generate_visual_adapter.py')", "from('../tools/prepare_client_controls.py')")
    build.write_text(text, encoding='utf-8')


INPUT_MIXIN = '''package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(KeyboardInput.class)
public abstract class ZombieSprintInputMixin {
    // Keep vanilla double-W, crouching and sprint eligibility checks. Only replace
    // the dedicated sprint-key contribution on the zombie backend.
    @Redirect(method="tick",at=@At(value="INVOKE",target="Lnet/minecraft/client/KeyMapping;isDown()Z"))
    private boolean zombie$sprint(KeyMapping mapping){
        var client=Minecraft.getInstance();
        if(mapping==client.options.keySprint && kr.mzs.gunbedvisual.ZombieControls.active())
            return kr.mzs.gunbedvisual.ZombieControls.sprintKey(client);
        return mapping.isDown();
    }
}
'''

PLAYER_MIXIN = '''package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LocalPlayer.class)
public abstract class ZombieSprintResetMixin {
    @Shadow protected int sprintTriggerTime;
    @Inject(method="aiStep",at=@At("HEAD"))
    private void zombie$resetSprint(CallbackInfo ci){
        boolean toggled=kr.mzs.gunbedvisual.ZombieControls.consumeSprintReset();
        var client=net.minecraft.client.Minecraft.getInstance();
        if(toggled||(kr.mzs.gunbedvisual.ZombieControls.active()&&client.options.keyShift.isDown())){
            sprintTriggerTime=0;
            ((LocalPlayer)(Object)this).setSprinting(false);
        }
    }
}
'''

CONTROLS = '''package kr.mzs.gunbedvisual;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
/** Zombie-only control state; vanilla key bindings and options are never rewritten. */
public final class ZombieControls {
    private static boolean zombie,auto=true,pending,resetSprint;
    private static long received,pendingSince;
    private ZombieControls(){}
    public static boolean active(){return zombie&&received>0&&System.nanoTime()-received<5_000_000_000L;}
    public static void packet(JsonObject data){
        String event=data.has("event")?data.get("event").getAsString():"";
        if(event.equals("hud")){
            boolean next=data.has("zombieServer")&&data.get("zombieServer").getAsBoolean();
            if(!next){clear();return;}
            if(!zombie){
                pending=false;
                // Vanilla sprint reads the held state rather than consumeClick.
                // Discard old presses accumulated on a different backend.
                while(Minecraft.getInstance().options.keySprint.consumeClick()){}
            }
            zombie=true;received=System.nanoTime();
            if(data.has("autoSprint")){
                boolean value=data.get("autoSprint").getAsBoolean();
                if(!pending||value==auto||System.nanoTime()-pendingSince>2_000_000_000L){auto=value;pending=false;}
            }
        }else if(event.equals("zombieSprint")&&active()){
            auto=data.get("enabled").getAsBoolean();pending=false;
        }
    }
    public static void tick(Minecraft client){
        if(client.player==null||!active()){if(zombie)clear();return;}
        // Consume presses, not the held/toggled isDown state: one Ctrl press is
        // one mode change even if the vanilla toggle-sprint option is enabled.
        while(client.options.keySprint.consumeClick())if(NO_SCREEN){
            auto=!auto;pending=true;pendingSince=System.nanoTime();resetSprint=true;
            GunbedVisualClient.zombieSprint(auto);
        }
    }
    public static boolean sprintKey(Minecraft client){
        return active()&&auto&&NO_SCREEN&&client.options.keyUp.isDown()
                &&!client.options.keyDown.isDown()&&!client.options.keyShift.isDown();
    }
    public static boolean consumeSprintReset(){boolean result=resetSprint;resetSprint=false;return result;}
    public static void clear(){zombie=false;auto=true;pending=false;received=0;resetSprint=false;}
}
'''


def patch():
    for version in VERSIONS:
        package = CLIENT / '.generated' / version / 'java/kr/mzs/gunbedvisual'
        network = package / 'GunbedVisualClient.java'
        text = network.read_text(encoding='utf-8')
        if 'ZombieControls.packet(data)' not in text:
            text = text.replace('GunbedNeuralClient.packet(data);', 'GunbedNeuralClient.packet(data);ZombieControls.packet(data);')
            text = text.replace('ClientTickEvents.END_CLIENT_TICK.register', 'ClientTickEvents.START_CLIENT_TICK.register(ZombieControls::tick);\n        ClientTickEvents.END_CLIENT_TICK.register', 1)
            text = text.replace('VisualState.INSTANCE.clear();HudState.INSTANCE.clear();PackOwnership.clear();', 'ZombieControls.clear();VisualState.INSTANCE.clear();HudState.INSTANCE.clear();PackOwnership.clear();')
            insertion = '''    public static void zombieSprint(boolean enabled){
        if(ClientPlayNetworking.canSend(Wire.TYPE))ClientPlayNetworking.send(new Wire(("{\\"v\\":1,\\"event\\":\\"zombie_sprint_setting\\",\\"enabled\\":"+enabled+"}").getBytes(StandardCharsets.UTF_8)));
    }
'''
            text = text.replace('    private static void requestReload(', insertion + '    private static void requestReload(', 1)
            network.write_text(text, encoding='utf-8')
        screen = 'client.gui.screen()==null' if version in ('26.2', '26.3') else 'client.screen==null'
        (package / 'ZombieControls.java').write_text(CONTROLS.replace('NO_SCREEN', screen), encoding='utf-8')
        (package / 'mixin/ZombieSprintInputMixin.java').write_text(INPUT_MIXIN, encoding='utf-8')
        (package / 'mixin/ZombieSprintResetMixin.java').write_text(PLAYER_MIXIN, encoding='utf-8')
        world = package / 'mixin/GunbedWorldMixin.java'
        text = world.read_text(encoding='utf-8')
        if 'ZombieControls.clear()' not in text:
            text = text.replace('kr.mzs.gunbedvisual.PackOwnership.transition();', 'kr.mzs.gunbedvisual.ZombieControls.clear();kr.mzs.gunbedvisual.PackOwnership.transition();')
            world.write_text(text, encoding='utf-8')
        config = CLIENT / '.generated' / version / 'resources/gunbed.mixins.json'
        data = json.loads(config.read_text(encoding='utf-8'))
        for name in ('ZombieSprintInputMixin', 'ZombieSprintResetMixin'):
            if name not in data['client']:
                data['client'].append(name)
        config.write_text(json.dumps(data, indent=2), encoding='utf-8')
    print(json.dumps({'client': str(CLIENT), 'versions': VERSIONS, 'operating_gunbed_modified': False}))


if __name__ == '__main__':
    fork()
    patch()
