from prepare_client_controls import CLIENT,VERSIONS
SOURCE=r'''package kr.mzs.gunbedvisual;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import org.joml.Quaternionf;
import org.joml.Vector3f;
public final class ZombieNameplates {
    public static void render(GuiGraphics graphics){
        var client=Minecraft.getInstance();var p=client.player;
        if(!ZombieMovement.active()||p==null||client.options.hideGui)return;
        var camera=client.gameRenderer.CAMERA();var origin=camera.position();
        var rotation=new Quaternionf(camera.rotation()).conjugate();
        double focal=graphics.guiHeight()/(2*Math.tan(Math.toRadians(client.options.fov().get())/2));
        for(var m:ZombieScene.members.values()){
            if(m.id().equals(p.getUUID())||m.respawning())continue;
            if(!ZombieScene.spectator&&(!ZombieScene.ally(p.getUUID(),m.id())||p.distanceToSqr(m.x(),m.y(),m.z())>2500))continue;
            var entity=client.level.getEntity(m.entityId());
            double x=entity==null?m.x():entity.getX(),y=entity==null?m.y()+2.15:entity.getY()+entity.getBbHeight()+.35,z=entity==null?m.z():entity.getZ();
            Vector3f view=new Vector3f((float)(x-origin.x),(float)(y-origin.y),(float)(z-origin.z)).rotate(rotation);
            if(view.z>=-.1)continue;
            int screenX=(int)(graphics.guiWidth()/2.0+view.x*focal/-view.z),screenY=(int)(graphics.guiHeight()/2.0-view.y*focal/-view.z);
            if(screenX<0||screenX>graphics.guiWidth()||screenY<0||screenY>graphics.guiHeight())continue;
            int color=switch(m.role()){case "host"->0xFFAA0000;case "zombie"->0xFFFF5555;default->0xFF4F86FF;};
            int width=client.font.width(m.name());graphics.fill(screenX-width/2-2,screenY-1,screenX+width/2+2,screenY+9,0x66000000);
            graphics.DRAW(client.font,m.name(),screenX-width/2,screenY,color);
        }
    }
}
'''
for version in VERSIONS:
    p=CLIENT/'.generated'/version/'java/kr/mzs/gunbedvisual'
    camera='mainCamera' if version in ('26.2','26.3') else 'getMainCamera'
    draw='text' if version.startswith('26.') else 'drawString'
    source=SOURCE.replace('CAMERA',camera).replace('DRAW',draw)
    if version.startswith('26.'):source=source.replace('GuiGraphics','GuiGraphicsExtractor')
    if version in ('26.2','26.3'):source=source.replace('||client.options.hideGui','')
    (p/'ZombieNameplates.java').write_text(source,encoding='utf-8')
    file=p/'GunbedHud.java';s=file.read_text(encoding='utf-8')
    if 'ZombieNameplates.render(g)' not in s:s=s.replace('        renderFeeds(g);','        ZombieNameplates.render(g);renderFeeds(g);')
    file.write_text(s,encoding='utf-8')
print('Prepared per-viewer head names: allies 50 blocks through walls; pure spectators unlimited.')
