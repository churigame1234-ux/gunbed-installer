"""2026-11-26 client rev 2: vanilla drop key instead of the mod's own G key, and hello reports zombie:2.

Run after prepare_client_movement.py. Idempotent.
"""
import re
from prepare_client_controls import CLIENT, VERSIONS

for version in VERSIONS:
    package = CLIENT / '.generated' / version / 'java/kr/mzs/gunbedvisual'
    client = package / 'GunbedVisualClient.java'
    text = client.read_text(encoding='utf-8')
    # remove the custom G key binding and its click loop
    text = re.sub(r'\n[ \t]*var zombieDropKey=[^\n]*', '', text)
    text = re.sub(r'[ \t]*while\(zombieDropKey\.consumeClick\(\)\)[^;]*;\n', '', text)
    # handshake revision (older mods keep sending zombie:1 and are refused by the server)
    text = text.replace('\\"zombie\\":1', '\\"zombie\\":2')
    assert 'zombieDropKey' not in text, version
    assert '\\"zombie\\":2' in text, version
    client.write_text(text, encoding='utf-8')

    mixin = package / 'mixin/GunbedInputMixin.java'
    text = mixin.read_text(encoding='utf-8')
    text = re.sub(r'[ \t]*@Inject\(method="handleKeybinds",at=@At\("HEAD"\)\)\n[ \t]*private void zombie\$drop\(CallbackInfo ci\)\{[^\n]*\n', '', text)
    assert 'zombie$drop' not in text, version
    mixin.write_text(text, encoding='utf-8')

    lang_dir = CLIENT / '.generated' / version / 'resources/assets/gunbed/lang'
    for lang in ('ko_kr', 'en_us'):
        file = lang_dir / f'{lang}.json'
        if file.exists():
            content = file.read_text(encoding='utf-8')
            content = re.sub(r',?"key\.zombie\.drop":"[^"]*"', '', content)
            file.write_text(content, encoding='utf-8')
    print('rev2', version)
