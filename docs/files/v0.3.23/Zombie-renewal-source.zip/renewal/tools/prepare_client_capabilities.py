from prepare_client_controls import CLIENT,VERSIONS
import json
for version in VERSIONS:
    file=CLIENT/'.generated'/version/'java/kr/mzs/gunbedvisual/GunbedVisualClient.java';s=file.read_text(encoding='utf-8')
    lines=s.splitlines()
    for i,line in enumerate(lines):
        if 'String hello=' not in line:continue
        prefix=json.dumps({'v':1,'event':'hello','mc':version,'client':'0.3.19','zombie':1},separators=(',',':'))[:-1]
        lines[i]='                String hello='+json.dumps(prefix)+r'''+",\"zombieAssets\":"+net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("mzs_zombie_assets")+",\"tissou\":"+net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("mzs_tissou_local")+"}";'''
    file.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('Prepared explicit zombie/asset capability flags; Gunbed hello version is preserved.')
