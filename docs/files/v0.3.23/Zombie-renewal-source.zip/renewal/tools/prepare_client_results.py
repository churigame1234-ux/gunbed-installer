from prepare_client_controls import CLIENT,VERSIONS
SOURCE=r'''package kr.mzs.gunbedvisual;
import com.google.gson.*;
import net.minecraft.client.Minecraft;
import GUI;
import java.util.*;
public final class ZombieResults {
    private static long until;
    private static String title="",subtitle="",score="";
    private static final List<String> rows=new ArrayList<>();
    public static void clear(){until=0;rows.clear();}
    public static boolean active(){return System.nanoTime()<until;}
    public static void packet(JsonObject data){
        if(!data.has("event"))return;
        if(data.get("event").getAsString().equals("zombieResultsClear")){clear();return;}
        if(data.get("event").getAsString().equals("zombieResults")){
            until=System.nanoTime()+12_000_000_000L;title=data.get("title").getAsString();subtitle=data.get("subtitle").getAsString();score="내 처치 + 감염 · "+data.get("score").getAsInt();rows.clear();
            for(JsonElement entry:data.getAsJsonArray("entries")){JsonObject row=entry.getAsJsonObject();rows.add(row.get("name").getAsString()+"  ·  "+row.get("score").getAsInt());}
        }
    }
    public static void render(GUISHORT g){
        if(System.nanoTime()>=until||!ZombieControls.active()||Minecraft.getInstance().screen!=null)return;
        var font=Minecraft.getInstance().font;int cx=g.guiWidth()/2,cy=g.guiHeight()/2;
        g.fill(cx-124,cy-70,cx+124,cy+52,0xD0111925);g.fill(cx-124,cy-70,cx+124,cy-68,0xFFFFD45A);
        g.pose().PUSH();g.pose().SCALE;
        g.DRAW(font,title,(int)((cx*2-font.width(title))/2), (int)((cy-55)/2),0xFFFFD45A);g.pose().POP();
        g.DRAW(font,subtitle,cx-font.width(subtitle)/2,cy-29,0xFFE4ECF5);
        for(int i=0;i<rows.size();i++){String row=(i+1)+"위  "+rows.get(i);g.DRAW(font,row,cx-103,cy-10+i*13,i==0?0xFFFFD45A:i==1?0xFFD9E4EE:0xFFDAA27B);}
        g.DRAW(font,score,cx-font.width(score)/2,cy+36,0xFFA5E987);
    }
}
'''
for version in VERSIONS:
    package=CLIENT/'.generated'/version/'java/kr/mzs/gunbedvisual'
    hud=package/'GunbedHud.java';s=hud.read_text(encoding='utf-8')
    matrix='pushMatrix()' in s;modern=version.startswith('26.')
    source=SOURCE.replace('GUI','net.minecraft.client.gui.GuiGraphicsExtractor' if modern else 'net.minecraft.client.gui.GuiGraphics').replace('net.minecraft.client.gui.GuiGraphicsExtractorSHORT','GuiGraphicsExtractor').replace('net.minecraft.client.gui.GuiGraphicsSHORT','GuiGraphics')
    source=source.replace('PUSH','pushMatrix' if matrix else 'pushPose').replace('POP','popMatrix' if matrix else 'popPose').replace('SCALE','scale(2f,2f)' if matrix else 'scale(2f,2f,1f)').replace('DRAW','text' if modern else 'drawString')
    # Scaled coordinates remain centred in the original GUI space.
    source=source.replace('(int)((cx*2-font.width(title))/2)','(int)(cx/2f-font.width(title)/2f)')
    if version in ('26.2','26.3'):source=source.replace('Minecraft.getInstance().screen','Minecraft.getInstance().gui.screen()')
    (package/'ZombieResults.java').write_text(source,encoding='utf-8')
    if 'ZombieResults.render(g)' not in s:s=s.replace('ZombieNameplates.render(g);','ZombieResults.render(g);ZombieNameplates.render(g);')
    hud.write_text(s,encoding='utf-8')
    network=package/'GunbedVisualClient.java';s=network.read_text(encoding='utf-8')
    if 'ZombieResults.packet(data)' not in s:s=s.replace('ZombieScene.packet(data);','ZombieScene.packet(data);ZombieResults.packet(data);')
    if 'ZombieResults.clear();' not in s:s=s.replace('ZombieScene.clear();','ZombieScene.clear();ZombieResults.clear();')
    network.write_text(s,encoding='utf-8')
print('Prepared native 12-second victory/result cards and top-three kill + infection rankings.')
