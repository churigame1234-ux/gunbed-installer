package kr.mzs.gunbedvisual;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.player.PlayerModelPart;
import org.joml.Vector3f;
import kr.mzs.gunbedvisual.model.GunMesh;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
public final class GunbedRender {
    private static String failed="";
    public static boolean active(AbstractClientPlayer player) {
        if(ZombieHands.active(player))return true;
        var item=player.getMainHandItem();
        if(HudState.INSTANCE.building())return true;
        return VisualState.INSTANCE.matches(player.getInventory().getSelectedSlot(),net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(item.getItem()).toString(),item.getHoverName().getString());
    }
    public static boolean controlled(AbstractClientPlayer player) {
        if(ZombieHands.active(player))return true;
        var item=player.getMainHandItem();
        return VisualState.INSTANCE.controls(player.getInventory().getSelectedSlot(),net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(item.getItem()).toString(),item.getHoverName().getString());
    }
    public static boolean render(AbstractClientPlayer player,PoseStack matrices,MultiBufferSource buffers,int light) {
        if(!(player instanceof LocalPlayer local))return false;
        if(ZombieHands.active(player)){var frame=ZombieHands.frame(player);var surfaces=frame.surfaces();for(var entry:surfaces.entrySet()){ResourceLocation texture=entry.getKey().equals("$skin")?local.getSkin().texture():ResourceLocation.parse(entry.getKey());var surface=new GunMesh.Frame(entry.getValue(),null,null,null);
            var renderType=(frame.surfaces().isEmpty()?RenderType.entityCutout(texture):RenderType.entityCutoutNoCull(texture)); vertices(surface,matrices.last(),buffers.getBuffer(renderType),light);
            }return true;}
        String demo=System.getProperty("gunbed.demo");
        VisualState state=VisualState.INSTANCE;
        state.demo(demo,local.getInventory().getSelectedSlot());
        if(HudState.INSTANCE.building()){
            var build=HudState.INSTANCE;float p=build.buildProgress();matrices.pushPose();matrices.translate(.12,-.42-.04*p,-.86);matrices.scale(.36f,.36f,.36f);matrices.mulPose(new org.joml.Matrix4f().rotationY((float)Math.PI+.12f*(float)Math.sin(p*8)));GunbedWorldMeshes.draw(build.buildKind,matrices,buffers,light);matrices.popPose();
            matrices.pushPose();matrices.mulPose(PlacementPose.arm(false,p));((PlayerRenderer)Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(local)).renderRightHand(matrices,buffers,light,local.getSkin().texture(),local.isModelPartShown(PlayerModelPart.RIGHT_SLEEVE)); matrices.popPose();matrices.pushPose();matrices.mulPose(PlacementPose.arm(true,p));((PlayerRenderer)Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(local)).renderLeftHand(matrices,buffers,light,local.getSkin().texture(),local.isModelPartShown(PlayerModelPart.LEFT_SLEEVE)); matrices.popPose();return true;
        }
        if(!active(local)||failed.equals(state.model()))return false;
        try {
            GunMesh.Frame frame=state.frame();if(state.optic())return true;
            var surfaces=frame.surfaces().isEmpty()?java.util.Map.of(state.texture(),frame.vertices()):frame.surfaces();
            for(var entry:surfaces.entrySet()){ResourceLocation texture=entry.getKey().equals("$skin")?local.getSkin().texture():ResourceLocation.parse(entry.getKey());var surface=new GunMesh.Frame(entry.getValue(),null,null,null);
            var renderType=(frame.surfaces().isEmpty()?RenderType.entityCutout(texture):RenderType.entityCutoutNoCull(texture)); vertices(surface,matrices.last(),buffers.getBuffer(renderType),light);
            }
            ResourceLocation texture=ResourceLocation.parse(state.texture());
            if(state.flashActive()&&frame.muzzle()!=null){var flash=state.flashFrame(frame);vertices(flash,matrices.last(),buffers.getBuffer(RenderType.entityTranslucent(ResourceLocation.parse(state.flashTexture()))),15728880);}
            if(frame.rightArm()!=null){matrices.pushPose();matrices.mulPose(frame.rightArm());((PlayerRenderer)Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(local)).renderRightHand(matrices,buffers,light,local.getSkin().texture(),local.isModelPartShown(PlayerModelPart.RIGHT_SLEEVE)); matrices.popPose();}
            if(frame.leftArm()!=null){matrices.pushPose();matrices.mulPose(frame.leftArm());((PlayerRenderer)Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(local)).renderLeftHand(matrices,buffers,light,local.getSkin().texture(),local.isModelPartShown(PlayerModelPart.LEFT_SLEEVE)); matrices.popPose();}
            if(state.firstFrame())GunbedVisualClient.LOG.info("Rendered original gun mesh and player arms: {} vertices={}",state.model(),frame.vertices().size());
            return true;
        } catch(RuntimeException error) {
            failed=state.model();GunbedVisualClient.LOG.error("Gun renderer failed for {}. Vanilla model retained.",failed,error);return false;
        }
    }
    private static void vertices(GunMesh.Frame frame,PoseStack.Pose pose,VertexConsumer consumer,int light) {
        Vector3f p=new Vector3f(),n=new Vector3f();
        for(var vertex:frame.vertices()) {
            pose.pose().transformPosition(vertex.x(),vertex.y(),vertex.z(),p);
            pose.normal().transform(vertex.nx(),vertex.ny(),vertex.nz(),n).normalize();
            consumer.addVertex(p.x,p.y,p.z).setColor(-1).setUv(vertex.u(),vertex.v()).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(n.x,n.y,n.z);
        }
    }
}
