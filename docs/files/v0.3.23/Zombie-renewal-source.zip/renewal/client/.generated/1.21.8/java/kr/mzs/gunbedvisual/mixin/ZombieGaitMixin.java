package kr.mzs.gunbedvisual.mixin;
import kr.mzs.gunbedvisual.*;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(net.minecraft.client.model.PlayerModel.class)
public abstract class ZombieGaitMixin {
    @Inject(method="setupAnim(Lnet/minecraft/client/renderer/entity/state/PlayerRenderState;)V",at=@At("TAIL"))
    private void zombie$gait(PlayerRenderState state,CallbackInfo ci){
        if(!ZombieVisuals.infected(state.id))return;var model=(HumanoidModel<?>)(Object)this;
        float phase=state.walkAnimationPos,walk=state.walkAnimationSpeed;
        float swing=(float)Math.sin(ZombieVisuals.swing(state.id)*Math.PI);
        boolean corpse=ZombieVisuals.corpse(state.id);float fall=corpse?ZombieVisuals.deathProgress(state.id):0;
        model.rightArm.xRot=(-1.35f+.13f*(float)Math.cos(phase*.65f)-swing*.85f)*(1-fall)+.1f*fall;
        model.leftArm.xRot=(-1.35f-.13f*(float)Math.cos(phase*.65f)-swing*.35f)*(1-fall)+.15f*fall;
        model.rightArm.yRot=-.13f;model.leftArm.yRot=.13f;
        model.body.xRot=.07f*(1-fall);
        model.rightLeg.xRot=(float)Math.cos(phase*.6662f)*1.15f*walk*(1-fall);
        model.leftLeg.xRot=(float)Math.cos(phase*.6662f+(float)Math.PI)*1.15f*walk*(1-fall);
        model.head.zRot=.045f*(float)Math.sin(phase*.3f)*(1-fall);
    }
}
