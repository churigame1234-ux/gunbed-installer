package kr.mzs.gunbedvisual.mixin;
import kr.mzs.gunbedvisual.*;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Avatar;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(AvatarRenderer.class)
public abstract class ZombieAvatarMixin {
    @Inject(method="getTextureLocation(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)Lnet/minecraft/resources/Identifier;",at=@At("HEAD"),cancellable=true)
    private void zombie$texture(AvatarRenderState state,CallbackInfoReturnable<Identifier> ci){if(ZombieVisuals.infected(state.id))ci.setReturnValue(ZombieVisuals.texture(state.id));}
    @Inject(method="extractRenderState(Lnet/minecraft/world/entity/Avatar;Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;F)V",at=@At("TAIL"))
    private void zombie$state(Avatar entity,AvatarRenderState state,float partial,CallbackInfo ci){
        if(ZombieVisuals.infected(state.id)&&!ZombieVisuals.ownCorpse(state.id)){
            state.showHat=false;state.showJacket=false;state.showLeftPants=false;state.showRightPants=false;state.showLeftSleeve=false;state.showRightSleeve=false;state.showCape=false;
            state.parrotOnLeftShoulder=null;state.parrotOnRightShoulder=null;
        }
        if(ZombieVisuals.corpse(state.id)){state.deathTime=0;state.walkAnimationSpeed=0;state.pose=net.minecraft.world.entity.Pose.STANDING;state.xRot=0;state.yRot=0;state.isSpectator=false;}
        if(ZombieVisuals.fade(state.id)){state.isInvisible=true;state.isInvisibleToPlayer=false;}
    }
    @Inject(method="setupRotations(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;FF)V",at=@At("TAIL"))
    private void zombie$fall(AvatarRenderState state,PoseStack pose,float bodyRot,float scale,CallbackInfo ci){
        if(!ZombieVisuals.corpse(state.id))return;
        float progress=ZombieVisuals.deathProgress(state.id);int fall=ZombieVisuals.deathPose(state.id);
        pose.translate(0,.08*progress,0);
        pose.mulPose((fall==1?Axis.ZP:Axis.XP).rotationDegrees((fall==2?-90:90)*progress));
    }
}
