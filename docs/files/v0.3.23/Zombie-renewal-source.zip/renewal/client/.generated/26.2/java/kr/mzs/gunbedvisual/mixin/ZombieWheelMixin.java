package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MouseHandler.class)
public abstract class ZombieWheelMixin {
    @Inject(method="onScroll",at=@At("HEAD"),cancellable=true)
    private void zombie$wheel(long window,double x,double y,CallbackInfo ci){var client=Minecraft.getInstance();if(kr.mzs.gunbedvisual.ZombieMovement.wheelEnabled()&&client.gui.screen()==null&&y!=0){kr.mzs.gunbedvisual.ZombieMovement.wheel();ci.cancel();}}
}
