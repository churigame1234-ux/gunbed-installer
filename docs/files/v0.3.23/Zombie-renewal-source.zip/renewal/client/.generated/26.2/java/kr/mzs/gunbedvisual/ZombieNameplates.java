package kr.mzs.gunbedvisual;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.joml.Quaternionf;
import org.joml.Vector3f;
public final class ZombieNameplates {
    public static void render(GuiGraphicsExtractor graphics){
        var client=Minecraft.getInstance();var p=client.player;
        if(!ZombieMovement.active()||p==null)return;
        var camera=client.gameRenderer.mainCamera();var origin=camera.position();
        var rotation=new Quaternionf(camera.rotation()).conjugate();
        double focal=graphics.guiHeight()/(2*Math.tan(Math.toRadians(client.options.fov().get())/2));
        for(var m:ZombieScene.members.values()){
            if(m.id().equals(p.getUUID())||m.respawning())continue;
            if(!ZombieScene.spectator&&(!ZombieScene.ally(p.getUUID(),m.id())||p.distanceToSqr(m.x(),m.y(),m.z())>2500))continue;
            var entity=client.level.getEntity(m.entityId());
            double x=entity==null?m.x():entity.getX(),y=entity==null?m.y()+2.15:entity.getY()+entity.getBbHeight()+.35,z=entity==null?m.z():entity.getZ();
            Vector3f view=new Vector3f((float)(x-origin.x),(float)(y-origin.y),(float)(z-origin.z)).rotate(rotation);
            if(view.z>=-.1)continue;
            int screenX=(int)(graphics.guiWidth()/2.0+view.x*focal/-view.z),screenY=(int)(graphics.guiHeight()/2.0-view.y*focal/-view.z);
            if(screenX<0||screenX>graphics.guiWidth()||screenY<0||screenY>graphics.guiHeight())continue;
            int color=switch(m.role()){case "host"->0xFFAA0000;case "zombie"->0xFFFF5555;default->0xFF4F86FF;};
            int width=client.font.width(m.name());graphics.fill(screenX-width/2-2,screenY-1,screenX+width/2+2,screenY+9,0x66000000);
            graphics.text(client.font,m.name(),screenX-width/2,screenY,color);
        }
    }
}
