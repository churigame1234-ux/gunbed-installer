package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.client.player.ClientInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(KeyboardInput.class)
public abstract class ZombieJumpInputMixin {
    @Inject(method="tick",at=@At("TAIL"))
    private void zombie$jump(CallbackInfo ci){ClientInput input=(ClientInput)(Object)this;input.keyPresses=kr.mzs.gunbedvisual.ZombieMovement.input(input.keyPresses);}
}
