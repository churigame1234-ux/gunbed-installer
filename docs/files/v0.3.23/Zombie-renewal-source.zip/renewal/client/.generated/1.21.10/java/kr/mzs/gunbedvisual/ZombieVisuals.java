package kr.mzs.gunbedvisual;
import com.google.gson.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import java.util.*;

public final class ZombieVisuals {
    public record Corpse(RemotePlayer entity,UUID source,long began,int pose){}
    private static final Map<Integer,Corpse> corpses=new HashMap<>();
    private static final Map<Integer,Long> swings=new HashMap<>();
    private static final Set<Integer> rightSwings=new HashSet<>();
    public static boolean secondary(int id){return rightSwings.contains(id);}
    private static List<ResourceLocation> textures=List.of();
    private static long nextTextureScan;
    private static int nextId=-870000,performanceTick;
    public static void clear(){for(var corpse:corpses.values())corpse.entity.discard();corpses.clear();swings.clear();textures=List.of();nextTextureScan=0;}
    public static void packet(JsonObject data){
        String event=data.has("event")?data.get("event").getAsString():"";
        if(event.equals("hud")&&data.has("zombieMatch")&&!data.get("zombieMatch").getAsBoolean()){clear();return;}
        if(event.equals("zombieRespawn")){UUID source=UUID.fromString(data.get("uuid").getAsString());for(var entry:List.copyOf(corpses.entrySet()))if(entry.getValue().source.equals(source)){entry.getValue().entity.discard();corpses.remove(entry.getKey());}return;}
        if(event.equals("zombieSwing")){int id=data.get("entityId").getAsInt();swings.put(id,System.nanoTime());if(data.get("secondary").getAsBoolean())rightSwings.add(id);else rightSwings.remove(id);return;}
        if(!event.equals("zombieDeath"))return;
        var client=Minecraft.getInstance();if(client.level==null||!ZombieMovement.active())return;
        UUID source=UUID.fromString(data.get("uuid").getAsString());
        var corpse=new RemotePlayer(client.level,new com.mojang.authlib.GameProfile(UUID.randomUUID(),"Zombie"));
        corpse.setId(nextId--);corpse.setPos(data.get("x").getAsDouble(),data.get("y").getAsDouble(),data.get("z").getAsDouble());
        float yaw=data.get("yaw").getAsFloat();corpse.setYRot(yaw);corpse.setYBodyRot(yaw);corpse.setYHeadRot(yaw);corpse.setNoGravity(true);
        corpse.setSilent(true);corpse.setDeltaMovement(0,0,0);
        var victim=client.level.getEntity(data.get("entityId").getAsInt());if(victim instanceof net.minecraft.world.entity.LivingEntity living)corpse.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD,living.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD).copy());
        client.level.addEntity(corpse);corpses.put(corpse.getId(),new Corpse(corpse,source,System.nanoTime(),data.get("pose").getAsInt()));
    }
    public static void tick(){
        var client=Minecraft.getInstance();
        if(ZombieMovement.active()&&++performanceTick%100==0)GunbedVisualClient.zombiePerformance(client.getFps());
        long now=System.nanoTime();for(var entry:List.copyOf(corpses.entrySet())){
            Corpse c=entry.getValue();if(now-c.began>8_000_000_000L||c.entity.level()!=Minecraft.getInstance().level){c.entity.discard();corpses.remove(entry.getKey());}
            else{c.entity.setDeltaMovement(0,0,0);c.entity.setNoGravity(true);c.entity.setOnGround(true);}
        }
    }
    public static ZombieScene.Member member(int id){for(var member:ZombieScene.members.values())if(member.entityId()==id)return member;return null;}
    private static UUID source(int id){Corpse corpse=corpses.get(id);if(corpse!=null)return corpse.source;var m=member(id);return m==null?null:m.id();}
    public static boolean infected(int id){
        var p=Minecraft.getInstance().player;if(!ZombieMovement.active()||p==null||id==p.getId())return false;
        UUID source=source(id);return source!=null&&(corpses.containsKey(id)||ZombieScene.zombie(source));
    }
    public static boolean corpse(int id){return corpses.containsKey(id);}
    public static float deathProgress(int id){var c=corpses.get(id);if(c==null)return 0;float t=Math.clamp((System.nanoTime()-c.began)/750_000_000f,0,1);return t*t*(3-2*t);}
    public static int deathPose(int id){return corpses.get(id).pose;}
    public static float swing(int id){long at=swings.getOrDefault(id,0L);return Math.clamp((System.nanoTime()-at)/900_000_000f,0,1);}
    public static boolean fade(int id){
        var p=Minecraft.getInstance().player;var m=member(id);
        return ZombieMovement.active()&&ZombieScene.escape&&p!=null&&id!=p.getId()&&m!=null&&!m.respawning()&&ZombieScene.ally(p.getUUID(),m.id())&&p.distanceToSqr(m.x(),m.y(),m.z())<6.25;
    }
    public static ResourceLocation texture(int id){
        var client=Minecraft.getInstance();long now=System.nanoTime();
        if(ownCorpse(id)&&client.player!=null)return client.player.getSkin().body().texturePath();
        if(textures.isEmpty()&&now>=nextTextureScan){nextTextureScan=now+5_000_000_000L;
            textures=client.getResourceManager().listResources("textures/zombie",p->p.getNamespace().equals("mzs_tissou")&&p.getPath().matches(".*/zombie[0-9]+\\.png")).keySet().stream().sorted(Comparator.comparing(Object::toString)).toList();
        }
        UUID source=source(id);if(textures.isEmpty()||source==null)return ResourceLocation.parse("minecraft:textures/entity/zombie/zombie.png");
        return textures.get(Math.floorMod(source.hashCode()+(int)(ZombieScene.appearanceSeed^(ZombieScene.appearanceSeed>>>32)),textures.size()));
    }
    public static boolean ownCorpse(int id){var p=Minecraft.getInstance().player;Corpse corpse=corpses.get(id);return p!=null&&corpse!=null&&corpse.source.equals(p.getUUID());}
}
