package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LivingEntity.class)
public abstract class ZombieTravelMixin {
    @Inject(method="travel",at=@At("HEAD"),cancellable=true)
    private void zombie$travel(Vec3 input,CallbackInfo ci){if((Object)this instanceof LocalPlayer player&&kr.mzs.gunbedvisual.ZombieMovement.travel(player))ci.cancel();}
}
