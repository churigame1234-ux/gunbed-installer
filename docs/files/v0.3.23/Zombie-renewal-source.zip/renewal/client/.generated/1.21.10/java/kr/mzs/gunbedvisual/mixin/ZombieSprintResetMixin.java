package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LocalPlayer.class)
public abstract class ZombieSprintResetMixin {
    @Shadow protected int sprintTriggerTime;
    @Inject(method="aiStep",at=@At("HEAD"))
    private void zombie$resetSprint(CallbackInfo ci){
        boolean toggled=kr.mzs.gunbedvisual.ZombieControls.consumeSprintReset();
        var client=net.minecraft.client.Minecraft.getInstance();
        if(toggled||(kr.mzs.gunbedvisual.ZombieControls.active()&&client.options.keyShift.isDown())){
            sprintTriggerTime=0;
            ((LocalPlayer)(Object)this).setSprinting(false);
        }
    }
}
