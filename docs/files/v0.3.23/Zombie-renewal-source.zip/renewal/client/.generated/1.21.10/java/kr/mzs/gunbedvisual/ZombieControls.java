package kr.mzs.gunbedvisual;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
/** Zombie-only control state; vanilla key bindings and options are never rewritten. */
public final class ZombieControls {
    private static boolean zombie,auto=true,pending,resetSprint;
    private static long received,pendingSince;
    private ZombieControls(){}
    public static boolean active(){return zombie&&received>0&&System.nanoTime()-received<5_000_000_000L;}
    public static void packet(JsonObject data){
        String event=data.has("event")?data.get("event").getAsString():"";
        if(event.equals("hud")){
            boolean next=data.has("zombieServer")&&data.get("zombieServer").getAsBoolean();
            if(!next){clear();return;}
            if(!zombie){
                pending=false;
                // Vanilla sprint reads the held state rather than consumeClick.
                // Discard old presses accumulated on a different backend.
                while(Minecraft.getInstance().options.keySprint.consumeClick()){}
            }
            zombie=true;received=System.nanoTime();
            if(data.has("autoSprint")){
                boolean value=data.get("autoSprint").getAsBoolean();
                if(!pending||value==auto||System.nanoTime()-pendingSince>2_000_000_000L){auto=value;pending=false;}
            }
        }else if(event.equals("zombieSprint")&&active()){
            auto=data.get("enabled").getAsBoolean();pending=false;
        }
    }
    public static void tick(Minecraft client){
        if(client.player==null||!active()){if(zombie)clear();return;}
        // Consume presses, not the held/toggled isDown state: one Ctrl press is
        // one mode change even if the vanilla toggle-sprint option is enabled.
        while(client.options.keySprint.consumeClick())if(client.screen==null){
            auto=!auto;pending=true;pendingSince=System.nanoTime();resetSprint=true;
            GunbedVisualClient.zombieSprint(auto);
        }
    }
    public static boolean sprintKey(Minecraft client){
        return active()&&auto&&client.screen==null&&client.options.keyUp.isDown()
                &&!client.options.keyDown.isDown()&&!client.options.keyShift.isDown();
    }
    public static boolean consumeSprintReset(){boolean result=resetSprint;resetSprint=false;return result;}
    public static void clear(){zombie=false;auto=true;pending=false;received=0;resetSprint=false;}
}
