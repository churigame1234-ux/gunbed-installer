package kr.mzs.gunbedvisual;
import com.google.gson.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import java.util.*;
public final class ZombieResults {
    private static long until;
    private static String title="",subtitle="",score="";
    private static final List<String> rows=new ArrayList<>();
    public static void clear(){until=0;rows.clear();}
    public static boolean active(){return System.nanoTime()<until;}
    public static void packet(JsonObject data){
        if(!data.has("event"))return;
        if(data.get("event").getAsString().equals("zombieResultsClear")){clear();return;}
        if(data.get("event").getAsString().equals("zombieResults")){
            until=System.nanoTime()+12_000_000_000L;title=data.get("title").getAsString();subtitle=data.get("subtitle").getAsString();score="내 처치 + 감염 · "+data.get("score").getAsInt();rows.clear();
            for(JsonElement entry:data.getAsJsonArray("entries")){JsonObject row=entry.getAsJsonObject();rows.add(row.get("name").getAsString()+"  ·  "+row.get("score").getAsInt());}
        }
    }
    public static void render(GuiGraphics g){
        if(System.nanoTime()>=until||!ZombieControls.active()||Minecraft.getInstance().screen!=null)return;
        var font=Minecraft.getInstance().font;int cx=g.guiWidth()/2,cy=g.guiHeight()/2;
        g.fill(cx-124,cy-70,cx+124,cy+52,0xD0111925);g.fill(cx-124,cy-70,cx+124,cy-68,0xFFFFD45A);
        g.pose().pushMatrix();g.pose().scale(2f,2f);
        g.drawString(font,title,(int)(cx/2f-font.width(title)/2f), (int)((cy-55)/2),0xFFFFD45A);g.pose().popMatrix();
        g.drawString(font,subtitle,cx-font.width(subtitle)/2,cy-29,0xFFE4ECF5);
        for(int i=0;i<rows.size();i++){String row=(i+1)+"위  "+rows.get(i);g.drawString(font,row,cx-103,cy-10+i*13,i==0?0xFFFFD45A:i==1?0xFFD9E4EE:0xFFDAA27B);}
        g.drawString(font,score,cx-font.width(score)/2,cy+36,0xFFA5E987);
    }
}
