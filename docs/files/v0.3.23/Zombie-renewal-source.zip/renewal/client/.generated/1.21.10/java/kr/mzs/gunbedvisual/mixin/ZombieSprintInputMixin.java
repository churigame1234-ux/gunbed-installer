package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(KeyboardInput.class)
public abstract class ZombieSprintInputMixin {
    // Keep vanilla double-W, crouching and sprint eligibility checks. Only replace
    // the dedicated sprint-key contribution on the zombie backend.
    @Redirect(method="tick",at=@At(value="INVOKE",target="Lnet/minecraft/client/KeyMapping;isDown()Z"))
    private boolean zombie$sprint(KeyMapping mapping){
        var client=Minecraft.getInstance();
        if(mapping==client.options.keySprint && kr.mzs.gunbedvisual.ZombieControls.active())
            return kr.mzs.gunbedvisual.ZombieControls.sprintKey(client);
        return mapping.isDown();
    }
}
