package kr.mzs.gunbedvisual.mixin;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ClientPacketListener.class)
public abstract class ZombieVelocityMixin {
    @Inject(method="handleSetEntityMotion",at=@At("TAIL"))
    private void zombie$velocity(ClientboundSetEntityMotionPacket packet,CallbackInfo ci){kr.mzs.gunbedvisual.ZombieMovement.velocityPacket(packet.id());}
}
